# ##### BEGIN LICENSE BLOCK #####
#
# This program is licensed under Creative Commons BY-NC-SA:
# https://creativecommons.org/licenses/by-nc-sa/3.0/
#
# Created by Dummiesman, 2016-2020
#
# ##### END LICENSE BLOCK #####

import bpy, bmesh
import struct

from angelstudios_fileeditor.shader_set import (ShaderSet, Shader)
import angelstudios_fileeditor.common_helpers as helper
import angelstudios_fileeditor.binary_helper as bin
from collections import Counter

def is_mat_shadeless(mat):
    for node in mat.node_tree.nodes:
        if node.type == "EMISSION":
            return True
    return False
            def _labeled(mat, label, ntype=None):
    for n in mat.node_tree.nodes:
        if n.label == label and (ntype is None or n.type == ntype):
            return n
    return None
    
def _labeled(mat, label, ntype=None):
    for n in mat.node_tree.nodes:
        if n.label == label and (ntype is None or n.type == ntype):
            return n
    return None
    
def create_shader_from_material(mat, use_roughness_instead_of_specular_one):
    shader = Shader()
    if not mat.use_nodes or mat.node_tree is None:
        return shader
    nodes = mat.node_tree.nodes
    root_node = next((n for n in nodes if n.type in ("BSDF_PRINCIPLED", "EMISSION")), None)
    if root_node is None:
        print("No Principled/Emission node on " + mat.name + "; empty shader.")
        return shader

    base_img = _labeled(mat, "Base Color", "TEX_IMAGE")
    if base_img is None:
        base_img = next((n for n in nodes if n.type == "TEX_IMAGE"
                         and n.image is not None and n.label != "Non-Color matte"), None)
    if base_img is not None and base_img.image is not None:
        shader.name = helper.get_undupe_name(base_img.image.name)

    tint1 = _labeled(mat, "tint1", "MIX_RGB")
    if tint1 is not None:
        c = tint1.inputs["Color2"].default_value
        shader.diffuse_color = [c[0], c[1], c[2], 1.0]
    else:
        key = "Base Color" if root_node.type == "BSDF_PRINCIPLED" else "Color"
        bc = root_node.inputs[key]
        if not bc.links:
            shader.diffuse_color = [bc.default_value[0], bc.default_value[1], bc.default_value[2], 1.0]
    shader.diffuse_color[3] = 1.0     # spatial alpha lives in the matte/flags

    emisc = _labeled(mat, "Emission Color", "MIX_RGB")   # tex * diffuse * EMISSIVE
    if emisc is not None:
        e = emisc.inputs["Color2"].default_value
        shader.emissive_color = [e[0], e[1], e[2], 1.0]
    else:
        shader.emissive_color = [0.0, 0.0, 0.0, 1.0]
    est = _labeled(mat, "emission_state", "VALUE")
    if est is not None and est.outputs[0].default_value < 0.5:
        shader.emissive_color = [0.0, 0.0, 0.0, 1.0]      # switch off -> non-emissive

    rv = _labeled(mat, "roughness", "VALUE")
    raw = rv.outputs[0].default_value if rv is not None else \
          (root_node.inputs["Roughness"].default_value if "Roughness" in root_node.inputs else 0.0)
    if use_roughness_instead_of_specular_one:
        shader.shininess = min(max(1.0 - raw, 0.0), 1.0)
    elif "Specular IOR Level" in root_node.inputs:
        shader.shininess = root_node.inputs["Specular IOR Level"].default_value

    shader.ambient_color = shader.diffuse_color
    return shader
    
def get_used_materials(ob, modifiers):
    """search for used materials at object level"""
    used_materials = []
    checked_material_indices = {}
    
    # create temp mesh
    temp_mesh = None
    if modifiers:
        dg = bpy.context.evaluated_depsgraph_get()
        eval_obj = ob.evaluated_get(dg)
        temp_mesh = eval_obj.to_mesh()
    else:
        temp_mesh = ob.to_mesh()
    
    # get bmesh
    bm = bmesh.new()
    bm.from_mesh(temp_mesh)
    
    # look for used materials
    for f in bm.faces:
      if (not f.material_index in checked_material_indices 
          and f.material_index >= 0 and f.material_index < len(ob.data.materials) 
          and ob.data.materials[f.material_index] is not None):

        material = ob.data.materials[f.material_index]
        if material.cloned_from is not None: # we want the reference to the ORIGINAL
            material = material.cloned_from
        used_materials.append(material)
        checked_material_indices[f.material_index] = True
    
    # finish off
    bm.free()
    
    return used_materials

def create_material_remap(modifiers): # Uses materials on selected objects only
    all_used_mats = []
    
    # Only loop through selected objects instead of the whole scene
    for ob in bpy.context.selected_objects:
        if ob.type != 'MESH':
            continue
        
        used_mats = get_used_materials(ob, modifiers)
        for mat in used_mats:
            if not mat in all_used_mats:
                all_used_mats.append(mat)
     
    material_map = {}
    material_idx = 0
    for mtl in all_used_mats:
        material_map[mtl.name] = material_idx
        material_idx += 1
    return material_map
 
def bounds(obj):
    """get the bounds of an object"""
    local_coords = obj.bound_box[:]
    om = obj.matrix_world
    coords = [p[:] for p in local_coords]

    rotated = zip(*coords[::-1])

    push_axis = []
    for (axis, _list) in zip('xyz', rotated):
        info = lambda: None
        info.max = max(_list)
        info.min = min(_list)
        info.distance = info.max - info.min
        push_axis.append(info)

    import collections

    originals = dict(zip(['x', 'y', 'z'], push_axis))

    o_details = collections.namedtuple('object_details', 'x y z')
    return o_details(**originals)

def write_matrix_standard(object, file):
    bnds = bounds(object)
    file.write(struct.pack('fff', *helper.convert_vecspace_to_game((bnds.x.min * -1, bnds.y.min, bnds.z.min)))) # have to do * -1 for some reason
    file.write(struct.pack('fff', *helper.convert_vecspace_to_game((bnds.x.max * -1, bnds.y.max, bnds.z.max)))) # have to do * -1 for some reason
    file.write(struct.pack('fff', *helper.convert_vecspace_to_game(object.location))) # write this twice. one is pivot and one is origin
    file.write(struct.pack('fff', *helper.convert_vecspace_to_game(object.location)))

def write_matrix(meshname, object, pkg_path):
    """write a *.mtx file"""
    mesh_name_parsed = helper.get_clean_name(helper.get_raw_object_name(meshname))
    mtx_path = pkg_path[:-4] + '_' + mesh_name_parsed + ".mtx"

    mtxfile = open(mtx_path, 'wb')
    
    if helper.is_matrix_object(object):
        bin.write_matrix3x4(mtxfile, object.matrix_world)
    else:
        write_matrix_standard(object, mtxfile)

    mtxfile.close()
    return
    
def prepare_mesh_data(mesh, material_index, tessface):
    """build mesh data for a PKG file"""
    # initialize lists for conversion
    cmtl_tris = []
    cmtl_indices = []
    cmtl_verts = []
    cmtl_uvs = []
    cmtl_cols = []
    
    # build the mesh data we need
    uv_layer = mesh.loops.layers.uv.active
    vc_layer = mesh.loops.layers.color.active
  
    # build tris that are in this material pass
    for lt in tessface:
        if lt[0].face.material_index == material_index:
          cmtl_tris.append(lt)
  
    # convert per face to per vertex indices
    index_remap_table = {}
    for lt in cmtl_tris:
        #funstuff :|
        indices = [-1, -1, -1]
        for x in range(3):
            l = lt[x]
            # prepare our hash entry
            uv_hash = "NOUV"
            col_hash = "NOCOL"
            pos_hash = str(l.vert.co)
            nrm_hash = str(l.vert.normal)
            if uv_layer is not None:
                uv_hash = str(l[uv_layer].uv)
            if vc_layer is not None:
                col_hash = str(l[vc_layer])
            index_hash = uv_hash + "|" + col_hash + "|" + pos_hash + "|" + nrm_hash
  
            # do we already have a vertex for this?
            if index_hash in index_remap_table:
                indices[x] = index_remap_table[index_hash]
            else:
                # get what our next index will be and append to remap table
                next_index = len(cmtl_verts)
                index_remap_table[index_hash] = next_index
                indices[x] = next_index
  
                # add neccessary data to remapping tables
                cmtl_verts.append(l.vert)
  
                if uv_layer is not None:
                    cmtl_uvs.append(l[uv_layer].uv)
                else:
                    cmtl_uvs.append((0,0))
  
                if vc_layer is not None:
                    cmtl_cols.append(l[vc_layer])
                else:
                    cmtl_cols.append((0,0,0,0))
  
        # finally append this triangle                
        cmtl_indices.append(indices)  
    
    # return mesh data :)
    return (cmtl_indices, cmtl_verts, cmtl_uvs, cmtl_cols)
  

def _canon(t):
    """winding-sensitive triangle key: smallest cyclic rotation"""
    a, b, c = t
    return min((a, b, c), (b, c, a), (c, a, b))

def _decode_for_verify(flat):
    """exact mirror of import_helper.convert_triangle_strips + triangle_strip_to_list"""
    tris, strip, cw0 = [], [], False
    for us in flat:
        cw, end, idx = (us & 0x4000) != 0, (us & 0x8000) != 0, us & 0x3FFF
        if not strip:
            cw0 = cw
        strip.append(idx)
        if end:
            clockwise = cw0
            for v in range(len(strip) - 2):
                if clockwise:
                    tris.append((strip[v + 1], strip[v], strip[v + 2]))
                else:
                    tris.append((strip[v], strip[v + 1], strip[v + 2]))
                if not (strip[v] == strip[v + 1] or strip[v] == strip[v + 2] or strip[v + 1] == strip[v + 2]):
                    clockwise = not clockwise
            strip, cw0 = [], False
    return tris

def stripify_section(triangles):
    """
    Greedy stripifier for prepare_mesh_data triangles.

    Two knobs:
      MODE            "per_tri"  -> each tri is its own 3-vertex strip. Confirmed to LOAD in-game for MCSR
                      "strips"   -> greedy strips, FLAG_CW=False, but vanilla crashes.
                      "strips_cw"-> greedy strips, vanilla-style FLAG_CW=True: 0x4000 on the first vertex of every multi-tri strip
      MAX_STRIP_VERTS  0 = unlimited (works, but game kinda freezes on import. Hey, we save space though?)

    Output is always self-verified against the importer's own decode; any mismatch falls back to per-triangle so geometry can never render wrong
    """
    if not triangles:
        return []

    for tri in triangles:
        for v in tri:
            if v > 0x3FFF:
                raise ValueError(
                    "Section vertex index %d exceeds the 14-bit compact limit (16383); "
                    "this section must be split before it can use compact strips." % v)

    MODE = "strips_cw"
    MAX_STRIP_VERTS = 0

    if MODE == "per_tri":
        out = []
        for a, b, c in triangles:
            out += [a & 0x3FFF, b & 0x3FFF, (c & 0x3FFF) | 0x8000]
        return out

    cw = (MODE == "strips_cw")

    edge_map = {}
    for ti, (a, b, c) in enumerate(triangles):
        edge_map.setdefault(frozenset((a, b)), []).append(ti)
        edge_map.setdefault(frozenset((b, c)), []).append(ti)
        edge_map.setdefault(frozenset((c, a)), []).append(ti)
    used = [False] * len(triangles)

    def extend(seed, s0, s1, s2):
        local = {seed}
        strip = [s0, s1, s2]
        while MAX_STRIP_VERTS == 0 or len(strip) < MAX_STRIP_VERTS:
            p2, p1 = strip[-2], strip[-1]
            even = (len(strip) - 2) % 2 == 0
            found = None
            for ti in edge_map.get(frozenset((p2, p1)), ()):
                if used[ti] or ti in local:
                    continue
                tri = triangles[ti]
                rest = [v for v in tri if v != p2 and v != p1]
                if len(rest) != 1:
                    continue
                w = rest[0]
                # FLAG_CW=True flips the parity branches vs FLAG_CW=False
                if cw:
                    decoded = (p1, p2, w) if even else (p2, p1, w)
                else:
                    decoded = (p2, p1, w) if even else (p1, p2, w)
                if _canon(decoded) == _canon(tri):
                    found = (ti, w)
                    break
            if found is None:
                break
            local.add(found[0])
            strip.append(found[1])
        return strip, local

    def seed_orders(a, b, c):
        # In cw mode the first triangle decodes as (s1,s0,s2), so seed [s1,s0,s2].
        for rot in ((a, b, c), (b, c, a), (c, a, b)):
            yield (rot[1], rot[0], rot[2]) if cw else rot

    out = []
    for seed in range(len(triangles)):
        if used[seed]:
            continue
        a, b, c = triangles[seed]
        best = None
        for s0, s1, s2 in seed_orders(a, b, c):
            strip, local = extend(seed, s0, s1, s2)
            if best is None or len(strip) > len(best[0]):
                best = (strip, local)
        strip, local = best
        for ti in local:
            used[ti] = True

        if cw and len(strip) > 3:
            out.append((strip[0] & 0x3FFF) | 0x4000)
            for v in strip[1:-1]:
                out.append(v & 0x3FFF)
            out.append((strip[-1] & 0x3FFF) | 0x8000)
        elif cw:
            # singleton: vanilla leaves these unflagged, natural winding
            out += [strip[1] & 0x3FFF, strip[0] & 0x3FFF, (strip[2] & 0x3FFF) | 0x8000]
        else:
            for i, v in enumerate(strip):
                out.append((v & 0x3FFF) | (0x8000 if i == len(strip) - 1 else 0))

    # permanent safety net: decode our output through the importer's algorithm
    if Counter(_canon(t) for t in _decode_for_verify(out)) != Counter(_canon(t) for t in triangles):
        print("stripify: fallback fired (winding mismatch): emitting per-triangle")
        out = []
        for a, b, c in triangles:
            out += [a & 0x3FFF, b & 0x3FFF, (c & 0x3FFF) | 0x8000]
    return out