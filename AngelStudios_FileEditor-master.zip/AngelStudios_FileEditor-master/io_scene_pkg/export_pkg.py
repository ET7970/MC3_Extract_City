# ##### BEGIN LICENSE BLOCK #####
#
# This program is licensed under Creative Commons BY-NC-SA:
# https://creativecommons.org/licenses/by-nc-sa/3.0/
#
# Created by Dummiesman, 2016-2020
#
# ##### END LICENSE BLOCK #####

import bpy, bmesh
import os, time, struct, math
from functools import cmp_to_key
from mathutils import Vector

import os.path as path

from angelstudios_fileeditor.fvf import FVF

import angelstudios_fileeditor.binary_helper as bin
import angelstudios_fileeditor.export_helper as export_helper
import angelstudios_fileeditor.common_helpers as helper

from angelstudios_fileeditor.shader_set import (ShaderSet, Shader)

# globals
global pkg_path
pkg_path = None

global material_remap_table
material_remap_table = {}


######################################################
# GLOBAL LISTS
######################################################

# AI/Player Vehicle
vehicle_list = ["BODY_H", "BODY_M", "BODY_L", "BODY_VL",
                "SHADOW_H", "SHADOW_M", "SHADOW_L", "SHADOW_VL",
                "HLIGHT_H", "HLIGHT_M", "HLIGHT_L", "HLIGHT_VL",
                "TLIGHT_H", "TLIGHT_M", "TLIGHT_L", "TLIGHT_VL",
                "RLIGHT_H", "RLIGHT_M", "RLIGHT_L", "RLIGHT_VL",
                "SLIGHT0_H", "SLIGHT0_M", "SLIGHT0_L", "SLIGHT0_VL",
                "SLIGHT1_H", "SLIGHT1_M", "SLIGHT1_L", "SLIGHT1_VL",
                "BLIGHT_H", "BLIGHT_M", "BLIGHT_L", "BLIGHT_VL",
                "BODYDAMAGE_H", "BODYDAMAGE_M", "BODYDAMAGE_L", "BODYDAMAGE_VL",
                "SIREN0_H", "SIREN0_M", "SIREN0_L", "SIREN0_VL",
                "SIREN1_H", "SIREN1_M", "SIREN1_L", "SIREN1_VL",
                "DECAL_H", "DECAL_M", "DECAL_L", "DECAL_VL",
                "DRIVER_H", "DRIVER_M", "DRIVER_L", "DRIVER_VL",
                "SHOCK0_H", "SHOCK0_M", "SHOCK0_L", "SHOCK0_VL",
                "SHOCK1_H", "SHOCK1_M", "SHOCK1_L", "SHOCK1_VL",
                "SHOCK2_H", "SHOCK2_M", "SHOCK2_L", "SHOCK2_VL",
                "SHOCK3_H", "SHOCK3_M", "SHOCK3_L", "SHOCK3_VL",
                "ARM0_H", "ARM0_M", "ARM0_L", "ARM0_VL",
                "ARM1_H", "ARM1_M", "ARM1_L", "ARM1_VL",
                "ARM2_H", "ARM2_M", "ARM2_L", "ARM2_VL",
                "ARM3_H", "ARM3_M", "ARM3_L", "ARM3_VL",
                "SHAFT2_H", "SHAFT2_M", "SHAFT2_L", "SHAFT2_VL",
                "SHAFT3_H", "SHAFT3_M", "SHAFT3_L", "SHAFT3_VL",
                "AXLE0_H", "AXLE0_M", "AXLE0_L", "AXLE0_VL",
                "AXLE1_H", "AXLE1_M", "AXLE1_L", "AXLE1_VL",
                "ENGINE_H", "ENGINE_M", "ENGINE_L", "ENGINE_VL",
                "WHL0_H", "WHL0_M", "WHL0_L", "WHL0_VL",
                "WHL1_H", "WHL1_M", "WHL1_L", "WHL1_VL",
                "WHL2_H", "WHL2_M", "WHL2_L", "WHL2_VL",
                "WHL3_H", "WHL3_M", "WHL3_L", "WHL3_VL",
                "BREAK0_H", "BREAK0_M", "BREAK0_L", "BREAK0_VL",
                "BREAK1_H", "BREAK1_M", "BREAK1_L", "BREAK1_VL",
                "BREAK2_H", "BREAK2_M", "BREAK2_L", "BREAK2_VL",
                "BREAK3_H", "BREAK3_M", "BREAK3_L", "BREAK3_VL",
                "BREAK01_H", "BREAK01_M", "BREAK01_L", "BREAK01_VL",
                "BREAK12_H", "BREAK12_M", "BREAK12_L", "BREAK12_VL",
                "BREAK23_H", "BREAK23_M", "BREAK23_L", "BREAK23_VL",
                "BREAK03_H", "BREAK03_M", "BREAK03_L", "BREAK03_VL",
                "HUB0_H", "HUB0_M", "HUB0_L", "HUB0_VL",
                "HUB1_H", "HUB1_M", "HUB1_L", "HUB1_VL",
                "HUB2_H", "HUB2_M", "HUB2_L", "HUB2_VL",
                "HUB3_H", "HUB3_M", "HUB3_L", "HUB3_VL",
                "TRAILER_HITCH_H", "TRAILER_HITCH_M", "TRAILER_HITCH_L", "TRAILER_HITCH_VL",
                "SRN0_H", "SRN0_M", "SRN0_L", "SRN0_VL",
                "SRN1_H", "SRN1_M", "SRN1_L", "SRN1_VL",
                "SRN2_H", "SRN2_M", "SRN2_L", "SRN2_VL",
                "SRN3_H", "SRN3_M", "SRN3_L", "SRN3_VL",
                "HEADLIGHT0_H", "HEADLIGHT0_M", "HEADLIGHT0_L", "HEADLIGHT0_VL",
                "HEADLIGHT1_H", "HEADLIGHT1_M", "HEADLIGHT1_L", "HEADLIGHT1_VL",
                "FNDR0_H", "FNDR0_M", "FNDR0_L", "FNDR0_VL",
                "FNDR1_H", "FNDR1_M", "FNDR1_L", "FNDR1_VL",
                "WHL4_H", "WHL4_M", "WHL4_L", "WHL4_VL",
                "WHL5_H", "WHL5_M", "WHL5_L", "WHL5_VL",
                "PLIGHTON_H", "PLIGHTON_M", "PLIGHTON_L", "PLIGHTON_VL",
                "PLIGHTOFF_H", "PLIGHTOFF_M", "PLIGHTOFF_L", "PLIGHTOFF_VL",
                "SWHL0_H", "SWHL0_M", "SWHL0_L", "SWHL0_VL",
                "SWHL1_H", "SWHL1_M", "SWHL1_L", "SWHL1_VL",
                "SWHL2_H", "SWHL2_M", "SWHL2_L", "SWHL2_VL",
                "SWHL3_H", "SWHL3_M", "SWHL3_L", "SWHL3_VL",
                "SWHL4_H", "SWHL4_M", "SWHL4_L", "SWHL4_VL",
                "SWHL5_H", "SWHL5_M", "SWHL5_L", "SWHL5_VL"]

# Vehicle dashboards
dash_list = ["DAMAGE_NEEDLE_H", "DAMAGE_NEEDLE_M", "DAMAGE_NEEDLE_L", "DAMAGE_NEEDLE_VL",
             "DASH_H", "DASH_M", "DASH_L", "DASH_VL",
             "GEAR_INDICATOR_H", "GEAR_INDICATOR_M", "GEAR_INDICATOR_L", "GEAR_INDICATOR_VL",
             "ROOF_H", "ROOF_M", "ROOF_L", "ROOF_VL",
             "SPEED_NEEDLE_H", "SPEED_NEEDLE_M", "SPEED_NEEDLE_L", "SPEED_NEEDLE_VL",
             "TACH_NEEDLE_H", "TACH_NEEDLE_M", "TACH_NEEDLE_L", "TACH_NEEDLE_VL",
             "WHEEL_H", "WHEEL_M", "WHEEL_L", "WHEEL_VL", 
             "DASH_EXTRA_H", "DASH_EXTRA_M", "DASH_EXTRA_L", "DASH_EXTRA_VL"]

# Vehicle trailers
trailer_list = ["TRAILER_H", "TRAILER_M", "TRAILER_L", "TRAILER_VL",
                "SHADOW_H", "SHADOW_M", "SHADOW_L", "SHADOW_VL",
                "TLIGHT_H", "TLIGHT_M", "TLIGHT_L", "TLIGHT_VL",
                "TWHL0_H", "TWHL0_M", "TWHL0_L", "TWHL0_VL",
                "TWHL1_H", "TWHL1_M", "TWHL1_L", "TWHL1_VL",
                "TWHL2_H", "TWHL2_M", "TWHL2_L", "TWHL2_VL",
                "TWHL3_H", "TWHL3_M", "TWHL3_L", "TWHL3_VL",
                "TRAILER_HITCH_H", "TRAILER_HITCH_M", "TRAILER_HITCH_L", "TRAILER_HITCH_VL",
                "RLIGHT_H", "RLIGHT_M", "RLIGHT_L", "RLIGHT_VL",
                "BLIGHT_H", "BLIGHT_M", "BLIGHT_L", "BLIGHT_VL",
                "HLIGHT_H", "HLIGHT_M", "HLIGHT_L", "HLIGHT_VL",
                "SLIGHT0_H", "SLIGHT0_M", "SLIGHT0_L", "SLIGHT0_VL",
                "SLIGHT1_H", "SLIGHT1_M", "SLIGHT1_L", "SLIGHT1_VL",
                "SIREN0_H", "SIREN0_M", "SIREN0_L", "SIREN0_VL",
                "SIREN1_H", "SIREN1_M", "SIREN1_L", "SIREN1_VL",
                "TWHL4_H", "TWHL4_M", "TWHL4_L", "TWHL4_VL",
                "TWHL5_H", "TWHL5_M", "TWHL5_L", "TWHL5_VL"]

# Props, buildings, etc
generic_list = ["H", "M", "L", "VL",
                "BREAK01_H", "BREAK01_M", "BREAK01_L", "BREAK01_VL",
                "BREAK02_H", "BREAK02_M", "BREAK02_L", "BREAK02_VL",
                "BREAK03_H", "BREAK03_M", "BREAK03_L", "BREAK03_VL",
                "BREAK04_H", "BREAK04_M", "BREAK04_L", "BREAK04_VL",
                "BREAK05_H", "BREAK05_M", "BREAK05_L", "BREAK05_VL",
                "BREAK06_H", "BREAK06_M", "BREAK06_L", "BREAK06_VL",
                "BREAK07_H", "BREAK07_M", "BREAK07_L", "BREAK07_VL",
                "BREAK08_H", "BREAK08_M", "BREAK08_L", "BREAK08_VL",
                "BREAK09_H", "BREAK09_M", "BREAK09_L", "BREAK09_VL",
                "REDGLOWDAY_H", "REDGLOWDAY_M", "REDGLOWDAY_L", "REDGLOWDAY_VL",
                "YELLOWGLOWDAY_H", "YELLOWGLOWDAY_M", "YELLOWGLOWDAY_L", "YELLOWGLOWDAY_VL",
                "GREENGLOWDAY_H", "GREENGLOWDAY_M", "GREENGLOWDAY_L", "GREENGLOWDAY_VL",
                "WALK_DAY_H", "WALK_DAY_M", "WALK_DAY_L", "WALK_DAY_VL",
                "NOWALK_DAY_H", "NOWALK_DAY_M", "NOWALK_DAY_L", "NOWALK_DAY_VL",
                "REDGLOWNIGHT_H", "REDGLOWNIGHT_M", "REDGLOWNIGHT_L", "REDGLOWNIGHT_VL",
                "YELLOWGLOWNIGHT_H", "YELLOWGLOWNIGHT_M", "YELLOWGLOWNIGHT_L", "YELLOWGLOWNIGHT_VL",
                "GREENGLOWNIGHT_H", "GREENGLOWNIGHT_M", "GREENGLOWNIGHT_L", "GREENGLOWNIGHT_VL",
                "WALK_NIGHT_H", "WALK_NIGHT_M", "WALK_NIGHT_L", "WALK_NIGHT_VL",
                "NOWALK_NIGHT_H", "NOWALK_NIGHT_M", "NOWALK_NIGHT_L", "NOWALK_NIGHT_VL"]

# Do not export list
dne_list = ["BOUND", "BINARY_BOUND",
            "EXHAUST0_H", "EXHAUST0_M", "EXHAUST0_L", "EXHAUST0_VL",
            "EXHAUST1_H", "EXHAUST1_M", "EXHAUST1_L", "EXHAUST1_VL"]

# Misc MTX objects are objects that aren't part of PKG, but 
# related/essential enough that we load them in for user editing.
misc_mtx_objects = ["EXHAUST0", "EXHAUST1"]#, "HLIGHT_L", "HLIGHT0_L", "HLIGHT1_L"] --HLIGHTs not used in MCSR, custom code for frontend lights (2X)


def unknown_objects_comparison(item1, item2):
    name1 = helper.get_raw_object_name(item1.name)
    name2 = helper.get_raw_object_name(item2.name)
    lod1 = helper.get_object_lod_name(item1.name)
    lod2 = helper.get_object_lod_name(item2.name)
    sortkey_a = name1 + "_" + helper.get_alphabetical_lod_id(lod1)
    sortkey_b = name2 + "_" + helper.get_alphabetical_lod_id(lod2)
    
    if sortkey_a < sortkey_b:
        return -1
    else:
        return 1

def reorder_objects(lst, pred):
    return_list = [None] * len(pred)
    append_list = []
    for v in lst:
        clean_upper_name = helper.get_clean_name(v.name).upper() #removes any .001 from filenames to make things easier for users :)
        try:
            # found in list, add in it's proper order
            return_list[pred.index(clean_upper_name)] = v
        except:
            # not found in predicate list, add on to the end
            append_list.append(v)
    return [x for x in return_list if x is not None] + sorted(append_list, key=cmp_to_key(unknown_objects_comparison))


######################################################
# EXPORT MAIN FILES
######################################################
def export_xrefs(file, selected_only):
    # build list of xrefs to export
    xref_objects = []
    for obj in bpy.context.scene.objects:
        if obj.name.lower().startswith("xref:"):
            if (selected_only and obj in bpy.context.selected_objects) or not selected_only:
                xref_objects.append(obj)

    # export xrefs
    if len(xref_objects) > 0:
        bin.write_file_header(file, "xrefs")
        num_xrefs = 0
        xref_num_offset = file.tell()
        file.write(struct.pack('L', 0))
        for obj in xref_objects:
            num_xrefs += 1
            #write matrix
            bin.write_matrix3x4(file, obj.matrix_basis)
           
            # write xref name
            xref_name = helper.get_undupe_name(obj.name[5:]) + "\x00max"
            null_length = 32 - len(xref_name)
            
            file.write(bytes(xref_name, 'utf-8'))
            file.write(bytes('\x00' * null_length, 'utf-8'))
                
        file_length = file.tell() - xref_num_offset
        file.seek(xref_num_offset - 4, 0)
        file.write(struct.pack('LL', file_length, num_xrefs))
        file.seek(0, 2)

def export_offset(file):
    bin.write_file_header(file, "offset", 12)
    file.write(struct.pack('fff', 0, 0, 0))

def export_shaders(file, context, type="byte", use_roughness_instead_of_specular_one=True):
    scene = context.scene
    num_variants = 1
    
    # write file header and record offset
    bin.write_file_header(file, "shaders")
    shaders_data_offset = file.tell()
    
    # prepare shaders header
    shadertype_raw = num_variants
    if type == "byte":
        shadertype_raw += 128
    shaders_per_paintjob = len(material_remap_table)
    
    # write header
    file.write(struct.pack('LL', shadertype_raw, shaders_per_paintjob))
    
    # write material sets
    ordered_material_remap = sorted(material_remap_table.items(), key=lambda x: x[1])
    
    # write out the default materials using the material remap
    for material_kvp in ordered_material_remap:
        material_id = material_kvp[0]
        material = bpy.data.materials[material_id]
        
        # create a shader for it, and write it
        shader = export_helper.create_shader_from_material(material, use_roughness_instead_of_specular_one)
        shader.write(file, type)

    # write file length
    shaders_file_length = file.tell() - shaders_data_offset
    file.seek(shaders_data_offset - 4)
    file.write(struct.pack('L', shaders_file_length))
    file.seek(0, 2)

def export_geometry(file, meshlist, options, export_headlights, export_origin_placement):
    collected_hlight_planes = [] #gets the headlight planes ready
    for obj in meshlist:
        
        clean_name = helper.get_clean_name(obj.name).upper()
        if "HLIGHT" in clean_name or "HEADLIGHT" in clean_name:
            if export_headlights is True:
                # Extract planes and add them to our master list
                extracted_planes = extract_hlight_planes(obj)
                collected_hlight_planes.extend(extracted_planes)
            continue #doesn't add hlight to the mesh (regardless of state), only adds it to mtx exporter (for MCSR!)
        if "BOUND" in clean_name:
            continue #don't add "bound" to pkg file, since it is only used for .bbnd

        # write FILE header for mesh name
        bin.write_file_header(file, helper.get_undupe_name(obj.name))
        file_data_start_offset = file.tell()
        
        # don't multiply vertices for objects requring a matrix3x4 export
        premultiply_vertices = not helper.is_matrix_object(obj)
        
        # create temp mesh
        temp_mesh = None
        if "MODIFIERS" in options:
            dg = bpy.context.evaluated_depsgraph_get()
            eval_obj = obj.evaluated_get(dg)
            temp_mesh = eval_obj.to_mesh()
        else:
            temp_mesh = obj.to_mesh()
            
        # REVERSE dgBangerData Offset, if applicable
        # Look for the custom property on the object, invert translation
        if export_origin_placement != 'NONE' and "dgbanger_cg" in obj:
            cg_blender = helper.convert_vecspace_to_blender(obj["dgbanger_cg"])
            temp_mesh.transform(Matrix.Translation(Vector(cg_blender) * -1))

        bm = bmesh.new()
        bm.from_mesh(temp_mesh)
        bm_tris = bm.calc_loop_triangles()
        
        # get mesh infos
        export_mats = export_helper.get_used_materials(obj, "MODIFIERS" in options)
        export_mat_names = {m.name for m in export_mats if m is not None}
        
        total_verts = len(bm.verts)
        total_faces = int(len(bm_tris) * 3)
        num_sections = len(export_mats)
        
        # debug
        print("Exporting object "  + str(obj.name) + ". total_verts=" + str(total_verts) + ", total_faces=" + str(total_faces) +", num_sections=" + str(num_sections))
        
        #build FVF
        FVF_FLAGS = FVF(("D3DFVF_XYZ", "D3DFVF_NORMAL", "D3DFVF_TEX1"))
        for mat in obj.data.materials:
            if mat is not None and export_helper.is_mat_shadeless(mat):
                # undo the previous flag since we arent
                # going to write normals
                FVF_FLAGS.clear_flag("D3DFVF_NORMAL")
                break
        if "VC_DIFFUSE" in options:
            FVF_FLAGS.set_flag("D3DFVF_DIFFUSE")
        if "VC_SPECULAR" in options:
            FVF_FLAGS.set_flag("D3DFVF_SPECULAR")

        # do we need a matrix file? Only for H object
        obj_offcenter = abs(obj.location[0]) > 0.001 or abs(obj.location[1]) > 0.001 or abs(obj.location[2]) > 0.001
        if obj_offcenter and helper.get_clean_name(obj.name).upper().endswith("_H"): #obj_offcenter and 
           export_helper.write_matrix(obj.name, obj, pkg_path)

        #mesh data header: num_verts_tot / num_indices_tot backpatched after sections
        header_offset = file.tell()
        file.write(struct.pack('LLLLL', num_sections, 0, 0, num_sections, FVF_FLAGS.value))

        written_verts_tot = 0
        written_indices_tot = 0

        cur_material_index = -1
        for material in obj.data.materials:
            real_material = material
            if material is not None and getattr(material, "cloned_from", None) is not None:
                real_material = material.cloned_from
            cur_material_index += 1
            if real_material is None or real_material.name not in export_mat_names:
                continue

            cmtl_indices, cmtl_verts, cmtl_uvs, cmtl_cols = export_helper.prepare_mesh_data(bm, cur_material_index, bm_tris)

            # compact section header: HHH, and section flag bit 8 = compact
            num_strips = 1
            section_flags = (1 << 8)
            shader_offset = material_remap_table[real_material.name]
            file.write(struct.pack('HHH', num_strips, section_flags, shader_offset))

            strip_primType = 4                      # 4 = triangle strip
            strip_vertices = len(cmtl_verts)
            file.write(struct.pack('HH', strip_primType, strip_vertices))

            for cv in range(len(cmtl_verts)):
                export_vert = cmtl_verts[cv]
                export_vert_location = ((obj.matrix_world @ export_vert.co) - obj.location) if premultiply_vertices else export_vert.co
                bin.write_float3(file, helper.convert_vecspace_to_game(export_vert_location))
                if FVF_FLAGS.has_flag("D3DFVF_NORMAL"):
                    bin.write_cfloat3(file, helper.convert_vecspace_to_game(export_vert.normal))
                if FVF_FLAGS.has_flag("D3DFVF_DIFFUSE"):
                    bin.write_color4d(file, cmtl_cols[cv])
                if FVF_FLAGS.has_flag("D3DFVF_SPECULAR"):
                    bin.write_color4d(file, cmtl_cols[cv])
                uv_data = cmtl_uvs[cv]
                bin.write_cfloat2(file, (uv_data[0], (uv_data[1] - 1) * -1))

            strip_index_data = export_helper.stripify_section(cmtl_indices)
            file.write(struct.pack('H', len(strip_index_data)))
            file.write(struct.pack('<%dH' % len(strip_index_data), *strip_index_data))

            written_verts_tot += strip_vertices
            written_indices_tot += len(strip_index_data)

        # backpatch the two totals now that sections are written
        end_offset = file.tell()
        file.seek(header_offset + 4)
        file.write(struct.pack('LL', written_verts_tot, written_indices_tot))
        file.seek(end_offset)

        # clean up bmesh
        bm.free()
		
        # write FILE length
        file_data_length = file.tell() - file_data_start_offset
        file.seek(file_data_start_offset - 4)
        file.write(struct.pack('L', file_data_length))
        file.seek(0, 2)

    if len(collected_hlight_planes) > 0: #adds hlight planes to export list (change from midtown madness)
        export_hlight_mtx(collected_hlight_planes, pkg_path)

def export_hlight_mtx(planes, pkg_path):
    """Takes a list of gathered planes and exports up to 2 GLOW .mtx files."""
    if not planes:
        return

    # Limit to exactly 2 planes max
    if len(planes) > 2:
        print(f"Notice: Found {len(planes)} HLIGHT quads across all objects. Limiting export to 2.")
        planes = planes[:2]

    # Stabilize order (Left vs Right by X coordinate)
    planes.sort(key=lambda verts: sum(v.x for v in verts) / len(verts))

    # Strip the .pkg extension off pkg_path to get the base userGivenFilename
    base_name = os.path.splitext(pkg_path)[0]

    for i, verts in enumerate(planes):
        # Convert to game space (X, Z, Y)
        game_corners = [Vector(helper.convert_vecspace_to_game(v)) for v in verts]

        min_x = min(c.x for c in game_corners)
        max_x = max(c.x for c in game_corners)
        min_y = min(c.y for c in game_corners)
        max_y = max(c.y for c in game_corners)
        min_z = min(c.z for c in game_corners)
        max_z = max(c.z for c in game_corners)

        center_x = (max_x + min_x) / 2.0
        center_y = (max_y + min_y) / 2.0
        center_z = (max_z + min_z) / 2.0

        float_data = struct.pack('<9f',
            min_x, min_y, min_z,
            max_x, max_y, max_z,
            center_x, center_y, center_z
        )

        padding_data = b'\x01\x00\x80\x7F' * 3

        output_path = f"{base_name}_HLIGHTGLOW{i}.mtx"

        with open(output_path, 'wb') as f:
            f.write(float_data)
            f.write(padding_data)

        print(f"Exported custom HLIGHT file: {output_path}")

def extract_hlight_planes(obj):
    """Converts an HLIGHT object to quads and returns a list of its planes in world space."""
    planes = []
    temp_mesh = obj.to_mesh()
    temp_bm = bmesh.new()
    temp_bm.from_mesh(temp_mesh)

    # Convert triangles to quads
    bmesh.ops.join_triangles(
        temp_bm, 
        faces=list(temp_bm.faces), 
        angle_face_threshold=math.pi, 
        angle_shape_threshold=math.pi,
        cmp_seam=False, cmp_sharp=False, cmp_uvs=False, cmp_vcols=False, cmp_materials=False
    )

    # Extract quads
    for f in temp_bm.faces:
        if len(f.verts) == 4:
            world_verts = [obj.matrix_world @ v.co for v in f.verts]
            planes.append(world_verts)

    temp_bm.free()
    obj.to_mesh_clear()
    
    return planes

def export_misc_mtx():
    for mtx in misc_mtx_objects:
        ob = bpy.data.objects.get(mtx)
        if ob is not None:
            export_helper.write_matrix(ob.name, ob, pkg_path)
    
######################################################
# EXPORT
######################################################
def save_pkg(filepath,
             e_vertexcolors,
             e_vertexcolors_s,
             apply_modifiers,
             selection_only,
             export_bbnd_file,
             use_roughness_instead_of_specular_one,
             export_headlights,
             export_origin_placement,
             context):
    global pkg_path
    pkg_path = filepath

    selection_only = True #override. Best usage anyway

    print("exporting PKG: %r..." % (filepath))
    
    time1 = time.perf_counter()
    file = open(filepath, 'wb')
    
    # create our options list
    export_options = []
    if e_vertexcolors:
        export_options.append("VC_DIFFUSE")
    if e_vertexcolors_s:
        export_options.append("VC_SPECULAR")
    if apply_modifiers:
        export_options.append("MODIFIERS")
        
    # what are we exporting?
    export_objects = None
    if selection_only:
      export_objects = bpy.context.selected_objects
    else:
      export_objects = bpy.context.scene.objects
    
    # first we need to figure out the export type before anything
    export_pred = generic_list
    export_typestr = 'generic'
    export_shadertype = 'byte'
    for obj in export_objects:
        if obj.type == 'MESH':
            obj_name = obj.name.upper()
            if obj_name.startswith("DASH_"):
                export_shadertype = 'float'
                export_typestr = 'dash'
                export_pred = dash_list
                break
            if obj_name.startswith("BODY_"):
                export_typestr = 'vehicle'
                export_pred = vehicle_list
                break
            if obj_name.startswith("TRAILER_") and not obj_name.startswith("TRAILER_HITCH"):
                export_typestr = 'trailer'
                export_pred = trailer_list
                break

    print('\tPKG autodetected export type: ' + export_typestr)
    
    #prepped mat list
    global material_remap_table
    material_remap_table = export_helper.create_material_remap(apply_modifiers)
    
    #prepped geo list
    export_geomlist = []
    for obj in export_objects:
        clean_upper_name = helper.get_clean_name(obj.name).upper()
        if (obj.type == 'MESH' and not obj.name.upper() in dne_list):
            export_geomlist.append(obj)

    #variants = paintjobs
    #if export_typestr == 'dash':
    #  if not "|" in paintjobs or not "," in paintjobs or not paintjobs.strip():
    #    variants = '"R",N|"R",one|"R",two|"R",three|"R",four|"R",five|"R",six'
    
    # begin write pkg file
    file.write(bytes('PKG3', 'utf-8'))
    print('\t[%.4f] exporting mesh data' % (time.perf_counter() - time1))
    export_geometry(file, reorder_objects(export_geomlist, export_pred), export_options, export_headlights, export_origin_placement)
    print('\t[%.4f] exporting shaders' % (time.perf_counter() - time1))
    export_shaders(file, context, export_shadertype, use_roughness_instead_of_specular_one)
    print('\t[%.4f] exporting xrefs' % (time.perf_counter() - time1))
    export_xrefs(file, selection_only)
    print('\t[%.4f] exporting offset' % (time.perf_counter() - time1))
    export_offset(file)
    print('\t[%.4f] exporting misc mtx' % (time.perf_counter() - time1))
    export_misc_mtx()
    # end write pkg file
    print(" done in %.4f sec." % (time.perf_counter() - time1))
    file.close()


def save(operator,
         context,
         filepath="",
         e_vertexcolors=False,
         e_vertexcolors_s=False,
         apply_modifiers=False,
         selection_only=True,
         export_bbnd_file=True,
         use_roughness_instead_of_specular_one=True,
         export_headlights=True,
         origin_placement="SKIP_UNRELATED",
         ):
    
    # save PKG
    save_pkg(filepath,
             e_vertexcolors,
             e_vertexcolors_s,
             apply_modifiers,
             selection_only,
             export_bbnd_file,
             use_roughness_instead_of_specular_one,
             export_headlights,
             origin_placement,
             context,
             )

    return {'FINISHED'}
