 # ##### BEGIN LICENSE BLOCK #####
#
# This program is licensed under Creative Commons BY-NC-SA:
# https://creativecommons.org/licenses/by-nc-sa/3.0/
#
# Created by Dummiesman, 2016-2020
#
# ##### END LICENSE BLOCK #####

import bpy, mathutils

from bpy.types import (Panel,
                       Menu,
                       Operator,
                       PropertyGroup,
                       UIList
                       )
                       
from bpy.props import (IntProperty,
                       BoolProperty,
                       StringProperty,
                       CollectionProperty,
                       PointerProperty)


TINT_PREFIX = "tint"                  # tint1, tint2... "tints" are color variants for traffic (and player vehicles in MM2)
TINT_NODE_VERTICAL_SPACING = 180.0

FRAME_TEXTURES_POS  = (-1080.0,  200.0)   # base color image
FRAME_COLORS_POS    = (-574.0,   418.0)   # tint1..N, emission color, roughness
FRAME_CONTROL_POS   = (-360.0,  -160.0)   # gates/math (NOT the state group)
PRINCIPLED_BSDF_POS = (-60.0,    160.0)   # 
MATERIAL_OUTPUT_POS = (250.0,    160.0)   # +250 right of BSDF area
MASK_IMAGE_OFFSET   = (0.0,     -520.0)   # mask sits this far below base image

GATE_GROUP_NAME = "Functionality Nodes DONT TOUCH"
GATE_GROUP_POS  = (-360.0, -160.0)

UV_WRAP_GROUP_NAME = "UV Wrapping DONT TOUCH"

def _build_uv_wrap_group():
    """
    Shared group giving PER-AXIS repeat/extend (Blender's Image Texture node has only one extension setting, so wrapping is done on the UVs instead).
    Inputs : Vector, Repeat X, Repeat Y   (Repeat = 1.0 -> tile/repeat, 0.0 -> clamp/extend)
    Output : Vector
    Per axis: extend = clamp(u,0,1) ; repeat = wrap(u,1,0) (tile) ; the Repeat value linearly selects between them, so users can flip either axis live.
    """
    existing = bpy.data.node_groups.get(UV_WRAP_GROUP_NAME)
    if existing is not None:
        return existing
    ng = bpy.data.node_groups.new(UV_WRAP_GROUP_NAME, 'ShaderNodeTree')
    I = ng.interface
    I.new_socket("Vector",   in_out='INPUT',  socket_type="NodeSocketVector")
    I.new_socket("Repeat X", in_out='INPUT',  socket_type="NodeSocketFloat")
    I.new_socket("Repeat Y", in_out='INPUT',  socket_type="NodeSocketFloat")
    I.new_socket("Vector",   in_out='OUTPUT', socket_type="NodeSocketVector")

    gin  = ng.nodes.new('NodeGroupInput');  gin.location  = (-900, 0)
    gout = ng.nodes.new('NodeGroupOutput'); gout.location = (620, 0)
    L = ng.links.new

    sep = ng.nodes.new('ShaderNodeSeparateXYZ'); sep.location = (-700, 0)
    L(gin.outputs["Vector"], sep.inputs[0])

    def m(op, x, y, clamp=False):
        n = ng.nodes.new('ShaderNodeMath'); n.operation = op; n.location = (x, y)
        n.use_clamp = clamp
        return n

    def axis(comp_out, repeat_socket, y):
        ext = m('ADD', -500, y, clamp=True)   # extend = clamp to [0,1]
        ext.inputs[1].default_value = 0.0
        L(comp_out, ext.inputs[0])
        rep = m('WRAP', -500, y - 170)        # repeat = tile into [0,1)
        rep.inputs[1].default_value = 1.0     # Max
        rep.inputs[2].default_value = 0.0     # Min
        L(comp_out, rep.inputs[0])
        # linear select: extend + (repeat - extend) * Repeat
        d  = m('SUBTRACT', -320, y - 85); L(rep.outputs[0], d.inputs[0]);  L(ext.outputs[0], d.inputs[1])
        dm = m('MULTIPLY', -150, y - 85); L(d.outputs[0], dm.inputs[0]);   L(repeat_socket, dm.inputs[1])
        res = m('ADD',       20, y - 85); L(ext.outputs[0], res.inputs[0]); L(dm.outputs[0], res.inputs[1])
        return res.outputs[0]

    x_out = axis(sep.outputs['X'], gin.outputs["Repeat X"],  260)
    y_out = axis(sep.outputs['Y'], gin.outputs["Repeat Y"], -140)

    comb = ng.nodes.new('ShaderNodeCombineXYZ'); comb.location = (280, 0)
    L(x_out, comb.inputs['X'])
    L(y_out, comb.inputs['Y'])
    L(comb.outputs['Vector'], gout.inputs["Vector"])
    return ng

# Which side of the matte carries the paint/tint. This is only a variable for isCarColorable
TINT_ON_MASK_BLACK = True

def _build_gate_group():
    """
    Per-material group holding the math/mix "architecture" for a matte material: base-colour selection, alpha, emission and reflection. 
    The only colour node that lives OUTSIDE is tint1 (the base x diffuse swatch); its result arrives here as "Tinted Color".

    Inputs : Base Color, Tinted Color, Mask, Emission In, Roughness In, alpha_state, emission_state, refl_state
    Outputs: Base Color Out, Alpha, Emission Out, Roughness Out

    Conventions (mask value 1.0 = white):
        base : picks Tinted vs raw Base Color by the matte (see TINT_ON_MASK_BLACK).
        alpha: switch off -> 1 (opaque);  on -> Mask  (so paint = mask BLACK
               goes transparent when alpha is on).
        emis : Emission In * Mask * emission_state * (1-refl). Switch off -> 0.
               Feed Mask=1 when there is no matte so emission still shows.
        refl : Roughness In * (off ->1 ; on -> Mask).
    """
    ng = bpy.data.node_groups.new(GATE_GROUP_NAME, 'ShaderNodeTree')
    I = ng.interface
    for s, t in (("Base Color","NodeSocketColor"),("Tinted Color","NodeSocketColor"),
                 ("Mask","NodeSocketFloat"),
                 ("Emission In","NodeSocketColor"),("Roughness In","NodeSocketFloat"),
                 ("alpha_state","NodeSocketFloat"),("emission_state","NodeSocketFloat"),
                 ("refl_state","NodeSocketFloat")):
        I.new_socket(s, in_out='INPUT', socket_type=t)
    for s, t in (("Base Color Out","NodeSocketColor"),("Alpha","NodeSocketFloat"),
                 ("Emission Out","NodeSocketColor"),("Roughness Out","NodeSocketFloat")):
        I.new_socket(s, in_out='OUTPUT', socket_type=t)

    gin  = ng.nodes.new('NodeGroupInput');  gin.location  = (-1040, 0)
    gout = ng.nodes.new('NodeGroupOutput'); gout.location = (760, 0)
    L = ng.links.new

    def m(op, x, y, a=None, b=None):
        n = ng.nodes.new('ShaderNodeMath'); n.operation = op; n.location = (x, y)
        if a is not None: n.inputs[0].default_value = a
        if b is not None: n.inputs[1].default_value = b
        return n
    def mix(blend, x, y, fac=1.0):
        n = ng.nodes.new('ShaderNodeMixRGB'); n.blend_type = blend; n.location = (x, y)
        n.inputs['Fac'].default_value = fac
        return n

    notrefl = m('SUBTRACT', -820, 300, a=1.0); L(gin.outputs["refl_state"], notrefl.inputs[1])  # 1 - refl
    inv_mask = m('SUBTRACT', -820, -300, a=1.0); L(gin.outputs["Mask"], inv_mask.inputs[1])       # 1 - Mask

    # BASE COLOUR: pick tinted vs raw by the matte 
    bmix = mix('MIX', -300, -60, fac=1.0)
    L(gin.outputs["Mask"], bmix.inputs['Fac'])
    if TINT_ON_MASK_BLACK:
        L(gin.outputs["Tinted Color"], bmix.inputs['Color1'])   # Fac 0 (black) -> tinted paint
        L(gin.outputs["Base Color"],   bmix.inputs['Color2'])   # Fac 1 (white) -> raw texture
    else:
        L(gin.outputs["Base Color"],   bmix.inputs['Color1'])
        L(gin.outputs["Tinted Color"], bmix.inputs['Color2'])
    L(bmix.outputs['Color'], gout.inputs["Base Color Out"])

    # ALPHA (off -> 1, on -> Mask)
    a_eff = m('MULTIPLY', -620, 300); L(gin.outputs["alpha_state"], a_eff.inputs[0]); L(notrefl.outputs[0], a_eff.inputs[1])
    a_mul = m('MULTIPLY', -430, 300); L(a_eff.outputs[0], a_mul.inputs[0]); L(inv_mask.outputs[0], a_mul.inputs[1])
    a_res = m('SUBTRACT', -240, 300, a=1.0); L(a_mul.outputs[0], a_res.inputs[1])   # 1 - a_eff*(1-Mask)
    L(a_res.outputs[0], gout.inputs["Alpha"])

    # EMISSION (off -> 0)  Emission In * Mask * emission_state * (1-refl)-
    e_f1 = m('MULTIPLY', -620, 120); L(gin.outputs["emission_state"], e_f1.inputs[0]); L(notrefl.outputs[0], e_f1.inputs[1])
    e_f2 = m('MULTIPLY', -430, 120); L(e_f1.outputs[0], e_f2.inputs[0]); L(gin.outputs["Mask"], e_f2.inputs[1])
    e_mix = mix('MIX', -240, 120, fac=0.0)
    e_mix.inputs['Color1'].default_value = (0.0, 0.0, 0.0, 1.0)    # switch off / masked-out -> black
    L(e_f2.outputs[0], e_mix.inputs['Fac']); L(gin.outputs["Emission In"], e_mix.inputs['Color2'])
    L(e_mix.outputs['Color'], gout.inputs["Emission Out"])

    # ROUGHNESS (off -> Rough, on -> Rough*Mask)
    r_mul = m('MULTIPLY', -430, -300); L(gin.outputs["refl_state"], r_mul.inputs[0]); L(inv_mask.outputs[0], r_mul.inputs[1])
    r_res = m('SUBTRACT', -240, -300, a=1.0); L(r_mul.outputs[0], r_res.inputs[1])   # 1 - refl*(1-Mask)
    r_out = m('MULTIPLY', -60, -300); L(r_res.outputs[0], r_out.inputs[0]); L(gin.outputs["Roughness In"], r_out.inputs[1])
    L(r_out.outputs[0], gout.inputs["Roughness Out"])
    return ng

def validate_material_for_setup(material):
    """Validates safety for generating material nodes"""
    if material is None: return False
    
    nodes = material.node_tree.nodes
    bsdfs = [n for n in nodes if n.type == 'BSDF_PRINCIPLED']
    
    if len(bsdfs) > 1: return False
    
    if len(bsdfs) == 1:
        has_incoming = any(len(inp.links) > 0 for inp in bsdfs[0].inputs)
        if has_incoming: return False
        
    return True

def build_angel_material_nodes(mtl, image=None, mask_image=None,
        diffuse_color=(1.0, 1.0, 1.0, 1.0), emissive_color=(0.0, 0.0, 0.0, 1.0), shininess=0.0,
        use_roughness_instead=True, is_substituted_tex=False, use_alpha_hash=True,
        setup_type='AUTO', connect_to_bsdf=True,
        sw_emission=None, sw_reflection=None, sw_transparency=None,
        is_colorable=False, tint_colors=None, uv_clip=None, colorable_transparent=None):

    mtl.use_nodes = True
    mtl.use_backface_culling = True
    tree = mtl.node_tree
    nodes, links = tree.nodes, tree.links

    def seed(explicit, key):
        if explicit is not None: return bool(explicit)
        if image is not None:
            try: return bool(image[key])
            except Exception: pass
        return False
    def _tex_bool(key, default=False):
        if image is None: return default
        try: return bool(image[key])
        except Exception: return default
    # Emission is driven by the .pkg emissive_color (below) OR a real emission matte (tex bit2 on a texture that actually has a matte: see tex_file).
    # An explicit override (MASK / EMISSION_MASK) still wins over everything.
    _emis_forced = (sw_emission is True)          # e.g. mask_H geometry -> MASK mode
    sw_emission     = seed(sw_emission,     'tex_emission')
    sw_reflection   = seed(sw_reflection,   'tex_reflection')
    sw_transparency = seed(sw_transparency, 'tex_transparency')
    if setup_type == 'EMISSION_MASK': sw_emission = True; _emis_forced = True
    if setup_type == 'ALPHA_MASK':    sw_transparency = True
    if image is not None:
        try: is_colorable = is_colorable or bool(image['tex_colorable'])
        except Exception: pass
    # The .pkg emissive_color only lights up NON-colorable materials. Car paint and colorable decals carry an emissive tint in their shader that must NOT make them glow.
    # Basically, isCarColorable setting overrides any emission.
    # (vp_decal_mitsuclassc_stripes) has a non-black emissive byte but is definitely non-emissive. This gate is trigged by NOT is_colorable.
    if (not is_colorable) and sum(emissive_color[:3]) > 0.001:
        sw_emission = True
    # The engine does not glow car-colorable paint, even when the .tex carries an emission bit or the shader an emissive tint 
    # Force Suppress it on true is_colorable
    # BUT NEVER override an explicit emission mode: mask_H building geometry must still emit even if its .tex bit1 reads as "colorable" on non-car geometry.
    if is_colorable and not _emis_forced:
        sw_emission = False
    #Need to include override for MM shadows here to purposefully interpret them as alpha
    if is_colorable and colorable_transparent is not None:
        sw_transparency = bool(colorable_transparent)
    if sw_reflection:            # refl uses the mask as roughness; it can't also alpha/emission-mask. Sets as false for both
        sw_transparency = False
        sw_emission = False
    if setup_type in ('COLOR', 'BASIC'):
        # No matte on a solid-colour / plain-textured material
        # EMISSION is still allowed, coming from .pkg's shader's emissive_color
        sw_reflection = sw_transparency = False
    
    bsdf = nodes.get("Principled BSDF")
    if not bsdf:
        bsdf = nodes.new("ShaderNodeBsdfPrincipled"); bsdf.name = "Principled BSDF"
    out = next((n for n in nodes if n.type == 'OUTPUT_MATERIAL'), None) or nodes.new("ShaderNodeOutputMaterial")
    links.new(bsdf.outputs[0], out.inputs[0])
    bsdf.location = PRINCIPLED_BSDF_POS
    out.location  = MATERIAL_OUTPUT_POS

    emission_key = "Emission Color" if "Emission Color" in bsdf.inputs else "Emission"
    specular_key = "Specular IOR Level" if "Specular IOR Level" in bsdf.inputs else "Specular"
    base_roughness = min(max(1.0 - shininess, 0.0), 1.0) if use_roughness_instead else 0.0

    bsdf.inputs['Base Color'].default_value = diffuse_color
    bsdf.inputs[emission_key].default_value = emissive_color
    bsdf.inputs['Roughness'].default_value = base_roughness
    bsdf.inputs[specular_key].default_value = 0.5 if use_roughness_instead else shininess
    mtl_alpha = diffuse_color[3]
    mtl.diffuse_color = diffuse_color
    mtl.metallic = shininess

    if setup_type == 'COLOR' or (setup_type == 'AUTO' and image is None):
        bsdf.inputs['Alpha'].default_value = mtl_alpha
        if mtl_alpha < 1:
            mtl.blend_method = 'HASHED' if use_alpha_hash else 'BLEND'
        # A solid-colour material still glows if its shader carries a non-black emissive
        if (not is_colorable) and sum(emissive_color[:3]) > 0.001:
            glow = (diffuse_color[0] * emissive_color[0],
                    diffuse_color[1] * emissive_color[1],
                    diffuse_color[2] * emissive_color[2], 1.0)
            bsdf.inputs[emission_key].default_value = glow
            if 'Emission Strength' in bsdf.inputs:
                bsdf.inputs['Emission Strength'].default_value = 1.0
        else:
            bsdf.inputs[emission_key].default_value = (0.0, 0.0, 0.0, 1.0)
            if 'Emission Strength' in bsdf.inputs:
                bsdf.inputs['Emission Strength'].default_value = 0.0
        return

    wants_mask = (mask_image is not None) or sw_emission or sw_transparency or sw_reflection \
                 or setup_type in ('ALPHA_MASK', 'EMISSION_MASK')

    def frame(label, color):
        f = nodes.new('NodeFrame'); f.label = label
        f.use_custom_color = True; f.color = color
        return f
    fr_tex  = frame("Textures", (0.18, 0.22, 0.30))
    fr_col  = frame("Colors",   (0.22, 0.28, 0.20))
    fr_ctrl = frame("Control",  (0.30, 0.20, 0.22)) if wants_mask else None

    tx, ty = FRAME_TEXTURES_POS
    tex = nodes.new('ShaderNodeTexImage'); tex.label = "Base Color"; tex.parent = fr_tex
    tex.location = (tx, ty)
    if image:
        tex.image = image
        if is_substituted_tex: tex.interpolation = "Closest"

    # Per-axis wrap is its OWN per-texture setting, NOT the colorable flag.
    # bit0 = extend-X, bit17 = extend-Y. 
    # MCSR supports (Blender language here) "extend OR repeat" for each axis of an image texture, so we build node handling here

    if uv_clip is not None:                       # explicit override (both axes)
        ext_x = ext_y = bool(uv_clip)
    else:
        ext_x = _tex_bool('tex_extend_x', False)
        ext_y = _tex_bool('tex_extend_y', False)

    uv_wrap_socket = None
    if image is not None:
        tex.extension = 'EXTEND'                  # UVs are pre-wrapped into [0,1]
        texcoord = nodes.new('ShaderNodeTexCoord'); texcoord.label = "UV Source"
        texcoord.parent = fr_tex; texcoord.location = (tx - 620, ty - 75)
        rep_x = nodes.new('ShaderNodeValue'); rep_x.label = "repeat_tex_x"   # 1=repeat, 0=extend
        rep_x.outputs[0].default_value = 0.0 if ext_x else 1.0
        rep_x.parent = fr_tex; rep_x.location = (tx - 620, ty - 300)
        rep_y = nodes.new('ShaderNodeValue'); rep_y.label = "repeat_tex_y"
        rep_y.outputs[0].default_value = 0.0 if ext_y else 1.0
        rep_y.parent = fr_tex; rep_y.location = (tx - 620, ty - 400)
        uvw = nodes.new('ShaderNodeGroup'); uvw.node_tree = _build_uv_wrap_group()
        uvw.label = "UV Wrap"; uvw.parent = fr_tex; uvw.location = (tx - 400, ty - 200)
        links.new(texcoord.outputs['UV'], uvw.inputs['Vector'])
        links.new(rep_x.outputs[0],       uvw.inputs['Repeat X'])
        links.new(rep_y.outputs[0],       uvw.inputs['Repeat Y'])
        links.new(uvw.outputs['Vector'],  tex.inputs['Vector'])
        uv_wrap_socket = uvw.outputs['Vector']

    mask = None
    mask_socket = None       # what feeds the group's "Mask" input
    if wants_mask:
        if mask_image is not None:
            mask = nodes.new('ShaderNodeTexImage'); mask.label = "Non-Color matte"; mask.parent = fr_tex
            mask.location = (tx + MASK_IMAGE_OFFSET[0], ty + MASK_IMAGE_OFFSET[1])
            mask.image = mask_image
            try: mask.image.colorspace_settings.name = 'Non-Color'
            except Exception: pass
            mask.extension = 'EXTEND'             # matte shares the base's wrapped UVs
            if uv_wrap_socket is not None:
                links.new(uv_wrap_socket, mask.inputs['Vector'])
            mask_socket = mask.outputs['Color']
        else:
            # No matte (e.g. a purely-emissive texture). Feed Mask = 1 so alpha / emission behave and the switches still work.
            mask_one = nodes.new('ShaderNodeValue'); mask_one.label = "mask_one"
            mask_one.outputs[0].default_value = 1.0
            mask_one.parent = fr_tex
            mask_one.location = (tx + MASK_IMAGE_OFFSET[0], ty + MASK_IMAGE_OFFSET[1])
            mask_socket = mask_one.outputs[0]

    # tint1 = the diffuse tint swatch (Color2 = diffuse; the tint-stack helpers read/write Color2). Its OUTPUT depends on whether the material is colorable:
    #   colorable     -> FLAT diffuse (Color1 = white). It must NOT be multiplied by the CLIPped texture, or it would go black outside the image bounds. The flat colour fills the whole plane and the matte carves out the textured (white) region.
    #   non-colorable -> texture * diffuse (Color1 = texture), the usual tinted texture used as the base colour everywhere.
    cx, cy = FRAME_COLORS_POS
    tint1 = nodes.new('ShaderNodeMixRGB'); tint1.blend_type = 'MULTIPLY'
    tint1.inputs['Fac'].default_value = 1.0
    tint1.inputs['Color1'].default_value = (1.0, 1.0, 1.0, 1.0)
    tint1.inputs['Color2'].default_value = diffuse_color
    tint1.label = "tint1"; tint1.parent = fr_col; tint1.location = (cx, cy)
    if not is_colorable:
        links.new(tex.outputs['Color'], tint1.inputs['Color1'])

    # Emission = texture * diffuse * emissive. Both colours matter.
    # Kept as two nodes so export can read diffuse (tint1.Color2) and emissive (Emission Color.Color2) back out independently, and helps round-tripping a file
    emis = nodes.new('ShaderNodeMixRGB'); emis.blend_type = 'MULTIPLY'
    emis.inputs['Fac'].default_value = 1.0
    emis.inputs['Color2'].default_value = diffuse_color
    emis.label = "Emission Tint"; emis.parent = fr_col; emis.location = (cx, cy - 240)
    links.new(tex.outputs['Color'], emis.inputs['Color1'])

    emis2 = nodes.new('ShaderNodeMixRGB'); emis2.blend_type = 'MULTIPLY'
    emis2.inputs['Fac'].default_value = 1.0
    # A black emissive_color would multiply the glow to nothing. Some emissive materials (e.g. mask_H windows m_xcorp_win*) glow via the game's emission matte and store black here
    # Black might be a 'default' to indicate white, so for shaders that have the emissive flag but are black, apply white here!
    # The 4th emissive byte looks like a per-window emission DENSITY for MASK_ geometry. Unsure though, requires testing
    _em_black = sum(emissive_color[:3]) <= 0.001
    emis2.inputs['Color2'].default_value = (1.0, 1.0, 1.0, 1.0) if (sw_emission and _em_black) else emissive_color
    try: mtl['emissive_raw'] = [float(c) for c in emissive_color]
    except Exception: pass
    emis2.label = "Emission Color"; emis2.parent = fr_col; emis2.location = (cx + 250, cy - 300)
    links.new(emis.outputs['Color'], emis2.inputs['Color1'])

    rough_val = nodes.new('ShaderNodeValue'); rough_val.label = "roughness"
    rough_val.outputs[0].default_value = base_roughness
    rough_val.parent = fr_col; rough_val.location = (cx, cy - 420)

    if connect_to_bsdf and 'Emission Strength' in bsdf.inputs:
        bsdf.inputs['Emission Strength'].default_value = 1.0

    if wants_mask and connect_to_bsdf:
        # Matte / stateful material: everything runs through the gate group. Only the user-facing switches stay OUTSIDE the group.
        fx, fy = FRAME_CONTROL_POS
        def state_node(label, on, dy):
            v = nodes.new('ShaderNodeValue'); v.label = label
            v.outputs[0].default_value = 1.0 if on else 0.0
            v.parent = fr_ctrl; v.location = (fx - 260, fy + dy)
            return v
        n_alpha = state_node("alpha_state",    sw_transparency,   0)
        n_emis  = state_node("emission_state", sw_emission,    -140)
        n_refl  = state_node("refl_state",     sw_reflection,  -280)

        gate = nodes.new('ShaderNodeGroup'); gate.node_tree = _build_gate_group()
        gate.label = GATE_GROUP_NAME; gate.parent = fr_ctrl; gate.location = GATE_GROUP_POS
        if is_colorable:
            # matte WHITE -> raw texture; matte BLACK / outside bounds -> flat tint.
            links.new(tex.outputs['Color'],   gate.inputs["Base Color"])
            links.new(tint1.outputs['Color'], gate.inputs["Tinted Color"])
        else:
            # base colour is the tinted texture everywhere (the matte drives only alpha / emission / reflection, not the base colour).
            links.new(tint1.outputs['Color'], gate.inputs["Base Color"])
            links.new(tint1.outputs['Color'], gate.inputs["Tinted Color"])
        links.new(mask_socket,            gate.inputs["Mask"])
        links.new(emis2.outputs['Color'],  gate.inputs["Emission In"])
        links.new(rough_val.outputs[0],   gate.inputs["Roughness In"])
        links.new(n_alpha.outputs[0],     gate.inputs["alpha_state"])
        links.new(n_emis.outputs[0],      gate.inputs["emission_state"])
        links.new(n_refl.outputs[0],      gate.inputs["refl_state"])
        links.new(gate.outputs["Base Color Out"], bsdf.inputs['Base Color'])
        links.new(gate.outputs["Alpha"],          bsdf.inputs['Alpha'])
        links.new(gate.outputs["Emission Out"],   bsdf.inputs[emission_key])
        links.new(gate.outputs["Roughness Out"],  bsdf.inputs['Roughness'])
    elif connect_to_bsdf:
        # BASIC material (no matte, no switches): plain texture * tint.
        if is_colorable:            # colorable but no matte -> tint1 must still see the texture
            links.new(tex.outputs['Color'], tint1.inputs['Color1'])
        links.new(tint1.outputs['Color'], bsdf.inputs['Base Color'])
        # A BASIC material has no matte and no switches. It can be emissive if the emissive bytes allow
        if sw_emission:
            links.new(emis2.outputs['Color'],  bsdf.inputs[emission_key])
        links.new(rough_val.outputs[0],   bsdf.inputs['Roughness'])
        bsdf.inputs['Alpha'].default_value = mtl_alpha

    if tint_colors and len(tint_colors) > 1:
        apply_tint_stack(mtl, [list(c) for c in tint_colors])

    tex_depth = image.depth if image else 0
    if mtl_alpha < 1 or tex_depth == 32 or sw_transparency:
        mtl.blend_method = 'HASHED' if use_alpha_hash else 'BLEND'

    if setup_type in ('COLOR', 'BASIC'): #removes orphan nodes :(
        for n in list(nodes):
            if n.type == 'VALUE' and n.label in ('alpha_state', 'emission_state', 'refl_state'):
                nodes.remove(n)
            elif n.type == 'GROUP' and n.node_tree and n.node_tree.name == GATE_GROUP_NAME:
                nodes.remove(n)

def get_base_tint_node(mtl):
    """The connected MULTIPLY mix driving Base Color. Accepts the old
       'Diffuse Color' label or the new 'tint1' label."""
    nodes = mtl.node_tree.nodes
    return (next((n for n in nodes if n.label == "tint1"), None)
            or next((n for n in nodes if n.label == "Diffuse Color"), None))

def apply_tint_stack(mtl, colors):
    """
    colors: ordered list of RGBA (linear). colors[0] -> tint1 (the connected base);
    the rest become MULTIPLY nodes stacked ABOVE it, each with Color1 fed by the same
    texture as tint1 so every variant shows a live texture x colour preview.
    Only tint1's output drives the BSDF.
    """
    if not colors:
        return
    tree = mtl.node_tree
    nodes, links = tree.nodes, tree.links

    base = get_base_tint_node(mtl)
    if base is None:
        base = nodes.new('ShaderNodeMixRGB')
        base.blend_type = 'MULTIPLY'
        base.inputs['Fac'].default_value = 1.0
        base.inputs['Color1'].default_value = (1.0, 1.0, 1.0, 1.0)
        base.location = mathutils.Vector(PRINCIPLED_BSDF_POS)
        bsdf = nodes.get("Principled BSDF")
        if bsdf:
            links.new(base.outputs['Color'], bsdf.inputs['Base Color'])

    base.label = "tint1"
    base.hide = False
    base.inputs['Color2'].default_value = tuple(colors[0])
    bx, by = base.location.x, base.location.y

    # texture (or other source) feeding tint1's Color1, reused for every tint node
    src_socket = None
    if base.inputs['Color1'].links:
        src_socket = base.inputs['Color1'].links[0].from_socket

    for n in [n for n in nodes
              if n.label.startswith(TINT_PREFIX) and n.label != "tint1"]:
        nodes.remove(n)

    for i in range(1, len(colors)):
        t = nodes.new('ShaderNodeMixRGB')
        t.blend_type = 'MULTIPLY'
        t.inputs['Fac'].default_value = 1.0
        t.inputs['Color1'].default_value = (1.0, 1.0, 1.0, 1.0)
        t.inputs['Color2'].default_value = tuple(colors[i])
        t.label = "%s%d" % (TINT_PREFIX, i + 1)
        if base.parent is not None:
            t.parent = base.parent
        t.hide = False
        t.location = mathutils.Vector((bx, by + TINT_NODE_VERTICAL_SPACING * i))
        if src_socket is not None:
            links.new(src_socket, t.inputs['Color1'])

def material_signature(mtl):
    if mtl is None or not mtl.use_nodes:
        return (mtl.name if mtl else None,)
    nodes = mtl.node_tree.nodes

    def img(label):
        n = next((n for n in nodes if n.type == 'TEX_IMAGE' and n.label == label and n.image), None)
        return n.image.name if n else None
    def val(label):
        n = next((n for n in nodes if n.type == 'VALUE' and n.label == label), None)
        return round(n.outputs[0].default_value, 4) if n else 0.0
    def col(label):
        n = next((n for n in nodes if n.label == label and 'Color2' in getattr(n, 'inputs', {})), None)
        return tuple(round(c, 4) for c in n.inputs['Color2'].default_value) if n else None

    tints = extract_tint_colors(mtl)
    tint_key = tuple(tuple(round(c, 4) for c in t) for t in tints) if tints else col("tint1")
    bsdf = nodes.get("Principled BSDF")
    rough = round(bsdf.inputs['Roughness'].default_value, 4) if bsdf else 0.0

    return (img("Base Color"), img("Non-Color matte"), tint_key, col("Emission Color"), rough,
            val("alpha_state"), val("emission_state"), val("refl_state"))

def extract_tint_colors(mtl):
    """Ordered [rgba_linear, ...] for tint1..tintN, or None for a plain
       single-colour material (only tint1 / no tint nodes)."""
    if mtl is None or not mtl.use_nodes:
        return None
    found = {}
    for n in mtl.node_tree.nodes:
        lbl = n.label
        if lbl.startswith(TINT_PREFIX) and lbl[len(TINT_PREFIX):].isdigit():
            found[int(lbl[len(TINT_PREFIX):])] = n
    if len(found) <= 1:
        return None
    return [list(found[i].inputs['Color2'].default_value) for i in sorted(found)]

class CreateColorMaterial(Operator):
    """ Forces the active material to be a single Color, regardless of current nodes """
    bl_idname = "angel.create_mat_color"
    bl_label = "Make Single Color Material"
    bl_options = {'REGISTER', 'UNDO', 'INTERNAL'}
    
    def execute(self, context):
        mat = context.active_object.active_material
        if mat:
            # Overrides the validate check, wipes existing nodes, and sets up a clean BSDF
            mat.node_tree.nodes.clear()
            build_angel_material_nodes(mat, setup_type='COLOR', connect_to_bsdf=True)
        return {'FINISHED'}

class CreateBasicMaterial(Operator):
    """ Create a .tex material with no masking """
    bl_idname = "angel.create_mat_basic"
    bl_label = "Make Basic Tex Material"
    bl_options = {'REGISTER', 'UNDO', 'INTERNAL'}
    
    def execute(self, context):
        mat = context.active_object.active_material
        if not validate_material_for_setup(mat):
            self.report({'ERROR'}, "Cannot create nodes! The Principled BSDF has connected node networks.")
            return {'CANCELLED'}
            
        build_angel_material_nodes(mat, setup_type='BASIC', connect_to_bsdf=True)
        return {'FINISHED'}

class CreateMattedEmission(Operator):
    """ Create a .tex material with an emission mask """
    bl_idname = "angel.create_mat_emissionmask"
    bl_label = "Make Emission Matted Material"
    bl_options = {'REGISTER', 'UNDO', 'INTERNAL'}
    
    def execute(self, context):
        mat = context.active_object.active_material
        if not validate_material_for_setup(mat):
            self.report({'ERROR'}, "Cannot create nodes! The Principled BSDF has connected node networks.")
            return {'CANCELLED'}
            
        build_angel_material_nodes(mat, setup_type='EMISSION_MASK', connect_to_bsdf=True)
        return {'FINISHED'}

class CreateMattedAlpha(Operator):
    """ Create a .tex material with an alpha mask """
    bl_idname = "angel.create_mat_alphamask"
    bl_label = "Make Alpha Matted Material"
    bl_options = {'REGISTER', 'UNDO', 'INTERNAL'}
    
    def execute(self, context):
        mat = context.active_object.active_material
        if not validate_material_for_setup(mat):
            self.report({'ERROR'}, "Cannot create nodes! The Principled BSDF has connected node networks.")
            return {'CANCELLED'}
            
        build_angel_material_nodes(mat, setup_type='ALPHA_MASK', connect_to_bsdf=True)
        return {'FINISHED'}

class CreateMulticolorMaterial(Operator):
    """ Build a va_* multicolour material: Basic tex material + 8 stacked tint colours """
    bl_idname = "angel.create_mat_multicolor"
    bl_label = "Make va_* multicolor material"
    bl_options = {'REGISTER', 'UNDO', 'INTERNAL'}

    def execute(self, context):
        mat = context.active_object.active_material
        if not validate_material_for_setup(mat):
            self.report({'ERROR'}, "Cannot create nodes! The Principled BSDF has connected node networks.")
            return {'CANCELLED'}
        build_angel_material_nodes(mat, setup_type='BASIC', connect_to_bsdf=True,
                                   tint_colors=[[1.0, 1.0, 1.0, 1.0] for _ in range(8)])
        return {'FINISHED'}

class ANGEL_PT_MaterialHelperPanel(bpy.types.Panel):
    bl_label = "Angel Tools: Quick Setup"	
    bl_idname = "OBJECT_PT_material_helper_panel"	
    bl_space_type = "PROPERTIES"   	
    bl_region_type = "WINDOW"	
    bl_context = "material"	
    bl_category = "Angel Tools" 

    @classmethod	
    def poll(self,context):
        ob = context.active_object
        mat = ob.active_material
        return mat is not None
        
    def draw(self, context):
        layout = self.layout
        layout.operator("angel.create_mat_color")
        layout.separator()
        layout.operator("angel.create_mat_basic")
        layout.operator("angel.create_mat_alphamask")
        layout.operator("angel.create_mat_emissionmask")
        layout.operator("angel.create_mat_multicolor")

classes = (	
    CreateColorMaterial,
    CreateBasicMaterial,
    CreateMattedEmission,
    CreateMattedAlpha,
    CreateMulticolorMaterial,
    ANGEL_PT_MaterialHelperPanel
)	

def register():        	
    from bpy.utils import register_class	
    for cls in classes:	
        register_class(cls)	

def unregister():	
    from bpy.utils import unregister_class	
    for cls in reversed(classes):	
        unregister_class(cls)	

