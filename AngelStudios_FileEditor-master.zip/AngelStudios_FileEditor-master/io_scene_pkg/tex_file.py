# ##### BEGIN LICENSE BLOCK #####
#
# This program is licensed under Creative Commons BY-NC-SA:
# https://creativecommons.org/licenses/by-nc-sa/3.0/
#
# Created by Dummiesman, 2016-2020 (2026 edit by Planet Xtreme for MCSR Opacity flags in 2026)
#
# ##### END LICENSE BLOCK #####

from enum import IntEnum
import struct
import bpy

# These flip the ACTUAL stored image pixels at import time (so exporting the image to a PNG via Blender's own tools comes out the right way round).
#
# import_pkg reads these SAME two constants and flips the UVs on the matching axes. Because the image AND the UVs move together, the on-model display is INVARIANT to these flags, and they are safe to change.
#
#   FLIP_TEXTURE_X : mirror left<->right      FLIP_TEXTURE_Y : mirror top<->bottom
FLIP_TEXTURE_X = False
FLIP_TEXTURE_Y = True

class TEXType(IntEnum):
    P8 = 1
    P8A8 = 2
    A1R5G5B5 = 6
    PA8 = 14
    P4 = 15
    PA4 = 16
    RGB888 = 17
    RGB8888 = 18
    
class TEXFile:
    def to_blender_image(self, name='tex_image', pack=True):
        has_alpha = self.has_alpha_channel()

        im = bpy.data.images.new(name=name, width=self.width, height=self.height, alpha=has_alpha)
        im['tex_emission']     = self.is_emission_mask()   # provisional; refined below
        im['tex_reflection']   = self.is_reflection_mask()
        im['tex_transparency'] = self.has_transparency()
        im['tex_colorable']    = self.is_colorable()       # bit1 (car-colorable)
        im['tex_alpha_matte']  = self.has_transparency()   # bit4 == a GENUINE alpha matte (might be wrong?)
        im['tex_extend_x']     = self.extend_x()           # bit0  -> extend/repeat horizontally (and carries alpha matte state?)
        im['tex_extend_y']     = self.extend_y()           # bit17 -> extend/repeat vertically

        im_mask = None
        mask_pixels = None
        if has_alpha:
            im_mask = bpy.data.images.new(name=name + "_mask", width=self.width, height=self.height, alpha=False)
            mask_pixels = list(im_mask.pixels)          # <-- materializes the mask buffer

        pixels = list(im.pixels)                        # <-- materializes the base buffer
        max_alpha = 0.0
        min_alpha = 1.0
        n_low = 0                                       # pixels that are ~transparent

        for y in range(self.height):
            for x in range(self.width):
                # Destination pixel in the Blender buffer (row 0 = bottom).
                # FLIP_TEXTURE_Y=False keeps the classic top-down -> upright map
                # (height-1-y); True stores it un-flipped (y). FLIP_TEXTURE_X
                # mirrors columns. base + mask share b, so both flip together.
                dst_col = (self.width  - 1 - x) if FLIP_TEXTURE_X else x
                dst_row = y if FLIP_TEXTURE_Y else (self.height - 1 - y)
                b = 4 * ((dst_row * self.width) + dst_col)
                pc = self.get_pixel(x, y)

                pixels[b]   = pc[0]
                pixels[b+1] = pc[1]
                pixels[b+2] = pc[2]
                pixels[b+3] = 1.0                       # base ALWAYS opaque; matte lives in mask

                if has_alpha:
                    a = pc[3]
                    mask_pixels[b] = a
                    mask_pixels[b+1] = a
                    mask_pixels[b+2] = a
                    mask_pixels[b+3] = 1.0
                    if a > max_alpha:
                        max_alpha = a
                    if a < min_alpha:
                        min_alpha = a
                    if a < 0.05:
                        n_low += 1

        if has_alpha and max_alpha == 0.0:
            print(f"[{name}] mask fully transparent; forcing opaque.")
            for i in range(0, len(mask_pixels), 4):
                mask_pixels[i] = mask_pixels[i+1] = mask_pixels[i+2] = 1.0

        # Content-aware transparency. bit4 (via has_transparency) is authoritative.
        # A "matte content" texture, one with a meaningful fraction of near-transparent pixels alongside opaque ones, has a genuine varying matte.
        # For NON-emission-mask textures that varying alpha means see-through
        # For an EMISSION mask (bit2) the same alpha is a GLOW map, NOT see-through, so bit2 textures stay opaque and only light up where the matte is white.
        if has_alpha:
            total = self.width * self.height
            low_frac = (n_low / total) if total else 0.0
            has_matte_content = (low_frac > 0.02) and (max_alpha > 0.9)
            cutout = (has_matte_content
                      and not bool(self.flags & 0x08)     # not a reflection matte
                      and not bool(self.flags & 0x04))    # not an emission matte (glow map)
            im['tex_transparency'] = bool(self.has_transparency() or cutout)
            # Emission matte = bit2 AND an actual matte. A fully opaque bit2 texture has no matte -> NOT emissive.
            # This is decoupled from transparency, so an emission mask glows while remaining OPAQUE.
            im['tex_emission'] = bool(self.is_emission_mask() and has_matte_content)
            _wx = 'extend' if im['tex_extend_x'] else 'repeat'
            _wy = 'extend' if im['tex_extend_y'] else 'repeat'
            print(f"[{name}] flags=0x{self.flags:X} fmt={self.format!r} "
                  f"max_a={max_alpha:.2f} min_a={min_alpha:.2f} low={low_frac:.2f} "
                  f"-> transp={im['tex_transparency']} emis={im['tex_emission']} "
                  f"wrap_x={_wx} wrap_y={_wy}")

        im.pixels = pixels[:]                            # <whole-attribute assign (NOT pixels[:] = ...)
        im.update()
        if pack:
            im.pack()

        if im_mask is not None:
            im_mask.pixels = mask_pixels[:]
            im_mask.update()
            if pack:
                im_mask.pack()
            try:
                im_mask.colorspace_settings.name = 'Non-Color'
            except Exception:
                pass

        return (im, im_mask)

    def _quantize_to_palette(self, rgba_u8):
        """numpy median-cut -> (palette[256] rgba 0-255, index_bytes). rgba_u8: (N,4) uint8"""
        import numpy as np
        uniq, inv = np.unique(rgba_u8, axis=0, return_inverse=True)
        if len(uniq) <= 256:
            pal = uniq
            idx_for_uniq = np.arange(len(uniq))
        else:
            buckets = [np.arange(len(uniq))]
            while len(buckets) < 256:
                best, best_rng, best_ax = -1, -1, 0
                for i, b in enumerate(buckets):
                    if len(b) <= 1:
                        continue
                    cols = uniq[b].astype(np.int32)
                    rng = cols.max(0) - cols.min(0)
                    ax = int(rng.argmax())
                    if rng[ax] > best_rng:
                        best_rng, best, best_ax = rng[ax], i, ax
                if best < 0:
                    break
                b = buckets.pop(best)
                order = b[np.argsort(uniq[b][:, best_ax], kind='stable')]
                mid = len(order) // 2
                buckets.append(order[:mid])
                buckets.append(order[mid:])
            pal = np.zeros((len(buckets), 4), np.uint8)
            idx_for_uniq = np.zeros(len(uniq), np.int64)
            for i, b in enumerate(buckets):
                pal[i] = uniq[b].astype(np.int32).mean(0).round()
                idx_for_uniq[b] = i
        if len(pal) < 256:
            pal = np.vstack([pal, np.zeros((256 - len(pal), 4), np.uint8)])
        indices = idx_for_uniq[inv].astype(np.uint8)
        return pal, indices.tobytes()

    def from_blender_image(self, image, mask_image=None, shader=None,
                           compression=None, is_colorable=False, alpha_cutoff=None,
                           emission=False, reflection=False, transparency=False,
                           extend_x=False, extend_y=False):
        """Populates the TEXFile from a Blender image. Single mip to match vanilla.
           alpha_cutoff: None = keep smooth alpha; 0.0-1.0 = 1-bit punch-through at that threshold.
           extend_x / extend_y: True writes the EXTEND (clamp) bit for that axis; False = repeat."""
        import numpy as np
        self.width, self.height = image.size[0], image.size[1]
        W, H = self.width, self.height
    
        def _to_tex(a):
            a = a.reshape(H, W, 4)
            if not FLIP_TEXTURE_Y:            # import left rows as-is -> flip back
                a = a[::-1, :, :]
            if FLIP_TEXTURE_X:                # import mirrored columns -> mirror back
                a = a[:, ::-1, :]
            return a
        arr = _to_tex(np.array(image.pixels[:], dtype=np.float32))
        u8 = np.clip(arr * 255.0, 0, 255).astype(np.uint8)
        if mask_image is not None:
            m = _to_tex(np.array(mask_image.pixels[:], dtype=np.float32))
            u8[..., 3] = np.clip(m[..., 0] * 255.0, 0, 255).astype(np.uint8)  # mask red -> alpha
    
        # PUNCH-THROUGH: match the engine's alpha test
        if alpha_cutoff is not None:
            thr = int(round(alpha_cutoff * 255))
            opaque = u8[..., 3] >= thr
            u8[..., 3] = np.where(opaque, 255, 0).astype(np.uint8)
            u8[~opaque] = (0, 0, 0, 0)      # collapse all hidden pixels to ONE palette slot
    
        rgba = u8.reshape(-1, 4)
    
        # Flag word assembly (from the vanilla dumps + byte testing):
        #   bit0 (0x00001)  = extend-X (clamp horiz); clear = repeat
        #   bit1 (0x00002)  = car-colorable            bit2 (0x00004) = emission matte
        #   bit3 (0x00008)  = reflection matte         bit4 (0x00010) = transparency matte
        #   bit16(0x10000)  = extend-Y (clamp vert); clear = repeat
        # An emission matte (bit2) needs a real matte; its "transparency" is a glow map, so we don't also set bit4 (matches s_tunnelside = 0x04).
        has_matte = mask_image is not None
        def _wrap_flags():
            return (0x00000001 if extend_x else 0) | (0x00010000 if extend_y else 0)
        def _role_flags():
            if reflection:
                return 0x18                          # bit3 + bit4
            if emission and has_matte:
                return 0x04                          # bit2 emission matte
            if transparency:
                return 0x10                          # bit4 transparency matte
            return 0x0

        if is_colorable:
            self.format = TEXType.PA8
            self.extra_flag = 1
            # bit1 (0x02) = car-colorable. Wrapping is separate (bit0 extend-X / bit16 extend-Y), added by _wrap_flags. So a repeating colorable decal is 0x02, and (repeat-X, extend-Y) rebuilds as 0x10002.
            self.flags = 0x02 | _wrap_flags() | _role_flags()
            pal, index_bytes = self._quantize_to_palette(rgba)
            self.palette = [(int(r) / 255, int(g) / 255, int(b) / 255, int(a) / 255)
                            for r, g, b, a in pal]
            self.mipmaps = [bytearray(index_bytes)]          # SINGLE MIP
        else:
            self.format = TEXType.RGB8888
            self.extra_flag = 0
            self.flags = _wrap_flags() | _role_flags()
            self.mipmaps = [bytearray(rgba.tobytes())]       # SINGLE MIP


    def _generate_mipmaps(self, base_bytes):
        """Generates a full chain of Box-Filtered Mipmaps for the engine."""
        self.mipmaps = [base_bytes]
        
        current_width = self.width
        current_height = self.height
        current_mip = base_bytes
        
        while current_width > 1 or current_height > 1:
            next_width = max(1, current_width // 2)
            next_height = max(1, current_height // 2)
            next_mip = bytearray(next_width * next_height * 4)
            
            # Simple Box Sampling downscale
            for y in range(next_height):
                for x in range(next_width):
                    src_y = y * 2
                    src_x = x * 2
                    
                    r, g, b, a = 0, 0, 0, 0
                    samples = 0
                    
                    for dy in range(2):
                        for dx in range(2):
                            if src_x + dx < current_width and src_y + dy < current_height:
                                idx = ((src_y + dy) * current_width + (src_x + dx)) * 4
                                r += current_mip[idx]
                                g += current_mip[idx+1]
                                b += current_mip[idx+2]
                                a += current_mip[idx+3]
                                samples += 1
                                
                    dst_idx = (y * next_width + x) * 4
                    next_mip[dst_idx] = r // samples
                    next_mip[dst_idx+1] = g // samples
                    next_mip[dst_idx+2] = b // samples
                    next_mip[dst_idx+3] = a // samples
                    
            self.mipmaps.append(next_mip)
            current_mip = next_mip
            current_width = next_width
            current_height = next_height

    def has_alpha_channel(self):
        return self.format not in (TEXType.P8, TEXType.P4, TEXType.RGB888)

    def is_emission_mask(self):
        return self.has_alpha_channel() and bool(self.flags & 0x04)   # bit2

    def extend_x(self):
        # bit0 (0x1) = EXTEND/clamp the texture horizontally at its UV bounds;
        # clear = REPEAT (tile). Confirmed on the lowrider stripes (02=repeat,
        # 03=extend) across every low-byte combination. There is NO "clip"
        # (transparent-outside) mode -- only extend vs repeat.
        return bool(self.flags & 0x00000001)

    def extend_y(self):
        # bit16 (0x10000) = EXTEND vertically; clear = REPEAT. Vertical wrap is bit0
        # of the offset-12 byte. Confirmed by the byte-12 sweep 00..05 giving
        # repeat/extend/repeat/extend/repeat/extend (odd = extend).
        return bool(self.flags & 0x00010000)

    def is_reflection_mask(self):
        return self.has_alpha_channel() and bool(self.flags & 0x08)   # bit3

    def has_transparency(self):
        # bit4 (0x10) marks a transparency/alpha matte. Only bit3 (0x08 = reflection, alpha is roughness) vetoes it. bit2 (0x04 = emission matte) is a SEPARATE role and does NOT block transparency
        # A bit2 texture is transparent when it has bit4 (e.g. the 0x14 windows) or a genuine cut-out (handled by the content check in to_blender_image)
        if not self.has_alpha_channel():
            return False
        if self.flags & 0x08:                  # reflection matte -> alpha is roughness
            return False
        return bool(self.flags & 0x10)         # bit4 == transparency matte

    def matte_role(self):
        """'EMISSION' | 'REFLECTION' | 'TRANSPARENCY' | 'NONE' — single source of truth."""
        if not self.has_alpha_channel():
            return 'NONE'
        if self.flags & 0x04: return 'EMISSION'
        if self.flags & 0x08: return 'REFLECTION'
        if self.flags & 0x10: return 'TRANSPARENCY'
        return 'NONE'

    def is_colorable(self):
        # bit1 (0x02) = car-colorable (paint reacts to the vehicle colour).
        return bool(self.flags & 0x02)
        
    def __read_palette(self, file, color_count):
        for x in range(color_count):
            col_data = file.read(4)
            self.palette.append((col_data[2] / 255, col_data[1] / 255, col_data[0] / 255, col_data[3] / 255)) 
    
    def __make_palette_opaque(self):
        for i in range(len(self.palette)):
            pal_color = list(self.palette[i])
            pal_color[3] = 1.0
            self.palette[i] = tuple(pal_color)
    
    def is_paletted_format(self):
        return self.format != TEXType.RGB888 and self.format != TEXType.RGB8888 and self.format != TEXType.A1R5G5B5
        
    def is_valid(self):
        return self.width != 0 and self.height != 0 and len(self.mipmaps) > 0
        
    def get_stride(self):
        strides = (0, 1, 2, None, None, None, 2, None, None, None, None, None, None, None, 1, -2, -2, 3, 4)
        fmt_int = int(self.format)
        if fmt_int >= 0 and fmt_int <= 18:
            return strides[fmt_int]
        raise Exception("A wild texture format has appeared")
            
    def calculate_mip_size(self, mipIndex):
        if mipIndex < 0:
            raise Exception("mipIndex must not be < 0")
        mip = 0
        width = self.width
        height = self.height
        while mip != mipIndex:
            width //= 2
            height //= 2
            mip += 1
        return (width, height)

    def calculate_mip_array_size(self, mipIndex):
        size = self.calculate_mip_size(mipIndex)
        stride = self.get_stride()
        retval = (size[0] * size[1]) // -stride if stride < 0 else (size[0] * size[1]) * stride
        return retval


    def __get_pixel_pa4_p4(self, x, y, stride, mip_data, mip_size, data_index):
        nibbles = mip_data[data_index]
        nibble1 = nibbles & 0x0F
        nibble2 = (nibbles & 0xF0) >> 4
        return self.palette[nibble1] if (x % 2) == 0 else self.palette[nibble2]
        #nibbleIdx = (x / -stride) + (y * (mip_size[0]  / -stride))
        #return self.palette[nibble2] if nibbleIdx > 0 else self.palette[nibble1]
        
    def __get_pixel_pa8_p8(self, x, y, stride, mip_data, mip_size, data_index):
        pal_index = mip_data[data_index]
        return self.palette[pal_index]
        
    def __get_pixel_p8a8(self, x, y, stride, mip_data, mip_size, data_index):
        pal_index = mip_data[data_index]
        alpha = mip_data[data_index + 1]
        color = self.palette[pal_index]
        return (color[0], color[1], color[2], alpha / 255)
       
    def __get_pixel_rgb888(self, x, y, stride, mip_data, mip_size, data_index):
        return (mip_data[data_index] / 255, mip_data[data_index + 1] / 255, mip_data[data_index + 2] / 255, 1.0)
        
    def __get_pixel_rgb8888(self, x, y, stride, mip_data, mip_size, data_index):
        return (mip_data[data_index] / 255, mip_data[data_index + 1] / 255, mip_data[data_index + 2] / 255, mip_data[data_index + 3] / 255)
        
    def __get_pixel_a1r5g5b5(self, x, y, stride, mip_data, mip_size, data_index):
        color_short = struct.unpack('<H', (mip_data[data_index], mip_data[data_index + 1]))[0]
        maskA = 32768 
        maskR = 0x7C00
        maskG = 0x3E0
        maskB = 0x1F

        alpha = ((maskA & color_short) >> 8)
        red = ((maskR & color_short) >> 7)
        green = ((maskG & color_short) >> 2)
        blue = ((maskB & color_short) << 3)
        alpha = 255 if alpha > 0 else 0

        red = red | 0xF if (red & 0x8) == 0x8 else red
        green = green | 0xF if (red & 0x8) == 0x8 else green
        blue = blue | 0xF if (red & 0x8) == 0x8 else blue

        return (red / 255, green / 255, blue / 255, alpha / 255)
        
    def get_pixel(self, x, y, mip_level = 0):
        mip_data = self.mipmaps[mip_level]
        mip_size = self.calculate_mip_size(mip_level)
        stride = self.get_stride()
        
        data_index =  (x * stride) + (y * (mip_size[0] * stride)) if stride > 0 else (x // -stride) + (y * (mip_size[0] // -stride))

        get_pixel_functions = (None, self.__get_pixel_pa8_p8, self.__get_pixel_p8a8, None, None, None, self.__get_pixel_a1r5g5b5, None, None, None, None, None, None, None, self.__get_pixel_pa8_p8, self.__get_pixel_pa4_p4, self.__get_pixel_pa4_p4, self.__get_pixel_rgb888, self.__get_pixel_rgb8888)

        fmt_int = int(self.format)
        if fmt_int >= 0 and fmt_int <= 18:
            return get_pixel_functions[fmt_int](x, y, stride, mip_data, mip_size, data_index)
        else:
            return (0, 0, 0, 0)

    # IO OPERATIONS
    def read(self, filepath):
        with open(filepath, 'rb') as file:
            width, height, format = struct.unpack('<HHH', file.read(6))
            self.width = width
            self.height = height
            self.format = TEXType(format)
            
            mipcount, self.extra_flag, self.flags = struct.unpack('<HHL', file.read(8))
            
            if self.format == TEXType.P4 or self.format == TEXType.PA4:
                self.__read_palette(file, 16)
            elif self.format == TEXType.P8A8 or self.format == TEXType.PA8 or self.format == TEXType.P8:
                self.__read_palette(file, 256)
                
            if not self.has_alpha_channel() and self.is_paletted_format():
                self.__make_palette_opaque()
             
            for i in range(mipcount):
                mip_data_size = self.calculate_mip_array_size(i)
                if mip_data_size == 0:
                    break
                data = file.read(mip_data_size)
                self.mipmaps.append(data)

    def write(self, filepath):
        """Writes the TEXFile out to binary."""
        if not self.is_valid():
            raise Exception("Cannot write invalid TEX data. Missing dimensions or mipmaps.")
            
        with open(filepath, 'wb') as file:
            # Header
            file.write(struct.pack('<HHH', self.width, self.height, int(self.format)))
            
            # Mip Count & Flags
            file.write(struct.pack('<HHL', len(self.mipmaps), self.extra_flag, self.flags))
            
            # Write Palette
            if self.is_paletted_format():
                for color in self.palette:
                    r = int(color[0] * 255)
                    g = int(color[1] * 255)
                    b = int(color[2] * 255)
                    a = int(color[3] * 255)
                    # Game expects BGRA
                    file.write(struct.pack('BBBB', b, g, r, a))
                    
            for mip in self.mipmaps:
                file.write(mip)

    def __init__(self, filepath=None):
        self.palette = []
        self.width = 0
        self.height = 0
        self.format = TEXType.RGB8888
        self.flags = 0x00010003   # Vanilla default flags FOR CAR-COLORABLE TEXTURES WITH ALPHA (may not be applicable to non-cars...)
        self.extra_flag = 1       # Vanilla default byte  FOR CAR-COLORABLE TEXTURES WITH ALPHA (may not be applicable to non-cars...)
        self.mipmaps = []
        
        if filepath is not None:
            self.read(filepath)