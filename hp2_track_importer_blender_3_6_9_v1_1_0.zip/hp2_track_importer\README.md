# HP2 PS2 Track Importer

Install `hp2_track_importer.zip` in Blender 3.6.9 through **Edit → Preferences → Add-ons → Install**, enable it, and use **3D View → N-panel → HP2 Track**.

Set:

- **Solids folder**: the `TRACKBxx.LZC` directory (not its `Solids` child)
- **Texture folders**: one or more `TEXxx*.BIN` directories separated by `;`; the first directory wins when two files use the same texture hash.
- **GLOBAL reference textures**: the common `...\hp2_ps2_imp_out\GLOBAL` folder. It is scanned recursively after the track packs and resolves reference textures such as start lines and barriers.

For track 26 the defaults already point to `TRACKB26.LZC`, `TEX26LOCATION.BIN`, `TEX26TRACK.BIN`, and `GLOBAL`.

The add-on runs `worker.py` outside Blender to read section placements, texture hashes, and alpha metadata. Blender then imports each referenced source solid once, creates linked mesh instances for all placements, and uses one `HP2_IMG_<hash>` image and one `HP2_MAT_<hash>` material per texture hash. The original Modelulator section matrices are preserved.

`Replace prior HP2 import` removes only collections/data blocks tagged by this add-on. It does not erase unrelated scene data.

If a solid references a texture absent from every specified folder, the importer creates exactly one `HP2_MAT_MISSING_<hash>` material with a magenta marker. Add the pack that contains that hash to **Texture folders** and re-import; this is intentionally safer than assigning an unrelated texture.

`Repair Existing HP2 Scene` upgrades an already imported v1.0 scene: it flips V directly in the shared UV data so Solid and Material Preview show the same orientation, rebuilds alpha modes from the actual PNG alpha channel, and resolves newly available GLOBAL textures without reimporting geometry.
