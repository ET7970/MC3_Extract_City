from __future__ import annotations


bl_info = {
    "name": "HP2 PS2 Track Importer (No Duplicate Materials)",
    "author": "OpenAI Codex",
    "version": (1, 1, 0),
    "blender": (3, 6, 0),
    "location": "View3D > Sidebar > HP2 Track",
    "description": "Imports Modelulator HP2 track DAE files as linked instances with canonical textures and materials",
    "category": "Import-Export",
}

import json
import os
import re
import subprocess
import sys
import tempfile
from pathlib import Path

import bpy
from bpy.props import BoolProperty, IntProperty, StringProperty
from bpy.types import Operator, Panel, PropertyGroup
from mathutils import Matrix


ADDON_TAG = "hp2_track_importer_v1"
ROOT_COLLECTION_NAME = "HP2 Track Import"
PROTOTYPE_COLLECTION_NAME = "HP2 Prototypes (hidden)"
HASH_RE = re.compile(r"TEX0x([0-9A-Fa-f]{8})")
MISSING_HASH_RE = re.compile(r"MISSING_([0-9A-Fa-f]{8})")


def _norm_path(value: str) -> str:
    return os.path.normcase(os.path.abspath(os.path.normpath(value)))


def _collection(name: str, parent=None):
    collection = bpy.data.collections.get(name)
    if collection is None:
        collection = bpy.data.collections.new(name)
        (parent or bpy.context.scene.collection).children.link(collection)
    elif parent is not None and collection not in parent.children:
        parent.children.link(collection)
    return collection


def _unlink_from_all_collections(obj):
    for collection in tuple(obj.users_collection):
        collection.objects.unlink(obj)


def _remove_collection_tree(collection):
    for child in tuple(collection.children):
        _remove_collection_tree(child)
    for obj in tuple(collection.objects):
        bpy.data.objects.remove(obj, do_unlink=True)
    bpy.data.collections.remove(collection)


def _clear_previous_import():
    root = bpy.data.collections.get(ROOT_COLLECTION_NAME)
    if root:
        _remove_collection_tree(root)
    prototypes = bpy.data.collections.get(PROTOTYPE_COLLECTION_NAME)
    if prototypes:
        _remove_collection_tree(prototypes)
    for material in tuple(bpy.data.materials):
        if material.get(ADDON_TAG):
            bpy.data.materials.remove(material, do_unlink=True)
    for image in tuple(bpy.data.images):
        if image.get(ADDON_TAG):
            bpy.data.images.remove(image, do_unlink=True)
    for mesh in tuple(bpy.data.meshes):
        if mesh.get(ADDON_TAG) and mesh.users == 0:
            bpy.data.meshes.remove(mesh)


def _texture_hash(material_name: str):
    match = HASH_RE.search(material_name or "")
    return match.group(1).upper() if match else None


def _canonical_image(texture_hash, info):
    filepath = info["path"]
    normalized = _norm_path(filepath)
    image = next((img for img in bpy.data.images if img.source == 'FILE' and img.filepath and _norm_path(bpy.path.abspath(img.filepath)) == normalized), None)
    if image is None:
        image = bpy.data.images.load(filepath, check_existing=True)
    image.name = "HP2_IMG_" + texture_hash
    image[ADDON_TAG] = True
    return image


def _canonical_images(manifest):
    return {texture_hash: _canonical_image(texture_hash, info) for texture_hash, info in manifest["textures"].items()}


def _effective_alpha_usage(image, texture_info):
    """Use real PNG alpha when Modelulator metadata incorrectly says None."""
    declared = texture_info.get("alpha_usage", "None")
    if image.channels < 4:
        return declared
    pixels = image.pixels[:]
    alpha_values = pixels[3::4]
    if not alpha_values or min(alpha_values) >= 0.99:
        return declared
    if declared != "None":
        return declared
    # Binary alpha is foliage/fences; partial alpha is glass/fx.
    has_partial_alpha = any(0.02 < value < 0.98 for value in alpha_values)
    return "Modulated" if has_partial_alpha else "PunchThru"


def _flip_v_uv_once(mesh):
    if mesh.get("hp2_uv_v_flipped"):
        return False
    for uv_layer in mesh.uv_layers:
        for uv_data in uv_layer.data:
            uv_data.uv.y = 1.0 - uv_data.uv.y
    mesh["hp2_uv_v_flipped"] = True
    return True


def _configure_material(material, texture_hash, image, texture_info):
    material.use_nodes = True
    material.node_tree.nodes.clear()
    nodes = material.node_tree.nodes
    links = material.node_tree.links
    output = nodes.new("ShaderNodeOutputMaterial")
    output.location = (520, 0)
    texture = nodes.new("ShaderNodeTexImage")
    texture.location = (-380, 0)
    texture.image = image
    texture.interpolation = 'Linear'
    texcoord = nodes.new("ShaderNodeTexCoord")
    texcoord.location = (-620, 0)
    vertex_color = nodes.new("ShaderNodeVertexColor")
    vertex_color.location = (-160, -180)
    multiply = nodes.new("ShaderNodeMixRGB")
    multiply.location = (40, 50)
    multiply.blend_type = 'MULTIPLY'
    multiply.inputs[0].default_value = 1.0
    emission = nodes.new("ShaderNodeEmission")
    emission.location = (260, 50)
    # UV V is flipped once in mesh data, so Solid and Material Preview agree.
    links.new(texcoord.outputs['UV'], texture.inputs['Vector'])
    links.new(texture.outputs['Color'], multiply.inputs[1])
    links.new(vertex_color.outputs['Color'], multiply.inputs[2])
    links.new(multiply.outputs['Color'], emission.inputs['Color'])

    alpha_usage = _effective_alpha_usage(image, texture_info)
    alpha_blend = texture_info.get("alpha_blend", "SrcCopy")
    if alpha_usage == "None":
        image.alpha_mode = 'NONE'
        material.blend_method = 'OPAQUE'
        material.shadow_method = 'OPAQUE'
        material.show_transparent_back = False
        links.new(emission.outputs['Emission'], output.inputs['Surface'])
    else:
        image.alpha_mode = 'STRAIGHT'
        material.show_transparent_back = True
        transparent = nodes.new("ShaderNodeBsdfTransparent")
        transparent.location = (260, -100)
        color_alpha_mul = nodes.new("ShaderNodeMath")
        color_alpha_mul.location = (-120, -120)
        color_alpha_mul.operation = 'MULTIPLY'
        color_alpha_mul.inputs[1].default_value = 255.0 * 2.0
        color_alpha_div = nodes.new("ShaderNodeMath")
        color_alpha_div.location = (-40, -120)
        color_alpha_div.operation = 'DIVIDE'
        color_alpha_div.inputs[1].default_value = 127.0
        alpha = nodes.new("ShaderNodeMath")
        alpha.location = (40, -100)
        alpha.operation = 'MULTIPLY'
        links.new(vertex_color.outputs['Alpha'], color_alpha_mul.inputs[0])
        links.new(color_alpha_mul.outputs[0], color_alpha_div.inputs[0])
        links.new(texture.outputs['Alpha'], alpha.inputs[0])
        links.new(color_alpha_div.outputs[0], alpha.inputs[1])
        if alpha_blend == "SrcAdditive":
            material.blend_method = 'BLEND'
            material.shadow_method = 'NONE'
            shader = nodes.new("ShaderNodeAddShader")
            links.new(alpha.outputs[0], emission.inputs['Strength'])
            links.new(transparent.outputs[0], shader.inputs[0])
            links.new(emission.outputs[0], shader.inputs[1])
            links.new(shader.outputs[0], output.inputs['Surface'])
        else:
            material.blend_method = 'CLIP' if alpha_usage == "PunchThru" else 'BLEND'
            material.shadow_method = 'CLIP' if alpha_usage == "PunchThru" else 'HASHED'
            shader = nodes.new("ShaderNodeMixShader")
            links.new(alpha.outputs[0], shader.inputs[0])
            links.new(transparent.outputs[0], shader.inputs[1])
            links.new(emission.outputs[0], shader.inputs[2])
            links.new(shader.outputs[0], output.inputs['Surface'])
    material[ADDON_TAG] = True
    material["hp2_texture_hash"] = texture_hash
    material["hp2_alpha_usage"] = alpha_usage
    material["hp2_alpha_blend"] = alpha_blend


def _canonical_materials(manifest, images):
    result = {}
    for texture_hash, image in images.items():
        material = bpy.data.materials.get("HP2_MAT_" + texture_hash)
        if material is None:
            material = bpy.data.materials.new("HP2_MAT_" + texture_hash)
        _configure_material(material, texture_hash, image, manifest["textures"][texture_hash])
        result[texture_hash] = material
    return result


def _materialize_missing(material, canonical_materials):
    texture_hash = _texture_hash(material.name)
    if texture_hash and texture_hash in canonical_materials:
        return canonical_materials[texture_hash]
    key = "MISSING_" + (texture_hash or re.sub(r"[. ]\\d+$", "", material.name).upper())
    name = "HP2_MAT_" + key
    existing = bpy.data.materials.get(name)
    if existing:
        return existing
    material.name = name
    material[ADDON_TAG] = True
    material.diffuse_color = (1.0, 0.0, 1.0, 1.0)
    return material


def _remap_imported_materials(imported_objects, canonical_materials):
    imported_materials = set()
    for obj in imported_objects:
        if obj.type == 'MESH':
            imported_materials.update(slot.material for slot in obj.material_slots if slot.material)
    remaps = {}
    for material in imported_materials:
        remaps[material] = _materialize_missing(material, canonical_materials)
    for obj in imported_objects:
        if obj.type == 'MESH':
            for slot in obj.material_slots:
                if slot.material in remaps:
                    slot.material = remaps[slot.material]
            obj.data.use_auto_smooth = False
            obj.data[ADDON_TAG] = True
            _flip_v_uv_once(obj.data)
    for old, new in remaps.items():
        if old != new and old.users == 0:
            bpy.data.materials.remove(old, do_unlink=True)


def _import_prototype(filepath, prototype_collection, canonical_materials):
    before = set(bpy.data.objects)
    result = bpy.ops.wm.collada_import(filepath=filepath)
    if 'FINISHED' not in result:
        raise RuntimeError("Collada importer returned %s for %s" % (result, filepath))
    imported = list(set(bpy.data.objects) - before)
    if not imported:
        raise RuntimeError("No objects were imported from " + filepath)
    _remap_imported_materials(imported, canonical_materials)
    for obj in imported:
        obj[ADDON_TAG] = True
        _unlink_from_all_collections(obj)
        prototype_collection.objects.link(obj)
        obj.hide_render = True
        obj.hide_set(True)
    roots = [obj for obj in imported if obj.parent not in imported]
    return imported, roots


def _copy_prototype(roots, target_collection, matrix, name):
    copies = {}
    for root in roots:
        for original in (root,) + tuple(root.children_recursive):
            clone = original.copy()
            clone.data = original.data
            target_collection.objects.link(clone)
            copies[original] = clone
    for original, clone in copies.items():
        if original.parent in copies:
            clone.parent = copies[original.parent]
            clone.matrix_parent_inverse = original.matrix_parent_inverse.copy()
        else:
            clone.matrix_world = matrix @ original.matrix_world
            clone.name = name
        clone.hide_set(False)
        clone.hide_render = False
    return len(copies)


def _matrix(values):
    if len(values) != 16:
        raise ValueError("Expected 16 matrix values, got %d" % len(values))
    # Modelulator writes translation in cells 3/7/11, i.e. the row layout Blender expects.
    return Matrix((values[0:4], values[4:8], values[8:12], values[12:16]))


def _dedupe_images():
    canonical = {}
    for image in tuple(bpy.data.images):
        if image.source != 'FILE' or not image.filepath:
            continue
        key = _norm_path(bpy.path.abspath(image.filepath))
        old = canonical.get(key)
        if old is None:
            canonical[key] = image
        elif old != image:
            image.user_remap(old)
            bpy.data.images.remove(image, do_unlink=True)


def _texture_directories(settings):
    paths = [Path(bpy.path.abspath(value.strip())) for value in settings.texture_dirs.split(';') if value.strip()]
    if settings.global_dir.strip():
        paths.append(Path(bpy.path.abspath(settings.global_dir.strip())))
    result = []
    seen = set()
    for path in paths:
        key = _norm_path(str(path))
        if key not in seen:
            seen.add(key)
            result.append(path)
    return result


def _run_worker(solids_dir, texture_dirs, manifest_path, prepared_dir=None, solids_only=False):
    worker = Path(__file__).with_name("worker.py")
    command = [sys.executable, str(worker), "--solids", str(solids_dir), "--output", str(manifest_path)]
    if prepared_dir is not None:
        command.extend(("--prepared-dir", str(prepared_dir)))
    for directory in texture_dirs:
        command.extend(("--textures", str(directory)))
    if solids_only:
        command.append("--solids-only")
    process = subprocess.run(command, capture_output=True, text=True, check=False)
    if process.returncode:
        raise RuntimeError(process.stderr.strip() or process.stdout.strip() or "Worker failed")
    return json.loads(manifest_path.read_text(encoding='utf-8'))


class HP2TrackSettings(PropertyGroup):
    solids_dir: StringProperty(name="Solids folder", subtype='DIR_PATH', default=r"C:\\Tools\\modelulator.v5.1.5.pub\\hp2_ps2_imp_out\\TRACKS\\TRACKB26.LZC")
    texture_dirs: StringProperty(name="Texture folders", description="One or more TEX*.BIN folders separated by semicolons", default=r"C:\\Tools\\modelulator.v5.1.5.pub\\hp2_ps2_imp_out\\TRACKS\\TEX26LOCATION.BIN;C:\\Tools\\modelulator.v5.1.5.pub\\hp2_ps2_imp_out\\TRACKS\\TEX26TRACK.BIN")
    global_dir: StringProperty(name="GLOBAL reference textures", description="GLOBAL folder, searched recursively after track texture packs", subtype='DIR_PATH', default=r"C:\\Tools\\modelulator.v5.1.5.pub\\hp2_ps2_imp_out\\GLOBAL")
    clear_previous: BoolProperty(name="Replace prior HP2 import", default=True)
    include_sections: BoolProperty(name="Use ScenerySections placement", default=True)
    limit_instances: IntProperty(name="Debug instance limit", description="0 imports the complete track", min=0, default=0)


class HP2_OT_import_track(Operator):
    bl_idname = "hp2.import_track"
    bl_label = "Import HP2 Track"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        settings = context.scene.hp2_track_settings
        solids_dir = Path(bpy.path.abspath(settings.solids_dir))
        texture_dirs = _texture_directories(settings)
        if not solids_dir.is_dir():
            self.report({'ERROR'}, "Solids folder does not exist: " + str(solids_dir))
            return {'CANCELLED'}
        if not texture_dirs or any(not path.is_dir() for path in texture_dirs):
            self.report({'ERROR'}, "Every texture folder must exist")
            return {'CANCELLED'}
        with tempfile.TemporaryDirectory(prefix="hp2_track_import_") as temp_dir:
            temp_root = Path(temp_dir)
            manifest_path = temp_root / "manifest.json"
            prepared_dir = temp_root / "prepared_dae"
            try:
                manifest = _run_worker(solids_dir, texture_dirs, manifest_path, prepared_dir, not settings.include_sections)
            except (OSError, RuntimeError) as exc:
                self.report({'ERROR'}, "Could not run worker: " + str(exc))
                return {'CANCELLED'}
            if not manifest["instances"]:
                self.report({'ERROR'}, "Worker found no solid instances")
                return {'CANCELLED'}
            context.window_manager.progress_begin(0, len(manifest["instances"]))
            if settings.clear_previous:
                _clear_previous_import()
            root = _collection(ROOT_COLLECTION_NAME)
            prototypes = _collection(PROTOTYPE_COLLECTION_NAME)
            prototypes.hide_render = True
            prototypes.hide_viewport = True
            images = _canonical_images(manifest)
            canonical_materials = _canonical_materials(manifest, images)
            section_collections = {}
            prototypes_by_file = {}
            imported_solids = 0
            total_objects = 0
            instances = manifest["instances"]
            if settings.limit_instances:
                instances = instances[:settings.limit_instances]
            try:
                for index, instance in enumerate(instances, 1):
                    solid = instance["solid"]
                    prototype = prototypes_by_file.get(solid)
                    if prototype is None:
                        filepath = manifest["import_files"][solid]
                        _, roots = _import_prototype(filepath, prototypes, canonical_materials)
                        prototype = roots
                        prototypes_by_file[solid] = prototype
                        imported_solids += 1
                    section = instance.get("section", "Solids")
                    target = section_collections.get(section)
                    if target is None:
                        target = _collection(section, root)
                        section_collections[section] = target
                    total_objects += _copy_prototype(prototype, target, _matrix(instance["matrix"]), instance["name"])
                    if index % 25 == 0:
                        context.window_manager.progress_update(index)
            finally:
                _dedupe_images()
                context.window_manager.progress_end()
            self.report({'INFO'}, "HP2 import complete: %d placed instances from %d unique solids, %d textures, %d materials" % (len(instances), imported_solids, len(images), len(canonical_materials)))
            return {'FINISHED'}

    def invoke(self, context, event):
        return self.execute(context)


class HP2_OT_repair_existing_track(Operator):
    bl_idname = "hp2.repair_existing_track"
    bl_label = "Repair Existing HP2 Scene"
    bl_description = "Flip HP2 UVs once, rebuild HP2 materials, and resolve textures from GLOBAL"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        settings = context.scene.hp2_track_settings
        solids_dir = Path(bpy.path.abspath(settings.solids_dir))
        texture_dirs = _texture_directories(settings)
        if not solids_dir.is_dir() or not texture_dirs or any(not path.is_dir() for path in texture_dirs):
            self.report({'ERROR'}, "Set valid Solids, track texture, and GLOBAL folders first")
            return {'CANCELLED'}
        try:
            with tempfile.TemporaryDirectory(prefix="hp2_track_repair_") as temp_dir:
                manifest = _run_worker(solids_dir, texture_dirs, Path(temp_dir) / "manifest.json")
        except (OSError, RuntimeError) as exc:
            self.report({'ERROR'}, "Could not scan texture folders: " + str(exc))
            return {'CANCELLED'}

        flipped_meshes = 0
        for mesh in bpy.data.meshes:
            if mesh.get(ADDON_TAG) and _flip_v_uv_once(mesh):
                flipped_meshes += 1

        repaired_materials = 0
        remaps = []
        for material in tuple(bpy.data.materials):
            if not material.get(ADDON_TAG):
                continue
            texture_hash = material.get("hp2_texture_hash") or _texture_hash(material.name)
            if texture_hash is None:
                missing = MISSING_HASH_RE.search(material.name)
                texture_hash = missing.group(1).upper() if missing else None
            if not texture_hash or texture_hash not in manifest["textures"]:
                continue
            canonical_name = "HP2_MAT_" + texture_hash
            canonical = bpy.data.materials.get(canonical_name)
            if canonical is None:
                canonical = material
                canonical.name = canonical_name
            image = _canonical_image(texture_hash, manifest["textures"][texture_hash])
            _configure_material(canonical, texture_hash, image, manifest["textures"][texture_hash])
            repaired_materials += 1
            if material != canonical:
                remaps.append((material, canonical))
        for old, canonical in remaps:
            old.user_remap(canonical)
            if old.users == 0:
                bpy.data.materials.remove(old, do_unlink=True)
        _dedupe_images()
        self.report({'INFO'}, "HP2 repair complete: %d UV meshes flipped, %d materials rebuilt" % (flipped_meshes, repaired_materials))
        return {'FINISHED'}


class HP2_PT_track_importer(Panel):
    bl_label = "HP2 Track Importer"
    bl_idname = "HP2_PT_track_importer"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'HP2 Track'

    def draw(self, context):
        layout = self.layout
        settings = context.scene.hp2_track_settings
        layout.prop(settings, "solids_dir")
        layout.prop(settings, "texture_dirs")
        layout.prop(settings, "global_dir")
        layout.prop(settings, "include_sections")
        layout.prop(settings, "clear_previous")
        layout.prop(settings, "limit_instances")
        layout.operator(HP2_OT_import_track.bl_idname, icon='IMPORT')
        layout.operator(HP2_OT_repair_existing_track.bl_idname, icon='FILE_REFRESH')
        layout.label(text="Texture folders use ; as separator", icon='INFO')


CLASSES = (HP2TrackSettings, HP2_OT_import_track, HP2_OT_repair_existing_track, HP2_PT_track_importer)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.Scene.hp2_track_settings = bpy.props.PointerProperty(type=HP2TrackSettings)


def unregister():
    del bpy.types.Scene.hp2_track_settings
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
