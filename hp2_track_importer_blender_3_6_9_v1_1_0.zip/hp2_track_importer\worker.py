"""External, Blender-independent scanner for Modelulator HP2 track exports."""

from __future__ import annotations

import argparse
import json
import re
import sys
import urllib.parse
import xml.etree.ElementTree as ET
from pathlib import Path


TEXTURE_HASH_RE = re.compile(r"^0x([0-9A-Fa-f]{8})\.")
MATERIAL_TEXTURE_HASH_RE = re.compile(r"TEX0x([0-9A-Fa-f]{8})")
NODE_ID_RE = re.compile(r'<node\s+id="([^"]+)"')


def local_name(element):
    return element.tag.rsplit('}', 1)[-1]


def parse_texture_metadata(texture_dir: Path):
    metadata = {}
    for path in sorted(texture_dir.rglob('*.json')):
        try:
            data = json.loads(path.read_text(encoding='utf-8'))
        except (OSError, UnicodeDecodeError, json.JSONDecodeError):
            continue
        for item in data.get('eTextureInfoList', []):
            match = TEXTURE_HASH_RE.match(item.get('Texture', ''))
            if match:
                metadata[match.group(1).upper()] = {
                    'alpha_usage': item.get('AlphaUsage', 'None'),
                    'alpha_blend': item.get('AlphaBlend', 'SrcCopy'),
                }
    return metadata


def collect_textures(texture_dirs, required_hashes=None):
    textures = {}
    for texture_dir in texture_dirs:
        metadata = parse_texture_metadata(texture_dir)
        for path in sorted(texture_dir.rglob('*')):
            if not path.is_file() or path.suffix.lower() not in {'.png', '.dds', '.tga', '.bmp', '.jpg', '.jpeg'}:
                continue
            match = TEXTURE_HASH_RE.match(path.name)
            if not match:
                continue
            texture_hash = match.group(1).upper()
            if required_hashes is not None and texture_hash not in required_hashes:
                continue
            # Earlier folders have priority. This makes the UI field order explicit and deterministic.
            if texture_hash not in textures:
                info = {'path': str(path), 'alpha_usage': 'None', 'alpha_blend': 'SrcCopy'}
                info.update(metadata.get(texture_hash, {}))
                textures[texture_hash] = info
    return textures


def parse_sections(solids_dir: Path):
    sections_dir = solids_dir / 'ScenerySections'
    instances = []
    if not sections_dir.is_dir():
        return instances
    for section_file in sorted(sections_dir.glob('*.dae')):
        try:
            root = ET.parse(section_file).getroot()
        except (OSError, ET.ParseError):
            continue
        for node in (element for element in root.iter() if local_name(element) == 'node'):
            reference = next((child for child in node if local_name(child) == 'instance_node'), None)
            matrix = next((child for child in node if local_name(child) == 'matrix'), None)
            if reference is None or matrix is None:
                continue
            url = urllib.parse.unquote(reference.get('url', ''))
            solid_path = url.split('#', 1)[0].replace('\\', '/')
            if not solid_path:
                continue
            resolved = (section_file.parent / solid_path).resolve()
            try:
                relative_solid = resolved.relative_to(solids_dir.resolve()).as_posix()
            except ValueError:
                continue
            try:
                values = [float(value) for value in (matrix.text or '').split()]
            except ValueError:
                continue
            if len(values) != 16 or not resolved.is_file():
                continue
            instances.append({
                'solid': relative_solid,
                'matrix': values,
                'section': section_file.stem,
                'name': node.get('id') or section_file.stem,
            })
    return instances


def parse_solids_only(solids_dir: Path):
    result = []
    for solid in sorted((solids_dir / 'Solids').glob('*.dae')):
        if solid.name.lower().startswith('esolidpalette.'):
            continue
        result.append({
            'solid': solid.relative_to(solids_dir).as_posix(),
            'matrix': [1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0],
            'section': 'Solids',
            'name': solid.stem,
        })
    return result


def referenced_texture_hashes(solids_dir: Path, instances):
    hashes = set()
    for relative_solid in {item['solid'] for item in instances}:
        source = solids_dir / relative_solid.replace('/', '\\')
        try:
            root = ET.parse(source).getroot()
        except (OSError, ET.ParseError):
            continue
        for element in root.iter():
            if local_name(element) != 'material':
                continue
            match = MATERIAL_TEXTURE_HASH_RE.search(element.get('name', ''))
            if match:
                hashes.add(match.group(1).upper())
    return hashes


def prepare_import_files(solids_dir: Path, instances, prepared_dir: Path):
    """Make DAE files that explicitly instantiate their library node for Blender.

    Modelulator solids define geometry only inside library_nodes. Blender reads
    that library but does not create an object until a visual_scene references
    it, so this adds one temporary scene without touching the source DAE.
    """
    prepared_dir.mkdir(parents=True, exist_ok=True)
    result = {}
    for relative_solid in sorted({item['solid'] for item in instances}):
        source = solids_dir / relative_solid.replace('/', '\\')
        raw = source.read_text(encoding='utf-8')
        match = NODE_ID_RE.search(raw)
        if match is None:
            raise ValueError('No library node found in ' + str(source))
        node_id = match.group(1)
        suffix = '\n<library_visual_scenes><visual_scene id="HP2_IMPORT_SCENE"><node id="HP2_IMPORT_ROOT"><instance_node url="#%s"/></node></visual_scene></library_visual_scenes><scene><instance_visual_scene url="#HP2_IMPORT_SCENE"/></scene>\n' % node_id
        closing = raw.rfind('</COLLADA>')
        if closing < 0:
            raise ValueError('Missing </COLLADA> in ' + str(source))
        destination = prepared_dir / relative_solid.replace('/', '__')
        destination.write_text(raw[:closing] + suffix + raw[closing:], encoding='utf-8')
        result[relative_solid] = str(destination)
    return result


def build_manifest(solids_dir: Path, texture_dirs, solids_only=False, prepared_dir=None):
    if not solids_dir.is_dir():
        raise ValueError('Solids directory does not exist: ' + str(solids_dir))
    instances = parse_solids_only(solids_dir) if solids_only else parse_sections(solids_dir)
    required_hashes = referenced_texture_hashes(solids_dir, instances)
    return {
        'format': 'hp2-track-manifest-v1',
        'solids_dir': str(solids_dir),
        'textures': collect_textures(texture_dirs, required_hashes),
        'instances': instances,
        'import_files': prepare_import_files(solids_dir, instances, prepared_dir) if prepared_dir else {},
    }


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--solids', required=True, type=Path)
    parser.add_argument('--textures', required=True, action='append', type=Path)
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--prepared-dir', type=Path, help='Temporary directory for Blender-ready DAE copies')
    parser.add_argument('--solids-only', action='store_true')
    args = parser.parse_args(argv)
    for directory in args.textures:
        if not directory.is_dir():
            parser.error('Texture directory does not exist: ' + str(directory))
    manifest = build_manifest(args.solids, args.textures, args.solids_only, args.prepared_dir)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(manifest, ensure_ascii=False, separators=(',', ':')), encoding='utf-8')
    print('instances=%d textures=%d' % (len(manifest['instances']), len(manifest['textures'])))


if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        print('worker error: ' + str(exc), file=sys.stderr)
        raise
