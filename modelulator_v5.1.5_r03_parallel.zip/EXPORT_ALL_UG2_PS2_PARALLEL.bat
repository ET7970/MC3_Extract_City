@echo off
setlocal EnableExtensions
pushd "%~dp0"

set "JOBS=4"
if not "%~1"=="" set "JOBS=%~1"

echo Starting PSX2 / UNDERGROUND2 with %JOBS% parallel workers...
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0PowerShell\ExportAllParallel.ps1" -Platform "PSX2" -Game "UNDERGROUND2" -MaxJobs %JOBS%
set "RC=%ERRORLEVEL%"

popd
echo.
if not "%RC%"=="0" echo Export finished with errors. Check the logs folder.
pause
exit /b %RC%
