param([String]$OPath = "");

Add-Type -AssemblyName System.IO
Add-Type -AssemblyName System.Drawing

$Files = Get-ChildItem -Path $OPath

foreach ($f in $Files)
{
	$bmp = New-Object System.Drawing.Bitmap($f.FullName);
	$bmp.Save($f.DirectoryName + "\" + $f.BaseName + ".png", [System.Drawing.Imaging.ImageFormat]::Png);
}

Remove-Item $OPath