﻿param(
    [string]$Platform = "PSX2",
    [string]$Game = "HOTPURSUIT2",
    [int]$MaxJobs = 4
)

$ErrorActionPreference = "Stop"

if ($MaxJobs -lt 1) { $MaxJobs = 1 }
if ($MaxJobs -gt 16) { $MaxJobs = 16 }

$Root = Split-Path -Parent $PSScriptRoot
$RunBat = Join-Path $Root "run.bat"
$InputRoot = Join-Path $Root "imp"
$OutputRoot = Join-Path $Root "out"
$TempRoot = Join-Path $Root "temp"
$LogRoot = Join-Path $Root "logs"

$Groups = @("FRONTEND", "GLOBAL", "TRACKS")
$Extensions = @(".BUN", ".LZC", ".BIN")

foreach ($Path in @($OutputRoot, $TempRoot, $LogRoot)) {
    if (-not (Test-Path -LiteralPath $Path)) {
        New-Item -ItemType Directory -Force -Path $Path | Out-Null
    }
}

if (-not (Test-Path -LiteralPath $RunBat)) {
    throw "run.bat not found: $RunBat"
}
if (-not (Test-Path -LiteralPath $InputRoot)) {
    throw "Input folder not found: $InputRoot"
}

$Files = @()
foreach ($Group in $Groups) {
    $GroupPath = Join-Path $InputRoot $Group
    if (Test-Path -LiteralPath $GroupPath) {
        $Files += Get-ChildItem -LiteralPath $GroupPath -File -Recurse | Where-Object {
            $Extensions -contains $_.Extension.ToUpperInvariant()
        }
    }
}

# Start larger files first. This usually reduces the long single-file tail at the end.
$Files = @($Files | Sort-Object Length -Descending)

if ($Files.Count -eq 0) {
    Write-Host "No .BUN/.LZC/.BIN files found under imp\\FRONTEND, imp\\GLOBAL or imp\\TRACKS."
    exit 2
}

Write-Host "============================================================"
Write-Host "Modelulator parallel exporter"
Write-Host "Platform : $Platform"
Write-Host "Game     : $Game"
Write-Host "Workers  : $MaxJobs"
Write-Host "Files    : $($Files.Count)"
Write-Host "Input    : $InputRoot"
Write-Host "Output   : $OutputRoot"
Write-Host "============================================================"
Write-Host ""

$Running = @()
$Results = @()
$NextIndex = 0
$Completed = 0
$Failed = 0
$Warnings = 0
$StartAll = Get-Date
$Stamp = Get-Date -Format "yyyyMMdd_HHmmss"

function Get-FreeSlot {
    param([object[]]$Jobs, [int]$Limit)
    $Used = @($Jobs | ForEach-Object { $_.Slot })
    foreach ($Slot in 1..$Limit) {
        if ($Used -notcontains $Slot) { return $Slot }
    }
    return $null
}

function Start-ExportJob {
    param(
        [System.IO.FileInfo]$File,
        [int]$Index,
        [int]$Slot
    )

    $Relative = $File.FullName.Substring($InputRoot.Length).TrimStart([char]92)
    $Destination = Join-Path $OutputRoot $Relative
    New-Item -ItemType Directory -Force -Path $Destination | Out-Null

    $WorkerTemp = Join-Path $TempRoot ("worker_{0}" -f $Slot)
    if (Test-Path -LiteralPath $WorkerTemp) {
        Get-ChildItem -LiteralPath $WorkerTemp -Force -ErrorAction SilentlyContinue |
            Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
    } else {
        New-Item -ItemType Directory -Force -Path $WorkerTemp | Out-Null
    }

    $SafeName = ($Relative -replace '[\\/:*?"<>| ]', '_')
    $JobLog = Join-Path $LogRoot ("job_{0:D3}_{1}.log" -f $Index, $SafeName)
    $JobCmd = Join-Path $WorkerTemp ("job_{0:D3}.cmd" -f $Index)

    $CmdLines = @(
        '@echo off',
        ('set "MODELULATOR_TEMP_DIR={0}"' -f $WorkerTemp),
        'set "MODELULATOR_NO_SOUND=1"',
        ('call "{0}" /pc -p "{1}" -g "{2}" -i "{3}" -o "{4}" > "{5}" 2>&1' -f $RunBat, $Platform, $Game, $File.FullName, $Destination, $JobLog),
        'exit /b %ERRORLEVEL%'
    )
    [System.IO.File]::WriteAllLines($JobCmd, $CmdLines, [System.Text.Encoding]::ASCII)

    $Process = Start-Process -FilePath $env:ComSpec -ArgumentList @('/d','/c',('"{0}"' -f $JobCmd)) -PassThru -WindowStyle Hidden

    Write-Host ("[START {0}/{1}] worker {2}: {3} ({4:N1} MB)" -f $Index, $Files.Count, $Slot, $Relative, ($File.Length / 1MB))

    return [PSCustomObject]@{
        Index = $Index
        Slot = $Slot
        File = $File
        Relative = $Relative
        Destination = $Destination
        Log = $JobLog
        Cmd = $JobCmd
        Process = $Process
        Started = Get-Date
    }
}

while (($NextIndex -lt $Files.Count) -or ($Running.Count -gt 0)) {
    while (($NextIndex -lt $Files.Count) -and ($Running.Count -lt $MaxJobs)) {
        $Slot = Get-FreeSlot -Jobs $Running -Limit $MaxJobs
        if ($null -eq $Slot) { break }

        $NextIndex++
        $Job = Start-ExportJob -File $Files[$NextIndex - 1] -Index $NextIndex -Slot $Slot
        $Running += $Job
    }

    foreach ($Job in @($Running)) {
        if ($Job.Process.HasExited) {
            $Job.Process.WaitForExit()
            $ExitCode = $Job.Process.ExitCode
            $Elapsed = (Get-Date) - $Job.Started
            $LogText = ""
            if (Test-Path -LiteralPath $Job.Log) {
                $LogText = Get-Content -LiteralPath $Job.Log -Raw -ErrorAction SilentlyContinue
            }

            $InternalError = $false
            if ($LogText -match 'FileOutputList Error:' -or $LogText -match '#Errors\s*=\s*[1-9][0-9]*') {
                $InternalError = $true
            }

            if ($ExitCode -ne 0) {
                $Status = "FAILED"
                $Failed++
            } elseif ($InternalError) {
                $Status = "WARN"
                $Warnings++
            } else {
                $Status = "OK"
            }

            $Completed++
            Write-Host ("[{0} {1}/{2}] worker {3}: {4} - {5:mm\:ss}" -f $Status, $Completed, $Files.Count, $Job.Slot, $Job.Relative, $Elapsed)

            $Results += [PSCustomObject]@{
                Index = $Job.Index
                Status = $Status
                ExitCode = $ExitCode
                Seconds = [math]::Round($Elapsed.TotalSeconds, 2)
                File = $Job.Relative
                Output = $Job.Destination
                Log = $Job.Log
            }

            Remove-Item -LiteralPath $Job.Cmd -Force -ErrorAction SilentlyContinue
            $PidToRemove = $Job.Process.Id
            $Running = @($Running | Where-Object { $_.Process.Id -ne $PidToRemove })
        }
    }

    if (($NextIndex -lt $Files.Count) -or ($Running.Count -gt 0)) {
        Start-Sleep -Milliseconds 250
    }
}

$ElapsedAll = (Get-Date) - $StartAll
$SummaryPath = Join-Path $LogRoot ("parallel_summary_{0}.log" -f $Stamp)
$Summary = @()
$Summary += "Modelulator parallel export summary"
$Summary += "Platform=$Platform"
$Summary += "Game=$Game"
$Summary += "Workers=$MaxJobs"
$Summary += "Files=$($Files.Count)"
$Summary += "Completed=$Completed"
$Summary += "Warnings=$Warnings"
$Summary += "Failed=$Failed"
$Summary += ("Elapsed={0}" -f $ElapsedAll)
$Summary += ""
foreach ($Result in ($Results | Sort-Object Index)) {
    $Summary += ("[{0}] exit={1} seconds={2} file={3} log={4}" -f $Result.Status, $Result.ExitCode, $Result.Seconds, $Result.File, $Result.Log)
}
[System.IO.File]::WriteAllLines($SummaryPath, $Summary, [System.Text.Encoding]::UTF8)

Write-Host ""
Write-Host "============================================================"
Write-Host ("Finished in {0:hh\:mm\:ss}" -f $ElapsedAll)
Write-Host "Completed: $Completed / $($Files.Count)"
Write-Host "Warnings : $Warnings"
Write-Host "Failed   : $Failed"
Write-Host "Summary  : $SummaryPath"
Write-Host "============================================================"

if ($Failed -eq 0) {
    $Sound = Join-Path $Root "Sound\\success.wav"
    if (Test-Path -LiteralPath $Sound) {
        try {
            $Player = New-Object System.Media.SoundPlayer $Sound
            $Player.PlaySync()
        } catch { }
    }
}

if ($Failed -gt 0) { exit 1 }
exit 0
