param([String]$SoundFile = '');

Add-Type -AssemblyName System;
Add-Type -AssemblyName System.IO;
Add-Type -AssemblyName System.Windows.Forms

$SoundPlayerMain = New-Object System.Media.SoundPlayer($SoundFile);
$SoundPlayerMain.PlaySync();