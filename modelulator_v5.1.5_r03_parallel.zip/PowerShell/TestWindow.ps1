﻿Add-Type -AssemblyName System;
Add-Type -AssemblyName System.Threading;
Add-Type -AssemblyName System.IO;
Add-Type -AssemblyName System.Windows.Forms;
Add-Type -AssemblyName System.Drawing;

$Form				= New-Object System.Windows.Forms.Form;
$Form.Text			= "some sick fuckin' malware";
$Form.Name          = "Form";
$Form.Size			= New-Object System.Drawing.Size(400, 200);
$Form.StartPosition		= "CenterScreen";
$Form.FormBorderStyle		= [System.Windows.Forms.FormBorderStyle]::Sizable;
$Form.MaximizeBox		= $true;

$MainImage			= New-Object System.Windows.Forms.PictureBox;
$MainImage.Width = 5120;
$MainImage.Height = 5120;
$MainImage.BackColor		= [System.Drawing.Color]::Black;
$MainImage.Name		= "MainImage";

$BasePen			= New-Object System.Drawing.Pen Red;
$BaseBrush			= New-Object System.Drawing.SolidBrush Red;

$MainImageGraphics = $MainImage.CreateGraphics();
#$MainImageGraphics.Clear([System.Drawing.Color]::Black);

#$TestBMP = New-Object System.Drawing.Bitmap(4096, 4096, $MainImageGraphics);
#$MainImage.Image = $TestBMP;

$Global:DrawExpression = "";
$Global:FileName = "Test";

function point([int] $px, [int] $py)
{
    return [System.Drawing.Point]::new($px, $py);
}

function MainImage_Paint([System.Object[]] $Arguments)
{
    [System.Windows.Forms.PictureBox] $Sender = $Arguments[0];
    [System.Windows.Forms.PaintEventArgs] $PaintEventArgs = $Arguments[1];
    
    [System.Drawing.Graphics] $graphics = $PaintEventArgs.Graphics;
    
    $TestBMP = New-Object System.Drawing.Bitmap(5120, 5120, $graphics);
    $g = [System.Drawing.Graphics]::FromImage($TestBMP);
    $g.Clear([System.Drawing.Color]::Black);
    Invoke-Expression $Global:DrawExpression;
    #$g.FillPolygon($BaseBrush, @([System.Drawing.Point]::new(0, 0), [System.Drawing.Point]::new(0, 2), [System.Drawing.Point]::new(2, 0)));

    #$graphics.DrawImage($TestBMP, [System.Drawing.Point]::new(0, 0));
    
    $TestBMP.Save("C:\lua\lua_tools\powershell_test\$Global:FileName.png",  [System.Drawing.Imaging.ImageFormat]::Png);

    #$Sender.Image = $Sender.Image;

	#[System.Windows.Forms.Application]::DoEvents();
    $EventString = " [Event]:{0}.Paint ";
	
    #[System.Console]::Clear();
	[System.Console]::Write($EventString, $Sender.Name);
    [System.Windows.Forms.Application]::Exit();
}

function Form_KeyDown([System.Object[]] $Arguments)
{
    [System.Windows.Forms.Form] $Sender = $Arguments[0];
    [System.Windows.Forms.KeyEventArgs] $KeyEventArgs = $Arguments[1];

    $EventString = " [Event]:{0}.KeyDown:<'Alt'='{1}';'Control'='{2}';'Handled'='{3}';'KeyCode'='{4}';'KeyData'='{5}';'KeyValue'='{6}';'Modifiers'='{7}';'Shift'='{8}';'SuppressKeyPress'='{9}';> ";

    [System.Console]::Clear();
    [System.Console]::Write($EventString, $Sender.Name, $KeyEventArgs.Alt, $KeyEventArgs.Control, $KeyEventArgs.Handled, $KeyEventArgs.KeyCode, $KeyEventArgs.KeyData, $KeyEventArgs.KeyValue, $KeyEventArgs.Modifiers, $KeyEventArgs.Modifiers, $KeyEventArgs.Shift, $KeyEventArgs.SuppressKeyPress);
}

function Form_KeyUp([System.Object[]] $Arguments)
{
    [System.Windows.Forms.Form] $Sender = $Arguments[0];
    [System.Windows.Forms.KeyEventArgs] $KeyEventArgs = $Arguments[1];
    
    $EventString = " [Event]:{0}.KeyUp:<'Alt'='{1}';'Control'='{2}';'Handled'='{3}';'KeyCode'='{4}';'KeyData'='{5}';'KeyValue'='{6}';'Modifiers'='{7}';'Shift'='{8}';'SuppressKeyPress'='{9}';> ";

    [System.Console]::Clear();
    [System.Console]::Write($EventString, $Sender.Name, $KeyEventArgs.Alt, $KeyEventArgs.Control, $KeyEventArgs.Handled, $KeyEventArgs.KeyCode, $KeyEventArgs.KeyData, $KeyEventArgs.KeyValue, $KeyEventArgs.Modifiers, $KeyEventArgs.Modifiers, $KeyEventArgs.Shift, $KeyEventArgs.SuppressKeyPress);
}

function MouseDown([System.Object[]] $Arguments)
{
    [System.Object] $Sender = $Arguments[0];
    [System.Windows.Forms.MouseEventArgs] $MouseEventArgs = $Arguments[1];

    $EventString = " [Event]:{0}.MouseDown:<'Button'='{1}';'Clicks'='{2}';'Delta'='{3}';'Location'='{4}';'X'='{5}';'Y'='{6}'> ";

    [System.Console]::Clear();
    [System.Console]::Write($EventString, $Sender.Name, $MouseEventArgs.Button, $MouseEventArgs.Clicks, $MouseEventArgs.Delta, $MouseEventArgs.Location, $MouseEventArgs.X, $MouseEventArgs.Y);
}

function MouseUp([System.Object[]] $Arguments)
{
    [System.Object] $Sender = $Arguments[0];
    [System.Windows.Forms.MouseEventArgs] $MouseEventArgs = $Arguments[1];

    $EventString = " [Event]:{0}.MouseUp:<'Button'='{1}';'Clicks'='{2}';'Delta'='{3}';'Location'='{4}';'X'='{5}';'Y'='{6}'> ";

    [System.Console]::Clear();
    [System.Console]::Write($EventString, $Sender.Name, $MouseEventArgs.Button, $MouseEventArgs.Clicks, $MouseEventArgs.Delta, $MouseEventArgs.Location, $MouseEventArgs.X, $MouseEventArgs.Y);
}

function MouseWheel([System.Object[]] $Arguments)
{
    [System.Object] $Sender = $Arguments[0];
    [System.Windows.Forms.MouseEventArgs] $MouseEventArgs = $Arguments[1];

    $EventString = " [Event]:{0}.MouseWheel:<'Button'='{1}';'Clicks'='{2}';'Delta'='{3}';'Location'='{4}';'X'='{5}';'Y'='{6}'> ";

    [System.Console]::Clear();
    [System.Console]::Write($EventString, $Sender.Name, $MouseEventArgs.Button, $MouseEventArgs.Clicks, $MouseEventArgs.Delta, $MouseEventArgs.Location, $MouseEventArgs.X, $MouseEventArgs.Y);
}

function MouseMove([System.Object[]] $Arguments)
{
    [System.Object] $Sender = $Arguments[0];
    [System.Windows.Forms.MouseEventArgs] $MouseEventArgs = $Arguments[1];

    $EventString = " [Event]:{0}.MouseMove:<'Button'='{1}';'Clicks'='{2}';'Delta'='{3}';'Location'='{4}';'X'='{5}';'Y'='{6}'> ";

    [System.Console]::Clear();
    [System.Console]::Write($EventString, $Sender.Name, $MouseEventArgs.Button, $MouseEventArgs.Clicks, $MouseEventArgs.Delta, $MouseEventArgs.Location, $MouseEventArgs.X, $MouseEventArgs.Y);
}

function MouseEnter([System.Object[]] $Arguments)
{
    [System.Object] $Sender = $Arguments[0];
    [System.EventArgs] $EventArgs = $Arguments[1];

    $EventString = " [Event]:{0}.MouseEnter ";

    [System.Console]::Clear();
    [System.Console]::Write($EventString, $Sender.Name);
}

function MouseLeave([System.Object[]] $Arguments)
{
    [System.Object] $Sender = $Arguments[0];
    [System.EventArgs] $EventArgs = $Arguments[1];

    $EventString = " [Event]:{0}.MouseLeave ";

    [System.Console]::Clear();
    [System.Console]::Write($EventString, $Sender.Name);
}

function MoveEvent([System.Object[]] $Arguments)
{
    [System.Object] $Sender = $Arguments[0];
    [System.EventArgs] $EventArgs = $Arguments[1];

    $EventString = " [Event]:{0}.Move:<'Location'='{1}';> ";

    [System.Console]::Clear();
    [System.Console]::Write($EventString, $Sender.Name, $Sender.Location);
}

function Resize([System.Object[]] $Arguments)
{
    [System.Object] $Sender = $Arguments[0];
    [System.EventArgs] $EventArgs = $Arguments[1];

    $EventString = " [Event]:{0}.Resize:<'Size'='{1}';> ";

    [System.Console]::Clear();
    [System.Console]::Write($EventString, $Sender.Name, $Sender.Size);
}

$Global:TestVar = "";

function ReadCommunications()
{
    [System.IO.FileStream] $CommFile = [System.IO.File]::Open(".\communications.bin", [System.IO.FileMode]::OpenOrCreate);

    [byte[]] $buff = [byte[]]::New($CommFile.Length);
    $CommFile.Read($buff, 0, $CommFile.Length);
    $CommFile.Close();

    if ($buff[0] -eq 0xEE)
    {
        $Global:DrawExpression = ([System.Text.Encoding]::ASCII.GetString($buff[1..($buff.Length-2)]));
        $MainImage.Update();
    }
}

function Activated([System.Object[]] $Arguments)
{
    [System.Object] $Sender = $Arguments[0];

    $EventString = " [Event]:{0}.Activated:<'Value'='{1}';> ";

    #$Global:TestVar = [System.Environment]::CurrentDirectory;

    ReadCommunications;

    [System.Console]::Write($EventString, $Sender.Name, $Global:TestVar);
    [System.Windows.Forms.Application]::DoEvents();

    #$Global:TestVar = "";
}

$MainImage.add_Paint({MainImage_Paint($args[0], $args[1])});
$Form.add_KeyDown({Form_KeyDown($args[0], $args[1])});
$Form.add_KeyUp({Form_KeyUp($args[0], $args[1])});
$MainImage.add_MouseDown({MouseDown($args[0], $args[1])});
$MainImage.add_MouseUp({MouseUp($args[0], $args[1])});
$MainImage.add_MouseWheel({MouseWheel($args[0], $args[1])});
$MainImage.add_MouseMove({MouseMove($args[0], $args[1])});
$MainImage.add_MouseEnter({MouseEnter($args[0], $args[1])});
$MainImage.add_MouseLeave({MouseLeave($args[0], $args[1])});
$Form.add_Move({MoveEvent($args[0], $args[1])});
$Form.add_Resize({Resize($args[0], $args[1])});
$Form.add_Activated({Activated($args[0], $args[1])});

$Form.Controls.Add($MainImage);

#ReadCommunications;

[System.Windows.Forms.Application]::Run($Form);
[System.Windows.Forms.Application]::Exit();