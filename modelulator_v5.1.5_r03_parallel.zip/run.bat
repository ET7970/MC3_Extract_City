@echo off
pushd "%~dp0"
"%~dp0src\lua\lua54.exe" src\init.lua "%~dp0." %*
popd
