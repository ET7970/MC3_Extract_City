local ProgramInfo	= require("src.info");

local Name		= ProgramInfo.Name;
local Version		= ProgramInfo.Version;
local Build		= Version.Build;

local base64		= "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

local sVersion		= string.format("v%i.%i.%i+%i.%i.%s", Version.Major, Version.Minor, Version.Patch, Build.Time, Build.Release, Version.EnvironmentState);

return string.format("%s | %s", Name, sVersion);