--[[
local MainProgram			= nil;
local CommunicationsFile		= nil;
local whatitsaid			= "";
local whatitsayin			= "";

if (os.execute()) then
	print("we got a shell. neat-o");
end;

local cmd_PowerShell_fmt	= "powershell -ExecutionPolicy Bypass -file \".\\PowerShell\\%s.ps1\"";

local io_input				= io.input();
local io_output				= io.output();

local TroughBoundaries		=
{
	Next	= TroughBoundaries;
	Prev	= TroughBoundaries;
};

TroughBoundaries.Next = TroughBoundaries;
TroughBoundaries.Prev = TroughBoundaries;

_ENV.BigEndian = true;

local ColourCoding	=
{
	[0x00000000]	= {R = 128, G = 128, B = 128, A = 255};
	[0x00000001]	= {R = 255, G = 255, B = 255, A = 255};
	[0x00000100]	= {R = 255, G = 128, B = 0, A = 255};
	[0x00010000]	= {R = 255, G = 0, B = 0, A = 255};
};

local function LoadCommunicationsTroughBoundary()
	local Expression = "";
	
	if (ResourceFile.isopen) then
		local FilePointer	= 0x00000000;
		
		while (FilePointer < ResourceFile.size) do
			--print(string.format("0x%08X", FilePointer));
			
			local bChunkID		= ResourceFile:read_int(FilePointer + 0x00);
			local bChunkSize	= ResourceFile:read_int(FilePointer + 0x04);
			
			if ((bChunkID == 0x57944655) or (bChunkID == 0x00034190)) then
				local Next		= TroughBoundaries.Next;
				local Prev		= TroughBoundaries.Prev;
		
				local TroughBoundaryNode	=
				{
					Next	= Prev;
					Prev	= Next;
					
					Name	= ResourceFile:read_int(FilePointer + 0x10);
					Type	= ResourceFile:read_int(FilePointer + 0x60);
					ID0	= ResourceFile:read_short(FilePointer + 0x64);
					ID1	= ResourceFile:read_short(FilePointer + 0x66);
					
					BBox	=
					{
						Min = {ResourceFile:read_float(FilePointer + 0x68), ResourceFile:read_float(FilePointer + 0x6C)};
						Max = {ResourceFile:read_float(FilePointer + 0x70), ResourceFile:read_float(FilePointer + 0x74)};
					};
					
					Count	= ResourceFile:read_int(FilePointer + 0x78);
					
					Points	= {};
				};
				
				local ColourCode	= ColourCoding[TroughBoundaryNode.Type] or ColourCoding[0x00000000];
				
				Expression = Expression .. string.rep(" ", math.min(#Expression, 1));
				Expression = Expression .. string.format("$BasePen.Color = [System.Drawing.Color]::FromArgb(%i, %i, %i, %i);", ColourCode.A, ColourCode.R, ColourCode.G, ColourCode.B);
				
				for i = 0, TroughBoundaryNode.Count - 1 do
					local PointPointer = FilePointer + 0x7C + i * 0x8;
					local Point = {ResourceFile:read_float(PointPointer + 0x00), ResourceFile:read_float(PointPointer + 0x04)};
					
					table.insert(TroughBoundaryNode.Points, Point);
					
					if (i > 0) then
						local x0, y0 = TroughBoundaryNode.Points[i][1], TroughBoundaryNode.Points[i][2];
						local x1, y1 = TroughBoundaryNode.Points[(i % (TroughBoundaryNode.Count)) + 1][1], TroughBoundaryNode.Points[(i % TroughBoundaryNode.Count) + 1][2];
						
						x0 = math.floor((x0 + 7300) * 0.256 + 0.5);
						y0 = math.floor((-y0 + 14000) * 0.256 + 0.5);
						
						x1 = math.floor((x1 + 7300) * 0.256 + 0.5);
						y1 = math.floor((-y1 + 14000) * 0.256 + 0.5);
						
						Expression = Expression .. string.rep(" ", math.min(#Expression, 1));
						Expression = Expression .. string.format("$g.DrawLine($BasePen, %i, %i, %i, %i);", x0, y0, x1, y1);
					end;
				end;
				
				local x0, y0 = TroughBoundaryNode.Points[TroughBoundaryNode.Count][1], TroughBoundaryNode.Points[TroughBoundaryNode.Count][2];
				local x1, y1 = TroughBoundaryNode.Points[1][1], TroughBoundaryNode.Points[1][2];
				
				x0 = math.floor((x0 + 7300) * 0.256 + 0.5);
				y0 = math.floor((-y0 + 14000) * 0.256 + 0.5);
				
				x1 = math.floor((x1 + 7300) * 0.256 + 0.5);
				y1 = math.floor((-y1 + 14000) * 0.256 + 0.5);
				
				Expression = Expression .. string.rep(" ", math.min(#Expression, 1));
				Expression = Expression .. string.format("$g.DrawLine($BasePen, %i, %i, %i, %i);", x0, y0, x1, y1);
				
				TroughBoundaryNode.Prev.Next = TroughBoundaryNode;
				TroughBoundaryNode.Next.Prev = TroughBoundaryNode;
			end;
			
			FilePointer = FilePointer + 0x08 + bChunkSize;
			print(string.format("%.2f%%", FilePointer / ResourceFile.size * 100));
		end;
	end;
	
	local PowerShellScript	= "communications";
	CommunicationsFile	= assert(io.open(string.format(".\\%s.bin", PowerShellScript), "wb"));
	
	CommunicationsFile:write("\xEE" .. Expression .. "\xEE");
	CommunicationsFile:close();
	
	--io.output(CommunicationsProgram);
	--io.output(io_output);
	--io.output():read(1);
end;

local Expression = "";

local function ToMinimapSpace(vec3)
	return math.floor((vec3.x + 7300) * 0.256 + 0.5), math.floor((-vec3.x + 14000) * 0.256 + 0.5);
end;

local function SurfaceNormal(A, B, C)
	local u = {x = B.x - A.x, y = B.y - A.y, z = B.z - A.z};
	local v = {x = C.x - A.x, y = C.y - A.y, z = C.z - A.z};
	
	local cx = u.y * v.z - u.z * v.y;
	local cy = u.z * v.x - u.x * v.z;
	local cz = u.x * v.y - u.y * v.x;
	
	local c = math.sqrt(cx * cx + cy * cy + cz * cz);
	
	if (c > 0) then
		c = 1 / c;
	end;
	
	return {x = cx * c, y = cy * c, z = cz * c};
end;

local function LoadSurfaceCollision(Address, px, py, pz)
	local TriangleStrips		= {};
	
	local fmt = _ENV.Config.BigEndian and ">" or "<";
	
	if (ResourceFile.isopen) then
		local FilePointer	= 0x00000000 + Address;
		
		local Header		=
		{
			Count		= ResourceFile:read_data(FilePointer + 0x00, fmt .. "h");
			TagOffset	= ResourceFile:read_data(FilePointer + 0x02, fmt .. "h");
			Unk0		= ResourceFile:read_data(FilePointer + 0x08, fmt .. "B");
			TagCount	= ResourceFile:read_data(FilePointer + 0x09, fmt .. "b");
			TagSize		= ResourceFile:read_data(FilePointer + 0x0A, fmt .. "h");
			ID		= ResourceFile:read_data(FilePointer + 0x0C, fmt .. "i");
		};
		
		FilePointer		= FilePointer + 0x10;
		
		for i = 0, Header.Count - 1 do
			local Vertices		= {};
			
			local ReferenceObject	=
			{
				Center		= 
				{
					x	= ResourceFile:read_data(FilePointer + i * 0x10 + 0x00, fmt .. "f");
					y	= ResourceFile:read_data(FilePointer + i * 0x10 + 0x04, fmt .. "f");
					z	= ResourceFile:read_data(FilePointer + i * 0x10 + 0x08, fmt .. "f");
				};
				Angle		= ResourceFile:read_data(FilePointer + i * 0x10 + 0x0C, fmt .. "h");
				Offset		= ResourceFile:read_data(FilePointer + i * 0x10 + 0x0E, fmt .. "H");
			};
			
			--print(string.format("%i \xF8", ReferenceObject.Angle));
			
			local VertexOffset	= FilePointer + ReferenceObject.Offset;
			local NumVertices	= ResourceFile:read_data(VertexOffset + 0x6 + (BigEndian and 0x1 or 0x0), fmt .. "b");
			
			local tx, ty, tz = 0, 0, 0;
			
			for j = 0, NumVertices - 1 do
				local Vertex	=
				{
					x	= ResourceFile:read_data(VertexOffset + j * 0x8 + 0x00, fmt .. "h");
					y	= ResourceFile:read_data(VertexOffset + j * 0x8 + 0x02, fmt .. "h");
					z	= ResourceFile:read_data(VertexOffset + j * 0x8 + 0x04, fmt .. "h");
					Count	= ResourceFile:read_data(VertexOffset + j * 0x8 + 0x06 + (BigEndian and 0x1 or 0x0), fmt .. "b");
					Unk	= ResourceFile:read_data(VertexOffset + j * 0x8 + 0x07 - (BigEndian and 0x1 or 0x0), fmt .. "b");
				};
				
				tx, ty, tz = Vertex.z / 128, Vertex.y / 128, Vertex.x / 128;
				
				tx = tx + ReferenceObject.Center.z - px;
				ty = ty + ReferenceObject.Center.y - py;
				tz = -tz - ReferenceObject.Center.x + pz;
				
				table.insert(Vertices, {x = tx, y = ty, z = tz, cnt = Vertex.Count});
			end;
			
			table.insert(TriangleStrips, Vertices);
		end;
		
		return TriangleStrips;
	end;
end;

local function LoadTestWindow()
	local PowerShellScript	= "TestWindow";
	MainProgram		= assert(io.popen(string.format(cmd_PowerShell_fmt, PowerShellScript), "r"));
	MainProgram:read("*a");
	--io.input(MainProgram);
	--io.input():read(1);
end;

local MainProgramOpen			= false;

local MessageQueue			= {};
local MessageHandlers			= {};

local function MessageToString(Message)
	local Keys	=
	{
		"Subject";
		"Name";
		"Sender";
		"Received";
		"Arguments";
	};
	
	local ConsoleString = "";
	
	--print("handling");
	
	for i = 1, #Keys do
		local KeyString = Keys[i];
		local Value = Message[KeyString];
		
		if (Value ~= nil) then
			local ConsoleStringBuffer = string.format("%-16s", KeyString .. ":");
			
			if (string.lower(type(Value)) == "table") then
				for k, v in pairs(Value) do
					ConsoleStringBuffer = ConsoleStringBuffer .. string.rep("\n\t", math.min(#ConsoleStringBuffer, 1));
					ConsoleStringBuffer = ConsoleStringBuffer .. string.format("%s = \"%s\"", k, v);
				end;
			else
				ConsoleStringBuffer = ConsoleStringBuffer .. string.format("\"%s\"", Value);
			end;
			
			ConsoleString = ConsoleString .. string.rep("\n", math.min(#ConsoleString * #ConsoleStringBuffer, 1));
			ConsoleString = ConsoleString .. ConsoleStringBuffer;
		end;
	end;
	
	return ConsoleString;
end;

--[[
function MessageHandlers.MouseEnter(Message)
	print("\n" .. MessageToString(Message));
end;

function MessageHandlers.MouseLeave(Message)
	print("\n" .. MessageToString(Message));
end;
--]]

local Test = true;

function MessageHandlers.Read(Message)
	print("\n" .. MessageToString(Message));
	--Test = false;
end;

function MessageHandlers.Move(Message)
	--[[
	print("\n" .. MessageToString(Message));
	--]]
end;

function MessageHandlers.Resize(Message)
	--[[
	print("\n" .. MessageToString(Message));
	--]]
end;

local MouseButtons	=
{
	Left		= false;
	Right		= false;
	Middle		= false;
	XButton1	= false;
	XButton2	= false;
};

function MessageHandlers.MouseDown(Message)
	--[[
	print("\n" .. MessageToString(Message));
	--]]
	
	MouseButtons[Message.Arguments.Button] = true;
	
	--print(string.format("MouseButtons.%s = %s", Message.Arguments.Button, MouseButtons[Message.Arguments.Button]));
	
	--print("");
end;

function MessageHandlers.MouseUp(Message)
	--[[
	print("\n" .. MessageToString(Message));
	--]]
	
	MouseButtons[Message.Arguments.Button] = false;
	
	--print(string.format("MouseButtons.%s = %s", Message.Arguments.Button, MouseButtons[Message.Arguments.Button]));
end;

local function HandleMessage(Message)
	if (MessageHandlers[Message.Name] ~= nil) then
		MessageHandlers[Message.Name](Message);
	end;
end;

local PrintOnHandle	=
{
	["MouseDown"]	= true;
	["MouseUp"]	= true;
	["KeyDown"]	= true;
	["KeyUp"]	= true;
	["Activated"]	= true;
	["Tick"]	= true;
};

local function DemistifyMessage(TimeReceived, MessageString)
	--print(TimeReceived, MessageString);
	
	local MessageSubject	= string.match(MessageString, "(%b[]):", 1);
	MessageString		= string.sub(MessageString, #MessageSubject + 2, -1);
	local MessageSender	= string.match(MessageString, "(.+)%.", 1);
	MessageString		= string.sub(MessageString, #MessageSender + 2, -1);
	local MessageTitle	= string.match(MessageString, "[%w_]+", 1)
	MessageString		= string.sub(MessageString, #MessageTitle + 1, -1);
	local MessageArgsString	= string.match(MessageString, ":(%b<>)", 1) or "<>";
	MessageString		= string.sub(MessageString, #MessageArgsString + 2, -1);
	
	MessageSubject		= string.sub(MessageSubject, 2, -2);
	
	--print(MessageSubject);
	--print(MessageSender);
	--print(MessageTitle);
	
	MessageArgsString = string.sub(MessageArgsString, 2, -2);
	
	local MessageArguments	= {};
	local NumArgs		= 0;
	
	for arg in string.gmatch(MessageArgsString, "%b''=%b''[;]?") do
		local key, value = string.match(arg, "(%b'')=(%b'')[;]?");
		if ((key ~= nil) and (value ~= nil)) then
			key	= string.sub(key, 2, -2);
			value	= string.sub(value, 2, -2);
			
			MessageArguments[key]	= value;
			
			NumArgs = NumArgs + 1;
			
			--print(string.format("%s = \"%s\"", key, value));
		end;
	end;
	
	if (NumArgs <= 0) then
		MessageArguments = nil;
	end;
	
	local MessageObject	=
	{
		Subject		= MessageSubject;
		Name		= MessageTitle;
		Sender		= MessageSender;
		Received	= TimeReceived;
		Arguments	= MessageArguments;
	};
	
	--table.insert(MessageQueue, MessageObject);
	
	---[[
	if (PrintOnHandle[MessageObject.Name] == true) then
		print("\n" .. MessageToString(MessageObject));
	end;
	--]]
	
	--print("\n" .. MessageToString(MessageObject));
	
	HandleMessage(MessageObject);
	
	--print(MessageString);
end;

local Timer	= 0;

local Debounce	= false;

local function ProcessMainProgram()
	local f = coroutine.create
	(
	function()
		local function ReadSentMessage(TimeReceived, WhatItSayin)
			local __whatitsayin = WhatItSayin;
			local __whatitmeans = "";
			
			if (__whatitsayin == "\xFF") then
				__whatitsayin = MainProgram:read(1);
				
				if (__whatitsayin ~= "\xFF") then
					repeat
						__whatitmeans = __whatitmeans .. __whatitsayin;
						__whatitsayin = MainProgram:read(1);
					until (__whatitsayin == "\xFF");
				else
					return;
				end;
			else
				return;
			end;
			
			if (#__whatitmeans > 0) then
				--print(__whatitmeans);
				DemistifyMessage(TimeReceived, __whatitmeans);
			end;
		end;
		
		while (true) do
			if (MainProgram ~= nil) then
				MainProgramOpen	= true;
				whatitsaid = whatitsayin;
				whatitsayin = MainProgram:read(1);
				
				if (whatitsayin == nil) then
					MainProgramOpen	= false;
					coroutine.yield(false);
				else
					local time_received = os.clock();
					
					local coReadSentMsg = coroutine.wrap(ReadSentMessage);
					coReadSentMsg(time_received, whatitsayin);
				end;
				--local whereitat	= MainProgram:seek();
			end;
			coroutine.yield(true);
		end;
	end
	);
	
	return f;
end;

local function ProcessCommunicationsProgram()
	local f = coroutine.create
	(
	function()
		while (true) do
			if (CommunicationsProgram ~= nil) then
				CommunicationsProgram:write(1);
				CommunicationsProgram:close();
			else
				coroutine.yield(false);
			end;
			coroutine.yield(true);
		end;
	end
	);
	
	return f;
end;
--]]

return {};