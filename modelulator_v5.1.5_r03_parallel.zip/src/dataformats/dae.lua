local build_str		= require("src.build");

local collada	= {};
local XML	= {};

local Lua	= {};

local LuaTypes	=
{
	[-1]	= "none";
	[0]	= "nil";
	[1]	= "boolean";
	[2]	= "light userdata";
	[3]	= "number";
	[4]	= "string";
	[5]	= "table";
	[6]	= "function";
	[7]	= "userdata";
	[8]	= "thread";
};

local InvalidCharsPattern	= "([%c%s%p]*)";
	
local function XMLEscape(StringToEscape)
	return string.format(string.rep("&#%i;", #StringToEscape), string.byte(StringToEscape, 1, #StringToEscape));
end;

local function URLEscape(StringToEscape)
	return string.format(string.rep("%%%02X", #StringToEscape), string.byte(StringToEscape, 1, #StringToEscape));
end;

function XML:Tag(Name, Parent, IsSingleValue, IsHeader)
	IsSingleValue		= (IsSingleValue == true); -- more truth behind it than (IsSingleValue ~= nil)
	IsHeader		= (IsHeader == true);
	
	local xmltag		=
	{
		Type		= "XMLTag";
		Parent		= nil;
		Index		= 0;
		
		Name		= Name or "";
		Attributes	= {};
		NumChildren	= 0;
	};
	
	function xmltag.SetParent(self, parent)
		if ((self.Parent ~= nil) and (type(self.Parent) == "table")) then
			if (self.Parent.Type == "XMLTag") then
				table.remove(self.Parent, math.min(self.Index, #self.Parent.NumChildren));
				self.Parent.NumChildren = self.Parent.NumChildren - 1;
			else
				table.remove(self.Parent, math.min(self.Index, #self.Parent));
			end;
		end;
		
		self.Parent	= nil;
		self.Index	= 0;
		
		if ((parent ~= nil) and (type(parent) == "table")) then
			table.insert(parent, self);
			
			if (parent.Type == "XMLTag") then
				parent.NumChildren	= parent.NumChildren + 1;
				self.Index		= parent.NumChildren;
			else
				self.Index		= #parent + 1;
			end;
			
			self.Parent	= parent;
			
		else
			self.Parent	= nil;
			self.Index	= 0;
		end;
		
		return;
	end;
	
	function xmltag.GetAttribute(self, name)
		for i = 1, #self.Attributes do
			if (self.Attributes[i].Name == name) then
				return self.Attributes[i].Value;
			end;
		end;
		
		return;
	end;
	
	function xmltag.SetAttribute(self, name, value)
		for i = 1, #self.Attributes do
			if (self.Attributes[i].Name == name) then
				self.Attributes[i].Value = value;
				return;
			end;
		end;
		
		table.insert(self.Attributes, {Name = name, Value = value});
		return;
	end;
	
	function xmltag.AddChild(self, child)
		if (type(child) == "table" and child.Type == "XMLTag") then
			child:SetParent(self);
		else
			self.NumChildren = self.NumChildren + 1;
			table.insert(self, child);
		end;
	end;
	
	function xmltag.__tostring(self, level)
		level = level or 0;
		
		local xml_tag_string = "";
		
		local xml_tag_elements = {self.Name};
		
		for i = 1, #self.Attributes do
			local xml_tag_attribute_string = string.format("%s=\"%s\"", self.Attributes[i].Name, self.Attributes[i].Value);
			table.insert(xml_tag_elements, xml_tag_attribute_string);
		end;
		
		xml_tag_string = xml_tag_string .. table.concat(xml_tag_elements, " ");
		
		if (IsHeader) then
			xml_tag_string = string.rep("\t", level) .. string.format("<?%s?>", xml_tag_string);
		else
			xml_tag_string = string.rep("\t", level) .. string.format("<%s%s>", xml_tag_string, string.rep("/", 1 - math.min(self.NumChildren, 1)));
		end;
		
		if (self.NumChildren > 0) then
			if ((self.NumChildren > 1) or ((self.NumChildren == 1) and (type(self[1]) == "table" and self[1].Type == "XMLTag"))) then
				level = level + 1;
				
				for i = 1, self.NumChildren do
					xml_tag_string = xml_tag_string .. "\n";
					
					if (type(self[i]) == "table" and self[i].Type == "XMLTag") then
						xml_tag_string = xml_tag_string .. self[i]:__tostring(level);
					else
						xml_tag_string = xml_tag_string .. string.rep("\t", level) .. tostring(self[i]);
					end;
				end;
				
				xml_tag_string = xml_tag_string .. "\n";
				
				level = level - 1;
				
				xml_tag_string = xml_tag_string .. string.rep("\t", level) .. string.format("</%s>", self.Name);
			else
				xml_tag_string = xml_tag_string .. tostring(self[1]);
				xml_tag_string = xml_tag_string .. string.format("</%s>", self.Name);
			end;
		end;
		
		return xml_tag_string;
	end;
	
	if (Parent ~= nil) then
		xmltag:SetParent(Parent);
	end;
	
	return xmltag;
end;

XML.Macro	= {};

function XML.Macro:Add(Name, func)
	XML.Macro[Name] = func;
end;

XML.Macro:Add
(
	"COLLADA",
	function(Parent)
		local TAG	= XML:Tag("COLLADA", Parent);
		TAG:SetAttribute("xmlns", "http://www.collada.org/2005/11/COLLADASchema");
		TAG:SetAttribute("version", "1.4.1");
		TAG:SetAttribute("xmlns:xsi", "http://www.w3.org/2001/XMLSchema-instance");
		return TAG;
	end
);

XML.Macro:Add
(
	"asset",
	function(Parent)
		local asset		= XML:Tag("asset", Parent);
		
		local contributor	= XML:Tag("contributor", asset);
		
		local author		= XML:Tag("author", contributor);
		author:AddChild("method man");
		
		local authoring_tool	= XML:Tag("authoring_tool", contributor);
		authoring_tool:AddChild(string.format("%s", build_str));
		
		local created		= XML:Tag("created", asset);
		created:AddChild(os.date("%Y-%m-%dT%H:%M:%S"));
		
		local modified		= XML:Tag("modified", asset);
		modified:AddChild(os.date("%Y-%m-%dT%H:%M:%S"));
		
		local unit		= XML:Tag("unit", asset);
		unit:SetAttribute("name", "meter");
		unit:SetAttribute("meter", 1);
		
		local up_axis		= XML:Tag("up_axis", asset);
		up_axis:AddChild("Z_UP");
		
		return asset;
	end
);

XML.Macro:Add
(
	"float",
	function(Parent, sid, value_float)
		local float		= XML:Tag("float", Parent);
		float:SetAttribute("sid", sid);
		
		float:AddChild(value_float);
		
		return float;
	end
);

XML.Macro:Add
(
	"param",
	function(Parent, name, __type)
		local param		= XML:Tag("param", Parent);
		param:SetAttribute("name", name);
		param:SetAttribute("type", __type);
		
		return param;
	end
);

XML.Macro:Add
(
	"input",
	function(Parent, semantic, source, offset, set)
		local input		= XML:Tag("input", Parent);
		input:SetAttribute("semantic", semantic);
		input:SetAttribute("source", string.format("#%s", source));
		if (offset ~= nil) then input:SetAttribute("offset", offset); end;
		if (set ~= nil) then input:SetAttribute("set", set); end;
		
		return input;
	end
);

XML.Macro:Add
(
	"technique_common",
	function(Parent)
		local technique_common		= XML:Tag("technique_common", Parent);
		return technique_common;
	end
);

XML.Macro:Add
(
	"accessor",
	function(Parent, source, count, stride)
		local accessor			= XML:Tag("accessor", Parent);
		accessor:SetAttribute("source", string.format("#%s", source));
		accessor:SetAttribute("count", count);
		accessor:SetAttribute("stride", stride);
		
		return accessor;
	end
);

XML.Macro:Add
(
	"float_array",
	function(Parent, id, value_float_array)
		local float_array		= XML:Tag("float_array", Parent);
		float_array:SetAttribute("id", id);
		float_array:SetAttribute("count", #value_float_array);
		
		float_array:AddChild(table.concat(value_float_array, " "));
		
		return float_array;
	end
);

XML.Macro:Add
(
	"color",
	function(Parent, sid, value_rgba)
		local color		= XML:Tag("color", Parent);
		color:SetAttribute("sid", sid);
		
		color:AddChild(table.concat(value_rgba, " "));
		
		return color;
	end
);

XML.Macro:Add
(
	"diffuse",
	function(Parent, rgba)
		local diffuse		= XML:Tag("diffuse", Parent);
		XML.Macro.color(diffuse, "diffuse", rgba);
		
		return diffuse;
	end
);

XML.Macro:Add
(
	"emission",
	function(Parent, rgba)
		local emission		= XML:Tag("emission", Parent);
		XML.Macro.color(emission, "emission", rgba);
		
		return emission;
	end
);

XML.Macro:Add
(
	"index_of_refraction",
	function(Parent, ior)
		local index_of_refraction	= XML:Tag("index_of_refraction", Parent);
		XML.Macro.float(index_of_refraction, "ior", ior);
		
		return index_of_refraction;
	end
);

XML.Macro:Add
(
	"image",
	function(Parent, id, directory)
		local image		= XML:Tag("image", Parent);
		image:SetAttribute("id", id);
		image:SetAttribute("name", "__" .. id);
		
		local init_from		= XML:Tag("init_from", image);
		init_from:AddChild(string.format("%s", directory));
		
		return image;
	end
);

XML.Macro:Add
(
	"instance_image",
	function(Parent, url)
		local instance_image	= XML:Tag("instance_image", Parent);
		instance_image:SetAttribute("url", string.format("#%s", url));
		
		return instance_image;
	end
);

XML.Macro:Add
(
	"sampler2D",
	function(Parent, sid, surface_id)
		local new_param		= XML:Tag("new_param", Parent);
		new_param:SetAttribute("sid", sid);
		
		local sampler2D		= XML:Tag("sampler2D", new_param);
		
		local source		= XML:Tag("source", sampler2D);
		source:AddChild(surface_id);
		
		local minfilter		= XML:Tag("minfilter", sampler2D);
		minfilter:AddChild("LINEAR_MIPMAP_LINEAR");
		
		local magfilter		= XML:Tag("magfilter", sampler2D);
		magfilter:AddChild("LINEAR");
		
		return new_param;
	end
);


XML.Macro:Add
(
	"effect",
	function(Parent, id, sid, image_id, unused)
		local effect		= XML:Tag("effect", Parent);
		effect:SetAttribute("id", id);
		
		local profile		= XML:Tag("profile_COMMON", effect);
		
		--[[
		local new_param		= XML:Tag("new_param", profile);
		new_param:SetAttribute("sid", "texture-surface");
		
		local surface		= XML:Tag("surface", new_param);
		surface:SetAttribute("type", "2D");
		
		local init_from		= XML:Tag("init_from", surface);
		init_from:AddChild(string.lower(image_id));
		
		local sampler2D		= XML.Macro.sampler2D(profile, "texture-sampler2D", "texture-surface");
		--]]
		
		
		local technique		= XML:Tag("technique", profile);
		technique:SetAttribute("sid", "common");
		
		local blinn		= XML:Tag("blinn", technique);
		
		XML.Macro.emission(blinn, {0, 0, 0, 1});
		XML.Macro.index_of_refraction(blinn, 1.45);
		local diffuse_tag = XML.Macro.diffuse(blinn, {1, 1, 1, 1});
		
		--[[
		if (not unused) then
			local texture		= XML:Tag("texture", diffuse_tag);
			texture:SetAttribute("texture", "texture-sampler2D");
			texture:SetAttribute("texcoord", string.format("texcoord_%s", id));
		end;
		--]]
		
		return effect;
	end
);

XML.Macro:Add
(
	"material",
	function(Parent, name, id, effect_id)
		local material		= XML:Tag("material", Parent);
		material:SetAttribute("id", id);
		material:SetAttribute("name", name);
		
		local instance_effect	= XML:Tag("instance_effect", material);
		instance_effect:SetAttribute("url", string.format("#%s", effect_id));
	end
);

XML.Macro:Add
(
	"source",
	function(Parent, id)
		local source		= XML:Tag("source", Parent);
		source:SetAttribute("id", id);
		
		return source;
	end
);

XML.Macro:Add
(
	"visual_scene",
	function(Parent, id)
		local visual_scene	= XML:Tag("visual_scene", Parent);
		visual_scene:SetAttribute("id", id);
		
		return visual_scene;
	end
);

XML.Macro:Add
(
	"node",
	function(Parent, id, name, __type)
		local node		= XML:Tag("node", Parent);
		node:SetAttribute("id", id);
		node:SetAttribute("name", name);
		node:SetAttribute("type", __type);
		
		return node;
	end
);

XML.Macro:Add
(
	"geometry",
	function(Parent, id, position, normal, normal_calc, colour, texcoord)
		local geometry		= XML:Tag("geometry", Parent);
		geometry:SetAttribute("id", id);
		--geometry:SetAttribute("name", name);
		
		local mesh	= XML:Tag("mesh", geometry);
		
		local source0	= XML.Macro.source(mesh, "src-position");
		local source1	= XML.Macro.source(mesh, "src-normal");
		local source2	= XML.Macro.source(mesh, "src-normal-calc");
		local source3	= XML.Macro.source(mesh, "src-colour0");
		local source4	= XML.Macro.source(mesh, "src-colour1");
		
		local float_array0	= XML.Macro.float_array(source0, "src-position-array", position);
		local common0		= XML.Macro.technique_common(source0);
		local accessor0		= XML.Macro.accessor(common0, float_array0:GetAttribute("id"), (#position) // 3, 3);
		XML.Macro.param(accessor0, "X", "float");
		XML.Macro.param(accessor0, "Y", "float");
		XML.Macro.param(accessor0, "Z", "float");
		
		local float_array1	= XML.Macro.float_array(source1, "src-normal-array", normal);
		local common1		= XML.Macro.technique_common(source1);
		local accessor1		= XML.Macro.accessor(common1, float_array1:GetAttribute("id"), (#normal) // 3, 3);
		XML.Macro.param(accessor1, "X", "float");
		XML.Macro.param(accessor1, "Y", "float");
		XML.Macro.param(accessor1, "Z", "float");
		
		local float_array2	= XML.Macro.float_array(source2, "src-normal-calc-array", normal_calc);
		local common2		= XML.Macro.technique_common(source2);
		local accessor2		= XML.Macro.accessor(common2, float_array2:GetAttribute("id"), (#normal_calc) // 3, 3);
		XML.Macro.param(accessor2, "X", "float");
		XML.Macro.param(accessor2, "Y", "float");
		XML.Macro.param(accessor2, "Z", "float");
		
		local float_array3	= XML.Macro.float_array(source3, "src-colour0-array", colour);
		local common3		= XML.Macro.technique_common(source3);
		local accessor3		= XML.Macro.accessor(common3, float_array3:GetAttribute("id"), (#colour) // 4, 4);
		XML.Macro.param(accessor3, "R", "float");
		XML.Macro.param(accessor3, "G", "float");
		XML.Macro.param(accessor3, "B", "float");
		XML.Macro.param(accessor3, "A", "float");
		
		local float_array4	= XML.Macro.float_array(source4, "src-colour1-array", colour);
		local common4		= XML.Macro.technique_common(source4);
		local accessor4		= XML.Macro.accessor(common4, float_array4:GetAttribute("id"), (#colour) // 4, 4);
		XML.Macro.param(accessor4, "R", "float");
		XML.Macro.param(accessor4, "G", "float");
		XML.Macro.param(accessor4, "B", "float");
		XML.Macro.param(accessor4, "A", "float");
		
		for i = 0, 7 do
			local source5		= XML.Macro.source(mesh, string.format("src-texcoord%i", i));
			local float_array5	= XML.Macro.float_array(source5, string.format("src-texcoord%i-array", i), texcoord);
			local common5		= XML.Macro.technique_common(source5);
			local accessor5		= XML.Macro.accessor(common5, float_array5:GetAttribute("id"), (#texcoord) // 2, 2);
			XML.Macro.param(accessor5, "S", "float");
			XML.Macro.param(accessor5, "T", "float");
		end;
		
		local vertices		= XML:Tag("vertices", mesh);
		vertices:SetAttribute("id", "verts");
		
		local v_input0		= XML.Macro.input(vertices, "POSITION", source0:GetAttribute("id"));
		
		return geometry, mesh;
	end
);

XML.Macro:Add
(
	"geometry2",
	function(Parent, id, position, normal, normal_calc, colour, texcoord)
		local geometry		= XML:Tag("geometry", Parent);
		geometry:SetAttribute("id", id);
		--geometry:SetAttribute("name", name);
		
		local mesh	= XML:Tag("mesh", geometry);
		
		local source0	= XML.Macro.source(mesh, "src-position");
		local source1	= XML.Macro.source(mesh, "src-normal");
		local source2	= XML.Macro.source(mesh, "src-normal-calc");
		local source3	= XML.Macro.source(mesh, "src-colour0");
		local source4	= XML.Macro.source(mesh, "src-colour1");
		
		local float_array0	= XML.Macro.float_array(source0, "src-position-array", position);
		local common0		= XML.Macro.technique_common(source0);
		local accessor0		= XML.Macro.accessor(common0, float_array0:GetAttribute("id"), (#position) // 3, 3);
		XML.Macro.param(accessor0, "X", "float");
		XML.Macro.param(accessor0, "Y", "float");
		XML.Macro.param(accessor0, "Z", "float");
		
		local float_array1	= XML.Macro.float_array(source1, "src-normal-array", normal);
		local common1		= XML.Macro.technique_common(source1);
		local accessor1		= XML.Macro.accessor(common1, float_array1:GetAttribute("id"), (#normal) // 3, 3);
		XML.Macro.param(accessor1, "X", "float");
		XML.Macro.param(accessor1, "Y", "float");
		XML.Macro.param(accessor1, "Z", "float");
		
		local float_array2	= XML.Macro.float_array(source2, "src-normal-calc-array", normal_calc);
		local common2		= XML.Macro.technique_common(source2);
		local accessor2		= XML.Macro.accessor(common2, float_array2:GetAttribute("id"), (#normal_calc) // 3, 3);
		XML.Macro.param(accessor2, "X", "float");
		XML.Macro.param(accessor2, "Y", "float");
		XML.Macro.param(accessor2, "Z", "float");
		
		local float_array3	= XML.Macro.float_array(source3, "src-colour0-array", colour[1]);
		local common3		= XML.Macro.technique_common(source3);
		local accessor3		= XML.Macro.accessor(common3, float_array3:GetAttribute("id"), (#colour[1]) // 4, 4);
		XML.Macro.param(accessor3, "R", "float");
		XML.Macro.param(accessor3, "G", "float");
		XML.Macro.param(accessor3, "B", "float");
		XML.Macro.param(accessor3, "A", "float");
		
		local float_array4	= XML.Macro.float_array(source4, "src-colour1-array", colour[2]);
		local common4		= XML.Macro.technique_common(source4);
		local accessor4		= XML.Macro.accessor(common4, float_array4:GetAttribute("id"), (#colour[2]) // 4, 4);
		XML.Macro.param(accessor4, "R", "float");
		XML.Macro.param(accessor4, "G", "float");
		XML.Macro.param(accessor4, "B", "float");
		XML.Macro.param(accessor4, "A", "float");
		
		for i = 0, 7 do
			local source5		= XML.Macro.source(mesh, string.format("src-texcoord%i", i));
			local float_array5	= XML.Macro.float_array(source5, string.format("src-texcoord%i-array", i), texcoord[-~i]);
			local common5		= XML.Macro.technique_common(source5);
			local accessor5		= XML.Macro.accessor(common5, float_array5:GetAttribute("id"), (#texcoord[-~i]) // 2, 2);
			XML.Macro.param(accessor5, "S", "float");
			XML.Macro.param(accessor5, "T", "float");
		end;
		
		local vertices		= XML:Tag("vertices", mesh);
		vertices:SetAttribute("id", "verts");
		
		local v_input0		= XML.Macro.input(vertices, "POSITION", source0:GetAttribute("id"));
		
		return geometry, mesh;
	end
);

XML.Macro:Add
(
	"xml",
	function(Parent)
		local xml	= XML:Tag("xml", Parent, false, true);
		xml:SetAttribute("version", "1.0");
		xml:SetAttribute("encoding", "utf-8");
		
		return xml;
	end
);

function collada:new_solid(xSolid, SectionName)
	local XML_ENV	= {};
	
	local xml			= XML.Macro.xml(XML_ENV);
	
	local COLLADA			= XML.Macro.COLLADA(XML_ENV);
	local asset			= XML.Macro.asset(COLLADA);
	
	COLLADA:AddChild("");
	
	local library_images		= XML:Tag("library_images", COLLADA);
	
	COLLADA:AddChild("");
	
	local library_materials		= XML:Tag("library_materials", COLLADA);
	
	COLLADA:AddChild("");
	
	local library_effects		= XML:Tag("library_effects", COLLADA);
	
	COLLADA:AddChild("");
	
	local library_geometries	= XML:Tag("library_geometries", COLLADA);
	
	COLLADA:AddChild("");
	
	local library_nodes		= XML:Tag("library_nodes", COLLADA);
	
	--[[
	local library_visual_scenes	= XML:Tag("library_visual_scenes", COLLADA)
	
	COLLADA:AddChild("");
	
	local scene			= XML:Tag("scene", COLLADA);
	---]]
	
	--
	
	local eSolid		= xSolid.EcstasySolid or xSolid.xSolidInfo;
	local xSolidInfo	= xSolid.xSolidInfo;
	
	local MaterialTable	= {};
	local TextureList	= {};
	local MaterialList	= {};
	
	--[[
	-- default material (for negative light material indices)
	do
		local NameHash_TEX	= 0xFFFFFFFF;
		local NameHash_ELM	= 0xFFFFFFFF;
		
		local Name		= string.format("x%02X_TEX0x%08X_MAT0x%08X", 0xFF, NameHash_TEX, NameHash_ELM);
		
		local effect_id		= string.format("effect_%s", Name);
		local material_id	= string.format("material_%s", Name);
		
		image_id 		= string.format("image_0x%08X", NameHash_TEX)
		local texture_dir	= "";
			
		XML.Macro.image(library_images, image_id, texture_dir);
		
		XML.Macro.effect(library_effects, effect_id, Name, image_id, true);
		XML.Macro.material(library_materials, Name, material_id, effect_id);
		
		table.insert(MaterialList, Name);
	end;
	--]]
	
	local NumStrips		= eSolid.NumStrips or xSolidInfo.NumStrips or xSolidInfo.NumMeshEntries;
	
	for i = 1, NumStrips do
		local StripEntry	= xSolidInfo.StripEntryTable[i];
		
		local TEX		= eSolid.pTextureTable[StripEntry.TextureIndex + 1];
		local ELM		= eSolid.LightMaterialTable[StripEntry.LightMaterialIndex + 1];
		
		local NameHash_TEX	= (TEX ~= nil) and TEX.NameHash or 0xFFFFFFFF;
		local NameHash_ELM	= (ELM ~= nil) and ELM.NameHash or 0xFFFFFFFF;
		
		local Name		= string.format("x%02X_TEX0x%08X_MAT0x%08X", StripEntry.PolyGroupNumber, NameHash_TEX, NameHash_ELM);
		
		local image_id		= "";
		
		if (MaterialTable[NameHash_TEX] == nil) then
			MaterialTable[NameHash_TEX] = {};
			
			--[[
			image_id 		= string.format("image_0x%08X", NameHash_TEX)
			local texture_dir	= string.format("..\\Textures\\0x%08X.png", NameHash_TEX);
			
			XML.Macro.image(library_images, image_id, texture_dir);
			--]]
		end;
		
		if (MaterialTable[NameHash_TEX][NameHash_ELM] == nil) then
			MaterialTable[NameHash_TEX][NameHash_ELM]	= Name;
			
			local effect_id		= string.format("effect_%s", Name);
			local material_id	= string.format("material_%s", Name);
			
			XML.Macro.effect(library_effects, effect_id, Name, image_id);
			XML.Macro.material(library_materials, Name, material_id, effect_id);
			
			table.insert(MaterialList, Name);
		end;
	end;
	
	--[[
	for i, eLightMaterialEntry in pairs(eSolid.LightMaterialTable) do
		local NameHash		= eLightMaterialEntry.NameHash;
		local Name		= string.format("0x%08X", NameHash);
		
		local effect_id		= string.format("effect_0x%08X", NameHash);
		local material_id	= string.format("material_0x%08X", NameHash);
		
		XML.Macro.effect(library_effects, effect_id, NameHash);
		XML.Macro.material(library_materials, Name, material_id, effect_id);
	end;
	--]]
	
	--[[
	for i, eTextureEntry in pairs(eSolid.pTextureTable) do
		local NameHash		= eTextureEntry.NameHash;
		local Name		= string.format("0x%08X", NameHash);
		
		local effect_id		= string.format("effect_0x%08X", NameHash);
		local material_id	= string.format("material_0x%08X", NameHash);
		
		XML.Macro.effect(library_effects, effect_id, NameHash);
		XML.Macro.material(library_materials, Name, material_id, effect_id);
	end;
	--]]
	
	local idx_off			= 0;
	
	local position			= {};
	local normal			= {};
	local normal_calc		= {};
	local texcoord			= {{}, {}, {}, {}, {}, {}, {}, {}};
	local colour			= {{}, {}};
	local triangle_list		= {};
	
	local vertex_list		= {};
	local vertex_red		= {};
	
	for _, xSolidGroup in pairs(xSolid.xSolidGroups) do
		local STRIPENTRY	= xSolidGroup.STRIPENTRY or xSolidGroup.MESHENTRY;
		local VERTICES		= xSolidGroup.VERTICES or {};
		local UV		= xSolidGroup.UV or {};
		local RGBA		= xSolidGroup.RGBA or {};
		local NORMALS		= xSolidGroup.NORMALS or {};
		local INDICES		= xSolidGroup.INDICES or {};
		local LINES		= xSolidGroup.LINES or {};
		
		local TextureNumber	= STRIPENTRY.TextureIndex + 1;
		local LightMatIndex	= STRIPENTRY.LightMaterialIndex + 1;
		
		local USE_TRI_NORM	= (#NORMALS == 0);
		
		for i = 1, #VERTICES do
			local VertexE	= VERTICES[i];
			local NormalE	= NORMALS[i];
			
			table.insert(position, VertexE[1]);
			table.insert(position, VertexE[2]);
			table.insert(position, VertexE[3]);
			
			--USE_TRI_NORM	= (NormalE ~= nil) and (USE_TRI_NORM) or (#NORMALS == 0);
			NormalE		= (NormalE ~= nil) and NormalE or {0, 0, 0};
			
			for j = 1, 2 do
				local ColourE		= RGBA[j][i] or {255, 255, 255, 127};
				
				table.insert(colour[j], ColourE[1] / 255.0);
				table.insert(colour[j], ColourE[2] / 255.0);
				table.insert(colour[j], ColourE[3] / 255.0);
				table.insert(colour[j], ColourE[4] / 255.0);
			end;
			
			table.insert(normal, NormalE[1]);
			table.insert(normal, NormalE[2]);
			table.insert(normal, NormalE[3]);
			
			for j = 1, 8 do
				local TexcoordE		= UV[j][i] or {0, 0};
				
				table.insert(texcoord[j], TexcoordE[1]);
				table.insert(texcoord[j], TexcoordE[2]);
			end;
		end;
		
		print(string.format("#position = %i", #position));
		
		local TEX		= eSolid.pTextureTable[TextureNumber];
		local ELM		= eSolid.LightMaterialTable[LightMatIndex];
		
		local NameHash_TEX	= (TEX ~= nil) and TEX.NameHash or 0xFFFFFFFF;
		local NameHash_ELM	= (ELM ~= nil) and ELM.NameHash or 0xFFFFFFFF;
		
		local triangles		= XML:Tag("triangles");
		--triangles:SetAttribute("material", string.format("material_0x%08X", (eSolid.LightMaterialTable[LightMatIndex] ~= nil) and eSolid.LightMaterialTable[LightMatIndex].NameHash or 0xFFFFFFFF));
		--triangles:SetAttribute("material", string.format("material_0x%08X", (eSolid.pTextureTable[TextureNumber] ~= nil) and eSolid.pTextureTable[TextureNumber].NameHash or 0xFFFFFFFF));
		if ((MaterialTable[NameHash_TEX] ~= nil) and (MaterialTable[NameHash_TEX][NameHash_ELM] ~= nil)) then
			triangles:SetAttribute("material", string.format("%s", MaterialTable[NameHash_TEX][NameHash_ELM]));
		end;
		triangles:SetAttribute("count", #INDICES);
		
		local lines		= XML:Tag("lines");
		if ((MaterialTable[NameHash_TEX] ~= nil) and (MaterialTable[NameHash_TEX][NameHash_ELM] ~= nil)) then
			lines:SetAttribute("material", string.format("%s", MaterialTable[NameHash_TEX][NameHash_ELM]));
		end;
		lines:SetAttribute("count", #LINES);
		
		XML.Macro.input(triangles, "VERTEX", "verts", 0);
		XML.Macro.input(triangles, "NORMAL", USE_TRI_NORM and "src-normal-calc" or "src-normal", 1);
		XML.Macro.input(triangles, "COLOR", "src-colour0", 0);
		XML.Macro.input(triangles, "COLOR", "src-colour1", 0);
		XML.Macro.input(triangles, "TEXCOORD", "src-texcoord0", 0);
		XML.Macro.input(triangles, "TEXCOORD", "src-texcoord1", 0);
		XML.Macro.input(triangles, "TEXCOORD", "src-texcoord2", 0);
		XML.Macro.input(triangles, "TEXCOORD", "src-texcoord3", 0);
		XML.Macro.input(triangles, "TEXCOORD", "src-texcoord4", 0);
		XML.Macro.input(triangles, "TEXCOORD", "src-texcoord5", 0);
		XML.Macro.input(triangles, "TEXCOORD", "src-texcoord6", 0);
		XML.Macro.input(triangles, "TEXCOORD", "src-texcoord7", 0);
		
		XML.Macro.input(lines, "VERTEX", "verts", 0);
		XML.Macro.input(lines, "NORMAL", USE_TRI_NORM and "src-normal-calc" or "src-normal", 1);
		XML.Macro.input(lines, "COLOR", "src-colour0", 0);
		XML.Macro.input(lines, "COLOR", "src-colour1", 0);
		XML.Macro.input(lines, "TEXCOORD", "src-texcoord0", 0);
		XML.Macro.input(lines, "TEXCOORD", "src-texcoord1", 0);
		XML.Macro.input(lines, "TEXCOORD", "src-texcoord2", 0);
		XML.Macro.input(lines, "TEXCOORD", "src-texcoord3", 0);
		XML.Macro.input(lines, "TEXCOORD", "src-texcoord4", 0);
		XML.Macro.input(lines, "TEXCOORD", "src-texcoord5", 0);
		XML.Macro.input(lines, "TEXCOORD", "src-texcoord6", 0);
		XML.Macro.input(lines, "TEXCOORD", "src-texcoord7", 0);
		
		local p_list		= {};
		
		for i = 1, #INDICES do
			local IndexElement = INDICES[i];
			
			local a, b, c = IndexElement[1], IndexElement[2], IndexElement[3];
			
			local va, vb, vc;
			
			if (#VERTICES > 0) then
				va, vb, vc = VERTICES[a - idx_off + 1], VERTICES[b - idx_off + 1], VERTICES[c - idx_off + 1];
			else
				va = {position[3 * a + 1], position[3 * a + 2], position[3 * a + 3]};
				vb = {position[3 * b + 1], position[3 * b + 2], position[3 * b + 3]};
				vc = {position[3 * c + 1], position[3 * c + 2], position[3 * c + 3]};
			end;
			
			if (va[1] == nil) then
				print(string.format("%i => 3 * %i + 1 = %i", a, a, a));
			end;
			
			if ((va == nil) or (vb == nil) or (vc == nil)) then
				print(eSolid.Name);
				print(string.format("tri <%i%s, %i%s, %i%s>", a - idx_off + 1, string.rep("*", (va == nil) and 1 or 0), b - idx_off + 1, string.rep("*", (vb == nil) and 1 or 0), c - idx_off + 1, string.rep("*", (vc == nil) and 1 or 0)));
			end;
			
			local U =
			{
				vb[1] - va[1],
				vb[2] - va[2],
				vb[3] - va[3]
			};
			local V =
			{
				vc[1] - va[1],
				vc[2] - va[2],
				vc[3] - va[3]
			};
			
			local Nx = U[2] * V[3] - U[3] * V[2];
			local Ny = U[3] * V[1] - U[1] * V[3];
			local Nz = U[1] * V[2] - U[2] * V[1];
			
			local tri_norm = {Nx / math.sqrt(Nx * Nx + Ny * Ny + Nz * Nz), Ny / math.sqrt(Nx * Nx + Ny * Ny + Nz * Nz), Nz / math.sqrt(Nx * Nx + Ny * Ny + Nz * Nz)};
			
			if (USE_TRI_NORM) then
				table.insert(p_list, a);
				table.insert(p_list, #normal_calc // 3);
				
				table.insert(p_list, b);
				table.insert(p_list, #normal_calc // 3);
				
				table.insert(p_list, c);
				table.insert(p_list, #normal_calc // 3);
				
				table.insert(normal_calc, tri_norm[1]);
				table.insert(normal_calc, tri_norm[2]);
				table.insert(normal_calc, tri_norm[3]);
			else
				table.insert(p_list, a);
				table.insert(p_list, a);
				
				table.insert(p_list, b);
				table.insert(p_list, b);
				
				table.insert(p_list, c);
				table.insert(p_list, c);
			end;
		end;
		
		local p = XML:Tag("p", triangles);
		p:AddChild(table.concat(p_list, " "));
		
		local l = XML:Tag("p", lines);
		l:AddChild(table.concat(LINES, " "));
			
		p_list = {};
		
		idx_off = idx_off + #VERTICES;
		
		table.insert(triangle_list, triangles);
		table.insert(triangle_list, lines);
	end;
	
	local geometry, mesh = XML.Macro.geometry2(library_geometries, "xSolidGeometry", position, normal, normal_calc, colour, texcoord);
	geometry:SetAttribute("name", string.format((eSolid.Name ~= nil) and "xSolid_0x%08X.%s.%s" or "xSolid_0x%08X.%s", eSolid.NameHash, SectionName, eSolid.Name or ""));
	
	for i = 1, #triangle_list do
		mesh:AddChild(triangle_list[i]);
	end;
	
	local pivot =
	{
		1, 0, 0, 0,
		0, 1, 0, 0,
		0, 0, 1, 0,
		0, 0, 0, 1
	};
	
	--pivot[4] = eSolid.PivotMatrix.v3.x;
	--pivot[8] = eSolid.PivotMatrix.v3.y;
	--pivot[12] = eSolid.PivotMatrix.v3.z;
	--pivot[16] = eSolid.PivotMatrix.v3.w;
	
	--local visual_scene	= XML.Macro.visual_scene(library_visual_scenes, "DefaultScene");
	
	local node		= XML.Macro.node(library_nodes, string.format("%s_0x%08X", SectionName, eSolid.NameHash), "", "NODE"); -- string.gsub(eSolid.Name, "\x00", "")
	
	local matrix		= XML:Tag("matrix", node);
	matrix:SetAttribute("sid", "transform");
	matrix:AddChild(table.concat(pivot, " "));
	
	local instance_geometry	= XML:Tag("instance_geometry", node);
	instance_geometry:SetAttribute("url", "#xSolidGeometry");
	
	local bind_material	= XML:Tag("bind_material", instance_geometry);
	local technique_common	= XML.Macro.technique_common(bind_material);
	
	--[[
	do
		local instance_material	= XML:Tag("instance_material", technique_common);
		instance_material:SetAttribute("symbol", string.format("material_0x%08X", 0xFFFFFFFF));
		instance_material:SetAttribute("target", string.format("#material_0x%08X", 0xFFFFFFFF));
	end;
	--]]
	
	--[[
	for i, eLightMaterialEntry in pairs(eSolid.LightMaterialTable) do
		local instance_material	= XML:Tag("instance_material", technique_common);
		instance_material:SetAttribute("symbol", string.format("material_0x%08X", eLightMaterialEntry.NameHash));
		instance_material:SetAttribute("target", string.format("#material_0x%08X", eLightMaterialEntry.NameHash));
	end;
	--]]
	
	--[[
	for i, eTextureEntry in pairs(eSolid.pTextureTable) do
		local instance_material	= XML:Tag("instance_material", technique_common);
		instance_material:SetAttribute("symbol", string.format("material_0x%08X", eTextureEntry.NameHash));
		instance_material:SetAttribute("target", string.format("#material_0x%08X", eTextureEntry.NameHash));
	end;
	--]]
	
	---[[
	for i, Name in pairs(MaterialList) do
		local instance_material	= XML:Tag("instance_material", technique_common);
		instance_material:SetAttribute("symbol", Name);
		instance_material:SetAttribute("target", string.format("#material_%s", Name));
		
		--[[
		local bind_vertex_input	= XML:Tag("bind_vertex_input", instance_material);
		bind_vertex_input:SetAttribute("semantic", string.format("texcoord_effect_%s", Name));
		bind_vertex_input:SetAttribute("input_semantic", "TEXCOORD");
		--]]
	end;
	--]]
	
	--
	--[[
	local instance_visual_scene	= XML:Tag("instance_visual_scene", scene);
	instance_visual_scene:SetAttribute("url", string.format("#%s", visual_scene:GetAttribute("id")))
	--]]
	
	--
	
	return xml:__tostring() .. "\n" .. COLLADA:__tostring();
end;

_ENV.hash_assoc = _ENV.hash_assoc or {};

local function SectionNumberToName(SectionNumber)
	local Base			= string.char(0x40 + (SectionNumber // 100));
	local Number			= SectionNumber % 100;
	
	return Base .. tostring(Number);
end;

function collada:new_scenery(ScenerySection, UseFloatsForRotation)
	local XML_ENV	= {};
	
	local xml			= XML.Macro.xml(XML_ENV);
	
	local COLLADA			= XML.Macro.COLLADA(XML_ENV);
	local asset			= XML.Macro.asset(COLLADA);
	
	COLLADA:AddChild("");
	
	local library_visual_scenes	= XML:Tag("library_visual_scenes", COLLADA)
	
	COLLADA:AddChild("");
	
	local scene			= XML:Tag("scene", COLLADA);
	
	--
	
	local visual_scene		= XML.Macro.visual_scene(library_visual_scenes, "DefaultScene");
	
	local pivot =
	{
		1, 0, 0, 0,
		0, 1, 0, 0,
		0, 0, 1, 0,
		0, 0, 0, 1
	};
	
	local function sx(x, n)
		local a = (-((x >> (n - 1)) & 1) << (n - 1));
		local b = ~((-1 >> (n - 1)) << (n - 1));
	
		return a | (x & b);
	end;
	
	local function sx16(x)
		return sx(x, 16);
	end;
	
	local SectionName		= SectionNumberToName(ScenerySection.Header.SectionNumber);
	local SectionBase		= ScenerySection.Header.SectionNumber // 100;
	
	for i = 1, ScenerySection.Header.NumSceneryInstances do
		local SceneryInstance	= ScenerySection.Instances[i];
		local SceneryInfo	= ScenerySection.InfoTable[SceneryInstance.SceneryInfoNumber + 1];
		
		local NameHash		= SceneryInfo.NameHash[1]; -- Highest LOD
		
		SectionName		= (_ENV.Config.Game == ModelulatorEnum.Game.HOTPURSUIT2) and "DEFAULT" or SectionNumberToName(ScenerySection.Header.SectionNumber);
		
		if ((hash_assoc[SectionName] == nil) or (hash_assoc[SectionName][NameHash] == nil)) then
			if (hash_assoc["<<<REDIRECT>>>"][NameHash] ~= nil) then
				for _, SectionRedirection in pairs(hash_assoc["<<<REDIRECT>>>"][NameHash]) do
					local SectionRedirectionBase	= string.byte(SectionRedirection, 1, 1) - 0x40;
					SectionName			= SectionRedirection;
					
					if (SectionRedirectionBase == SectionBase) then
						break;
					end;
				end;
			else
				--print("oh no!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
			end;
		end;
		
		if ((hash_assoc[SectionName] == nil) or (hash_assoc[SectionName][NameHash] == nil)) then
			print(ScenerySection.Header.SectionNumber, string.format("0x%08X.%s", NameHash, SectionName), i - 1, SceneryInstance.SceneryInfoNumber);
			--hash_assoc[NameHash] = string.format("0x%08X", NameHash);
		end;
		
		if (hash_assoc[SectionName] and hash_assoc[SectionName][NameHash]) then
			if (UseFloatsForRotation) then
				pivot[1] = (SceneryInstance.Rotation[1]);
				pivot[2] = (SceneryInstance.Rotation[4]);
				pivot[3] = (SceneryInstance.Rotation[7]);
				
				pivot[5] = (SceneryInstance.Rotation[2]);
				pivot[6] = (SceneryInstance.Rotation[5]);
				pivot[7] = (SceneryInstance.Rotation[8]);
				
				pivot[9] = (SceneryInstance.Rotation[3]);
				pivot[10] = (SceneryInstance.Rotation[6]);
				pivot[11] = (SceneryInstance.Rotation[9]);
				
				pivot[4] = SceneryInstance.Position[1];
				pivot[8] = SceneryInstance.Position[2];
				pivot[12] = SceneryInstance.Position[3];
				pivot[16] = 1;
			else
				local Scale	= (_ENV.Config.Game == ModelulatorEnum.Game.HOTPURSUIT2) and 0x4000 or 0x2000;
				pivot[1] = sx16(SceneryInstance.Rotation[1]) / Scale;
				pivot[2] = sx16(SceneryInstance.Rotation[4]) / Scale;
				pivot[3] = sx16(SceneryInstance.Rotation[7]) / Scale;
				
				pivot[5] = sx16(SceneryInstance.Rotation[2]) / Scale;
				pivot[6] = sx16(SceneryInstance.Rotation[5]) / Scale;
				pivot[7] = sx16(SceneryInstance.Rotation[8]) / Scale;
				
				pivot[9] = sx16(SceneryInstance.Rotation[3]) / Scale;
				pivot[10] = sx16(SceneryInstance.Rotation[6]) / Scale;
				pivot[11] = sx16(SceneryInstance.Rotation[9]) / Scale;
				
				pivot[4] = SceneryInstance.Position[1];
				pivot[8] = SceneryInstance.Position[2];
				pivot[12] = SceneryInstance.Position[3];
				pivot[16] = 1;
			end;
			
			-- node
			
			local node		= XML.Macro.node(visual_scene, string.format("S%i_0x%04X", ScenerySection.Header.SectionNumber, i), "", "NODE");
			local instance_node	= XML:Tag("instance_node", node);
			instance_node:SetAttribute("url", string.format("..\\Solids\\%s#%s_0x%08X", string.gsub(hash_assoc[SectionName][NameHash], InvalidCharsPattern, URLEscape) .. ".dae", SectionName, NameHash));
			
			--local translate		= XML:Tag("translate", node);
			--translate:AddChild(table.concat({SceneryInstance.Position[1], SceneryInstance.Position[2], SceneryInstance.Position[3]}, " "));
			
			local matrix		= XML:Tag("matrix", node);
			matrix:SetAttribute("sid", "transform");
			matrix:AddChild(table.concat(pivot, " "));
		end;
	end;
	
	--
	
	---[[
	local instance_visual_scene	= XML:Tag("instance_visual_scene", scene);
	instance_visual_scene:SetAttribute("url", string.format("#%s", visual_scene:GetAttribute("id")))
	---]]
	
	--
	
	return xml:__tostring() .. "\n" .. COLLADA:__tostring();
end;

function collada:new_megainstance(xSolidList, SectionName)
	local XML_ENV	= {};
	
	local xml			= XML.Macro.xml(XML_ENV);
	
	local COLLADA			= XML.Macro.COLLADA(XML_ENV);
	local asset			= XML.Macro.asset(COLLADA);
	
	COLLADA:AddChild("");
	
	local library_visual_scenes	= XML:Tag("library_visual_scenes", COLLADA)
	
	COLLADA:AddChild("");
	
	local scene			= XML:Tag("scene", COLLADA);
	
	--
	
	local visual_scene		= XML.Macro.visual_scene(library_visual_scenes, "DefaultScene");
	
	local pivot =
	{
		1, 0, 0, 0,
		0, 1, 0, 0,
		0, 0, 1, 0,
		0, 0, 0, 1
	};
	
	for i, xSolid in pairs(xSolidList) do
		local Solid		= xSolid.EcstasySolid or xSolid.xSolidInfo;
		local NameHash		= Solid.NameHash;
		
		if (hash_assoc[SectionName][NameHash]) then
			local node		= XML.Macro.node(visual_scene, string.format((Solid.Name ~= nil) and "xSolidInstance0x%08X.%s.%s" or "xSolidInstance0x%08X.%s", NameHash, SectionName, Solid.Name), "", "NODE");
			local instance_node	= XML:Tag("instance_node", node);
			instance_node:SetAttribute("url", string.format("..\\Solids\\%s#%s_0x%08X", string.gsub(hash_assoc[SectionName][NameHash], InvalidCharsPattern, URLEscape) .. ".dae", SectionName, NameHash));
			
			--local translate		= XML:Tag("translate", node);
			--translate:AddChild(table.concat({SceneryInstance.Position[1], SceneryInstance.Position[2], SceneryInstance.Position[3]}, " "));
			
			if (Solid.PivotMatrix ~= nil) then			
				pivot[1]		= Solid.PivotMatrix.v0.x;
				pivot[5]		= Solid.PivotMatrix.v0.y;
				pivot[9]		= Solid.PivotMatrix.v0.z;
				pivot[13]		= Solid.PivotMatrix.v0.w;
				
				pivot[2]		= Solid.PivotMatrix.v1.x;
				pivot[6]		= Solid.PivotMatrix.v1.y;
				pivot[10]		= Solid.PivotMatrix.v1.z;
				pivot[14]		= Solid.PivotMatrix.v1.w;
				
				pivot[3]		= Solid.PivotMatrix.v2.x;
				pivot[7]		= Solid.PivotMatrix.v2.y;
				pivot[11]		= Solid.PivotMatrix.v2.z;
				pivot[15]		= Solid.PivotMatrix.v2.w;
				
				pivot[4]		= Solid.PivotMatrix.v3.x;
				pivot[8]		= Solid.PivotMatrix.v3.y;
				pivot[12]		= Solid.PivotMatrix.v3.z;
				pivot[16]		= Solid.PivotMatrix.v3.w;
			end;
			
			local matrix		= XML:Tag("matrix", node);
			matrix:SetAttribute("sid", "transform");
			matrix:AddChild(table.concat(pivot, " "));
		end;
	end;
	
	--
	
	---[[
	local instance_visual_scene	= XML:Tag("instance_visual_scene", scene);
	instance_visual_scene:SetAttribute("url", string.format("#%s", visual_scene:GetAttribute("id")))
	---]]
	
	--
	
	return xml:__tostring() .. "\n" .. COLLADA:__tostring();
end;

function collada:new_texturepack(eTextureHashList)
	local XML_ENV	= {};
	
	local xml			= XML.Macro.xml(XML_ENV);
	
	local COLLADA			= XML.Macro.COLLADA(XML_ENV);
	local asset			= XML.Macro.asset(COLLADA);
	
	COLLADA:AddChild("");
	
	local library_images		= XML:Tag("library_images", COLLADA);
	
	for i = 1, #eTextureHashList do
		local eTextureHash	= eTextureHashList[i];
		
		local image_id 		= string.format("image_%s", string.gsub(eTextureHash, InvalidCharsPattern, URLEscape));
		local image_dir		= string.format("..\\Textures\\%s.png", string.gsub(eTextureHash, InvalidCharsPattern, URLEscape));
		local image		= XML.Macro.image(library_images, image_id, image_dir);
	end;
	
	return xml:__tostring() .. "\n" .. COLLADA:__tostring();
end;

local InvalidWindowsFilenameChars =
{
	["<"] = true;
	[">"] = true;
	[":"] = true;
	["\""] = true;
	["/"] = true;
	["\\"] = true;
	["|"] = true;
	["?"] = true;
	["*"] = true;
};

local function SanitizeWindowsFilenamePart(Name)
	Name = tostring(Name or "");
	local Result = {};

	for i = 1, #Name do
		local Byte = string.byte(Name, i, i);
		local Character = string.char(Byte);

		if ((Byte < 0x20) or InvalidWindowsFilenameChars[Character]) then
			table.insert(Result, "_");
		else
			table.insert(Result, Character);
		end;
	end;

	return table.concat(Result);
end;

function collada:generate_solid_name(xSolidList, SectionName)
	local SectionBase = string.byte(SectionName, 1, 1) - 0x40;

	hash_assoc[SectionName] = hash_assoc[SectionName] or {};
	hash_assoc["<<<REDIRECT>>>"] = hash_assoc["<<<REDIRECT>>>"] or {};

	for _, xSolid in pairs(xSolidList) do
		local Solid = xSolid.EcstasySolid or xSolid.xSolidInfo;
		local SafeSolidName = SanitizeWindowsFilenamePart(Solid.Name or "");
		local file_name = string.format((Solid.Name ~= nil) and "0x%08X.%s.%s" or "0x%08X.%s", Solid.NameHash, SectionName, SafeSolidName);
		hash_assoc[SectionName][Solid.NameHash] = file_name;

		if (hash_assoc["<<<REDIRECT>>>"][Solid.NameHash] == nil) then
			hash_assoc["<<<REDIRECT>>>"][Solid.NameHash] = {};
		end;

		table.insert(hash_assoc["<<<REDIRECT>>>"][Solid.NameHash], SectionName);
		table.sort(hash_assoc["<<<REDIRECT>>>"][Solid.NameHash]);
	end;
end;

function collada:generate_solid_single(xSolid, SectionName)
	local Solid = xSolid.EcstasySolid or xSolid.xSolidInfo;
	local file_name = hash_assoc[SectionName] and hash_assoc[SectionName][Solid.NameHash];

	if (file_name == nil) then
		collada:generate_solid_name({xSolid}, SectionName);
		file_name = hash_assoc[SectionName][Solid.NameHash];
	end;

	return {{FileName = file_name, FileType = "dae"; Data = collada:new_solid(xSolid, SectionName)}};
end;

function collada:generate_solid_palette(xSolidList, SectionName)
	return {{FileName = string.format("eSolidPalette.%s", SectionName), FileType = "dae"; Data = collada:new_megainstance(xSolidList, SectionName)}};
end;

-- Compatibility wrapper for other loaders. eSolid loaders use per-solid jobs.
function collada:generate_solid(xSolidList, SectionName)
	local files = {};

	for _, xSolid in pairs(xSolidList) do
		local SingleFiles = collada:generate_solid_single(xSolid, SectionName);
		for _, File in ipairs(SingleFiles) do
			table.insert(files, File);
		end;
	end;

	table.insert(files, collada:generate_solid_palette(xSolidList, SectionName)[1]);
	return files;
end;

function collada:generate_scenery(ScenerySection, UseFloatsForRotation)
	local files = {};
	
	local scenery_file_name 	= string.format("SECTION_%s", (_ENV.Config.Game == ModelulatorEnum.Game.HOTPURSUIT2) and ScenerySection.Header.SectionNumber or SectionNumberToName(ScenerySection.Header.SectionNumber));
	table.insert(files, {FileName = scenery_file_name, FileType = "dae"; Data = collada:new_scenery(ScenerySection, UseFloatsForRotation)});
	
	return files;
end;


return collada;