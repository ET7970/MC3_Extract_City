-- # i dont use this anymore except for testing, and even then dae has that covered!

local obj = {};
obj.pipeline = {};

function obj:generate_solid(xSolidList)
	local g = {};
	
	local files =
	{
		obj = {};
		mtl = {};
	};
	
	local buffer_file = "";
	
	for _, xSolid in pairs(xSolidList) do
		local idx_off		= 0;
		local idx_off_vn	= 0;
		
		local eSolid = xSolid.EcstasySolid;
		
		files.mtl[eSolid.NameHash] = "";
		
		for _, eLightMaterialEntry in pairs(eSolid.LightMaterialTable) do
			files.mtl[eSolid.NameHash] = files.mtl[eSolid.NameHash] .. string.rep("\n", math.min(#files.mtl[eSolid.NameHash], 1) * 2);
			files.mtl[eSolid.NameHash] = files.mtl[eSolid.NameHash] .. string.format("newmtl\t0x%08X", eLightMaterialEntry.NameHash);
			files.mtl[eSolid.NameHash] = files.mtl[eSolid.NameHash] .. string.rep("\n", math.min(#files.mtl[eSolid.NameHash], 1));
			files.mtl[eSolid.NameHash] = files.mtl[eSolid.NameHash] .. string.format("Kd\t%f %f %f", 1, 1, 1);
			files.mtl[eSolid.NameHash] = files.mtl[eSolid.NameHash] .. string.rep("\n", math.min(#files.mtl[eSolid.NameHash], 1));
			files.mtl[eSolid.NameHash] = files.mtl[eSolid.NameHash] .. string.format("d\t%f", 1);
		end;
		
		buffer_file = "";
		buffer_file_v = "";
		buffer_file_vt = "";
		buffer_file_vn = "";
		
		local LastLightMatIndex		= 0;
		local LightMatIndex		= 0;
		
		for _, xSolidGroup in pairs(xSolid.xSolidGroups) do
			local STRIPENTRY	= xSolidGroup.STRIPENTRY;
			local VERTICES		= xSolidGroup.VERTICES;
			local UV		= xSolidGroup.UV;
			local RGBA		= xSolidGroup.RGBA;
			local NORMALS		= xSolidGroup.NORMALS;
			local INDICES		= xSolidGroup.INDICES;
			
			local PGN		= STRIPENTRY.PolyGroupNumber + 1;
			LightMatIndex		= string.unpack("b", string.pack("B", STRIPENTRY.LightMaterialIndex)) + 1;
			
			if (g[PGN] == nil) then
				g[PGN] = {""};
			end;
			
			local buffer_v	= "";
			local buffer_vt	= "";
			local buffer_vn = "";
			local buffer_f	= "";
			
			--print(#VERTICES - STRIPENTRY.NumVerts, #INDICES - STRIPENTRY.NumPolys);
			
			local USE_TRI_NORM = #NORMALS == 0;
			
			--print(#NORMALS < #VERTICES);
			
			if ((LightMatIndex ~= LastLightMatIndex) and (LightMatIndex > 0)) then
				buffer_f = buffer_f .. string.format("usemtl\t0x%08X", eSolid.LightMaterialTable[LightMatIndex].NameHash);
				LastLightMatIndex = LightMatIndex;
			end;
			
			for i = 1, #INDICES do
				local IndexElement = INDICES[i];
				
				local a, b, c = IndexElement[1] + 1, IndexElement[2] + 1, IndexElement[3] + 1;
				
				local va, vb, vc = VERTICES[a - idx_off], VERTICES[b - idx_off], VERTICES[c - idx_off];
				local U = {vb[1] - va[1], vb[2] - va[2], vb[3] - va[3]};
				local V = {vc[1] - va[1], vc[2] - va[2], vc[3] - va[3]};
				
				local Nx = U[2] * V[3] - U[3] * V[2];
				local Ny = U[3] * V[1] - U[1] * V[3];
				local Nz = U[1] * V[2] - U[2] * V[1];
				
				local tri_norm = {Nx / math.sqrt(Nx * Nx + Ny * Ny + Nz * Nz), Ny / math.sqrt(Nx * Nx + Ny * Ny + Nz * Nz), Nz / math.sqrt(Nx * Nx + Ny * Ny + Nz * Nz)};
				
				local A = {(VERTICES[a - idx_off] ~= nil) and a or 0, (UV[a - idx_off] ~= nil) and a or 0};
				local B = {(VERTICES[b - idx_off] ~= nil) and b or 0, (UV[b - idx_off] ~= nil) and b or 0};
				local C = {(VERTICES[c - idx_off] ~= nil) and c or 0, (UV[c - idx_off] ~= nil) and c or 0};
				
				if (not USE_TRI_NORM) then
					table.insert(A, (NORMALS[a - idx_off] ~= nil) and (a) or 0);
					table.insert(B, (NORMALS[b - idx_off] ~= nil) and (b) or 0);
					table.insert(C, (NORMALS[c - idx_off] ~= nil) and (c) or 0);
				else
					table.insert(A, -1);
					table.insert(B, -1);
					table.insert(C, -1);
				end;
				
				for I = 3, 1, -1 do
					if (A[I] == 0) then
						if ((I == #A) and (I > 1)) then
							table.remove(A, I);
						else
							A[I] = "";
						end;
					else
						A[I] = tostring(A[I]);
					end;
					
					if (B[I] == 0) then
						if ((I == #B) and (I > 1)) then
							table.remove(B, I);
						else
							B[I] = "";
						end;
					else
						B[I] = tostring(B[I]);
					end;
					
					if (C[I] == 0) then
						if ((I == #C) and (I > 1)) then
							table.remove(C, I);
						else
							C[I] = "";
						end;
					else
						C[I] = tostring(C[I]);
					end;
				end;
				
				A = table.concat(A, "/");
				B = table.concat(B, "/");
				C = table.concat(C, "/");
				
				local line_f = string.format("f\t%s %s %s", A, B, C);
				
				if (USE_TRI_NORM) then
					line_f = string.format("vn\t%f %f %f\n", tri_norm[1], tri_norm[2], tri_norm[3]) .. line_f;
				end;
				
				buffer_f = buffer_f .. string.rep("\n", math.min(#buffer_f * #line_f, 1));
				buffer_f = buffer_f .. line_f;
			end;
			
			for i = 1, #VERTICES do
				local VertexElement	= VERTICES[i];
				local UVElement		= UV[i];
				local RGBAElement	= RGBA[i];
				local NormalElement	= NORMALS[i];
				--local IndexElement	= INDICES[i];
				
				local line_v	= string.format("v\t%f %f %f %i %i %i %i", VertexElement[1], VertexElement[2], VertexElement[3], table.unpack(RGBAElement));
				line_v		= string.gsub(line_v, "%x+", string.upper);
				
				buffer_v	= buffer_v .. string.rep("\n", math.min(#buffer_v * #line_v, 1));
				buffer_v	= buffer_v .. line_v;
				
				local line_vt	= string.format("vt\t%f %f", UVElement[1], UVElement[2]);
				line_vt		= string.gsub(line_vt, "%x+", string.upper);
				
				buffer_vt	= buffer_vt .. string.rep("\n", math.min(#buffer_vt * #line_vt, 1));
				buffer_vt	= buffer_vt .. line_vt;
				
				if (NormalElement ~= nil) then
					local line_vn	= string.format("vn\t%f %f %f", NormalElement[1], NormalElement[2], NormalElement[3]);
					line_vn		= string.gsub(line_vn, "%x+", string.upper);
					
					buffer_vn	= buffer_vn .. string.rep("\n", math.min(#buffer_vn * #line_vn, 1));
					buffer_vn	= buffer_vn .. line_vn;
				else
					local line_vn	= string.format("vn\t%f %f %f", 0, 0, 0);
					line_vn		= string.gsub(line_vn, "%x+", string.upper);
					
					buffer_vn	= buffer_vn .. string.rep("\n", math.min(#buffer_vn * #line_vn, 1));
					buffer_vn	= buffer_vn .. line_vn;
				end;
			end;
			
			buffer_file_v = buffer_file_v .. string.rep("\n", math.min(#buffer_file_v * #buffer_v, 1) * 2);
			buffer_file_v = buffer_file_v .. buffer_v;
			buffer_file_vt = buffer_file_vt .. string.rep("\n", math.min(#buffer_file_vt * #buffer_vt, 1) * 2);
			buffer_file_vt = buffer_file_vt .. buffer_vt;
			buffer_file_vn = buffer_file_vn .. string.rep("\n", math.min(#buffer_file_vn * #buffer_vn, 1) * 2);
			buffer_file_vn = buffer_file_vn .. buffer_vn;
			
			g[PGN][1] = g[PGN][1] .. string.rep("\n", math.min(#g[PGN][1], 1) * 1);
			g[PGN][1] = g[PGN][1] .. buffer_f;
			
			idx_off = idx_off + #VERTICES;
			
			if (USE_TRI_NORM) then idx_off_vn = idx_off_vn + #VERTICES; end;
		end;
		
		buffer_file = buffer_file .. string.rep("\n", math.min(#buffer_file * #buffer_file_v, 1) * 2);
		buffer_file = buffer_file .. buffer_file_v;
		buffer_file = buffer_file .. string.rep("\n", math.min(#buffer_file * #buffer_file_vt, 1) * 2);
		buffer_file = buffer_file .. buffer_file_vt;
		buffer_file = buffer_file .. string.rep("\n", math.min(#buffer_file * #buffer_file_vn, 1) * 2);
		buffer_file = buffer_file .. buffer_file_vn;
		
		buffer_file = buffer_file .. string.rep("\n", math.min(#buffer_file, 1) * 2);
		
		for i, v in pairs(g) do
			buffer_file = buffer_file .. string.rep("\n", math.min(#buffer_file, 1) * 2);
			buffer_file = buffer_file .. string.format("g\t%i\n", i);
			--buffer_file = buffer_file .. string.format("s\t%i\n", i);
			buffer_file = buffer_file .. table.concat(v, "\n");
		end;
		
		buffer_file = string.format("o\t%s\n", string.gsub(eSolid.Name, "\x00", "")) .. buffer_file;
		
		buffer_file = string.format("mtllib\t0x%08X.mtl\n\n", eSolid.NameHash) .. buffer_file;
		
		files.obj[eSolid.NameHash] = buffer_file;
	end;
	
	return files;
end;

return obj;