-- # i dont use this anymore except for testing, and even then dae has that covered!

local ply = {};

function transform(Vertex, Matrix)
	local x, y, z, w = Vertex[1], Vertex[2], Vertex[3], 1.0;
	
	local m00, m01, m02, m03 = Matrix.v0.x, Matrix.v0.y, Matrix.v0.z, Matrix.v0.w;
	local m10, m11, m12, m13 = Matrix.v1.x, Matrix.v1.y, Matrix.v1.z, Matrix.v1.w;
	local m20, m21, m22, m23 = Matrix.v2.x, Matrix.v2.y, Matrix.v2.z, Matrix.v2.w;
	local m30, m31, m32, m33 = Matrix.v3.x, Matrix.v3.y, Matrix.v3.z, Matrix.v3.w;
	
	local rx = 1 * x + 0 * y + 0 * z + m30 * w;
	local ry = 0 * x + 1 * y + 0 * z + m31 * w;
	local rz = 0 * x + 0 * y + 1 * z + m32 * w;
	local rw = 0 * x + 0 * y + 0 * z + m33 * w;
	
	return {rx, ry, rz, rw};
end;

function ply:generate_solid(xSolidList)
	local files =
	{
		ply = {};
	};
	local buffer_file = "";
	
	for _, xSolid in pairs(xSolidList) do
		local eSolid = xSolid.EcstasySolid;
		
		buffer_file = "";
		
		local num_verts_total = 0;
		local num_polys_total = 0;
		
		local buffer_v	= "";
		local buffer_f	= "";
		
		local PivotMatrix = eSolid.PivotMatrix;
		
		for _, xSolidGroup in pairs(xSolid.xSolidGroups) do
			local STRIPENTRY	= xSolidGroup.STRIPENTRY;
			local VERTICES		= xSolidGroup.VERTICES;
			local UV		= xSolidGroup.UV;
			local RGBA		= xSolidGroup.RGBA;
			local NORMALS		= xSolidGroup.NORMALS;
			local INDICES		= xSolidGroup.INDICES;
			
			local PGN		= STRIPENTRY.PolyGroupNumber + 1;
			
			--print(#VERTICES - STRIPENTRY.NumVerts, #INDICES - STRIPENTRY.NumPolys);
			
			for i = 1, #VERTICES do
				local VertexElement	= VERTICES[i];
				local UVElement		= UV[i];
				local RGBAElement	= RGBA[i];
				
				VertexElement = transform(VERTICES[i], PivotMatrix);
				
				buffer_v = buffer_v .. string.rep("\n", math.min(#buffer_v, 1));
				buffer_v = buffer_v .. string.format("%f %f %f %f %f %i %i %i %i", VertexElement[1], VertexElement[2], VertexElement[3], UVElement[1], UVElement[2], RGBAElement[1], RGBAElement[2], RGBAElement[3], RGBAElement[4]);
				
				num_verts_total = num_verts_total + 1;
			end;
			
			for i = 1, #INDICES do
				local IndexElement = INDICES[i];
				
				local a, b, c = IndexElement[1], IndexElement[2], IndexElement[3];
				
				buffer_f = buffer_f .. string.rep("\n", math.min(#buffer_f, 1));
				buffer_f = buffer_f .. string.format("3 %i %i %i", a, b, c);
				
				num_polys_total = num_polys_total + 1;
			end;
		end;
		
		buffer_file = buffer_file .. string.rep("\n", math.min(#buffer_file, 1));
		buffer_file = buffer_file .. buffer_v .. "\n" .. buffer_f;
		
		local ply_header = "";
		
		ply_header = ply_header .. "ply\n";
		ply_header = ply_header .. "format ascii 1.0\n";
		ply_header = ply_header .. string.format("element vertex %i\n", num_verts_total);
		ply_header = ply_header .. "property float x\n";
		ply_header = ply_header .. "property float y\n";
		ply_header = ply_header .. "property float z\n";
		ply_header = ply_header .. "property float s\n";
		ply_header = ply_header .. "property float t\n";
		ply_header = ply_header .. "property uchar red\n";
		ply_header = ply_header .. "property uchar green\n";
		ply_header = ply_header .. "property uchar blue\n";
		ply_header = ply_header .. "property uchar alpha\n";
		ply_header = ply_header .. string.format("element face %i\n", num_polys_total);
		ply_header = ply_header .. "property list uchar int vertex_index\n";
		ply_header = ply_header .. "end_header\n";
		
		buffer_file = ply_header .. buffer_file;
		
		files.ply[eSolid.NameHash] = buffer_file;
	end;
	
	return files;
end;

return ply;