local EnvironmentStateType	=
{
	[1]			= "dev";
	[2]			= "pre";
	[3]			= "pub";
	[4]			= "rc";
};

local ProgramInfo		=
{
	Name			= "Modelulator";
	Description		= "(prev. psx2-pipeline-v3) Tool for exporting models";
	Credits			=
	{
		{
			Role	= "Program Developer";
			Name	= "thulim";
			Contact	=
			{
				Discord		= "@þulim#9816 <@228372021082456065>";
				Elsewhere	= "";
			};
		};
		
		{
			Role	= "Game Library Reference";
			Name	= "PlayStation DataCenter";
			Site	= "https://www.psxdatacenter.com/";
		};
	};
	
	Support			=
	{
		Formats		=
		{
			Input	= {".bin", ".bun"};
			Output	=
			{
				{
					Name		= "Portable Network Graphics";
					Extension	= ".png";
					Description	= "(Binary) common image format";
					Documentation	= "http://www.libpng.org/pub/png/spec/";
				};
			};
		};
		
		Games		=
		{
			{
				Title	= "(NFS:HP2) Need for Speed: Hot Pursuit 2";
				Library	=
				{
					{
						Serial	= {"SLUS-20362"};
						Region	= "NTSC-U";
					};
					{
						Serial	= {"SLES-50731"};
						Region	= "PAL";
					};
					{
						Serial	= {"SLPM-65181", "SLPM-67527"};
						Region	= "NTSC-J";
					};
				};
			};
		};
	};
	
	Version			=
	{
		Major			= 5;
		Minor			= 1;
		Patch			= 5;
		EnvironmentState	= EnvironmentStateType[3];
		
		Build		=
		{
			Time	= 1762123408;
			Release	= 03;
		};
	};
};

return ProgramInfo;