_ENV.env_path		= arg[1];

-- lye berries

package.path		= package.path .. ";" .. string.format("%s\\?.lua", env_path);
package.path		= package.path .. ";" .. string.format("%s\\?\\init.lua", env_path);
package.path		= package.path .. ";" .. string.format("%s\\?\\__Initialise.lua", env_path);

local DEF		= require("src.util.definitions");



--#
local build		= require("src.build");


--#
local ARGS		= {};

local sDEF_TYPES	= "Argument Types";
local sDEF_LIST		= "Definitions";

local ArgumentTypes	= {};
local ArgumentRef	= {};
local ArgumentHelp	= {};

sDEF_TYPES		= sDEF_TYPES .. ("\n" .. string.rep("=", 64));

for i, v in pairs(DEF.Types) do
	local TYPE_NAME		= string.upper(v.NAME[1]);
	local TYPE_NAME_PLURAL	= string.upper(v.NAME[2]);
	local TYPE_PREFIX	= string.lower(v.PREFIX);
	local TYPE_SYNTAX	= string.lower(string.format(v.SYNTAX, TYPE_PREFIX, TYPE_NAME));
	
	sDEF_LIST		= sDEF_LIST .. string.rep("\n", math.min(#sDEF_LIST, 1));
	sDEF_LIST		= sDEF_LIST .. (string.rep("=", 64) .. "\n");
	sDEF_LIST		= sDEF_LIST .. string.format("(%s) %s", TYPE_PREFIX, TYPE_NAME_PLURAL);
	
	ArgumentTypes[i]		= {Type = v; Items = {};};
	ArgumentHelp[TYPE_NAME]		= string.format("%-23s|%8s%32s", string.format("%-8s%s", string.format("(%s)", TYPE_PREFIX), TYPE_NAME), "SYNTAX:", TYPE_SYNTAX);
	ArgumentHelp[TYPE_NAME_PLURAL]	= ArgumentHelp[TYPE_NAME];
	
	local BufferT		= "";
	BufferT			= BufferT .. string.format("%-16s\"%s\" | \"%s\"", "Name:", TYPE_NAME, TYPE_NAME_PLURAL);
	BufferT			= BufferT .. "\n";
	BufferT			= BufferT .. string.format("%-16s'%s'", "Prefix:", TYPE_PREFIX);
	BufferT			= BufferT .. "\n";
	BufferT			= BufferT .. string.format("%-16s%s", "Usage:", TYPE_SYNTAX);
	
	sDEF_TYPES		= sDEF_TYPES .. string.rep("\n", math.min(#sDEF_TYPES, 1));
	sDEF_TYPES		= sDEF_TYPES .. string.rep((string.rep("-", 64) .. "\n"), math.min(i - 1, 1));
	sDEF_TYPES		= sDEF_TYPES .. BufferT;
	
	if (v.STRUCT ~= nil) then
		ArgumentTypes[i].Items	= DEF.Items[TYPE_NAME];
		
		local Buffer = "";
		for ii, vv in pairs(DEF.Items[TYPE_NAME]) do
			vv.ARGTYPE		= TYPE_NAME;
			
			Buffer = Buffer .. string.rep("\n" .. string.rep("-", 64) .. "\n", math.min(#Buffer, 1));
			--[[
			for ___, iii in pairs(v.STRUCT) do
				local vvv;
				
				if (type(vv[iii]) == "table") then
					vvv	= string.format("[%s]", table.concat(vv[iii], ", "));
				else
					vvv	= string.format("%q", vv[iii]);
				end;
				
				Buffer	= Buffer .. string.rep("\n", math.min(#Buffer, 1));
				Buffer	= Buffer .. string.format("%-10s%s", iii, vvv);
			end;
			--]]
			---[[
			local BufferI	= "";
			
			local NAME	= vv.NAME;
			local DESC	= vv.DESC;
			local TAGS	= vv.TAGS;
			local VALUETYPE	= vv.VALUETYPE;
			local REQUIRED	= vv.REQUIRED == true;
			local USED	= vv.USED;
			local VALID	= vv.VALID;
			local VALUE	= vv.VALUE;
			
			VALID		= (vv.VALID ~= nil) and vv.VALID or {};
			
			NAME		= vv.NAME .. string.rep("*", REQUIRED and 1 or 0);
			--TAGS		= TYPE_PREFIX .. table.concat(vv.TAGS, ", " .. TYPE_PREFIX .. TYPE_PREFIX);
			VALUETYPE	= vv.VALUETYPE or "";
			
			
			BufferI = BufferI .. string.format("%-16s\"%s\"", "Name:", NAME);
			BufferI = BufferI .. string.format("\n%-16s%s", "Description:", DESC);
			
			BufferI = BufferI .. "\n";
			
			BufferI = BufferI .. string.format("%-16s", "Usage:");
			
			for iii = 1, #vv.TAGS do
				BufferI = BufferI .. string.rep("\n" .. string.rep(" ", 16), math.min(iii - 1, 1));
				BufferI = BufferI .. string.format("%s%s", TYPE_PREFIX, TAGS[iii]);
				if (#VALUETYPE > 0) then
					BufferI = BufferI .. " ";
					BufferI = BufferI .. string.format("<%s>", (#VALID > 0) and table.concat(VALID, " | ") or VALUETYPE);
				end;
			end;
			
			Buffer			= Buffer .. BufferI;
			
			--BufferI = BufferI .. string.format("{%s}%s%s", TAGS, string.rep(" ", math.min(#VALUETYPE, 1)), VALUETYPE);
			
			for ___, vvv in pairs(vv.TAGS) do
				--print(TYPE_PREFIX .. vvv);
				ArgumentRef[string.upper(TYPE_PREFIX .. vvv)] = vv;
				ArgumentHelp[string.upper(TYPE_PREFIX .. vvv)] = string.format("%-16s(%s) %s\n%s", "Type:", TYPE_PREFIX, TYPE_NAME, BufferI);
				ArgumentRef[string.lower(TYPE_PREFIX .. vvv)] = ArgumentRef[string.upper(TYPE_PREFIX .. vvv)];
				ArgumentHelp[string.lower(TYPE_PREFIX .. vvv)] = ArgumentHelp[string.upper(TYPE_PREFIX .. vvv)];
			end;
			
			ArgumentRef[string.upper(vv.NAME)] = vv;
			ArgumentRef[string.lower(vv.NAME)] = vv;
			---]]
		end;
		
		Buffer = (string.rep("-", 64) .. "\n") .. Buffer;
		
		sDEF_LIST = sDEF_LIST .. "\n" .. Buffer;
	end;
end;

sDEF_LIST	= sDEF_LIST .. ("\n" .. string.rep("=", 64));
sDEF_TYPES	= sDEF_TYPES .. ("\n" .. string.rep("=", 64));

--print(sDEF_TYPES);

local arg_start	= 2;
local arg_end	= 2;

if (arg[arg_end] ~= nil) then
	repeat arg_end = arg_end + 1;
	until (arg[arg_end] == nil);
end;

local arg_index = arg_start + 0;

if (arg_end - arg_start > 0) then
	local ArgumentListBuffer = "";
	
	local show_info		= ArgumentRef.SHOWINFO.VALUE;
	local print_comments	= ArgumentRef.PRINTCOMMENTS.VALUE;
	
	while (true) do
		local ARG = arg[arg_index];
		local PREFIX = string.sub(ARG, 1, 1);
		local TAG = string.reverse(string.match(string.reverse(string.lower(ARG)), "[%?%!%-%w]+") or "");
		
		arg_index = arg_index + 1;
		
		local REF_LOOKUP = string.gsub(PREFIX .. TAG, "(%" .. PREFIX .. "+)", PREFIX);
		local REF = ArgumentRef[string.upper(REF_LOOKUP)] or ArgumentRef[string.lower(REF_LOOKUP)];
		
		local TYPE = 0;
		
		for i = 1, #DEF.Types do
			if (PREFIX == DEF.Types[i].PREFIX) then TYPE = i; break; end;
		end;
		
		if (REF ~= nil) then
			REF.USED = true;
		end;
		
		local ArgumentBuffer = "";
		
		if ((REF ~= nil) and (TYPE == 1)) then
			REF.VALUE = not REF.VALUE;
			
			show_info		= ArgumentRef.SHOWINFO.VALUE;
			print_comments		= ArgumentRef.PRINTCOMMENTS.VALUE;
			
			if (true) then
				ArgumentBuffer = ArgumentBuffer .. string.rep("\n", math.min(#ArgumentBuffer, 1));
				ArgumentBuffer = ArgumentBuffer .. ARG;
			end;
		elseif ((REF ~= nil) and (TYPE == 2)) then
			if (arg[arg_index + 1] ~= nil) then
				if (string.sub(arg[arg_index], 1, 1) == DEF.Types[4].PREFIX) then
					repeat
						arg_index = arg_index + 1;
					until (arg[arg_index] == nil) or (string.sub(arg[arg_index], 1, 1) ~= DEF.Types[3].PREFIX);
				end;
			end;
			
			REF.VALUE	= arg[arg_index] or "";
			
			if (#REF.VALID > 0) then
				REF.USED	= false;
				for i = 1, #REF.VALID do
					if (string.upper(REF.VALID[i]) == string.upper(REF.VALUE)) then
						REF.USED = true;
						break;
					end;
				end;
			else
				REF.USED	= (type(REF.VALUE) == type(REF.VALUETYPE));
				REF.USED	= REF.USED and (#REF.VALUE > 0);
			end;
			
			if (true) then
				ArgumentBuffer = ArgumentBuffer .. string.rep("\n", math.min(#ArgumentBuffer, 1));
				ArgumentBuffer = ArgumentBuffer .. string.format("%s \"%s\"", ARG, REF.VALUE);
			end;
			
			if ((not REF.USED) and print_comments) then
				if (not show_info) then
					ArgumentBuffer = ArgumentBuffer .. string.rep("\n", math.min(#ArgumentBuffer, 1));
					ArgumentBuffer = ArgumentBuffer .. string.format("# %s \"%s\"", ARG, REF.VALUE);
				end;
				
				if (REF.REQUIRED) then
					ArgumentBuffer = ArgumentBuffer .. string.rep("\n", math.min(#ArgumentBuffer, 1));
					ArgumentBuffer = ArgumentBuffer .. "# required value is not used! That's probably bad!";
				end;
				
				if (#REF.VALUE > 0) then
					ArgumentBuffer = ArgumentBuffer .. string.rep("\n", math.min(#ArgumentBuffer, 1));
					ArgumentBuffer = ArgumentBuffer .. "# reason: invalid option";
				else
					ArgumentBuffer = ArgumentBuffer .. string.rep("\n", math.min(#ArgumentBuffer, 1));
					ArgumentBuffer = ArgumentBuffer .. "# reason: no value - invalid";
				end;
			end;
			
			arg_index = arg_index + 1;
		elseif ((REF ~= nil) and (TYPE == 3)) then
			if (arg[arg_index + 1] ~= nil) then
				if (string.sub(arg[arg_index], 1, 1) == DEF.Types[4].PREFIX) then
					repeat
						arg_index = arg_index + 1;
					until (arg[arg_index] == nil) or (string.sub(arg[arg_index], 1, 1) ~= DEF.Types[3].PREFIX);
				end;
			end;
			
			table.insert(REF.VALUES, arg[arg_index] or "");
			
			REF.USED	= REF.USED and (#REF.VALUES > 0);
			
			if (true) then
				ArgumentBuffer = ArgumentBuffer .. string.rep("\n", math.min(#ArgumentBuffer, 1));
				ArgumentBuffer = ArgumentBuffer .. string.format("%s \"%s\"", ARG, REF.VALUES[#REF.VALUES]);
				
				if (#(REF.VALUES[#REF.VALUES]) <= 0) then
					REF.USED	= false;
				end;
			end;
			
			if ((not REF.USED) and print_comments) then
				if (REF.REQUIRED) then
					ArgumentBuffer = ArgumentBuffer .. string.rep("\n", math.min(#ArgumentBuffer, 1));
					ArgumentBuffer = ArgumentBuffer .. "# required array has value that can't be used! That's probably bad!";
				end;
				
				if (not show_info) then
					ArgumentBuffer = ArgumentBuffer .. string.rep("\n", math.min(#ArgumentBuffer, 1));
					ArgumentBuffer = ArgumentBuffer .. string.format("# %s \"%s\"", ARG, REF.VALUES[#REF.VALUES]);
				end;
				
				if (#REF.VALUES[#REF.VALUES] > 0) then
					ArgumentBuffer = ArgumentBuffer .. string.rep("\n", math.min(#ArgumentBuffer, 1));
					ArgumentBuffer = ArgumentBuffer .. "# reason: invalid option";
				else
					ArgumentBuffer = ArgumentBuffer .. string.rep("\n", math.min(#ArgumentBuffer, 1));
					ArgumentBuffer = ArgumentBuffer .. "# reason: no value - invalid";
				end;
			end;
			
			arg_index = arg_index + 1;
		elseif (TYPE == 4) then
			if (print_comments) then
				ArgumentBuffer = ArgumentBuffer .. string.rep("\n", math.min(#ArgumentBuffer, 1));
				ArgumentBuffer = ArgumentBuffer .. string.format("%s%s", PREFIX, string.sub(ARG, 2, -1));
			end;
		end;
		
		if (REF ~= nil) then
			if (TYPE > 0) then
				local INFO	= DEF.Types[TYPE].INFO or {};
				for i = 1, #INFO do
					local ii = INFO[i];
					local vv = REF[ii];
					
					if (type(vv) == "table") then
						vv = (#vv > 0) and string.format("%s", table.concat(REF[ii], " | ")) or "";
					else
						vv = string.format("%q", REF[ii]);
					end;
					
					if (ii == "NAME") then
						vv = REF[ii] .. string.rep("*", REF.REQUIRED and 1 or 0);
						vv = string.format("\"%s\"", vv);
					end;
					
					if (#tostring(vv) > 0) then
						ArgumentBuffer = ArgumentBuffer .. string.rep("\n", math.min(#ArgumentBuffer, 1));
						ArgumentBuffer = ArgumentBuffer .. string.format("%-10s%s", ii, vv);
					end;
				end;
			end;
		end;
		
		if ((REF == nil) and (PREFIX ~= DEF.Types[4].PREFIX)) then
			ArgumentBuffer = ArgumentBuffer .. string.rep("\n", math.min(#ArgumentBuffer, 1));
			ArgumentBuffer = ArgumentBuffer .. string.format("%s\n%s", ARG, "/!\\ Invalid Argument /!\\");
		end;
		
		ArgumentListBuffer = ArgumentListBuffer .. string.rep("\n" .. string.rep("-", 64) .. "\n", math.min(#ArgumentListBuffer * #ArgumentBuffer, 1) * 1);
		ArgumentListBuffer = ArgumentListBuffer .. ArgumentBuffer;
		
		if (arg_index >= arg_end) then break; end;
	end;
	
	ArgumentListBuffer = string.rep("Argument List" .. ("\n" .. string.rep("=", 64) .. "\n") .. ArgumentListBuffer .. ("\n" .. string.rep("=", 64)), math.min(#ArgumentListBuffer, 1));
	
	if (ArgumentRef.CLEAR.VALUE) then
		local clear	= os.execute("clear 2> nul");
		local cls	= os.execute("cls 2> nul");
	end;
	
	if (ArgumentRef.BUILD.VALUE) then
		print(build);
	end;
	
	if (ArgumentRef.SHOWHELP.VALUE) then
		print(string.rep("\n", math.min(#sDEF_LIST, 1)) .. sDEF_LIST);
	end;
	
	if (ArgumentRef.SHOWTYPES.VALUE) then
		print(string.rep("\n", math.min(#sDEF_TYPES, 1)) .. sDEF_TYPES);
	end;
	
	if ((#ArgumentListBuffer > 0) and (ArgumentRef.SHOWINFO.VALUE)) then print(string.rep("\n", math.min(#ArgumentListBuffer, 1)) .. ArgumentListBuffer); end;
	
	if ((ArgumentRef.HELP.USED) and (ArgumentRef.HELP.VALUE ~= nil)) then
		local help_str = (ArgumentHelp[string.lower(ArgumentRef.HELP.VALUE)]);
		
		if (help_str ~= nil) then
			help_str = (string.rep("-", 64) .. "\n") .. help_str .. ("\n" .. string.rep("-", 64));
			print(help_str);
		else
			local dunno_messages	=
			{
				"I don't know what \"%s\" is";
				"Y'haven't defined \"%s\" (properly)";
				"Not gonna even bother making a fool out of myself man-splaining to you what \"%s\" is";
				"\"%s\"? That ain't real!";
				"There's no reference for \"%s\"";
			};
			
			local trailer_special	=
			{
				"Try putting `run /%s` into the command line, it should tell ya all the commands that exist";
			};
			
			local dunno_message	= dunno_messages[math.random(1, #dunno_messages)];
			
			print(string.format(dunno_message, ArgumentRef.HELP.VALUE));
		end;
	end;
end;


--#
if ((ArgumentRef.LOADTEST ~= nil) and (ArgumentRef.LOADTEST.VALUE)) then
	local program		= require("src.test");
	program:run(ArgumentRef);
else
	local program		= require("src.program");
	program:run(ArgumentRef);
end;