local bChunk_Speed_eSolid_Pack_List_Chunks	= 0x80034000;
local bChunk_Speed_eSolid_Pack_List_Header	= 0x00034001;
local bChunk_Speed_eSolid_Chunks		= 0x80034002;
local bChunk_Speed_eSolid			= 0x00034003;
local bChunk_Speed_eSolid_Strip_Entry_Table	= 0x00034004;
local bChunk_Speed_eSolid_Strip_Data		= 0x00034005;
local bChunk_Speed_eSolid_TextureTable		= 0x00034006;
local bChunk_Speed_eSolid_LightMaterialTable	= 0x0003401D;

local function Loader_eSolidPackList(bChunk)
	local FilePointer	= bChunk.Address;
	
	local fmt		= Config.BigEndian and ">" or "<";
	
	if (bChunk.ID == bChunk_Speed_eSolid_Pack_List_Chunks) then
		local ReturnAddress		= (bChunk.Address);
		
		local SolidPackList		= {};
		SolidPackList.Address		= bChunk.Address;
		SolidPackList.Header		= {};
		SolidPackList.NameHashList	= {};
		SolidPackList.SolidInventory	= {};
		SolidPackList.Size		= bChunk.Size;
		
		local xSolidList		= {};
		
		local __SolidObject		= {};
		local __Data			= {};
		local __Groups			= {};
		
		bChunk.Address			= bChunk.Address + 0x00000008;
		
		local function Loader_eSolidListHeader()
			if (bChunk.ID == bChunk_Speed_eSolid_Pack_List_Header) then
				local TempAddress	= bChunk.Address + 0x00000008;
				
				local AlignDiff		= bChunk:Align(0x10);
				bChunk.Address		= bChunk.Address - 0x00000008 - AlignDiff;
				
				TempAddress		= TempAddress + AlignDiff;
				
				SolidPackList.Header	=
				{
					FileName	= string.unpack("<z", ResourceFile:Read(TempAddress + 0x00000000, "<c48"));
					InventoryHandle	= ResourceFile:Read(TempAddress + 0x00000030, "<I4");
				};
				
				print(SolidPackList.Header.FileName);
				
				return true;
			end;
			
			return false;
		end;
		
		local function Loader_eSolid()
			if (bChunk.ID == bChunk_Speed_eSolid) then
				local TempAddress	= bChunk.Address + 0x00000008;
				
				local AlignDiff		= bChunk:Align(0x10);
				bChunk.Address		= bChunk.Address - 0x00000008 - AlignDiff;
				
				TempAddress		= TempAddress + AlignDiff;
				
				local eSolid				=
				{
					NameHash			= ResourceFile:Read(TempAddress + 0x00000008, "<I4");
					Version				= ResourceFile:Read(TempAddress + 0x0000000C, "<i4");
					Name				= string.unpack("<z", ResourceFile:Read(TempAddress + 0x00000010, "<c24") .. "\x00");
					ExternalRigidAnimationNameHash	= ResourceFile:Read(TempAddress + 0x00000028, "<I4");
					Flags				= ResourceFile:Read(TempAddress + 0x00000030, "<H");
					StripFlags			= ResourceFile:Read(TempAddress + 0x00000032, "<H");
					NumStrips			= ResourceFile:Read(TempAddress + 0x00000034, "<h");
					NumPolys			= ResourceFile:Read(TempAddress + 0x00000036, "<h");
					NumVerts			= ResourceFile:Read(TempAddress + 0x00000038, "<h");
					NumOriginalVerts		= ResourceFile:Read(TempAddress + 0x0000003A, "<h");
					SizeOfStripEntryData		= ResourceFile:Read(TempAddress + 0x0000003C, "<i4");
					
					AABBMin				=
					{
						x			= ResourceFile:Read(TempAddress + 0x00000040 + 0x00000000, "<f");
						y			= ResourceFile:Read(TempAddress + 0x00000040 + 0x00000004, "<f");
						z			= ResourceFile:Read(TempAddress + 0x00000040 + 0x00000008, "<f");
						w			= ResourceFile:Read(TempAddress + 0x00000040 + 0x0000000C, "<f");
					};
					
					AABBMax				=
					{
						x			= ResourceFile:Read(TempAddress + 0x00000050 + 0x00000000, "<f");
						y			= ResourceFile:Read(TempAddress + 0x00000050 + 0x00000004, "<f");
						z			= ResourceFile:Read(TempAddress + 0x00000050 + 0x00000008, "<f");
						w			= ResourceFile:Read(TempAddress + 0x00000050 + 0x0000000C, "<f");
					};
					
					PivotMatrix			=
					{
						v0			=
						{
							x		= ResourceFile:Read(TempAddress + 0x00000060 + 0x00000000 + 0x00000000, "<f");
							y		= ResourceFile:Read(TempAddress + 0x00000060 + 0x00000000 + 0x00000004, "<f");
							z		= ResourceFile:Read(TempAddress + 0x00000060 + 0x00000000 + 0x00000008, "<f");
							w		= ResourceFile:Read(TempAddress + 0x00000060 + 0x00000000 + 0x0000000C, "<f");
						};
						v1			=
						{
							x		= ResourceFile:Read(TempAddress + 0x00000060 + 0x00000010 + 0x00000000, "<f");
							y		= ResourceFile:Read(TempAddress + 0x00000060 + 0x00000010 + 0x00000004, "<f");
							z		= ResourceFile:Read(TempAddress + 0x00000060 + 0x00000010 + 0x00000008, "<f");
							w		= ResourceFile:Read(TempAddress + 0x00000060 + 0x00000010 + 0x0000000C, "<f");
						};
						v2			=
						{
							x		= ResourceFile:Read(TempAddress + 0x00000060 + 0x00000020 + 0x00000000, "<f");
							y		= ResourceFile:Read(TempAddress + 0x00000060 + 0x00000020 + 0x00000004, "<f");
							z		= ResourceFile:Read(TempAddress + 0x00000060 + 0x00000020 + 0x00000008, "<f");
							w		= ResourceFile:Read(TempAddress + 0x00000060 + 0x00000020 + 0x0000000C, "<f");
						};
						v3			=
						{
							x		= ResourceFile:Read(TempAddress + 0x00000060 + 0x00000030 + 0x00000000, "<f");
							y		= ResourceFile:Read(TempAddress + 0x00000060 + 0x00000030 + 0x00000004, "<f");
							z		= ResourceFile:Read(TempAddress + 0x00000060 + 0x00000030 + 0x00000008, "<f");
							w		= ResourceFile:Read(TempAddress + 0x00000060 + 0x00000030 + 0x0000000C, "<f");
						};
					};
					
					TextureCount			= ResourceFile:Read(TempAddress + 0x000000AC, "<i4");
					LightMaterialCount		= ResourceFile:Read(TempAddress + 0x000000B0, "<i4");
					
					StripEntryTable			= {};
					StripEntryDataStart		= 0x00000000;
					
					pTextureTable			= {};
					LightMaterialTable		= {};
				};
				
				local HashTestName	= 0xFFFFFFFF;
						
				for j = 1, #eSolid.Name, 1 do
					HashTestName = HashTestName * 0x21;
					HashTestName = HashTestName + string.byte(eSolid.Name, j, j);
					HashTestName = HashTestName & 0xFFFFFFFF;
				end;
				
				local SectionName	= ((#_ENV.Stream.CurrentSection > 0) and _ENV.Stream.CurrentSection or "DEFAULT");
				
				print(string.format("@ 0x%08X: %s.0x%08X - %s\\%s%s", TempAddress, SectionName, eSolid.NameHash, SectionName, eSolid.Name, string.rep("...", (HashTestName ~= eSolid.NameHash) and 1 or 0)));
				
				table.insert(SolidPackList.SolidInventory, eSolid);
				
				__SolidObject = SolidPackList.SolidInventory[#SolidPackList.SolidInventory];
				
				return true;
			end;
			
			return false;
		end;
		
		local function Loader_eSolidStripEntryTable()
			if (bChunk.ID == bChunk_Speed_eSolid_Strip_Entry_Table) then
				local TempAddress	= bChunk.Address + 0x00000008;
				
				local AlignDiff		= bChunk:Align(0x10);
				bChunk.Address		= bChunk.Address - 0x00000008 - AlignDiff;
				
				TempAddress		= TempAddress + AlignDiff;
				
				while (TempAddress < bChunk.Address + 0x00000008 + bChunk.Size) do
					local eStripEntry		=
					{
						TextureIndex		= ResourceFile:Read(TempAddress + 0x00000000, "<i4");
						TextureWidthScale	= ResourceFile:Read(TempAddress + 0x00000004, "<h");
						TextureHeightScale	= ResourceFile:Read(TempAddress + 0x00000006, "<h");
						Data			= ResourceFile:Read(TempAddress + 0x00000008, "<I4");
						DataQWordSize		= ResourceFile:Read(TempAddress + 0x0000000C, "<H");
						Flags			= ResourceFile:Read(TempAddress + 0x0000000E, "<H");
						AABBMin			= {ResourceFile:Read(TempAddress + 0x00000010, "<fff")};
						PolyGroupNumber		= ResourceFile:Read(TempAddress + 0x0000001C, "<B");
						NumVerts		= ResourceFile:Read(TempAddress + 0x0000001D, "<B");
						NumPolys		= ResourceFile:Read(TempAddress + 0x0000001E, "<B");
						LightMaterialIndex	= ResourceFile:Read(TempAddress + 0x0000001F, "<b");
						AABBMax			= {ResourceFile:Read(TempAddress + 0x00000020, "<fff")};
						OriginalFlags		= ResourceFile:Read(TempAddress + 0x0000002C, "<H");
						Nx			= ResourceFile:Read(TempAddress + 0x00000030, "<h");
						Ny			= ResourceFile:Read(TempAddress + 0x00000032, "<h");
						Nz			= ResourceFile:Read(TempAddress + 0x00000034, "<h");
						Nt			= ResourceFile:Read(TempAddress + 0x00000036, "<h");
						MaterialDensity		= ResourceFile:Read(TempAddress + 0x00000038, "<f");
						MipMapK			= ResourceFile:Read(TempAddress + 0x0000003C, "<h");
						MipMapL			= ResourceFile:Read(TempAddress + 0x0000003E, "<b");
					};
					
					TempAddress	= TempAddress + 0x00000040;
					
					table.insert(__SolidObject.StripEntryTable, eStripEntry);
				end;
				
				return true;
			end;
			
			return false;
		end;
		
		local function Loader_eSolidTextureTable()
			if (bChunk.ID == bChunk_Speed_eSolid_TextureTable) then
				local TempAddress	= bChunk.Address + 0x00000008;
				
				while (TempAddress < bChunk.Address + 0x00000008 + bChunk.Size) do
					local eTextureEntry		=
					{
						NameHash		= ResourceFile:Read(TempAddress + 0x00000000, "<I4");
						pTextureInfo		= {};
					};
					
					table.insert(__SolidObject.pTextureTable, eTextureEntry);
					
					TempAddress	= TempAddress + 0x00000008;
				end;
				
				return true;
			end;
			
			return false;
		end;
		
		local function Loader_eSolidLightMaterialTable()
			if (bChunk.ID == bChunk_Speed_eSolid_LightMaterialTable) then
				local TempAddress	= bChunk.Address + 0x00000008;
				
				while (TempAddress < bChunk.Address + 0x00000008 + bChunk.Size) do
					local eLightMaterialEntry	=
					{
						NameHash		= ResourceFile:Read(TempAddress + 0x00000000, "<I4");
						LightMaterial		= {};
					};
					
					table.insert(__SolidObject.LightMaterialTable, eLightMaterialEntry);
					
					TempAddress	= TempAddress + 0x00000008;
				end;
				
				return true;
			end;
			
			return false;
		end;
		
		local function Loader_eSolidStripData()
			if (bChunk.ID == bChunk_Speed_eSolid_Strip_Data) then
				local TempAddress	= bChunk.Address + 0x00000008;
				
				local AlignDiff		= bChunk:Align(0x10);
				bChunk.Address		= bChunk.Address - 0x00000008 - AlignDiff;
				
				TempAddress		= TempAddress + AlignDiff;
				
				__SolidObject.StripEntryDataStart	= (TempAddress);
				
				return true;
			end;
			
			return false;
		end;
		
		local eSolidChunksList		=
		{
			Loader_eSolid;
			Loader_eSolidTextureTable;
			Loader_eSolidLightMaterialTable;
			Loader_eSolidStripEntryTable;
			Loader_eSolidStripData;
		};
		
		local function Loader_eSolidChunks()
			if (bChunk.ID == bChunk_Speed_eSolid_Chunks) then
				local eSolidChunksAddress	= (bChunk.Address);
				local eSolidChunksSize		= (bChunk.Size);
				
				bChunk.Address			= bChunk.Address + 0x00000008;
				
				while (bChunk.Address < eSolidChunksAddress + 0x00000008 + eSolidChunksSize) do
					for i = 1, #eSolidChunksList do
						local Success	= eSolidChunksList[i]();
						
						if (Success == true) then
							break;
						end;
					end;
					
					bChunk:Next();
				end;
				
				__Data				=
				{
					Mode			= PlatChunks.Enum["PSX2/Mode"].Standard;
					
					Type			= ModelulatorEnum.Pipeline.PSX2;
					Version			= __SolidObject.Version;
					StripFlags		= __SolidObject.StripFlags;
					NumStrips		= __SolidObject.NumStrips;
					SizeOfStripEntryData	= __SolidObject.SizeOfStripEntryData;
					StripEntryTable		= __SolidObject.StripEntryTable;
					StripDataPointer	= __SolidObject.StripEntryDataStart;
				};
				
				__Groups			= xSolid.GenerateGroups.PSX2(__Data);
				
				local xSolid	=
				{
					EcstasySolid	= __SolidObject;
					xSolidInfo	= __Data;
					xSolidGroups	= __Groups;
				};
				
				bChunk.Address			= eSolidChunksAddress;
				
				table.insert(xSolidList, xSolid);
				
				return true;
			end;
			
			return false;
		end;
		
		local eSolidPackChunksList	=
		{
			Loader_eSolidListHeader;
			Loader_eSolidChunks;
		};
		
		while (bChunk.Address < SolidPackList.Address + 0x00000008 + SolidPackList.Size) do
			for i = 1, #eSolidPackChunksList do
				local Success	= eSolidPackChunksList[i]();
				
				if (Success == true) then
					break;
				end;
			end;
			
			bChunk:Next();
		end;
		
		local SectionName	= ((#_ENV.Stream.CurrentSection > 0) and _ENV.Stream.CurrentSection or "DEFAULT");
		
		-- HP2: export each parsed solid independently. A single broken object can
		-- no longer discard the rest of the pack during DAE generation.
		dae:generate_solid_name(xSolidList, SectionName);

		for _, SolidToExport in ipairs(xSolidList) do
			table.insert(_ENV.FileOutputList,
			{
				Inventory = "Solids";
				Output = {Function = dae.generate_solid_single, Arguments = {dae, SolidToExport, SectionName}};
			});
		end;

		table.insert(_ENV.FileOutputList,
		{
			Inventory = "Solids";
			Output = {Function = dae.generate_solid_palette, Arguments = {dae, xSolidList, SectionName}};
		});
		
		bChunk.Address		= ReturnAddress;
		
		return true;
	end;
	
	return false;
end;

return Loader_eSolidPackList;