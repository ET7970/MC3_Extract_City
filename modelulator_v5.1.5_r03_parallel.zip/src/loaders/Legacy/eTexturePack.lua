local bChunk_Speed_TexturePack_Chunks		= 0xB0300001;
local bChunk_Speed_TexturePack_Header		= 0x30300002;
local bChunk_Speed_TexturePack_Info_Table	= 0x30300003;
local bChunk_Speed_TexturePack_Data		= 0x30300004;

local function Loader_eTexturePack(bChunk)
	local ReturnAddress			= (bChunk.Address);
	
	local IsEarlyAlpha		= _ENV.Config.Game.Value < ModelulatorEnum.Game.HOTPURSUIT2.Value;
	local EarlyAlphaOffset		= (IsEarlyAlpha == true) and 0x01 or 0x00;
	local ImageInfoOffset		= 0x00000052 - EarlyAlphaOffset * 0x00000002;
	local PostImageInfoOffset	= ImageInfoOffset + 0x00000004 * 0x00000007;
	local TextureInfoSize		= 0x000000A4 - EarlyAlphaOffset * 0x00000004;
	
	local function MaxAlign(x, n)
		n	= ~-(1 << n);
		return (x + n) & ~n;
	end;
	
	if (bChunk.ID == bChunk_Speed_TexturePack_Chunks) then
		local eTexturePack			= {};
		eTexturePack.Header			= {};
		eTexturePack.TextureInfoTable		= {};
		eTexturePack.Address			= (bChunk.Address);
		eTexturePack.Size			= (bChunk.Size);
		eTexturePack.DataHash			= 0xFFFFFFFF;
		
		eTexturePack.Data			= {};
		eTexturePack.Data.Pointer		= 0x00000000;
		eTexturePack.Data.Size			= 0x00000000;
		
		for Offset = 0x00000000, ~-eTexturePack.Size do
			local CurrentByte	= ResourceFile:Read(eTexturePack.Address + 0x08 + Offset, "<B");
			eTexturePack.DataHash	= eTexturePack.DataHash * 0x21 + CurrentByte;
			eTexturePack.DataHash	= eTexturePack.DataHash & 0xFFFFFFFF;
		end;
		
		local eTexturePackInfoJSON		= "";
		
		bChunk.Address				= bChunk.Address + 0x00000008;
		
		local function Loader_TexturePackHeader()
			if (bChunk.ID == bChunk_Speed_TexturePack_Header) then
				local TempAddress	= bChunk.Address + 0x00000008;
				
				local AlignDiff		= bChunk:Align(0x10);
				bChunk.Address		= bChunk.Address - 0x00000008 - AlignDiff;
				
				TempAddress		= TempAddress + AlignDiff;
				
				eTexturePack.Header	=
				{
					Name		= string.unpack("<z", ResourceFile:Read(TempAddress + 0x00000000, "<c16"));
					FileName	= string.unpack("<z", ResourceFile:Read(TempAddress + 0x00000010, "<c64"));
					pTexturePack	= {};
				};
				
				return true;
			end;
			
			return false;
		end;
		
		local function Loader_TextureInfoTable()
			if (bChunk.ID == bChunk_Speed_TexturePack_Info_Table) then
				local TempAddress	= bChunk.Address + 0x00000008;
				
				while (TempAddress < bChunk.Address + 0x00000008 + bChunk.Size) do
					local TextureInfo					=
					{
						DebugName					= string.unpack("<z", ResourceFile:Read(TempAddress + 0x00000008, "<c24") .. "\x00");
						NameHash					= ResourceFile:Read(TempAddress + 0x00000020, "<I4");
						Width						= ResourceFile:Read(TempAddress + 0x00000024, "<h");
						Height						= ResourceFile:Read(TempAddress + 0x00000026, "<h");
						BitDepth					= ResourceFile:Read(TempAddress + 0x00000028, "<B");
						RenderingOrder					= ResourceFile:Read(TempAddress + 0x00000029, "<B");
						NumPaletteEntries				= ResourceFile:Read(TempAddress + 0x0000002A, "<h");
						PaletteVramBlocksRequired			= ResourceFile:Read(TempAddress + 0x0000002C, "<h");
						ImageVramBlocksRequired				= ResourceFile:Read(TempAddress + 0x0000002E, "<h");
						ImagePlacement					= ResourceFile:Read(TempAddress + 0x00000030, "<i4");
						PalettePlacement				= ResourceFile:Read(TempAddress + 0x00000034, "<i4");
						ImageSize					= ResourceFile:Read(TempAddress + 0x00000038, "<i4");
						PaletteSize					= ResourceFile:Read(TempAddress + 0x0000003C, "<i4");
						ImageParentHash					= ResourceFile:Read(TempAddress + 0x00000040, "<I4");
						BaseImageSize					= ResourceFile:Read(TempAddress + 0x00000044, "<i4");
						ShiftWidth					= ResourceFile:Read(TempAddress + 0x00000048, "<B");
						ShiftHeight					= ResourceFile:Read(TempAddress + 0x00000049, "<B");
						PixelStorageMode				= ResourceFile:Read(TempAddress + 0x0000004A, "<B");
						ClutPixelStorageMode				= ResourceFile:Read(TempAddress + 0x0000004B, "<B");
						TilableUV					= ResourceFile:Read(TempAddress + 0x0000004C, "<B");
						ApplyAlphaSorting				= ResourceFile:Read(TempAddress + 0x0000004D, "<B");
						TextureFx					= ResourceFile:Read(TempAddress + 0x0000004E, "<B");
						IsAnySemitransparencyFlag			= ResourceFile:Read(TempAddress + 0x0000004F, "<B");
						bWriteZ						= (IsEarlyAlpha == true) and 0x00 or ResourceFile:Read(TempAddress + 0x00000050, "<B");
						ImageInfos					=
						{
							{
								TextureBasePointerOffset	= ResourceFile:Read(TempAddress + ImageInfoOffset + 0x00000000 + 0x00000000, "<h");
								TextureBufferWidth		= ResourceFile:Read(TempAddress + ImageInfoOffset + 0x00000000 + 0x00000002, "<B");
								Is32BitSwizzled			= ResourceFile:Read(TempAddress + ImageInfoOffset + 0x00000000 + 0x00000003, "<B");
							};
							{
								TextureBasePointerOffset	= ResourceFile:Read(TempAddress + ImageInfoOffset + 0x00000004 + 0x00000000, "<h");
								TextureBufferWidth		= ResourceFile:Read(TempAddress + ImageInfoOffset + 0x00000004 + 0x00000002, "<B");
								Is32BitSwizzled			= ResourceFile:Read(TempAddress + ImageInfoOffset + 0x00000004 + 0x00000003, "<B");
							};
							{
								TextureBasePointerOffset	= ResourceFile:Read(TempAddress + ImageInfoOffset + 0x00000008 + 0x00000000, "<h");
								TextureBufferWidth		= ResourceFile:Read(TempAddress + ImageInfoOffset + 0x00000008 + 0x00000002, "<B");
								Is32BitSwizzled			= ResourceFile:Read(TempAddress + ImageInfoOffset + 0x00000008 + 0x00000003, "<B");
							};
							{
								TextureBasePointerOffset	= ResourceFile:Read(TempAddress + ImageInfoOffset + 0x0000000C + 0x00000000, "<h");
								TextureBufferWidth		= ResourceFile:Read(TempAddress + ImageInfoOffset + 0x0000000C + 0x00000002, "<B");
								Is32BitSwizzled			= ResourceFile:Read(TempAddress + ImageInfoOffset + 0x0000000C + 0x00000003, "<B");
							};
							{
								TextureBasePointerOffset	= ResourceFile:Read(TempAddress + ImageInfoOffset + 0x00000010 + 0x00000000, "<h");
								TextureBufferWidth		= ResourceFile:Read(TempAddress + ImageInfoOffset + 0x00000010 + 0x00000002, "<B");
								Is32BitSwizzled			= ResourceFile:Read(TempAddress + ImageInfoOffset + 0x00000010 + 0x00000003, "<B");
							};
							{
								TextureBasePointerOffset	= ResourceFile:Read(TempAddress + ImageInfoOffset + 0x00000014 + 0x00000000, "<h");
								TextureBufferWidth		= ResourceFile:Read(TempAddress + ImageInfoOffset + 0x00000014 + 0x00000002, "<B");
								Is32BitSwizzled			= ResourceFile:Read(TempAddress + ImageInfoOffset + 0x00000014 + 0x00000003, "<B");
							};
							{
								TextureBasePointerOffset	= ResourceFile:Read(TempAddress + ImageInfoOffset + 0x00000018 + 0x00000000, "<h");
								TextureBufferWidth		= ResourceFile:Read(TempAddress + ImageInfoOffset + 0x00000018 + 0x00000002, "<B");
								Is32BitSwizzled			= ResourceFile:Read(TempAddress + ImageInfoOffset + 0x00000018 + 0x00000003, "<B");
							};
						};
						NumMipMapLevels					= ResourceFile:Read(TempAddress + PostImageInfoOffset + 0x00000000, "<B");
						MMag						= ResourceFile:Read(TempAddress + PostImageInfoOffset + 0x00000001, "<b");
						MMin						= ResourceFile:Read(TempAddress + PostImageInfoOffset + 0x00000002, "<b");
						MipMapL						= ResourceFile:Read(TempAddress + PostImageInfoOffset + 0x00000003, "<b");
						MipMapK						= ResourceFile:Read(TempAddress + PostImageInfoOffset + 0x00000004, "<h");
						GlossMapInAlpha					= ResourceFile:Read(TempAddress + PostImageInfoOffset + 0x00000006, "<B");
						BiasLevel					= ResourceFile:Read(TempAddress + PostImageInfoOffset + 0x00000007, "<B");
						AlphaBits					= ResourceFile:Read(TempAddress + PostImageInfoOffset + 0x00000008, "<B");
						AlphaFix					= ResourceFile:Read(TempAddress + PostImageInfoOffset + 0x00000009, "<B");
						UsedFlag					= ResourceFile:Read(TempAddress + PostImageInfoOffset + 0x0000000A, "<B");
						ScrollType					= ResourceFile:Read(TempAddress + PostImageInfoOffset + 0x0000000B, "<B");
						ScrollSpeedS					= ResourceFile:Read(TempAddress + MaxAlign(PostImageInfoOffset + 0x0000000C, 02) + 0x00000000, "<f");
						ScrollSpeedT					= ResourceFile:Read(TempAddress + MaxAlign(PostImageInfoOffset + 0x0000000C, 02) + 0x00000004, "<f");
						ScrollTimeStep					= ResourceFile:Read(TempAddress + MaxAlign(PostImageInfoOffset + 0x0000000C, 02) + 0x00000008, "<f");
					};
					
					TextureInfo.PixelStorageMode				= ModelulatorEnum.PixelStorageMode:GetEnumFromValue(TextureInfo.PixelStorageMode);
					TextureInfo.ClutPixelStorageMode			= ModelulatorEnum.PixelStorageMode:GetEnumFromValue(TextureInfo.ClutPixelStorageMode);
					
					TempAddress						= TempAddress + TextureInfoSize;
					
					table.insert(eTexturePack.TextureInfoTable, TextureInfo);
				end;
				
				return true;
			end;
			
			return false;
		end;
		
		local eTextureHashList			= {};
		
		local function UnpackTextures()
			local file_output		= {};
			
			local eTextureInfoLast		= {};
			
			local SectionName		= (_ENV.Stream.CurrentSection ~= "") and _ENV.Stream.CurrentSection or eTexturePack.Header.Name;
			
			local eTextureInfoJSON		= {};
			
			for i = 1, #eTexturePack.TextureInfoTable do
				local eTextureInfo		= eTexturePack.TextureInfoTable[i];
				local NameHash			= eTextureInfo.NameHash;
				
				local ImageCompressionType	= eTextureInfo.PixelStorageMode;
				local PaletteCompressionType	= eTextureInfo.ClutPixelStorageMode;
				
				--print(string.format("eTexture_0x%08X", NameHash));
				--print(string.format("eTexture_0x%08X", NameHash));
				
				if (_ENV.Config.Pipeline == ModelulatorEnum.Pipeline.PSX2) then
					print(string.format("eTexture_0x%08X\n\tImage:      0x%08X, %s;\n\tPalette:    0x%08X, %s;\n\tResolution: %i x %i (0x%01X, 0x%01X);\n\tAlphaBits:  0x%02X;\n\tBitDepth:   %i;\n\tDebugName:  %q;", NameHash, eTextureInfo.ImagePlacement + eTexturePack.Data.Pointer, ImageCompressionType.Name, eTextureInfo.PalettePlacement + eTexturePack.Data.Pointer, PaletteCompressionType.Name, eTextureInfo.Width, eTextureInfo.Height, eTextureInfo.ShiftWidth, eTextureInfo.ShiftHeight, eTextureInfo.AlphaBits, eTextureInfo.BitDepth, eTextureInfo.DebugName));
					print(string.format("\tTextureFX:                 0x%02X;", eTextureInfo.TextureFx));
					print(string.format("\tIsAnySemitransparencyFlag: 0x%02X;", eTextureInfo.IsAnySemitransparencyFlag));
					for i = 1, #eTextureInfo.ImageInfos do
						local ImageInfo		= eTextureInfo.ImageInfos[i];
						print(string.format("\tTBP:\t0x%08X;\n\tTBW:\t0x%08X;\n\t32S:\t0x%02X;", ImageInfo.TextureBasePointerOffset, ImageInfo.TextureBufferWidth, ImageInfo.Is32BitSwizzled));
					end;
				end;
				
				local TextureName		= string.format("0x%08X.TPK0x%08X.%s.%s", eTextureInfo.NameHash, eTexturePack.DataHash, SectionName, eTextureInfo.DebugName);
				
				table.insert(eTextureHashList, TextureName);
				table.insert(eTextureInfoJSON, string.format("{\"Texture\":%q,\"TextureFX\":%q,\"AlphaUsage\":\"None\",\"AlphaBlend\":\"SrcCopy\"}", TextureName .. ".png", ModelulatorEnum.TextureFX:GetEnumFromValue(eTextureInfo.TextureFx).Name));
				--table.insert(eTextureInfoJSON, string.format("{\"Texture\":%q,\"AlphaUsage\":%q,\"AlphaBlend\":%q}", TextureName .. ".png", eTextureInfo.AlphaUsageType.Name, eTextureInfo.AlphaBlendType.Name));
				
				local CLUTData		= "";
				local TextureData	= "";
				
				local do_shift		= false;
				
				BGRA32ImageData			= texture.Legacy.PSX2:Get(eTexturePack.Data.Pointer, eTextureInfo);
				
				local dib_size			= 0x6C;
				local dib_width			= eTextureInfo.Width;
				local dib_height		= eTextureInfo.Height;
				local dib_numcolourplanes	= 0x0001;
				local dib_bpp			= 0x0020;
				local dib_pxarraycomp		= 0x00000003;
				local dib_rawsize		= (#BGRA32ImageData * 0x04);
				local dib_printwidth		= 0x00000000;
				local dib_printheight		= 0x00000000;
				local dib_numcolours		= 0x00000000;
				local dib_numicolours		= 0x00000000;
				local dib_mask_r		= 0x00FF0000;
				local dib_mask_g		= 0x0000FF00;
				local dib_mask_b		= 0x000000FF;
				local dib_mask_a		= 0xFF000000;
				local dib_lcs			= 0x73524742;
				local dib_gamma_r		= 0x00000000;
				local dib_gamma_g		= 0x00000000;
				local dib_gamma_b		= 0x00000000;
				
				local bmp_magic			= 0x4D42;
				local bmp_size			= 0x0E + dib_size + (#BGRA32ImageData * 0x04);
				local bmp_reserved		= 0x00000000;
				local bmp_indexoffset		= 0x0E + dib_size;
				
				local bmp_header		= string.pack("<H i4 I4 i4", bmp_magic, bmp_size, bmp_reserved, bmp_indexoffset);
				local dib_header		= string.pack("<i4 i4 i4 h h I4 i4 i4 i4 i4 i4 I4 I4 I4 I4 I4 xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx I4 I4 I4", dib_size, dib_width, dib_height, dib_numcolourplanes, dib_bpp, dib_pxarraycomp, dib_rawsize, dib_printwidth, dib_printheight, dib_numcolours, dib_numicolours, dib_mask_r, dib_mask_g, dib_mask_b, dib_mask_a, dib_lcs, dib_gamma_r, dib_gamma_g, dib_gamma_b);
				
				local bmp_data			= bmp_header .. dib_header .. table.concat(BGRA32ImageData, "");
				
				table.insert(file_output, {FileName = TextureName, FileType = "bmp"; Data = bmp_data});
			end;
			
			table.insert(FileOutputInventory.Textures, file_output);
			
			eTexturePackInfoJSON	= string.format("{\"Name\":%q,\"FileName\":%q,\"eTextureInfoList\":[%s]}", eTexturePack.Header.Name, eTexturePack.Header.FileName, table.concat(eTextureInfoJSON, ","));
			
			if (#eTextureHashList > 0) then
				table.insert(FileOutputInventory.Textures, {{FileName = string.format("eTexturePack.TPK0x%08X.%s", eTexturePack.DataHash, SectionName), FileType = "dae"; Data = dae:new_texturepack(eTextureHashList)}});
				table.insert(FileOutputInventory.Textures, {{FileName = string.format("eTexturePackInfo.TPK0x%08X.%s", eTexturePack.DataHash, SectionName), FileType = "json"; Data = eTexturePackInfoJSON}});
				eTextureHashList	= {};
			end;
		end;
		
		local function Loader_TextureData()
			if (bChunk.ID == bChunk_Speed_TexturePack_Data) then
				local TempAddress	= bChunk.Address + 0x00000008;
				
				local AlignDiff		= bChunk:Align(0x80);
				bChunk.Address		= bChunk.Address - 0x00000008 - AlignDiff;
				
				eTexturePack.Data.Pointer	= TempAddress + AlignDiff;
				eTexturePack.Data.Size		= bChunk.Size - AlignDiff;
				
				UnpackTextures();
				
				return true;
			end;
			
			return false;
		end;
		
		while (bChunk.Address < eTexturePack.Address + 0x00000008 + eTexturePack.Size) do
			Loader_TexturePackHeader();
			Loader_TextureInfoTable();
			Loader_TextureData();
			
			bChunk:Next();
		end;
		
		return true;
	end;
	
	return false;
end;

return Loader_eTexturePack;