local function Loader_bGeomPack(bChunk)
	local ReturnAddress	= bChunk.Address;
	
	if (bChunk.ID == 0x80030100) then
		local bGeom		= {};
		bGeom.DataPointer	= 0xFFFFFFFF;
		bGeom.EntryTable	= {};
		
		local __Data		= {};
		local __Groups		= {};
		
		local xSolidList	= {};
		
		local EOC		= bChunk.Address + 0x08 + bChunk.Size;
		
		bChunk.Address		= bChunk.Address + 0x08;
		
		while (bChunk.Address < EOC) do
			if (bChunk.ID == 0x00030101) then
				bGeom.DataPointer	= bChunk.Address + 0x08;
			elseif (bChunk.ID == 0x00030102) then
				local TempAddress	= bChunk.Address + 0x08;
				
				local bGeomEntry	=
				{
					NameHash	= ResourceFile:Read(TempAddress + 0x08, "<I4");
					
					Unk00		= ResourceFile:Read(TempAddress + 0x0C, "<H");
					Unk01		= ResourceFile:Read(TempAddress + 0x0E, "<B");
					Scale		= ResourceFile:Read(TempAddress + 0x0F, "<B");
					
					DataPointer	= bGeom.DataPointer;
					
					UnkCount	= {ResourceFile:Read(TempAddress + 0x14, "<BBBB")};
					
					Unk02		= ResourceFile:Read(TempAddress + 0x18, "<I4");
					Unk03		= ResourceFile:Read(TempAddress + 0x1C, "<I4");
					
					DataOffsets	=
					{
						RGBA	= ResourceFile:Read(TempAddress + 0x20, "<I4");
						ST	= ResourceFile:Read(TempAddress + 0x24, "<I4");
						Texture	= ResourceFile:Read(TempAddress + 0x28, "<I4");
						XYZ	= ResourceFile:Read(TempAddress + 0x2C, "<I4");
					};
					
					Unk04		= ResourceFile:Read(TempAddress + 0x30, "<H");
					Unk05		= ResourceFile:Read(TempAddress + 0x32, "<H");
					
					StripEntryTable	= {};
				};
				
				bGeomEntry.pTextureTable	= {};
				bGeomEntry.LightMaterialTable	= {};
				
				TempAddress		= TempAddress + 0x34;
				
				while (TempAddress < bChunk.Address + 0x08 + bChunk.Size) do
					local bGeomStrip	=
					{
						Flags		= ResourceFile:Read(TempAddress + 0x00, "<B");
						
						Unk00		= ResourceFile:Read(TempAddress + 0x01, "<B");
						Unk01		= ResourceFile:Read(TempAddress + 0x02, "<B");
						Unk02		= ResourceFile:Read(TempAddress + 0x03, "<B");
						
						VertexIndices	= {ResourceFile:Read(TempAddress + 0x04, "<BBBB")};
						
						DataIndices	=
						{
							RGBA	= ResourceFile:Read(TempAddress + 0x08, "<B");
							Texture	= ResourceFile:Read(TempAddress + 0x09, "<B");
							ST	= ResourceFile:Read(TempAddress + 0x0A, "<B");
							XYZ	= ResourceFile:Read(TempAddress + 0x0B, "<B");
						};
					};
					
					local TexturePointer	= bGeomEntry.DataPointer + bGeomEntry.DataOffsets.Texture + bGeomStrip.DataIndices.Texture * 0x0C;
					local TextureNameHash	= ResourceFile:Read(TexturePointer + 0x00, "<I4");
					
					bGeomStrip.TextureIndex		= #bGeomEntry.pTextureTable;
					bGeomStrip.LightMaterialIndex	= -1;
					bGeomStrip.PolyGroupNumber	= 0;
					
					table.insert(bGeomEntry.pTextureTable, {NameHash = TextureNameHash});
					
					table.insert(bGeomEntry.StripEntryTable, bGeomStrip);
					
					TempAddress	= TempAddress + 0x0C;
				end;
				
				bGeomEntry.NumStrips		= #bGeomEntry.StripEntryTable;
				
				table.insert(bGeom.EntryTable, bGeomEntry);
				
				__Data			= bGeom.EntryTable[#bGeom.EntryTable];
				__Groups		= xSolid.GenerateGroups.PSX_NASCAR(__Data);
				
				local xSolid	=
				{
					xSolidInfo	= __Data;
					xSolidGroups	= __Groups;
				};
				
				table.insert(xSolidList, xSolid);
			end;
			
			bChunk:Next();
		end;
		
		bChunk.Address		= ReturnAddress;
		
		bChunk:Next();
		
		if (bChunk.ID == 0x00030017) then
			local TempAddress	= bChunk.Address + 0x08;
			local Count		= ResourceFile:Read(TempAddress, "<i4");
			
			TempAddress		= TempAddress + 0x04;
			
			while (TempAddress < bChunk.Address + 0x08 + bChunk.Size) do
				local Position	= {ResourceFile:Read(TempAddress + 0x10, "<i4i4i4")};
				local NameHash	= ResourceFile:Read(TempAddress + 0x3C, "<I4");
				
				for i = 1, #bGeom.EntryTable do
					local bGeomEntry	= bGeom.EntryTable[i];
					
					if (bGeomEntry.NameHash == NameHash) then
						bGeomEntry.PivotMatrix	=
						{
							v0		=
							{
								x	= 1;
								y	= 0;
								z	= 0;
								w	= 0;
							};
							v1		=
							{
								x	= 0;
								y	= 1;
								z	= 0;
								w	= 0;
							};
							v2		=
							{
								x	= 0;
								y	= 0;
								z	= 1;
								w	= 0;
							};
							v3	=
							{
								x	= Position[1] / 0x8000;
								y	= Position[2] / 0x8000;
								z	= Position[3] / 0x8000;
								w	= 1;
							};
						};
						
						break;
					end;
				end;
				
				TempAddress	= TempAddress + 0x4C;
			end;
		end;
		
		bChunk.Address		= ReturnAddress;
		
		---[[
		local SectionName	= ((#_ENV.Stream.CurrentSection > 0) and _ENV.Stream.CurrentSection or "DEFAULT");
						
		local FileOutputObject	=
		{
			Inventory	= "Solids";
			Output		= {Function = dae.generate_solid, Arguments = {dae, xSolidList, SectionName}};
		};
		
		dae:generate_solid_name(xSolidList, SectionName);
		
		table.insert(_ENV.FileOutputList, FileOutputObject);
		---]]
		
		return true;
	else
		return false;
	end;
end;

return Loader_bGeomPack;