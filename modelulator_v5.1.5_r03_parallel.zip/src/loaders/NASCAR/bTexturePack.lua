local VersionToUse		= 0;
		
local VersionDefinitions	=
{
	{
		Game	= ModelulatorEnum.Game.NASCAR2001;
		Version	= 1;
	};
	{
		Game	= ModelulatorEnum.Game.NASCARTHUNDER2004;
		Version	= 2;
	};
};
		
local function SortVersionDefinitions(a, b)
	return a.Game.Value < b.Game.Value;
end;

table.sort(VersionDefinitions, SortVersionDefinitions);

local function Loader_Null(bChunk)
	return false;
end;

local function SetupVersionToUse()
	for i = 1, #VersionDefinitions do
		local VersionDefinition		= VersionDefinitions[i];
		
		if (_ENV.Config.Game.Value >= VersionDefinition.Game.Value) then
			VersionToUse		= VersionDefinition.Version;
		else
			break;
		end;
	end;
	
	if (VersionToUse == 0) then
		print(string.format("why are you using the game \"%s\" with this?", _ENV.Config.Game.Name));
		
		return false;
	end;
	
	print(string.format("Game: %s\nVersion: %i", _ENV.Config.Game.Name, VersionToUse));
	
	return true;
end;

--# actual stuff

local function sx(x, n)
	local SignExtension	= -(((x >> (~-n)) & 0x01) << n);
	
	return (x & ~SignExtension) | SignExtension;
end;

local function CreateBitmaps(TexturePack)
	local file_output			= {};
	
	local ImageDecode			= {};
	
	ImageDecode[1]		=
	function(TextureInfo)
		local BGRA32ImageDataTable	= {};
		
		local TextureCompressionType	= TextureInfo.TextureCompressionType;
		local BPP			= TextureCompressionType;
		local TX, TY			= table.unpack(TextureInfo.ImageInfo.Texture.Location);
		local CX, CY			= table.unpack(TextureInfo.ImageInfo.CLUT.Location);
		local TextureDataInfo		= TexturePack.Header.DataInfo[-~TextureInfo.ImageInfo.Texture.Index];
		
		if (TextureDataInfo == nil) then
			print(TextureInfo.ImageInfo.Texture.Index);
		end;
		
		local CLUTDataInfo		= TexturePack.Header.DataInfo[-~TextureInfo.ImageInfo.CLUT.Index];
		local TextureBase		= TextureDataInfo.Pointer + 0x08 + TX * 0x02 + TY * TextureDataInfo.Resolution[1] * 0x02;
		local CLUTBase			= CLUTDataInfo.Pointer + 0x08 + CX * 0x02 + CY * CLUTDataInfo.Resolution[1] * 0x02;
		local Width, Height		= table.unpack(TextureInfo.DataInfo.Resolution);
		
		local Mask			= ~-(0x01 << BPP);
		local Size			= (BPP >> 0x02);
		
		for y = Height - 1, 0, -1 do
			for x = 0, Width - 1 do
				local Offset		= BPP * (x & 0x01);
				
				local TexturePointer	= TextureBase + (x >> 0x01) * Size + y * TextureDataInfo.Resolution[1] * 0x02;
				local TextureIndex	= (ResourceFile:Read(TexturePointer, "<I" .. Size) >> Offset) & Mask;
				
				local CLUTPointer	= CLUTBase + TextureIndex * 0x02;
				local ColourData	= ResourceFile:Read(CLUTPointer, "<H");
				
				local RGBSize		= 0x05;
				local RGBMask		= ~-(0x01 << RGBSize);
				local STP		= ((ColourData >> (0x03 * RGBSize)) & 0x01);
				
				local R			= math.floor((((ColourData >> (0x00 * RGBSize)) & RGBMask) / RGBMask) * 0xFF + 0.5);
				local G			= math.floor((((ColourData >> (0x01 * RGBSize)) & RGBMask) / RGBMask) * 0xFF + 0.5);
				local B			= math.floor((((ColourData >> (0x02 * RGBSize)) & RGBMask) / RGBMask) * 0xFF + 0.5);
				local A			= (((R + G + B + STP) > 0) and 0xFF or 0x00) << (STP * (TextureInfo.Unk00));
				
				table.insert(BGRA32ImageDataTable, string.pack("<BBBB", B, G, R, A));
			end;
		end;
		
		return BGRA32ImageDataTable;
	end;
	
	ImageDecode[2]		=
	function(TextureInfo)
		local BGRA32ImageDataTable	= {};
		
		local TextureCompressionType	= TextureInfo.TextureCompressionType;
		local BPP			= (TextureCompressionType & 0x0C);
		local Unk00			= sx(TextureCompressionType >> 0x4, 0x4);
		local TX, TY			= table.unpack(TextureInfo.ImageInfo.Texture.Location);
		local CX, CY			= table.unpack(TextureInfo.ImageInfo.CLUT.Location);
		local TextureDataInfo		= TexturePack.Header.DataInfo[-~TextureInfo.ImageInfo.Texture.Index];
		
		local CLUTDataInfo		= TexturePack.Header.DataInfo[-~TextureInfo.ImageInfo.CLUT.Index];
		local TextureBase		= TextureDataInfo.Pointer + 0x08 + TX * 0x02 + TY * TextureDataInfo.Resolution[1] * 0x02;
		local CLUTBase			= CLUTDataInfo.Pointer + 0x08 + CX * 0x02 + CY * CLUTDataInfo.Resolution[1] * 0x02;
		local Width, Height		= table.unpack(TextureInfo.Resolution);
		
		local Mask			= ~-(0x01 << BPP);
		local Size			= (BPP >> 0x02);
		
		for y = Height - 1, 0, -1 do
			for x = 0, Width - 1 do
				local Offset		= BPP * (x & 0x01);
				
				local TexturePointer	= TextureBase + (x >> 0x01) * Size + y * TextureDataInfo.Resolution[1] * 0x02;
				local TextureIndex	= (ResourceFile:Read(TexturePointer, "<I" .. Size) >> Offset) & Mask;
				
				local CLUTPointer	= CLUTBase + TextureIndex * 0x02;
				local ColourData	= ResourceFile:Read(CLUTPointer, "<H");
				
				local RGBSize		= 0x05;
				local RGBMask		= ~-(0x01 << RGBSize);
				local STP		= ((ColourData >> (0x03 * RGBSize)) & 0x01);
				
				local R			= math.floor((((ColourData >> (0x00 * RGBSize)) & RGBMask) / RGBMask) * 0xFF + 0.5);
				local G			= math.floor((((ColourData >> (0x01 * RGBSize)) & RGBMask) / RGBMask) * 0xFF + 0.5);
				local B			= math.floor((((ColourData >> (0x02 * RGBSize)) & RGBMask) / RGBMask) * 0xFF + 0.5);
				local A			= (((R + G + B + STP) > 0) and 0xFF or 0x00) << (STP * Unk00);
				
				table.insert(BGRA32ImageDataTable, string.pack("<BBBB", B, G, R, A));
			end;
		end;
		
		return BGRA32ImageDataTable;
	end;
	
	local TextureInfoJSON		= {};
	
	for j = 1, #TexturePack.TextureInfoTable do
		local TextureInfo		= TexturePack.TextureInfoTable[j];
		
		local TextureName		= string.format("0x%08X.TPK0x%08X.0x%08X", TextureInfo.NameHash, TexturePack.Header.Name1Hash, TexturePack.Header.Name0Hash);
		
		local BGRA32ImageData		= ImageDecode[VersionToUse](TextureInfo);
		
		table.insert(eTextureHashList, TextureName);
		
		table.insert(TextureInfoJSON, string.format("{\"Texture\":%q,\"AlphaUsage\":%q,\"AlphaBlend\":%q}", TextureName .. ".png", "PunchThru", "SrcCopy"));
		
		local Resolution		= {};
		
		if (VersionToUse == 1) then
			Resolution		= TextureInfo.DataInfo.Resolution;
		else
			Resolution		= TextureInfo.Resolution;
		end;
		
		local dib_size			= 0x6C;
		local dib_width			= Resolution[1];
		local dib_height		= Resolution[2];
		local dib_numcolourplanes	= 0x0001;
		local dib_bpp			= 0x0020;
		local dib_pxarraycomp		= 0x00000003;
		local dib_rawsize		= (#BGRA32ImageData * 0x04);
		local dib_printwidth		= 0x00000000;
		local dib_printheight		= 0x00000000;
		local dib_numcolours		= 0x00000000;
		local dib_numicolours		= 0x00000000;
		local dib_mask_r		= 0x00FF0000;
		local dib_mask_g		= 0x0000FF00;
		local dib_mask_b		= 0x000000FF;
		local dib_mask_a		= 0xFF000000;
		local dib_lcs			= 0x73524742;
		local dib_gamma_r		= 0x00000000;
		local dib_gamma_g		= 0x00000000;
		local dib_gamma_b		= 0x00000000;
		
		local bmp_magic			= 0x4D42;
		local bmp_size			= 0x0E + dib_size + (#BGRA32ImageData * 0x04);
		local bmp_reserved		= 0x00000000;
		local bmp_indexoffset		= 0x0E + dib_size;
		
		local bmp_header		= string.pack("<H i4 I4 i4", bmp_magic, bmp_size, bmp_reserved, bmp_indexoffset);
		local dib_header		= string.pack("<i4 i4 i4 h h I4 i4 i4 i4 i4 i4 I4 I4 I4 I4 I4 xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx I4 I4 I4", dib_size, dib_width, dib_height, dib_numcolourplanes, dib_bpp, dib_pxarraycomp, dib_rawsize, dib_printwidth, dib_printheight, dib_numcolours, dib_numicolours, dib_mask_r, dib_mask_g, dib_mask_b, dib_mask_a, dib_lcs, dib_gamma_r, dib_gamma_g, dib_gamma_b);
		
		local bmp_data			= bmp_header .. dib_header .. table.concat(BGRA32ImageData, "");
		
		table.insert(file_output, {FileName = TextureName, FileType = "bmp"; Data = bmp_data});
	end;
	
	table.insert(FileOutputInventory.Textures, file_output);
	
	TexturePackInfoJSON	= string.format("{\"eTextureInfoList\":[%s]}", table.concat(TextureInfoJSON, ","));
	
	if (#eTextureHashList > 0) then
		table.insert(FileOutputInventory.Textures, {{FileName = string.format("eTexturePack.TPK0x%08X.0x%08X", TexturePack.Header.Name1Hash, TexturePack.Header.Name0Hash), FileType = "dae"; Data = dae:new_texturepack(eTextureHashList)}});
		table.insert(FileOutputInventory.Textures, {{FileName = string.format("eTexturePackInfo.TPK0x%08X.0x%08X", TexturePack.Header.Name1Hash, TexturePack.Header.Name0Hash), FileType = "json"; Data = TexturePackInfoJSON}});
		eTextureHashList	= {};
	end;
end;

local function Loader_Nascar_bTexturePack(bChunk)
	if (SetupVersionToUse() == false) then
		return false;
	end;
	
	local ReturnAddress	= bChunk.Address;
	
	if (bChunk.ID == 0x80030014) then
		local EOC		= bChunk.Address + 0x08 + bChunk.Size;
		
		local TexturePack	= {};
		local DataIndex		= -1;
		
		bChunk.Address		= bChunk.Address + 0x08;
		
		while (bChunk.Address < EOC) do
			if (bChunk.ID == 0x00030015) then
				local TempAddress	= bChunk.Address + 0x08;
				
				TexturePack.Header		=
				{
					Name0Hash		= ResourceFile:Read(TempAddress + 0x08, "<I4");
					Name1Hash		= ResourceFile:Read(TempAddress + 0x0C, "<I4");
					DataInfo		=
					{
						{
							Pointer		= ResourceFile:Read(TempAddress + 0x10, "<I4");
							Resolution	= {ResourceFile:Read(TempAddress + 0x14, "<hh")};
						};
						{
							Pointer		= ResourceFile:Read(TempAddress + 0x18, "<I4");
							Resolution	= {ResourceFile:Read(TempAddress + 0x1C, "<hh")};
						};
					};
					TextureInfoCount	= ResourceFile:Read(TempAddress + 0x20, "<i4");
				};
				
				TempAddress			= TempAddress + 0x24;
				
				TexturePack.TextureInfoTable	= {};
				
				while (TempAddress < bChunk.Address + 0x08 + bChunk.Size) do
					local TextureInfo	= {};
					
					if (_ENV.Config.Game.Value < ModelulatorEnum.Game.NASCARTHUNDER2004.Value) then
						TextureInfo	=
						{
							NameHash		= ResourceFile:Read(TempAddress + 0x00, "<I4");
							TextureCompressionType	= ResourceFile:Read(TempAddress + 0x04, "<B");
							Unk00			= ResourceFile:Read(TempAddress + 0x05, "<b");
							PaletteEntryCount	= ResourceFile:Read(TempAddress + 0x06, "<h");
							ImageInfo		=
							{
								Texture		=
								{
									Index		= ResourceFile:Read(TempAddress + 0x08, "<h");
									Location	= {ResourceFile:Read(TempAddress + 0x0A, "<hh")};
								};
								CLUT		=
								{
									Index		= ResourceFile:Read(TempAddress + 0x0E, "<h");
									Location	= {ResourceFile:Read(TempAddress + 0x10, "<hh")};
								};
							};
							DataInfo		=
							{
								Pointer			= ResourceFile:Read(TempAddress + 0x14, "<I4");
								Resolution		= {ResourceFile:Read(TempAddress + 0x18, "<hh")};
							};
						};
						
						TempAddress			= TempAddress + 0x1C;
					else
						TextureInfo	=
						{
							NameHash		= ResourceFile:Read(TempAddress + 0x00, "<I4");
							TextureCompressionType	= ResourceFile:Read(TempAddress + 0x04, "<B");
							PaletteMaxIndex		= ResourceFile:Read(TempAddress + 0x05, "<B");
							Resolution		= {ResourceFile:Read(TempAddress + 0x06, "<BB")};
							ImageInfo		=
							{
								Texture		=
								{
									Index		= 1;
									Location	= {ResourceFile:Read(TempAddress + 0x08, "<hh")};
								};
								CLUT		=
								{
									Index		= 0;
									Location	= {ResourceFile:Read(TempAddress + 0x0C, "<hh")};
								};
							};
							Pointer			= ResourceFile:Read(TempAddress + 0x10, "<I4");
						};
						
						TextureInfo.Resolution[1]		= -~TextureInfo.Resolution[1];
						TextureInfo.Resolution[2]		= -~TextureInfo.Resolution[2];
						
						TextureInfo.ImageInfo.CLUT.Index	= TextureInfo.TextureCompressionType & 0x01;
						
						TempAddress			= TempAddress + 0x14;
					end;
					
					table.insert(TexturePack.TextureInfoTable, TextureInfo);
				end;
			elseif (bChunk.ID == 0x00030016) then
				local TempAddress		= bChunk.Address + 0x08;
				DataIndex			= DataIndex + 1;
				
				TexturePack.Header.DataInfo[-~DataIndex].Pointer = TempAddress;
			end;
			
			bChunk:Next();
		end;
		
		CreateBitmaps(TexturePack);
		
		return true;
	end;
	
	return false;
end;

return Loader_Nascar_bTexturePack;