local function Loader_PlatChunksGamecube(bChunk, SolidPackList, SolidDataSize)
	local fmt		= _ENV.Config.BigEndian and ">" or "<";
	
	local GamecubeInfoPointer	= bChunk.Address;
	local GamecubeListPointer	= bChunk.Address;
	local GamecubeDataPointer	= bChunk.Address;
	local GamecubeInfoSize		= bChunk.Size;
	local GamecubeListSize		= bChunk.Size;
	local GamecubeDataSize		= bChunk.Size;
	
	local GamecubeData		= {};
	GamecubeData.Type		= ModelulatorEnum.Pipeline.GAMECUBE;
	GamecubeData.Version		= 0x0000;
	GamecubeData.StripFlags		= 0x0000;
	GamecubeData.NumStrips		= 0x0000;
	GamecubeData.NumIdxClrTable	= 0x0000;
	GamecubeData.SizeOfStripData	= 0x00000000;
	GamecubeData.DataOffset0	= 0x00000000;
	GamecubeData.DataOffset1	= 0x00000000;
	GamecubeData.DataOffset2	= 0x00000000;
	GamecubeData.DataOffset3	= 0x00000000;
	GamecubeData.StripDataPointer	= 0x00000000;
	GamecubeData.StripEntryTable	= {};
	
	local SolidDataPointer = bChunk.Address;
	
	while (bChunk.Address - SolidDataPointer < SolidDataSize) do
		if (bChunk.ID == 0x00134800) then
			eSolidPlatInfoPointer		= bChunk.Address + 0x08;
			eSolidPlatInfoSize		= bChunk.Size;
			
			local AlignDiff			= bChunk:Align(0x10);
			bChunk.Address			= bChunk.Address - 0x08 - AlignDiff;
			
			eSolidPlatInfoPointer		= eSolidPlatInfoPointer + AlignDiff;
			eSolidPlatInfoSize		= eSolidPlatInfoSize - AlignDiff;
			
			GamecubeData.Version		= ResourceFile:Read(eSolidPlatInfoPointer + 0x00, fmt .. "H");
			GamecubeData.Flags		= ResourceFile:Read(eSolidPlatInfoPointer + 0x02, fmt .. "H");
			GamecubeData.NumStrips		= ResourceFile:Read(eSolidPlatInfoPointer + 0x04, fmt .. "h");
			GamecubeData.NumIdxClrTable	= ResourceFile:Read(eSolidPlatInfoPointer + 0x06, fmt .. "H");
			GamecubeData.SizeOfStripData	= ResourceFile:Read(eSolidPlatInfoPointer + 0x08, fmt .. "i");
			GamecubeData.DataOffset0	= ResourceFile:Read(eSolidPlatInfoPointer + 0x0C, fmt .. "I");
			GamecubeData.DataOffset1	= ResourceFile:Read(eSolidPlatInfoPointer + 0x10, fmt .. "I");
			GamecubeData.DataOffset2	= ResourceFile:Read(eSolidPlatInfoPointer + 0x14, fmt .. "I");
			GamecubeData.DataOffset3	= ResourceFile:Read(eSolidPlatInfoPointer + 0x18, fmt .. "I");
		elseif (bChunk.ID == 0x00134801) then
			eStripEntryTablePointer		= bChunk.Address + 0x08;
			eStripEntryTableSize		= bChunk.Size;
			
			local AlignDiff			= bChunk:Align(0x10);
			bChunk.Address			= bChunk.Address - 0x08 - AlignDiff;
			
			eStripEntryTablePointer		= eStripEntryTablePointer + AlignDiff;
			eStripEntryTableSize		= eStripEntryTableSize - AlignDiff;
			
			while (eStripEntryTablePointer < bChunk.Address + 0x08 + bChunk.Size) do
				local eStripEntry		= {};
				
				--if (GamecubeData.Version >= 0x001C) then
					local eStripEntry	=
					{
						DataOffset		= ResourceFile:Read(eStripEntryTablePointer + 0x00, fmt .. "I");
						DataSize		= ResourceFile:Read(eStripEntryTablePointer + 0x04, fmt .. "H");
						Flags			= ResourceFile:Read(eStripEntryTablePointer + 0x06, fmt .. "H");
						NumVerts		= ResourceFile:Read(eStripEntryTablePointer + 0x08, fmt .. "B");
						NumPolys		= ResourceFile:Read(eStripEntryTablePointer + 0x09, fmt .. "B");
						PolyGroupNumber		= ResourceFile:Read(eStripEntryTablePointer + 0x0A, fmt .. "B");
						TextureIndex		= ResourceFile:Read(eStripEntryTablePointer + 0x0B, fmt .. "B");
						LightMaterialIndex	= ResourceFile:Read(eStripEntryTablePointer + 0x0C, fmt .. "B");
						VtxDescAndFmt		= ResourceFile:Read(eStripEntryTablePointer + 0x0E, fmt .. "H");
						DataDisplayListSize	= ResourceFile:Read(eStripEntryTablePointer + 0x10, fmt .. "H");
						GDOptDLDiffuse		= ResourceFile:Read(eStripEntryTablePointer + 0x12, fmt .. "H");
					};
					
					eStripEntryTablePointer		= eStripEntryTablePointer + 0x14;
				--end;
				
				table.insert(GamecubeData.StripEntryTable, eStripEntry);
			end;
		elseif (bChunk.ID == 0x00134802) then
			eStripDataPointer		= bChunk.Address + 0x08;
			eStripDataSize			= bChunk.Size;
			
			local AlignDiff			= bChunk:Align(SolidPackList.Header.Alignment);
			bChunk.Address			= bChunk.Address - 0x08 - AlignDiff;
			
			eStripDataPointer		= eStripDataPointer + AlignDiff;
			eStripDataSize			= eStripDataSize - AlignDiff;
			
			GamecubeData.StripDataPointer	= eStripDataPointer;
		end;
		
		bChunk:Next();
	end;
	
	return GamecubeData;
end;

return Loader_PlatChunksGamecube;