local PlatChunks	= {};
PlatChunks.Enum		= Cleanums.new("PlatChunksEnum");

_ENV.PlatChunks		= PlatChunks;

PlatChunks.PSX2		= require("src.loaders.PlatChunksPSX2");
PlatChunks.Gamecube	= require("src.loaders.PlatChunksGamecube");
PlatChunks.Revolution	= require("src.loaders.PlatChunksRevolution");

return PlatChunks;