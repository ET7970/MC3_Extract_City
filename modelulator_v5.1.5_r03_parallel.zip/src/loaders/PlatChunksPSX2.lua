if (PlatChunks.Enum["PSX2/Mode"] == nil) then
	PlatChunks.Enum:Add("PSX2/Mode");
	PlatChunks.Enum["PSX2/Mode"]:Add("Standard",	0x00000000);
	PlatChunks.Enum["PSX2/Mode"]:Add("Morph",	0x00000001);
end;

local function Loader_PlatChunksPSX2(bChunk, SolidPackList, SolidDataSize)
	local fmt			= _ENV.Config.BigEndian and ">" or "<";
	
	local PSX2Data			= {};
	PSX2Data.Type			= ModelulatorEnum.Pipeline.PSX2;
	PSX2Data.Version		= 0x0000;
	PSX2Data.StripFlags		= 0x0000;
	PSX2Data.NumStrips		= 0x0000;
	PSX2Data.SizeOfStripData	= 0x00000000;
	PSX2Data.StripEntryTable	= {};
	PSX2Data.Mode			= PlatChunks.Enum["PSX2/Mode"].Standard;
	
	local SolidDataPointer 		= bChunk.Address;
	
	while (bChunk.Address - SolidDataPointer < SolidDataSize) do
		local AlignDiff		= 0x00;
		local AlignmentValue	= 0x01;
		
		if
		(
			(PSX2Data.Mode == PlatChunks.Enum["PSX2/Mode"].Standard)
			and
			(
				(bChunk.ID > 0x00134A02)
				and
				(bChunk.ID < 0x00134A07)
			)
		)
		then
			PSX2Data.Mode	= PlatChunks.Enum["PSX2/Mode"].Morph;
			PSX2Data.Morph	= {};
		end;
		
		if (bChunk.ID == 0x00134A00) then
			--# BCHUNK_SPEED_ESOLID_PS2_PLATINFO
			
			local PSX2HeaderPointer		= bChunk.Address + 0x08;
			
			AlignmentValue			= 0x10;
			AlignDiff			= bChunk:Align(AlignmentValue);
			bChunk.Address			= bChunk.Address - 0x08 - AlignDiff;
			
			PSX2HeaderPointer		= PSX2HeaderPointer + AlignDiff;
			
			PSX2Data.Version		= ResourceFile:Read(PSX2HeaderPointer + 0x00, fmt .. "H");
			PSX2Data.StripFlags		= ResourceFile:Read(PSX2HeaderPointer + 0x02, fmt .. "H");
			PSX2Data.NumStrips		= ResourceFile:Read(PSX2HeaderPointer + 0x04, fmt .. "H");
			PSX2Data.VertexCount		= ResourceFile:Read(PSX2HeaderPointer + 0x06, fmt .. "H");
			PSX2Data.SizeOfStripData	= ResourceFile:Read(PSX2HeaderPointer + 0x08, fmt .. "I4");
			
			--print(string.format("0x%08X", PSX2HeaderPointer));
		elseif (bChunk.ID == 0x00134A01) then
			--# BCHUNK_SPEED_ESOLID_PS2_STRIP_ENTRY_TABLE
			
			local StripEntryTablePointer	= bChunk.Address + 0x08;
			
			AlignmentValue			= 0x10;
			AlignDiff			= bChunk:Align(AlignmentValue);
			bChunk.Address			= bChunk.Address - 0x08 - AlignDiff;
			
			StripEntryTablePointer		= StripEntryTablePointer + AlignDiff;
			
			for i = 0, PSX2Data.NumStrips - 1 do
				local StripEntry	= {};
				
				if (_ENV.Config.Game == ModelulatorEnum.Game.PROSTREET) then
					StripEntry	=
					{
						Flags			= ResourceFile:Read(StripEntryTablePointer + 0x00 + i * 0x10, fmt .. "H");
						NumVerts		= ResourceFile:Read(StripEntryTablePointer + 0x02 + i * 0x10, fmt .. "B");
						NumPolys		= ResourceFile:Read(StripEntryTablePointer + 0x03 + i * 0x10, fmt .. "B");
						DataQWordOffset		= ResourceFile:Read(StripEntryTablePointer + 0x04 + i * 0x10, fmt .. "H");
						DataQWordSize		= ResourceFile:Read(StripEntryTablePointer + 0x06 + i * 0x10, fmt .. "B");
						PolyGroupNumber		= ResourceFile:Read(StripEntryTablePointer + 0x07 + i * 0x10, fmt .. "B");
						
						MaterialDensity		= 1.0;
						
						Nz			= ResourceFile:Read(StripEntryTablePointer + 0x0A + i * 0x10, fmt .. "b");
						Nt			= ResourceFile:Read(StripEntryTablePointer + 0x0B + i * 0x10, fmt .. "b");
						TextureIndex		= ResourceFile:Read(StripEntryTablePointer + 0x0C + i * 0x10, fmt .. "b");
						LightMaterialIndex	= ResourceFile:Read(StripEntryTablePointer + 0x0D + i * 0x10, fmt .. "b");
					};
				else
					StripEntry	=
					{
						Flags			= ResourceFile:Read(StripEntryTablePointer + 0x00 + i * 0x10, fmt .. "H");
						NumVerts		= ResourceFile:Read(StripEntryTablePointer + 0x02 + i * 0x10, fmt .. "B");
						NumPolys		= ResourceFile:Read(StripEntryTablePointer + 0x03 + i * 0x10, fmt .. "B");
						MaterialDensity		= ResourceFile:Read(StripEntryTablePointer + 0x04 + i * 0x10, fmt .. "f");
						DataQWordOffset		= ResourceFile:Read(StripEntryTablePointer + 0x08 + i * 0x10, fmt .. "H");
						Nz			= ResourceFile:Read(StripEntryTablePointer + 0x0A + i * 0x10, fmt .. "b");
						Nt			= ResourceFile:Read(StripEntryTablePointer + 0x0B + i * 0x10, fmt .. "b");
						DataQWordSize		= ResourceFile:Read(StripEntryTablePointer + 0x0C + i * 0x10, fmt .. "B");
						PolyGroupNumber		= ResourceFile:Read(StripEntryTablePointer + 0x0D + i * 0x10, fmt .. "B");
						TextureIndex		= ResourceFile:Read(StripEntryTablePointer + 0x0E + i * 0x10, fmt .. "b");
						LightMaterialIndex	= ResourceFile:Read(StripEntryTablePointer + 0x0F + i * 0x10, fmt .. "b");
					};
				end;
				
				table.insert(PSX2Data.StripEntryTable, StripEntry);
			end;
		elseif (bChunk.ID == 0x00134A02) then
			--# BCHUNK_SPEED_ESOLID_PS2_STRIP_DATA
			
			local StripDataPointer		= bChunk.Address + 0x08;
			
			AlignmentValue			= SolidPackList.Header.Alignment;
			AlignDiff			= bChunk:Align(AlignmentValue);
			bChunk.Address			= bChunk.Address - 0x08 - AlignDiff;
			
			StripDataPointer		= StripDataPointer + AlignDiff;
			
			--local StripDataQWordPointer	= StripDataPointer >> 0x4;
			PSX2Data.StripDataPointer	= StripDataPointer;
		elseif (bChunk.ID == 0x00134A03) then
			--# BCHUNK_SPEED_ESOLID_PS2_MORPHSTRIPINDEX_DATA
			
			--# <<2024.06.09>>
			--[[
			PROSTREET:
			looks to be a list of indices, each index is a 16-bit integer (short / word)
			signed? (will assume they are by default)
			
			comes after BCHUNK_SPEED_ESOLID_PS2_MORPHVERTEX_DATA
			--]]
			
			local StripIndexPointer			= bChunk.Address + 0x08;
			
			AlignmentValue				= 0x10;
			AlignDiff				= bChunk:Align(AlignmentValue);
			bChunk.Address				= bChunk.Address - 0x08 - AlignDiff;
			
			StripIndexPointer			= StripIndexPointer + AlignDiff;
			
			PSX2Data.Morph.StripIndexPointer	= StripIndexPointer;
		elseif (bChunk.ID == 0x00134A04) then
			--# BCHUNK_SPEED_ESOLID_PS2_MORPHVERTEX_DATA
			
			--# <<2024.06.09>>
			--[[
			PROSTREET:
			list of vertex elements - each 0x30 / 48 bytes in size, 0x20 / 32 of which explicity store data
			
			+0x0000	bVector3 Position
				+0x0000	float X
				+0x0004	float Y
				+0x0008	float Z
			
			+0x000C	bVector2 TextureCoordinate
				+0x0000	float U
				+0x0004	float V
			
			+0x0014	bVector3 Normal
				+0x0000	float X
				+0x0004	float Y
				+0x0008	float Z
			
			
			comes after BCHUNK_SPEED_ESOLID_PS2_STRIP_ENTRY_TABLE
			--]]
			
			local VertexDataPointer			= bChunk.Address + 0x08;
			
			AlignmentValue				= 0x10;
			AlignDiff				= bChunk:Align(AlignmentValue);
			bChunk.Address				= bChunk.Address - 0x08 - AlignDiff;
			
			VertexDataPointer			= VertexDataPointer + AlignDiff;
			
			PSX2Data.Morph.VertexDataPointer	= VertexDataPointer;
		elseif (bChunk.ID == 0x00134A05) then
			--# BCHUNK_SPEED_ESOLID_PS2_MORPHVERTEX_WORKDATA
			
			--# <<2024.06.09>>
			--[[
			PROSTREET:
			surface-level observation: data looks to be a copy of BCHUNK_SPEED_ESOLID_PS2_MORPHVERTEX_DATA
			i guess this one is used in game when damage is turned on
			
			comes after and indexes data from BCHUNK_SPEED_ESOLID_PS2_MORPHSTRIPINDEX_OFFSET_DATA
			--]]
			
			local VertexWorkDataPointer		= bChunk.Address + 0x08;
			
			AlignmentValue				= 0x10;
			AlignDiff				= bChunk:Align(AlignmentValue);
			bChunk.Address				= bChunk.Address - 0x08 - AlignDiff;
			
			VertexWorkDataPointer			= VertexWorkDataPointer + AlignDiff;
			
			PSX2Data.Morph.VertexWorkDataPointer	= VertexWorkDataPointer;
		elseif (bChunk.ID == 0x00134A06) then
			--# BCHUNK_SPEED_ESOLID_PS2_MORPHSTRIPINDEX_OFFSET_DATA
			
			--# <<2024.06.09>>
			--[[
			PROSTREET:
			looks to be a list of indices, each index is a 16-bit integer (short / word)
			signed? (will assume they are by default)
			
			comes after and indexes data from BCHUNK_SPEED_ESOLID_PS2_MORPHSTRIPINDEX_DATA
			--]]
			
			local StripIndexOffsetPointer		= bChunk.Address + 0x08;
			
			AlignmentValue				= 0x10;
			AlignDiff				= bChunk:Align(AlignmentValue);
			bChunk.Address				= bChunk.Address - 0x08 - AlignDiff;
			
			StripIndexOffsetPointer			= StripIndexOffsetPointer + AlignDiff;
			
			PSX2Data.Morph.StripIndexOffsetPointer	= StripIndexOffsetPointer;
		end;
		
		--log_string = log_string .. string.rep("\n", math.min(#log_string, 1)) .. (string.format("0x%08X: %s [0x%02X] (0x%08X)", bChunk.Address, bChunk, AlignmentValue, bChunk.Size - AlignDiff));
		
		bChunk:Next();
	end;
	
	if (PSX2Data.StripDataPointer == nil) then
		--PSX2Data.Unsupported		= true; --# shhhhhh
		PSX2Data.StripDataPointer	= 0xFFFFFFFF;
		--PSX2Data.NumStrips		= 0x0000;
	end;
	
	return PSX2Data;
end;

return Loader_PlatChunksPSX2;