local function Loader_PlatChunksRevolution(bChunk, SolidPackList, SolidDataSize)
	local fmt		= _ENV.Config.BigEndian and ">" or "<";
	
	local RevolutionInfoPointer	= bChunk.Address;
	local RevolutionListPointer	= bChunk.Address;
	local RevolutionDataPointer	= bChunk.Address;
	local RevolutionInfoSize	= bChunk.Size;
	local RevolutionListSize	= bChunk.Size;
	local RevolutionDataSize	= bChunk.Size;
	
	local RevolutionData		= {};
	RevolutionData.Type		= ModelulatorEnum.Pipeline.REVOLUTION;
	RevolutionData.Version		= 0x0000;
	RevolutionData.StripFlags	= 0x0000;
	RevolutionData.NumStrips	= 0x0000;
	RevolutionData.NumIdxClrTable	= 0x0000;
	RevolutionData.SizeOfStripData	= 0x00000000;
	RevolutionData.DataOffset0	= 0x00000000;
	RevolutionData.DataOffset1	= 0x00000000;
	RevolutionData.DataOffset2	= 0x00000000;
	RevolutionData.DataOffset3	= 0x00000000;
	RevolutionData.StripDataPointer	= 0xFFFFFFFF;
	RevolutionData.StripEntryTable	= {};
	
	local SolidDataPointer		= bChunk.Address + 0x00;
	
	while (bChunk.Address - SolidDataPointer < SolidDataSize) do
		if (bChunk.ID == 0x00134800) then
			eSolidPlatInfoPointer		= bChunk.Address + 0x08;
			eSolidPlatInfoSize		= bChunk.Size;
			
			local AlignDiff			= bChunk:Align(0x10);
			bChunk.Address			= bChunk.Address - 0x08 - AlignDiff;
			
			eSolidPlatInfoPointer		= eSolidPlatInfoPointer + AlignDiff;
			eSolidPlatInfoSize		= eSolidPlatInfoSize - AlignDiff;
			
			RevolutionData.Version		= ResourceFile:Read(eSolidPlatInfoPointer + 0x00, fmt .. "H");
			RevolutionData.Flags		= ResourceFile:Read(eSolidPlatInfoPointer + 0x02, fmt .. "H");
			RevolutionData.NumStrips	= ResourceFile:Read(eSolidPlatInfoPointer + 0x04, fmt .. "h");
			RevolutionData.NumIdxClrTable	= ResourceFile:Read(eSolidPlatInfoPointer + 0x06, fmt .. "H");
			RevolutionData.SizeOfStripData	= ResourceFile:Read(eSolidPlatInfoPointer + 0x08, fmt .. "i");
			RevolutionData.DataOffset0	= ResourceFile:Read(eSolidPlatInfoPointer + 0x0C, fmt .. "I");
			RevolutionData.DataOffset1	= ResourceFile:Read(eSolidPlatInfoPointer + 0x10, fmt .. "I");
			RevolutionData.DataOffset2	= ResourceFile:Read(eSolidPlatInfoPointer + 0x14, fmt .. "I");
			RevolutionData.DataOffset3	= ResourceFile:Read(eSolidPlatInfoPointer + 0x18, fmt .. "I");
		elseif (bChunk.ID == 0x00134801) then
			eStripEntryTablePointer		= bChunk.Address + 0x08;
			eStripEntryTableSize		= bChunk.Size;
			
			local AlignDiff			= bChunk:Align(0x10);
			bChunk.Address			= bChunk.Address - 0x08 - AlignDiff;
			
			eStripEntryTablePointer		= eStripEntryTablePointer + AlignDiff;
			eStripEntryTableSize		= eStripEntryTableSize - AlignDiff;
			
			while (eStripEntryTablePointer < bChunk.Address + 0x08 + bChunk.Size) do
				local eStripEntry		= {};
				
				if (RevolutionData.Version >= 0x001C) then
					eStripEntry	=
					{
						DataOffset		= ResourceFile:Read(eStripEntryTablePointer + 0x00, fmt .. "I");
						DataSize		= ResourceFile:Read(eStripEntryTablePointer + 0x04, fmt .. "H");
						Flags			= ResourceFile:Read(eStripEntryTablePointer + 0x06, fmt .. "H");
						NumVerts		= ResourceFile:Read(eStripEntryTablePointer + 0x08, fmt .. "B");
						PolyGroupNumber		= ResourceFile:Read(eStripEntryTablePointer + 0x09, fmt .. "b");
						TextureIndex		= ResourceFile:Read(eStripEntryTablePointer + 0x0A, fmt .. "b");
						LightMaterialIndex	= ResourceFile:Read(eStripEntryTablePointer + 0x0B, fmt .. "b");
						VtxDescAndFmt		= ResourceFile:Read(eStripEntryTablePointer + 0x0C, fmt .. "H");
						DataDisplayListSize	= ResourceFile:Read(eStripEntryTablePointer + 0x0E, fmt .. "H");
						GDOptDLDiffuse		= ResourceFile:Read(eStripEntryTablePointer + 0x10, fmt .. "I");
					};
					
					eStripEntryTablePointer		= eStripEntryTablePointer + 0x14;
				else
					eStripEntry	=
					{
						DataOffset		= ResourceFile:Read(eStripEntryTablePointer + 0x00, fmt .. "I");
						DataSize		= ResourceFile:Read(eStripEntryTablePointer + 0x04, fmt .. "H");
						Flags			= ResourceFile:Read(eStripEntryTablePointer + 0x06, fmt .. "H");
						NumVerts		= ResourceFile:Read(eStripEntryTablePointer + 0x08, fmt .. "B");
						PolyGroupNumber		= ResourceFile:Read(eStripEntryTablePointer + 0x09, fmt .. "b");
						TextureIndex		= ResourceFile:Read(eStripEntryTablePointer + 0x0A, fmt .. "b");
						LightMaterialIndex	= ResourceFile:Read(eStripEntryTablePointer + 0x0B, fmt .. "b");
						VtxDescAndFmt		= ResourceFile:Read(eStripEntryTablePointer + 0x0C, fmt .. "H");
						DataDisplayListSize	= ResourceFile:Read(eStripEntryTablePointer + 0x0E, fmt .. "H");
					};
					
					eStripEntryTablePointer		= eStripEntryTablePointer + 0x10;
				end;
				
				--print(string.format("0x%08X", eStripEntry.DataOffset));
				
				_ENV.BITMASK_REVOLUTION_VTXDESCANDFMT		= _ENV.BITMASK_REVOLUTION_VTXDESCANDFMT | eStripEntry.VtxDescAndFmt;
				_ENV.BITMASK_BAND_REVOLUTION_VTXDESCANDFMT	= _ENV.BITMASK_BAND_REVOLUTION_VTXDESCANDFMT & eStripEntry.VtxDescAndFmt;
				
				table.insert(RevolutionData.StripEntryTable, eStripEntry);
			end;
		elseif (bChunk.ID == 0x00134802) then
			eStripDataPointer		= bChunk.Address + 0x08;
			eStripDataSize			= bChunk.Size;
			
			local AlignDiff			= bChunk:Align(SolidPackList.Header.Alignment);
			bChunk.Address			= bChunk.Address - 0x08 - AlignDiff;
			
			eStripDataPointer		= eStripDataPointer + AlignDiff;
			eStripDataSize			= eStripDataSize - AlignDiff;
			
			RevolutionData.StripDataPointer	= eStripDataPointer;
		elseif (bChunk.ID == 0x00134806) then
			RevolutionExtracurricularsPointer	= bChunk.Address + 0x08;
			RevolutionExtracurricularsSize		= bChunk.Size;
			
			local AlignDiff			= bChunk:Align(0x10);
			bChunk.Address			= bChunk.Address - 0x08 - AlignDiff;
			
			RevolutionExtracurricularsPointer	= RevolutionExtracurricularsPointer + AlignDiff;
			RevolutionExtracurricularsSize		= RevolutionExtracurricularsSize - AlignDiff;
			
			--# what am i going to do with you?
		end;
		
		bChunk:Next();
	end;
	
	return RevolutionData;
end;

return Loader_PlatChunksRevolution;