local function Loader_PlatChunksXbox(bChunk, SolidPackList, SolidDataSize)
	local fmt			= _ENV.Config.BigEndian and ">" or "<";
	
	local XboxData			= {};
	XboxData.Type			= ModelulatorEnum.Pipeline.XBOX;
	XboxData.Version		= 0x0000;
	XboxData.Flags			= 0x0000;
	XboxData.NumPolys		= 0x0000;
	XboxData.NumMeshEntries		= 0x0000;
	XboxData.MaxVertexSize		= 0x0000;
	XboxData.MeshEntryTable		= {};
	XboxData.MeshEntryDataPointer	= 0xFFFFFFFF;
	
	local MeshEntryIndex		= 1;
	
	local SolidDataPointer = bChunk.Address;
	
	while (bChunk.Address - SolidDataPointer < SolidDataSize) do
		local AlignDiff		= 0x00;
		local AlignmentValue	= 0x01;
		
		if (bChunk.ID == 0x00134B00) then
			eSolidPlatInfoPointer		= bChunk.Address + 0x08;
			eSolidPlatInfoSize		= bChunk.Size;
			
			local AlignDiff			= bChunk:Align(0x10);
			bChunk.Address			= bChunk.Address - 0x08 - AlignDiff;
			
			eSolidPlatInfoPointer		= eSolidPlatInfoPointer + AlignDiff;
			eSolidPlatInfoSize		= eSolidPlatInfoSize - AlignDiff;
			
			XboxData.Version		= ResourceFile:Read(eSolidPlatInfoPointer + 0x00, fmt .. "H");
			XboxData.Flags			= ResourceFile:Read(eSolidPlatInfoPointer + 0x04, fmt .. "H");
			XboxData.NumPolys		= ResourceFile:Read(eSolidPlatInfoPointer + 0x06, fmt .. "H");
			XboxData.NumMeshEntries		= ResourceFile:Read(eSolidPlatInfoPointer + 0x08, fmt .. "H");
			XboxData.MaxVertexSize		= ResourceFile:Read(eSolidPlatInfoPointer + 0x0A, fmt .. "H");
			--print(string.format("0x%08X", PSX2HeaderPointer));
		elseif (bChunk.ID == 0x00134B02) then
			eMeshEntryTablePointer		= bChunk.Address + 0x08;
			eMeshEntryTableSize		= bChunk.Size;
			
			local AlignDiff			= bChunk:Align(0x10);
			bChunk.Address			= bChunk.Address - 0x08 - AlignDiff;
			
			eMeshEntryTablePointer		= eMeshEntryTablePointer + AlignDiff;
			eMeshEntryTableSize		= eMeshEntryTableSize - AlignDiff;
			
			while (eMeshEntryTablePointer < bChunk.Address + 0x08 + bChunk.Size) do
				local eMeshEntry	=
				{
					BBoxMin		= {ResourceFile:Read(eMeshEntryTablePointer + 0x00, fmt .. "fff")};
					BBoxMax		= {ResourceFile:Read(eMeshEntryTablePointer + 0x10, fmt .. "fff")};
				};
				
				eMeshEntryTablePointer		= eMeshEntryTablePointer + 0x60;
				
				table.insert(XboxData.MeshEntryTable, eMeshEntry);
			end;
		elseif (bChunk.ID == 0x00134B03) then
			MeshEntryDataPointer		= bChunk.Address + 0x08;
			
			local AlignDiff			= bChunk:Align(0x10);
			bChunk.Address			= bChunk.Address - 0x08 - AlignDiff;
			
			MeshEntryDataPointer		= MeshEntryDataPointer + AlignDiff;
			
			XboxData.MeshEntryDataPointer	= MeshEntryDataPointer;
		elseif (bChunk.ID == 0x00134B01) then
			local VertexDataPointer		= bChunk.Address + 0x08;
			
			AlignmentValue			= SolidPackList.Header.Alignment;
			AlignDiff			= bChunk:Align(AlignmentValue);
			bChunk.Address			= bChunk.Address - 0x08 - AlignDiff;
			
			VertexDataPointer		= VertexDataPointer + AlignDiff;
			
			XboxData.MeshEntryTable[MeshEntryIndex].VertexDataPointer	= VertexDataPointer;
			
			MeshEntryIndex			= MeshEntryIndex + 1;
		end;
		
		--log_string = log_string .. string.rep("\n", math.min(#log_string, 1)) .. (string.format("0x%08X: %s [0x%02X] (0x%08X)", bChunk.Address, bChunk, AlignmentValue, bChunk.Size - AlignDiff));
		
		bChunk:Next();
	end;
	
	return XboxData;
end;

return Loader_PlatChunksXbox;