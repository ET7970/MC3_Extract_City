local function Loader_ScenerySection(bChunk)
	local ReturnAddress	= (bChunk.Address);
	local fmt		= Config.BigEndian and ">" or "<";
	
	if (bChunk.ID == 0x80034100) then
		local ScenerySection		= {};
		ScenerySection.Header		= {};
		ScenerySection.InfoTable	= {};
		ScenerySection.Instances	= {};
		ScenerySection.TreeNodes	= {};
		ScenerySection.LightMaps	= {};
		
		local ScenerySectionPointer	= bChunk.Address + 0x08;
		local ScenerySectionSize	= bChunk.Size;
		
		bChunk.Address			= bChunk.Address + 0x08;
		
		while (bChunk.Address - ScenerySectionPointer < ScenerySectionSize) do
			if (bChunk.ID == 0x00034101) then
				local HeaderPointer	= bChunk.Address + 0x08;
				
				local AlignDiff		= bChunk:Align(0x10);
				bChunk.Address		= bChunk.Address - 0x08 - AlignDiff;
				
				HeaderPointer		= HeaderPointer + AlignDiff;
				
				if (_ENV.Config.Game == ModelulatorEnum.Game.HOTPURSUIT2) then
					ScenerySection.Header.SectionNumber	= ResourceFile:Read(HeaderPointer + 0x08, "<i4");
				else
					ScenerySection.Header.SectionNumber	= ResourceFile:Read(HeaderPointer + 0x0C, "<i4");
				end;
			elseif (bChunk.ID == 0x00034102) then
				local StructSizeLU	=
				{
					[ModelulatorEnum.Game.HOTPURSUIT2.Value]	= 0x28;
					[ModelulatorEnum.Game.UNDERGROUNDPROTO.Value]	= 0x48;
					[ModelulatorEnum.Game.UNDERGROUND.Value]	= 0x48;
					[ModelulatorEnum.Game.UNDERGROUND2.Value]	= 0x40;
					[ModelulatorEnum.Game.MOSTWANTED.Value]		= 0x48;
					[ModelulatorEnum.Game.CARBON.Value]		= 0x48;
					[ModelulatorEnum.Game.NITRO.Value]		= 0x54;
				};
				local StructSize	= StructSizeLU[math.min(_ENV.Config.Game.Value, ModelulatorEnum.Game.NITRO.Value)];
				
				local SceneryInfoTablePointer	= bChunk.Address + 0x08;
				local NumSceneryInfo		= bChunk.Size // StructSize;
				
				ScenerySection.Header.NumSceneryInfo = NumSceneryInfo;
				
				for i = 0, NumSceneryInfo - 1 do
					local SceneryInfo = {};
					
					if (_ENV.Config.Game == ModelulatorEnum.Game.HOTPURSUIT2) then
						SceneryInfo.NameHash =
						{
							ResourceFile:Read(SceneryInfoTablePointer + 0x00 + i * StructSize, "<I4");
							ResourceFile:Read(SceneryInfoTablePointer + 0x04 + i * StructSize, "<I4");
							ResourceFile:Read(SceneryInfoTablePointer + 0x08 + i * StructSize, "<I4");
						};
					elseif ((_ENV.Config.Game == ModelulatorEnum.Game.UNDERGROUND) or (_ENV.Config.Game == ModelulatorEnum.Game.UNDERGROUNDPROTO)) then
						SceneryInfo.NameHash =
						{
							ResourceFile:Read(SceneryInfoTablePointer + 0x00 + i * StructSize, "<I4");
							ResourceFile:Read(SceneryInfoTablePointer + 0x04 + i * StructSize, "<I4");
							ResourceFile:Read(SceneryInfoTablePointer + 0x08 + i * StructSize, "<I4");
							ResourceFile:Read(SceneryInfoTablePointer + 0x0C + i * StructSize, "<I4");
							ResourceFile:Read(SceneryInfoTablePointer + 0x10 + i * StructSize, "<I4");
							ResourceFile:Read(SceneryInfoTablePointer + 0x14 + i * StructSize, "<I4");
						};
					elseif (_ENV.Config.Game.Value == ModelulatorEnum.Game.UNDERGROUND2.Value) then
						SceneryInfo.NameHash =
						{
							ResourceFile:Read(SceneryInfoTablePointer + 0x20 + i * StructSize, "<I4");
						};
					elseif (_ENV.Config.Game.Value >= ModelulatorEnum.Game.MOSTWANTED.Value) then
						SceneryInfo.NameHash =
						{
							ResourceFile:Read(SceneryInfoTablePointer + 0x1C + i * StructSize, "<I4");
						};
					end;
					
					table.insert(ScenerySection.InfoTable, SceneryInfo);
				end;
			elseif (bChunk.ID == 0x00034103) then
				local SceneryInstancePointer	= bChunk.Address + 0x08;
				
				local AlignDiff		= bChunk:Align(0x10);
				bChunk.Address		= bChunk.Address - 0x08 - AlignDiff;
				
				SceneryInstancePointer	= SceneryInstancePointer + AlignDiff;
				
				local StructSizeLU	=
				{
					[ModelulatorEnum.Game.HOTPURSUIT2.Value]	= 0x30;
					[ModelulatorEnum.Game.UNDERGROUNDPROTO.Value]	= 0x30;
					[ModelulatorEnum.Game.UNDERGROUND.Value]	= 0x30;
					[ModelulatorEnum.Game.UNDERGROUND2.Value]	= 0xB0;
					[ModelulatorEnum.Game.MOSTWANTED.Value]		= 0x30;
					[ModelulatorEnum.Game.CARBON.Value]		= 0x60;
				};
				local StructSize	= StructSizeLU[math.min(_ENV.Config.Game.Value, ModelulatorEnum.Game.CARBON.Value)];
				
				local NumSceneryInstances	= (bChunk.Size - AlignDiff) // StructSize;
				ScenerySection.Header.NumSceneryInstances	= NumSceneryInstances;
				
				for i = 0, NumSceneryInstances - 1 do
					local SceneryInstance	= {};
					
					if (Config.Game.Value < ModelulatorEnum.Game.CARBON.Value) then
						SceneryInstance	=
						{
							BBoxMin			=
							{
								ResourceFile:Read(SceneryInstancePointer + 0x00 + i * StructSize, "<h");
								ResourceFile:Read(SceneryInstancePointer + 0x02 + i * StructSize, "<h");
								ResourceFile:Read(SceneryInstancePointer + 0x04 + i * StructSize, "<h");
							};
							BBoxMax			=
							{
								ResourceFile:Read(SceneryInstancePointer + 0x06 + i * StructSize, "<h");
								ResourceFile:Read(SceneryInstancePointer + 0x08 + i * StructSize, "<h");
								ResourceFile:Read(SceneryInstancePointer + 0x0A + i * StructSize, "<h");
							};
							SceneryInfoNumber	= ResourceFile:Read(SceneryInstancePointer + 0x0C + i * StructSize, "<h");
							ExcludeFlags		= ResourceFile:Read(SceneryInstancePointer + 0x0E + i * StructSize, "<H");
							Position		=
							{
								ResourceFile:Read(SceneryInstancePointer + 0x10 + i * StructSize, "<f");
								ResourceFile:Read(SceneryInstancePointer + 0x14 + i * StructSize, "<f");
								ResourceFile:Read(SceneryInstancePointer + 0x18 + i * StructSize, "<f");
							};
							Rotation		=
							{
								ResourceFile:Read(SceneryInstancePointer + 0x1C + i * StructSize, "<H");
								ResourceFile:Read(SceneryInstancePointer + 0x1E + i * StructSize, "<H");
								ResourceFile:Read(SceneryInstancePointer + 0x20 + i * StructSize, "<H");
								ResourceFile:Read(SceneryInstancePointer + 0x22 + i * StructSize, "<H");
								ResourceFile:Read(SceneryInstancePointer + 0x24 + i * StructSize, "<H");
								ResourceFile:Read(SceneryInstancePointer + 0x26 + i * StructSize, "<H");
								ResourceFile:Read(SceneryInstancePointer + 0x28 + i * StructSize, "<H");
								ResourceFile:Read(SceneryInstancePointer + 0x2A + i * StructSize, "<H");
								ResourceFile:Read(SceneryInstancePointer + 0x2C + i * StructSize, "<H");
							};
						};
						
						if (Config.Game == ModelulatorEnum.Game.MOSTWANTED) then
							SceneryInstance.SceneryInfoNumber	= ResourceFile:Read(SceneryInstancePointer + 0x2E + i * StructSize, "<h");
						end;
					else
						SceneryInstance	=
						{
							BBoxMin			=
							{
								ResourceFile:Read(SceneryInstancePointer + 0x00 + i * StructSize, "<f");
								ResourceFile:Read(SceneryInstancePointer + 0x04 + i * StructSize, "<f");
								ResourceFile:Read(SceneryInstancePointer + 0x08 + i * StructSize, "<f");
							};
							BBoxMax			=
							{
								ResourceFile:Read(SceneryInstancePointer + 0x0C + i * StructSize, "<f");
								ResourceFile:Read(SceneryInstancePointer + 0x10 + i * StructSize, "<f");
								ResourceFile:Read(SceneryInstancePointer + 0x14 + i * StructSize, "<f");
							};
							ExcludeFlags		= ResourceFile:Read(SceneryInstancePointer + 0x18 + i * StructSize, "<I");
							Position		=
							{
								ResourceFile:Read(SceneryInstancePointer + 0x20 + i * StructSize, "<f");
								ResourceFile:Read(SceneryInstancePointer + 0x24 + i * StructSize, "<f");
								ResourceFile:Read(SceneryInstancePointer + 0x28 + i * StructSize, "<f");
							};
							Rotation		=
							{
								ResourceFile:Read(SceneryInstancePointer + 0x2C + i * StructSize, "<f");
								ResourceFile:Read(SceneryInstancePointer + 0x30 + i * StructSize, "<f");
								ResourceFile:Read(SceneryInstancePointer + 0x34 + i * StructSize, "<f");
								ResourceFile:Read(SceneryInstancePointer + 0x38 + i * StructSize, "<f");
								ResourceFile:Read(SceneryInstancePointer + 0x3C + i * StructSize, "<f");
								ResourceFile:Read(SceneryInstancePointer + 0x40 + i * StructSize, "<f");
								ResourceFile:Read(SceneryInstancePointer + 0x44 + i * StructSize, "<f");
								ResourceFile:Read(SceneryInstancePointer + 0x48 + i * StructSize, "<f");
								ResourceFile:Read(SceneryInstancePointer + 0x4C + i * StructSize, "<f");
							};
							SceneryInfoNumber	= ResourceFile:Read(SceneryInstancePointer + 0x54 + i * StructSize, "<h");
						};
					end;
					
					table.insert(ScenerySection.Instances, SceneryInstance);
				end;
			elseif (bChunkID == 0x00034104) then
				--print("yeah its here");
			elseif (bChunkID == 0x0003410D) then
				--print("yeah its here");
			end;
			
			bChunk:Next();
		end;
		
		local FileOutputObject	=
		{
			Inventory	= "ScenerySections";
			Output		= {Function = dae.generate_scenery, Arguments = {dae, ScenerySection, (Config.Game.Value >= ModelulatorEnum.Game.CARBON.Value)}};
		};
		
		table.insert(_ENV.FileOutputList, FileOutputObject);
		
		bChunk.Address		= ReturnAddress;
		
		return true;
	else
		return false;
	end;
end;

return Loader_ScenerySection;