local ChunkInfo			=
{
	Identifier		= 0x33310001;
	
	Name			=
	{
		BlackBox	= "BCHUNK_SPEED_TEXTURE_PACK_HEADER";
		Reference	= "bChunk: Speed > Texture Pack > Header > Main";
	};
	
	Type			=
	{
		Nesting		=
		{
			Used	= false;
			Scope	= {};
		};
		
		Alignment	=
		{
			Used	= true;
			Value	= 0x00000010;
		};
	};
};

return ChunkInfo;