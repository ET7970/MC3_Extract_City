local function Loader(eTexturePack, Address, Size)
	local Address	= bChunk.Address + 0x08;
	local Size	= bChunk.Size;
	
	local AlignDiff				= bChunk:Align(0x10);
	bChunk.Address				= bChunk.Address - 0x08 - AlignDiff;
	
	Address					= Address + AlignDiff;
	Size					= Size - AlignDiff;
	
	eTexturePack.Header.Version		= ResourceFile:Read(Address + 0x00, "<i4");
	
	if (_ENV.Config.Game.Value < ModelulatorEnum.Game.UNDERGROUND.Value) then
		eTexturePack.Header.Name	= ResourceFile:Read(Address + 0x04, "<c32");
		eTexturePack.Header.FileName	= ResourceFile:Read(Address + 0x24, "<c60");
	else
		eTexturePack.Header.Name	= ResourceFile:Read(Address + 0x04, "<c28");
		eTexturePack.Header.FileName	= ResourceFile:Read(Address + 0x20, "<c64");
	end;
	
	eTexturePack.Header.FileNameHash	= ResourceFile:Read(Address + 0x60, "<I4");
	
	eTexturePack.Header.Name		= string.gsub(eTexturePack.Header.Name, "\x00", "");
	eTexturePack.Header.FileName		= string.gsub(eTexturePack.Header.FileName, "\x00", "");
	
	print(eTexturePack.Header.Name, eTexturePack.Header.FileName);
	
	return eTexturePack;
end;

return Loader;