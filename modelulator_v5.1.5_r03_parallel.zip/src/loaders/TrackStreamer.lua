local function Loader_TrackStreamer_Version1(bChunk)
	if (bChunk.ID == 0x00034107) then
		local TempAddress	= bChunk.Address + 0x08;
		local EndOfChunk	= TempAddress + bChunk.Size;
		
		while (TempAddress < EndOfChunk) do
			local Struct	= {};
			Struct.SectionName	= ResourceFile:Read(TempAddress + 0x00, "<c8");
			Struct.SectionID	= ResourceFile:Read(TempAddress + 0x08, "<i2");
			Struct.Unk00		= ResourceFile:Read(TempAddress + 0x0A, "<I2");
			Struct.Unk01		= ResourceFile:Read(TempAddress + 0x0C, "<I4");
			Struct.FileIndex	= ResourceFile:Read(TempAddress + 0x10, "<I4");
			Struct.SectionAddress	= ResourceFile:Read(TempAddress + 0x14, "<I4");
			Struct.SectionSize	= ResourceFile:Read(TempAddress + 0x18, "<I4");
			Struct.CompressedSize	= ResourceFile:Read(TempAddress + 0x1C, "<I4");
			
			Struct.SectionName	= string.unpack("<z", string.pack("<c8x", Struct.SectionName));
			
			print(string.format("%s %i 0x%04X 0x%04X 0x%08X 0x%08X 0x%08X", Struct.SectionName, Struct.SectionID, Struct.Unk00, Struct.Unk01, Struct.FileIndex, Struct.SectionAddress, Struct.SectionSize));
			
			table.insert(_ENV.Track.Streaming, Struct);
			
			TempAddress	= TempAddress + 0x34;
		end;
		
		return true;
	end;
end;

local function Loader_TrackStreamer_Version2(bChunk)
	if (bChunk.ID == 0x00034110) then
		local TempAddress	= bChunk.Address + 0x08;
		local EndOfChunk	= TempAddress + bChunk.Size;
		
		while (TempAddress < EndOfChunk) do
			local Struct	= {};
			Struct.SectionName	= ResourceFile:Read(TempAddress + 0x00, "<c8");
			Struct.SectionID	= ResourceFile:Read(TempAddress + 0x08, "<i4");
			Struct.Unk00		= ResourceFile:Read(TempAddress + 0x0C, "<I4");
			Struct.FileIndex	= ResourceFile:Read(TempAddress + 0x10, "<I4");
			Struct.SectionAddress	= ResourceFile:Read(TempAddress + 0x14, "<I4");
			Struct.SectionSize	= ResourceFile:Read(TempAddress + 0x18, "<I4");
			Struct.CompressedSize	= ResourceFile:Read(TempAddress + 0x1C, "<I4");
			
			Struct.SectionName	= string.unpack("<z", string.pack("<c8x", Struct.SectionName));
			
			print(string.format("%s %i 0x%08X 0x%08X 0x%08X 0x%08X", Struct.SectionName, Struct.SectionID, Struct.Unk00, Struct.FileIndex, Struct.SectionAddress, Struct.SectionSize));
			
			table.insert(_ENV.Track.Streaming, Struct);
			
			TempAddress	= TempAddress + 0x44;
		end;
		
		return true;
	end;
end;

local function Loader_TrackStreamer_Version3(bChunk)
	if (bChunk.ID == 0x00034110) then
		local TempAddress	= bChunk.Address + 0x08;
		local EndOfChunk	= TempAddress + bChunk.Size;
		
		while (TempAddress < EndOfChunk) do
			local Struct	= {};
			Struct.SectionName	= ResourceFile:Read(TempAddress + 0x00, "<c8");
			Struct.SectionID	= ResourceFile:Read(TempAddress + 0x08, "<i4");
			Struct.Unk00		= ResourceFile:Read(TempAddress + 0x0C, "<I4");
			Struct.FileIndex	= ResourceFile:Read(TempAddress + 0x10, "<I4");
			Struct.SectionAddress	= ResourceFile:Read(TempAddress + 0x14, "<I4");
			Struct.SectionSize	= ResourceFile:Read(TempAddress + 0x18, "<I4");
			Struct.CompressedSize	= ResourceFile:Read(TempAddress + 0x1C, "<I4");
			
			Struct.SectionName	= string.unpack("<z", string.pack("<c8x", Struct.SectionName));
			
			print(string.format("%s %i 0x%08X 0x%08X 0x%08X 0x%08X", Struct.SectionName, Struct.SectionID, Struct.Unk00, Struct.FileIndex, Struct.SectionAddress, Struct.SectionSize));
			
			table.insert(_ENV.Track.Streaming, Struct);
			
			TempAddress	= TempAddress + 0x54;
		end;
		
		return true;
	end;
end;

local function Loader_TrackStreamer_Version4(bChunk)
	if (bChunk.ID == 0x00034110) then
		local TempAddress	= bChunk.Address + 0x08;
		local EndOfChunk	= TempAddress + bChunk.Size;
		
		while (TempAddress < EndOfChunk) do
			local Struct	= {};
			Struct.SectionName	= ResourceFile:Read(TempAddress + 0x00, "<c8");
			Struct.SectionID	= ResourceFile:Read(TempAddress + 0x08, "<i4");
			Struct.Unk00		= ResourceFile:Read(TempAddress + 0x0C, "<I4");
			Struct.FileIndex	= ResourceFile:Read(TempAddress + 0x10, "<I4");
			Struct.SectionAddress	= ResourceFile:Read(TempAddress + 0x14, "<I4");
			Struct.SectionSize	= ResourceFile:Read(TempAddress + 0x18, "<I4");
			Struct.CompressedSize	= ResourceFile:Read(TempAddress + 0x1C, "<I4");
			
			Struct.SectionName	= string.unpack("<z", string.pack("<c8x", Struct.SectionName));
			
			print(string.format("%s %i 0x%08X 0x%08X 0x%08X 0x%08X", Struct.SectionName, Struct.SectionID, Struct.Unk00, Struct.FileIndex, Struct.SectionAddress, Struct.SectionSize));
			
			table.insert(_ENV.Track.Streaming, Struct);
			
			TempAddress	= TempAddress + 0x5C;
		end;
		
		return true;
	end;
end;

local function Loader_TrackStreamer(bChunk)
	if (_ENV.Config.Game.Value <= _ENV.ModelulatorEnum.Game.UNDERGROUND.Value) then
		return Loader_TrackStreamer_Version1(bChunk);
	elseif (_ENV.Config.Game.Value == _ENV.ModelulatorEnum.Game.UNDERGROUND2.Value) then
		return Loader_TrackStreamer_Version2(bChunk);
	elseif ((_ENV.Config.Game.Value == _ENV.ModelulatorEnum.Game.NITRO.Value) or (_ENV.Config.Game == _ENV.ModelulatorEnum.Game.MOSTWANTED_DEMO)) then
		return Loader_TrackStreamer_Version3(bChunk);
	else
		return Loader_TrackStreamer_Version4(bChunk);
	end;
end;

return Loader_TrackStreamer;