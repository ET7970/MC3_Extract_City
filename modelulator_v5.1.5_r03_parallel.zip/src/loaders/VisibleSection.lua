local function Loader_VisibleSection_Version1(bChunk)
	local FilePointer	= bChunk.Address;
	
	if (bChunk.ID == 0x80034150) then
		local VisibleSectionPack	= {};
		VisibleSectionPack.Address	= bChunk.Address;
		
		
	end;
end;

local function Loader_VisibleSection_Version2(bChunk)
	local FilePointer	= bChunk.Address;
	
	if (bChunk.ID == 0x80034150) then
		local VisibleSectionPack	= {};
		VisibleSectionPack.Address	= bChunk.Address;
		
		
	end;
end;

return Loader_VisibleSection;