local scats =
{
	"zip";
	"tee";
	"too";
	"tah";
	"bee";
	"bah";
	"bop";
	"beep";
	"boop";
	"boo";
	"doot";
	"doop";
	"dot";
	"zoop";
	"zah";
	"dee";
	"doo";
	"doh";
};

local function SurfaceNormal(...)
	local Vertices			= {...};
	local Normal			= {x = 0, y = 0, z = 0};
	
	for i = 1, #Vertices do
		local VertexA		= Vertices[((i - 1) % #Vertices) + 1];
		local VertexB		= Vertices[((i - 0) % #Vertices) + 1];
		
		local Summation		= {x = VertexA.x + VertexB.x, y = VertexA.y + VertexB.y, z = VertexA.z + VertexB.z};
		local Difference	= {x = VertexA.x - VertexB.x, y = VertexA.y - VertexB.y, z = VertexA.z - VertexB.z};
		
		Normal.x		= Normal.x + Difference.y * Summation.z;
		Normal.y		= Normal.y + Difference.z * Summation.x;
		Normal.z		= Normal.z + Difference.x * Summation.y;
	end;
	
	local Magnitude			= math.sqrt(Normal.x * Normal.x + Normal.y * Normal.y + Normal.z * Normal.z);
	
	if (Magnitude > 0) then
		Normal.x		= Normal.x / Magnitude;
		Normal.y		= Normal.y / Magnitude;
		Normal.z		= Normal.z / Magnitude;
	end;
	
	return Normal;
end;

local function LoadSurfaceCollision(Address, px, py, pz)
	local TriangleStrips		= {};
	local TriangleEdges		= {};
	
	local fmt = _ENV.Config.BigEndian and ">" or "<";
	
	if (ResourceFile.Size > 0x00000000) then
		local FilePointer	= 0x00000000 + Address;
		
		local Header		=
		{
			StripCount		= ResourceFile:Read(FilePointer + 0x00, fmt .. "H");
			StripSize		= ResourceFile:Read(FilePointer + 0x02, fmt .. "H");
			EdgeCount		= ResourceFile:Read(FilePointer + 0x04, fmt .. "H");
			EdgeSize		= ResourceFile:Read(FilePointer + 0x06, fmt .. "H");
			ResolvedFlag		= ResourceFile:Read(FilePointer + 0x08, fmt .. "B");
			SurfaceCount		= ResourceFile:Read(FilePointer + 0x09, fmt .. "B");
			SurfaceSize		= ResourceFile:Read(FilePointer + 0x0A, fmt .. "H");
			IntermediateObjectIndex	= ResourceFile:Read(FilePointer + 0x0C, fmt .. "H");
			Flags			= ResourceFile:Read(FilePointer + 0x0E, fmt .. "H");
		};
		
		FilePointer		= FilePointer + 0x10;
		
		for i = 0, Header.StripCount - 1 do
			local Vertices		= {};
			
			local ReferenceObject	=
			{
				Center		= 
				{
					x	= ResourceFile:Read(FilePointer + i * 0x10 + 0x00, fmt .. "f");
					y	= ResourceFile:Read(FilePointer + i * 0x10 + 0x04, fmt .. "f");
					z	= ResourceFile:Read(FilePointer + i * 0x10 + 0x08, fmt .. "f");
				};
				Angle		= ResourceFile:Read(FilePointer + i * 0x10 + 0x0C, fmt .. "h");
				Offset		= ResourceFile:Read(FilePointer + i * 0x10 + 0x0E, fmt .. "H");
			};
			
			--print(string.format("%i \xF8", ReferenceObject.Angle));
			
			local VertexOffset	= FilePointer + ReferenceObject.Offset;
			local NumVertices	= ResourceFile:Read(VertexOffset + 0x6 + (_ENV.Config.BigEndian and 0x1 or 0x0), fmt .. "B");
			
			local tx, ty, tz = 0, 0, 0;
			
			for j = 0, NumVertices - 1 do
				local Vertex	=
				{
					x	= ResourceFile:Read(VertexOffset + j * 0x8 + 0x00, fmt .. "h");
					y	= ResourceFile:Read(VertexOffset + j * 0x8 + 0x02, fmt .. "h");
					z	= ResourceFile:Read(VertexOffset + j * 0x8 + 0x04, fmt .. "h");
					Count	= ResourceFile:Read(VertexOffset + j * 0x8 + 0x06, fmt .. "H");
				};
				
				tx, ty, tz = Vertex.z / 128, Vertex.y / 128, Vertex.x / 128;
				
				tx = tx + ReferenceObject.Center.z - px;
				ty = ty + ReferenceObject.Center.y - py;
				tz = -tz - ReferenceObject.Center.x + pz;
				
				Vertices[j + 1]	= {x = tx, y = ty, z = tz, cnt = Vertex.Count};
			end;
			
			TriangleStrips[i + 1]	= Vertices;
		end;
		
		for i = 0, Header.EdgeCount - 1 do
			local Vertices		= {};
			
			local EdgeObject	=
			{
				Vertex0		=
				{
					x	= ResourceFile:Read(FilePointer + i * 0x20 + 0x00, fmt .. "f");
					y	= ResourceFile:Read(FilePointer + i * 0x20 + 0x04, fmt .. "f");
					z	= ResourceFile:Read(FilePointer + i * 0x20 + 0x08, fmt .. "f");
				};
				Unk00		= ResourceFile:Read(FilePointer + i * 0x20 + 0x0C, fmt .. "B");
				Unk01		= ResourceFile:Read(FilePointer + i * 0x20 + 0x0D, fmt .. "B");
				Unk02		= ResourceFile:Read(FilePointer + i * 0x20 + 0x0E, fmt .. "H");
				Vertex1		=
				{
					x	= ResourceFile:Read(FilePointer + i * 0x20 + 0x10, fmt .. "f");
					y	= ResourceFile:Read(FilePointer + i * 0x20 + 0x14, fmt .. "f");
					z	= ResourceFile:Read(FilePointer + i * 0x20 + 0x18, fmt .. "f");
				};
				Radius		= ResourceFile:Read(FilePointer + i * 0x20 + 0x1C, fmt .. "f");
			};
			
			Vertices[1]		= {x = EdgeObject.Vertex0.z - px, y = EdgeObject.Vertex0.y - py, z = -EdgeObject.Vertex0.x + pz};
			Vertices[2]		= {x = EdgeObject.Vertex1.z - px, y = EdgeObject.Vertex1.y - py, z = -EdgeObject.Vertex1.x + pz};
			Vertices.r		= EdgeObject.Radius;
			
			TriangleEdges[i + 1]	= Vertices;
		end;
		
		return TriangleStrips, TriangleEdges;
	end;
end;

local function Loader_WCollisionPack(bChunk)
	local FilePointer	= (bChunk.Address);
	local obj_string	= {};
	local faces		= {};
	
	local fmt		= (_ENV.Config.BigEndian == true) and ">" or "<";
	
	if (bChunk.ID == 0x0003B801) then
		local al_fp		= (FilePointer + 0x17) & -0x10;
		
		local SectionNumber	= ResourceFile:Read(al_fp + 0x04, "<I4");
		local Base		= ResourceFile:Read(al_fp + 0x0C, "<I4");
		
		if (Base <= 0x00000000) then
			Base		= nil;
		else
			Base		= Base + 0x10;
		end;
		
		local ObjectMain	= CARP:Read(al_fp + 0x10, Base);
		
		for i = 0, ObjectMain.CARP.Arti.ci[1].Count - 1 do
			local idx		= ResourceFile:Read(ObjectMain.CARP.Arti.ci[1].AbsoluteOffset + 0x40 * i + 0x1A, fmt .. "h");
			local pz, py, px	= ResourceFile:Read(ObjectMain.CARP.Arti.ci[1].AbsoluteOffset + 0x40 * i + 0x30, fmt .. "fff");
			
			px = px;
			py = py;
			
			local v					= ObjectMain.CARP.Arti.ca[idx + 1];
			
			local CollisionArticleOffset		= v.AbsoluteOffset;
			local TriangleStrips, TriangleEdges	= LoadSurfaceCollision(v.AbsoluteOffset, px, py, pz);
			local flip;
			
			flip		= 1;
			
			--print(scats[math.random(1, #scats)]);
			
			for j = 1, #TriangleStrips do
				local Vertices = TriangleStrips[j];
				
				for k = 1, #Vertices do
					if ((Vertices[k].cnt ~= nil) and (Vertices[k].cnt > 0)) then
						flip = 1 - 2 * ((k + (Vertices[k].cnt % 2)) & 1);
					end;
					
					if (k >= 3) then
						local Vertex0	= Vertices[k - 1 + flip];
						local Vertex1	= Vertices[k - 1];
						local Vertex2	= Vertices[k - 1 - flip];
						
						--local Normal	= SurfaceNormal(Vertex0, Vertex1, Vertex2);
						
						table.insert(obj_string, "\n");
						table.insert(obj_string, string.format("v\t%f %f %f", Vertex0.x, Vertex0.z, Vertex0.y));
						table.insert(obj_string, string.format("v\t%f %f %f", Vertex1.x, Vertex1.z, Vertex1.y));
						table.insert(obj_string, string.format("v\t%f %f %f", Vertex2.x, Vertex2.z, Vertex2.y));
						table.insert(obj_string, string.format("f\t%i %i %i", -3, -2, -1));
						
						--obj_string = "";
					end;
					
					flip	= -flip;
				end;
			end;
			
			flip		= 1;
			
			for j = 1, #TriangleEdges do
				local Vertices = TriangleEdges[j];
				
				local Vertex0	= Vertices[1];
				local Vertex1	= Vertices[2];
				--local Normal	= SurfaceNormal(Vertex0, Vertex1, Vertex2);
						
				table.insert(obj_string, "\n");
				table.insert(obj_string, string.format("v\t%f %f %f", Vertex0.x, Vertex0.z, Vertex1.y));
				table.insert(obj_string, string.format("v\t%f %f %f", Vertex0.x, Vertex0.z, Vertex0.y));
				table.insert(obj_string, string.format("v\t%f %f %f", Vertex1.x, Vertex1.z, Vertex1.y));
				table.insert(obj_string, string.format("v\t%f %f %f", Vertex1.x, Vertex1.z, Vertex0.y));
				
				table.insert(obj_string, string.format("f\t%i %i %i", -2, -3, -4));
				table.insert(obj_string, string.format("f\t%i %i %i", -3, -2, -1));
			end;
		end;
		
		local FileName;
		
		if (#_ENV.Stream.CurrentSection > 0) then
			FileName	= string.format("WCollisionPack.%s.S%i", _ENV.Stream.CurrentSection, SectionNumber);
		else
			FileName	= string.format("WCollisionPack.S%i", SectionNumber);
		end;
		
		table.insert(FileOutputInventory.CollisionPacks, {{FileName = FileName, FileType = "obj"; Data = table.concat(obj_string, "\n")}});
		
		return true;
	else
		return false;
	end;
end;

return Loader_WCollisionPack;