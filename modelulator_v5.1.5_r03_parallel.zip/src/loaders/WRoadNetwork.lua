local function Lerp(n0, n1, x)
	return n0 + x * (n1 - n0);
end;

local Math		= {};
Math.Vector4		= {};
Math.Matrix4		= {};

function Math.Matrix4:New(a, b, c, d, e, f, g, h, i, j, k, l, m, n, o, p)
	return Maths.Matrix4.new(Maths.Vector4.new(a, b, c, d), Maths.Vector4.new(e, f, g, h), Maths.Vector4.new(i, j, k, l), Maths.Vector4.new(m, n, o, p));
end;

function Math.Matrix4:New2(V0, V1, V2, V3)
	return
	{
		V0	= V0;
		V1	= V1;
		V2	= V2;
		V3	= V3;
	};
end;

function Math.Matrix4:Transpose(m)
	local Values		= {};
	
	local Columns		= {"V0", "V1", "V2", "V3"};
	local Rows		= {"X", "Y", "Z", "W"};
	
	for y = 1, 4 do
		local Column			= Columns[y];
		local TempRow			= Rows[y];
		
		for x = 1, 4 do
			local Row		= Rows[x];
			local TempColumn	= Columns[x];
			
			Values[x + (y - 1) * 4] = m1[TempColumn][TempRow];
		end;
	end;
	
	return Math.Matrix4:New(table.unpack(Values));
end;

function Math.Matrix4:Mult(m1, m2)
	local A, B, C, D = m1.V0.X, m1.V0.Y, m1.V0.Z, m1.V0.W;
	local E, F, G, H = m1.V1.X, m1.V1.Y, m1.V1.Z, m1.V1.W;
	local I, J, K, L = m1.V2.X, m1.V2.Y, m1.V2.Z, m1.V2.W;
	local M, N, O, P = m1.V3.X, m1.V3.Y, m1.V3.Z, m1.V3.W;
	
	local a, b, c, d = m1.V0.X, m1.V0.Y, m1.V0.Z, m1.V0.W;
	local e, f, g, h = m1.V1.X, m1.V1.Y, m1.V1.Z, m1.V1.W;
	local i, j, k, l = m1.V2.X, m1.V2.Y, m1.V2.Z, m1.V2.W;
	local m, n, o, p = m1.V3.X, m1.V3.Y, m1.V3.Z, m1.V3.W;
	
	return
	Math.Matrix4:New
	(
		A * a + B * e + C * i + D * m,
		A * b + B * f + C * j + D * n,
		A * c + B * g + C * k + D * o,
		A * d + B * h + C * l + D * p,
		
		E * a + F * e + G * i + H * m,
		E * b + F * f + G * j + H * n,
		E * c + F * g + G * k + H * o,
		E * d + F * h + G * l + H * p,
		
		I * a + J * e + K * i + L * m,
		I * b + J * f + K * j + L * n,
		I * c + J * g + K * k + L * o,
		I * d + J * h + K * l + L * p,
		
		M * a + N * e + O * i + P * m,
		M * b + N * f + O * j + P * n,
		M * c + N * g + O * k + P * o,
		M * d + N * h + O * l + P * p
	);
end;

function Math.Vector4:RotateTranslate(v, m)
	return
	Maths.Vector4.new
	(
		v.X * m.V0.X + v.Y * m.V1.X + v.Z * m.V2.X + v.W * m.V3.X,
		v.X * m.V0.Y + v.Y * m.V1.Y + v.Z * m.V2.Y + v.W * m.V3.Y,
		v.X * m.V0.Z + v.Y * m.V1.Z + v.Z * m.V2.Z + v.W * m.V3.Z,
		v.X * m.V0.W + v.Y * m.V1.W + v.Z * m.V2.W + v.W * m.V3.W
	);
end;

local BasisMatrices			= {};

local function BinomialExpansion(NumberTable)
	if (NumberTable == nil) then
		return {1};
	end;
	
	local Values		= {};
	
	for i = 1, #NumberTable + 1 do
		local Previous	= NumberTable[i - 1] or 0;
		local Current	= NumberTable[i] or 0;
		
		Values[i]	= Current - Previous;
	end;
	
	return Values;
end;

local function GetDerivative(BasisMatrix)
	local V1, V2, V3	= BasisMatrix.V0 * 3, BasisMatrix.V1 * 2, BasisMatrix.V2 * 1;
	
	return Math.Matrix4:New(0, 0, 0, 0, V1.X, V1.Y, V1.Z, V1.W, V2.X, V2.Y, V2.Z, V2.W, V3.X, V3.Y, V3.Z, V3.W);
end;

local function BuildBasisMatrices()
	local BinomialList	= {};
	local Values		= {};
	
	for i = 4, 1, -1 do
		BinomialList[i]		= BinomialExpansion(BinomialList[i + 1]);
	end;
	
	for i = 4, 1, -1 do
		BinomialList[i]		= Maths.Vector4.new(table.unpack(BinomialList[i])) * BinomialList[1][4 - i + 1];
		local Current		= BinomialList[i];
		
		BinomialList[i]		= {Current.X, Current.Y, Current.Z, Current.W};
	end;
	
	for y = 1, 4 do
		for x = 1, 4 do
			Values[x + (y - 1) * 4] = BinomialList[y][x];
		end;
	end;
	
	local PrimaryMatrix			= Math.Matrix4:New(table.unpack(Values));
	
	for i = 1, 3 do
		if (i <= 1) then
			BasisMatrices[i]	= PrimaryMatrix;
		else
			BasisMatrices[i]	= GetDerivative(BasisMatrices[i - 1]);
		end;
	end;
end;

BuildBasisMatrices();

local function Evaluate(SplineMatrix, BasisMatrix, t)
	local A		= BasisMatrix.V0.X * SplineMatrix.V0.X + BasisMatrix.V0.Y * SplineMatrix.V1.X + BasisMatrix.V0.Z * SplineMatrix.V2.X + BasisMatrix.V0.W * SplineMatrix.V3.X;
	local E		= BasisMatrix.V0.X * SplineMatrix.V0.Y + BasisMatrix.V0.Y * SplineMatrix.V1.Y + BasisMatrix.V0.Z * SplineMatrix.V2.Y + BasisMatrix.V0.W * SplineMatrix.V3.Y;
	local I		= BasisMatrix.V0.X * SplineMatrix.V0.Z + BasisMatrix.V0.Y * SplineMatrix.V1.Z + BasisMatrix.V0.Z * SplineMatrix.V2.Z + BasisMatrix.V0.W * SplineMatrix.V3.Z;
	local M		= BasisMatrix.V0.X * SplineMatrix.V0.W + BasisMatrix.V0.Y * SplineMatrix.V1.W + BasisMatrix.V0.Z * SplineMatrix.V2.W + BasisMatrix.V0.W * SplineMatrix.V3.W;
	
	local B		= BasisMatrix.V1.X * SplineMatrix.V0.X + BasisMatrix.V1.Y * SplineMatrix.V1.X + BasisMatrix.V1.Z * SplineMatrix.V2.X + BasisMatrix.V1.W * SplineMatrix.V3.X;
	local F		= BasisMatrix.V1.X * SplineMatrix.V0.Y + BasisMatrix.V1.Y * SplineMatrix.V1.Y + BasisMatrix.V1.Z * SplineMatrix.V2.Y + BasisMatrix.V1.W * SplineMatrix.V3.Y;
	local J		= BasisMatrix.V1.X * SplineMatrix.V0.Z + BasisMatrix.V1.Y * SplineMatrix.V1.Z + BasisMatrix.V1.Z * SplineMatrix.V2.Z + BasisMatrix.V1.W * SplineMatrix.V3.Z;
	local N		= BasisMatrix.V1.X * SplineMatrix.V0.W + BasisMatrix.V1.Y * SplineMatrix.V1.W + BasisMatrix.V1.Z * SplineMatrix.V2.W + BasisMatrix.V1.W * SplineMatrix.V3.W;
	
	local C		= BasisMatrix.V2.X * SplineMatrix.V0.X + BasisMatrix.V2.Y * SplineMatrix.V1.X + BasisMatrix.V2.Z * SplineMatrix.V2.X + BasisMatrix.V2.W * SplineMatrix.V3.X;
	local G		= BasisMatrix.V2.X * SplineMatrix.V0.Y + BasisMatrix.V2.Y * SplineMatrix.V1.Y + BasisMatrix.V2.Z * SplineMatrix.V2.Y + BasisMatrix.V2.W * SplineMatrix.V3.Y;
	local K		= BasisMatrix.V2.X * SplineMatrix.V0.Z + BasisMatrix.V2.Y * SplineMatrix.V1.Z + BasisMatrix.V2.Z * SplineMatrix.V2.Z + BasisMatrix.V2.W * SplineMatrix.V3.Z;
	local O		= BasisMatrix.V2.X * SplineMatrix.V0.W + BasisMatrix.V2.Y * SplineMatrix.V1.W + BasisMatrix.V2.Z * SplineMatrix.V2.W + BasisMatrix.V2.W * SplineMatrix.V3.W;
	
	local D		= BasisMatrix.V3.X * SplineMatrix.V0.X + BasisMatrix.V3.Y * SplineMatrix.V1.X + BasisMatrix.V3.Z * SplineMatrix.V2.X + BasisMatrix.V3.W * SplineMatrix.V3.X;
	local H		= BasisMatrix.V3.X * SplineMatrix.V0.Y + BasisMatrix.V3.Y * SplineMatrix.V1.Y + BasisMatrix.V3.Z * SplineMatrix.V2.Y + BasisMatrix.V3.W * SplineMatrix.V3.Y;
	local L		= BasisMatrix.V3.X * SplineMatrix.V0.Z + BasisMatrix.V3.Y * SplineMatrix.V1.Z + BasisMatrix.V3.Z * SplineMatrix.V2.Z + BasisMatrix.V3.W * SplineMatrix.V3.Z;
	local P		= BasisMatrix.V3.X * SplineMatrix.V0.W + BasisMatrix.V3.Y * SplineMatrix.V1.W + BasisMatrix.V3.Z * SplineMatrix.V2.W + BasisMatrix.V3.W * SplineMatrix.V3.W;
	
	local InterpolatedVector	=
	Maths.Vector4.new
	(
		((A * t + B) * t + C) * t + D,
		((E * t + F) * t + G) * t + H,
		((I * t + J) * t + K) * t + L,
		((M * t + N) * t + O) * t + P
	);
	
	--[[
	local LerpVector		= Maths.Vector4.new(t * t * t, t * t, t, 1);
	
	local InterpolatedMatrix	= Math.Matrix4:Mult(BasisMatrix, SplineMatrix);
	local InterpolatedVector	= Math.Vector4:RotateTranslate(LerpVector, InterpolatedMatrix);
	--]]
	
	return InterpolatedVector;
end;

local function EvaluateSpline(SplineMatrix, t)
	return Evaluate(SplineMatrix, BasisMatrices[1], t);
end;

local function EvaluateFirstDerivative(SplineMatrix, t)
	return Evaluate(SplineMatrix, BasisMatrices[2], t);
end;

local function EvaluateSecondDerivative(SplineMatrix, t)
	return Evaluate(SplineMatrix, BasisMatrices[3], t);
end;

local function EvaluateTangent(SplineMatrix, t)
	local TangentVector		= EvaluateFirstDerivative(SplineMatrix, t);
	
	return TangentVector:Normalise();
end;

local function EvaluateCurvatureXZ(SplineMatrix, t)
	local VectorA			= EvaluateFirstDerivative(SplineMatrix, t);
	local VectorB			= EvaluateSecondDerivative(SplineMatrix, t);
	
	local Magnitude			= math.sqrt(VectorA.X * VectorA.X + VectorA.Z * VectorA.Z);
	Magnitude			= Magnitude * Magnitude * Magnitude;
	
	local Curvature			= 1000;
	
	if (Magnitude ~= math.min(math.max(Magnitude, -0.0001), 0.0001)) then
		Curvature		= (VectorA.X * VectorB.Z - VectorA.Z * VectorB.X) / Magnitude;
	end;
	
	return Curvature;
end;

local function LoadRoads(Address, RoadCount)
	local Roads			= {};
	
	local fmt			= _ENV.Config.BigEndian and ">" or "<";
	
	for i = 0, RoadCount - 1 do
		local RoadAddress	= Address + i * 0x00000008;
		
		local RoadObject	=
		{
			Scale		= ResourceFile:Read(RoadAddress + 0x00000000, fmt .. "H");
			Length		= ResourceFile:Read(RoadAddress + 0x00000002, fmt .. "H");
			Shortcut	= ResourceFile:Read(RoadAddress + 0x00000004, fmt .. "b");
			MinWidth	= ResourceFile:Read(RoadAddress + 0x00000005, fmt .. "B");
			SpeechID	= ResourceFile:Read(RoadAddress + 0x00000006, fmt .. "H");
		};
		
		Roads[i + 1]		= RoadObject;
	end;
	
	return Roads;
end;

local function LoadNodeData(Address, NodeCount)
	local Nodes		= {};
	
	local fmt		= _ENV.Config.BigEndian and ">" or "<";
	
	for i = 0, NodeCount - 1 do
		local NodeAddress	= Address + i * 0x00000020;
		
		local NodeObject	=
		{
			Position	=
			{
				x	= ResourceFile:Read(NodeAddress + 0x00000008, fmt .. "f");
				y	= -ResourceFile:Read(NodeAddress + 0x00000000, fmt .. "f");
				z	= ResourceFile:Read(NodeAddress + 0x00000004, fmt .. "f");
			};
			NodeID		= ResourceFile:Read(NodeAddress + 0x0000000C, fmt .. "H");
			ProfileID	= ResourceFile:Read(NodeAddress + 0x0000000E, fmt .. "H");
			Count		= ResourceFile:Read(NodeAddress + 0x00000010, fmt .. "B");
			Connections	= {};
		};
		
		NodeObject.Position	= Maths.Vector4.new(NodeObject.Position.x, NodeObject.Position.y, NodeObject.Position.z, 0.0);
		
		for j = 0, NodeObject.Count - 1 do
			NodeObject.Connections[j + 1] = ResourceFile:Read(NodeAddress + 0x00000012 + j * 0x00000002, fmt .. "h");
		end;
		
		Nodes[i + 1] = NodeObject;
	end;
	
	return Nodes;
end;

local function LoadSegments(Address, SegmentCount)
	local Segments		= {};
	
	local fmt		= _ENV.Config.BigEndian and ">" or "<";
	
	for i = 0, SegmentCount - 1 do
		local SegmentAddress	= Address + 0x00;
		
		if (_ENV.Config.Game == ModelulatorEnum.Game.MOSTWANTED_DEMO) then
			SegmentAddress	= SegmentAddress + i * 0x00000020;
		elseif ((_ENV.Config.Game == ModelulatorEnum.Game.MOSTWANTED) or (_ENV.Config.Game == ModelulatorEnum.Game.CARBON)) then
			SegmentAddress	= SegmentAddress + i * 0x00000016;
		elseif (_ENV.Config.Game == ModelulatorEnum.Game.WORLD) then
			SegmentAddress	= SegmentAddress + i * 0x00000018;
		else
			SegmentAddress	= SegmentAddress + i * 0x00000038;
		end;
		
		local SegmentObject;
		
		if (_ENV.Config.Game == ModelulatorEnum.Game.WORLD) then
			SegmentObject	=
			{
				NodeID0			= ResourceFile:Read(SegmentAddress + 0x00, fmt .. "H");
				NodeID1			= ResourceFile:Read(SegmentAddress + 0x02, fmt .. "H");
				Length			= ResourceFile:Read(SegmentAddress + 0x04, fmt .. "H");
				RoadID			= ResourceFile:Read(SegmentAddress + 0x06, fmt .. "h");
				SegmentID		= ResourceFile:Read(SegmentAddress + 0x08, fmt .. "h");
				Flags			= ResourceFile:Read(SegmentAddress + 0x0C, fmt .. "H");
				EndHandleLength		= ResourceFile:Read(SegmentAddress + 0x0E, fmt .. "H") / 131.07;
				StartHandleLength	= ResourceFile:Read(SegmentAddress + 0x10, fmt .. "H") / 131.07;
				EndHandle		= {ResourceFile:Read(SegmentAddress + 0x12, fmt .. "bbb")};
				StartHandle		= {ResourceFile:Read(SegmentAddress + 0x15, fmt .. "bbb")};
			};
		elseif (_ENV.Config.Game == ModelulatorEnum.Game.MOSTWANTED_DEMO) then
			SegmentObject	=
			{
				NodeID0			= ResourceFile:Read(SegmentAddress + 0x00, fmt .. "H");
				NodeID1			= ResourceFile:Read(SegmentAddress + 0x02, fmt .. "H");
				Unknown0		= ResourceFile:Read(SegmentAddress + 0x04, fmt .. "H");
				Unknown1		= ResourceFile:Read(SegmentAddress + 0x06, fmt .. "H");
				ProfileID0		= ResourceFile:Read(SegmentAddress + 0x08, fmt .. "h");
				ProfileID1		= ResourceFile:Read(SegmentAddress + 0x0A, fmt .. "h");
				Length			= ResourceFile:Read(SegmentAddress + 0x0C, fmt .. "H");
				RoadID			= ResourceFile:Read(SegmentAddress + 0x0E, fmt .. "h");
				SegmentID		= ResourceFile:Read(SegmentAddress + 0x10, fmt .. "h");
				Flags			= ResourceFile:Read(SegmentAddress + 0x12, fmt .. "H");
				EndHandleLength		= ResourceFile:Read(SegmentAddress + 0x14, fmt .. "H") / 131.07;
				StartHandleLength	= ResourceFile:Read(SegmentAddress + 0x16, fmt .. "H") / 131.07;
				EndHandle		= {ResourceFile:Read(SegmentAddress + 0x18, fmt .. "bbb")};
				StartHandle		= {ResourceFile:Read(SegmentAddress + 0x1B, fmt .. "bbb")};
			};
		else
			SegmentObject	=
			{
				NodeID0			= ResourceFile:Read(SegmentAddress + 0x00, fmt .. "H");
				NodeID1			= ResourceFile:Read(SegmentAddress + 0x02, fmt .. "H");
				Length			= ResourceFile:Read(SegmentAddress + 0x04, fmt .. "H");
				RoadID			= ResourceFile:Read(SegmentAddress + 0x06, fmt .. "h");
				SegmentID		= ResourceFile:Read(SegmentAddress + 0x08, fmt .. "h");
				Flags			= ResourceFile:Read(SegmentAddress + 0x0A, fmt .. "H");
				EndHandleLength		= ResourceFile:Read(SegmentAddress + 0x0C, fmt .. "H") / 131.07;
				StartHandleLength	= ResourceFile:Read(SegmentAddress + 0x0E, fmt .. "H") / 131.07;
				EndHandle		= {ResourceFile:Read(SegmentAddress + 0x10, fmt .. "bbb")};
				StartHandle		= {ResourceFile:Read(SegmentAddress + 0x13, fmt .. "bbb")};
			};
		end;
		
		SegmentObject.StartHandle	= Maths.Vector4.new(SegmentObject.StartHandle[3] / 127, -SegmentObject.StartHandle[1] / 127, SegmentObject.StartHandle[2] / 127, 0);
		SegmentObject.EndHandle		= Maths.Vector4.new(SegmentObject.EndHandle[3] / 127, -SegmentObject.EndHandle[1] / 127, SegmentObject.EndHandle[2] / 127, 0);
		
		Segments[i + 1]			= SegmentObject;
	end;
	
	return Segments;
end;

local function LoadProfiles(Address, ProfileCount)
	local Profiles		= {};
	
	local fmt		= _ENV.Config.BigEndian and ">" or "<";
	
	for i = 0, ProfileCount - 1 do
		local ProfileAddress		= Address + i * 0x00000040;
		
		local ProfileObject	=
		{
			ZoneCount		= ResourceFile:Read(ProfileAddress + 0x00, fmt .. "B");
			MiddleZone		= ResourceFile:Read(ProfileAddress + 0x01, fmt .. "B");
		};
		
		ProfileObject.Lanes		= {ResourceFile:Read(ProfileAddress + 0x00000004, fmt .. string.rep("I4", ProfileObject.ZoneCount))};
		
		Profiles[i + 1]		= ProfileObject;
	end;
	
	return Profiles;
end;

local LanePalette	=
{
	{255, 000, 000};
	{255, 147, 000};
	{060, 247, 064};
	{014, 199, 106};
	
	{255, 102, 051};
	{254, 197, 001};
	{055, 185, 000};
	{004, 139, 001};
	
	{000, 208, 225};
	{014, 158, 184};
	{248, 022, 214};
	{241, 029, 103};
	
	{009, 069, 159};
	{069, 050, 239};
	{207, 132, 253};
	{207, 063, 132};
};

for i = 1, #LanePalette do
	for j = 1, #LanePalette[i] do
		LanePalette[i][j]	= (LanePalette[i][j] * LanePalette[i][j]) / (255 * 255);
	end;
end;

local SegmentResolution		= 16;

local Epsilon			= 0.01;
local ScalingFactor0		= 1 / ((2048 / 25) - Epsilon);

local LaneFlags		=
{
	0xFFFFFFFF ~ 0x00002080;
	0x00000000 ~ 0x00000002;
	0xFFFFFFFF ~ 0x00002080;
	0xFFFFFFFF ~ 0x00002084;
	0xFFFFFFFF ~ 0x00002080;
	0x00000000 ~ 0x00000402;
	0xFFFFFFFF ~ 0x00002080;
	0xFFFFFFFF ~ 0x00000000;
};

local WRoadNavigation		=
{
	VehicleWidth		= 2.0;
	TrafficCookieWidth	= 2.5; --# eh
	
	NavigationType		= ModelulatorEnum.NavigationType.None;
	PathType		= ModelulatorEnum.PathType.Player;	--# setting it to this for now since setting it to "None" will skip over everything else
	LaneType		= ModelulatorEnum.LaneType.Any;
	
	NodeInd			= 0;
	BoundPosWidth		= 0;
	
	Center	=
	{
		Start		=
		{
			Position	= Maths.Vector4.new();
			Control		= Maths.Vector4.new();
		};
		
		End		=
		{
			Position	= Maths.Vector4.new();
			Control		= Maths.Vector4.new();
		};
		
		Spline		= Math.Matrix4:New();
	};
	
	Left	=
	{
		Start		=
		{
			Position	= Maths.Vector4.new();
			Control		= Maths.Vector4.new();
		};
		
		End		=
		{
			Position	= Maths.Vector4.new();
			Control		= Maths.Vector4.new();
		};
		
		Spline		= Math.Matrix4:New();
	};
	
	Right	=
	{
		Start		=
		{
			Position	= Maths.Vector4.new();
			Control		= Maths.Vector4.new();
		};
		
		End		=
		{
			Position	= Maths.Vector4.new();
			Control		= Maths.Vector4.new();
		};
		
		Spline		= Math.Matrix4:New();
	};
};

local ZoneCache		= {};

local function Loader_WRoadNetwork(bChunk)
	local obj_string	= "";
	local FilePointer	= bChunk.Address;
	
	local fmt		= _ENV.Config.BigEndian and ">" or "<";
	
	if (bChunk.ID == 0x0003B800) then
		local al_fp		= (FilePointer + 0x17) & -0x10;
		local ObjectMain	= CARP:Read(al_fp, 0x00000000);
		
		local NodeData		= LoadNodeData(ObjectMain.CARP.RNgp.RNnd.AbsoluteOffset, ObjectMain.CARP.RNgp.RNnd.Count);
		local Segments		= LoadSegments(ObjectMain.CARP.RNgp.RNsg.AbsoluteOffset, ObjectMain.CARP.RNgp.RNsg.Count);
		local Roads		= LoadRoads(ObjectMain.CARP.RNgp.RNrd.AbsoluteOffset, ObjectMain.CARP.RNgp.RNrd.Count);
		local Profiles		= LoadProfiles(ObjectMain.CARP.RNgp.RNpf.AbsoluteOffset, ObjectMain.CARP.RNgp.RNpf.Count);
		
		local v_String	= {};
		local l_String	= {};
		
		local MaxUnkID = -math.huge;
		local MinUnkID = math.huge;
		
		--[[
		for i = 1, #NodeData do
			local Node	= NodeData[i];
			
			--MaxUnkID = math.max(MaxUnkID, Node.UnkID);
			--MinUnkID = math.min(MinUnkID, Node.UnkID);
			
			v_String = v_String .. string.rep("\n", math.min(#v_String, 1));
			v_String = v_String .. (string.format("v\t%f %f %f", Node.Position.x, Node.Position.y, Node.Position.z));
			
			for j = 1, #Node.Connections do
				--MaxConn = math.max(MaxConn, Node.Connections[j]);
				--MinConn = math.min(MinConn, Node.Connections[j]);
				
				local SegmentID	= Node.Connections[j];
				local Segment	= Segments[SegmentID + 1];
				
				l_String = l_String .. string.rep("\n", math.min(#l_String, 1));
				l_String = l_String .. string.format("l\t%i %i", Segment.NodeID0 + 1, Segment.NodeID1 + 1);
			end;
		end;
		--]]
		
		local VertexGroupCount		= 0;
		local FaceGroupCount		= 0;
		
		local StartTime			= os.clock();
		
		for i, Segment in pairs(Segments) do
			local StartFlipped	= AdjustWithMask(Segment.Flags, 01, 10);
			local EndFlipped	= AdjustWithMask(Segment.Flags, 01, 09);
			local HasCurvature	= 1 or AdjustWithMask(Segment.Flags, 01, 08);
			
			local StartNode		= NodeData[Segment.NodeID0 + 1];
			local EndNode		= NodeData[Segment.NodeID1 + 1];
			
			local NodeDistance	= math.max(Maths.Vector4.Magnitude(EndNode.Position - StartNode.Position), Epsilon);
			
			local StartControl	= Segment.StartHandle * Segment.StartHandleLength;
			local EndControl	= Segment.EndHandle * Segment.EndHandleLength;
			
			local StartHandle	= StartNode.Position + StartControl;
			local EndHandle		= EndNode.Position + EndControl;
			
			local StartRightVector	= Maths.Vector4.new(-Segment.StartHandle.Y, Segment.StartHandle.X, 0.0, 0.0);
			local EndRightVector	= Maths.Vector4.new(Segment.EndHandle.Y, -Segment.EndHandle.X, 0.0, 0.0);
			
			local StartProfile	= Profiles[StartNode.ProfileID + 1];
			local EndProfile	= Profiles[EndNode.ProfileID + 1];
			
			if (StartProfile == nil) then
				print("Null Start Profile!");
				print(string.format("StartNode.NodeID = 0x%04X", StartNode.NodeID));
				print(string.format("StartNode.ProfileID = 0x%04X", StartNode.ProfileID));
				
				StartProfile	=
				{
					ZoneCount	= 0;
					MiddleZone	= 0;
					Lanes		= {};
				};
			end;
			
			if (EndProfile == nil) then
				print("Null End Profile!");
				print(string.format("EndNode.NodeID = 0x%04X", EndNode.NodeID));
				print(string.format("EndNode.ProfileID = 0x%04X", EndNode.ProfileID));
				
				EndProfile	=
				{
					ZoneCount	= 0;
					MiddleZone	= 0;
					Lanes		= {};
				};
			end;
			
			local StartMiddleZone	= StartProfile.MiddleZone;
			local EndMiddleZone	= EndProfile.MiddleZone;
			
			--[[
			if (StartFlipped ~= 0x00000000) then
				StartMiddleZone	= StartProfile.ZoneCount - StartMiddleZone - 1;
			end;
			
			if (EndFlipped ~= 0x00000000) then
				EndMiddleZone	= EndProfile.ZoneCount - EndMiddleZone - 1;
			end;
			--]]
			
			for j = 1, math.max(StartProfile.ZoneCount, EndProfile.ZoneCount) do
				local StartLane		= StartProfile.Lanes[math.min(math.max(j, 1), #StartProfile.Lanes)] or 0xFEBFFAFF;
				local EndLane		= EndProfile.Lanes[math.min(math.max(j, 1), #EndProfile.Lanes)] or 0xFEBFFAFF;
				
				local StartDirection	= 1;
				local EndDirection	= 1;
				
				if (StartFlipped ~= 0x00000000) then
					StartLane	= StartProfile.Lanes[math.min(math.max(StartProfile.ZoneCount - j + 1, 1), #StartProfile.Lanes)] or 0xFEBFFAFF;
					--StartDirection	= -StartDirection;
				end;
				
				if (EndFlipped ~= 0x00000000) then
					EndLane		= EndProfile.Lanes[math.min(math.max(EndProfile.ZoneCount - j + 1, 1), #EndProfile.Lanes)] or 0xFEBFFAFF;
					--EndDirection	= -EndDirection;
				end;
				
				local StartLaneType, StartOffset, StartRoadWidth;
				local EndLaneType, EndOffset, EndRoadWidth;
				
				local StartLeftOffset, StartRightOffset;
				local EndLeftOffset, EndRightOffset;
				
				if (ZoneCache[StartLane] ~= nil) then
					StartLaneType		= ZoneCache[StartLane][1];
					StartOffset		= ZoneCache[StartLane][2];
					StartRoadWidth		= ZoneCache[StartLane][3];
				else
					StartLaneType		= AdjustWithMask(StartLane, 04, 00);
					StartOffset		= SX(AdjustWithMask(StartLane, 14, 18), 14) * ScalingFactor0;
					StartRoadWidth		= SX(AdjustWithMask(StartLane, 14, 04), 14) * ScalingFactor0;
					
					ZoneCache[StartLane]	= {StartLaneType, StartOffset, StartRoadWidth};
				end;
				
				if (ZoneCache[EndLane] ~= nil) then
					EndLaneType		= ZoneCache[EndLane][1];
					EndOffset		= ZoneCache[EndLane][2];
					EndRoadWidth		= ZoneCache[EndLane][3];
				else
					EndLaneType		= AdjustWithMask(EndLane, 04, 00);
					EndOffset		= SX(AdjustWithMask(EndLane, 14, 18), 14) * ScalingFactor0;
					EndRoadWidth		= SX(AdjustWithMask(EndLane, 14, 04), 14) * ScalingFactor0;
					
					ZoneCache[EndLane]	= {EndLaneType, EndOffset, EndRoadWidth};
				end;
				
				if (StartMiddleZone > 0) then
					if (j >= StartMiddleZone + 1) then
						StartDirection	= -StartDirection;
					end;
				end;
				
				if (EndMiddleZone > 0) then
					if (j >= EndMiddleZone + 1) then
						EndDirection	= -EndDirection;
					end;
				end;
				
				StartLeftOffset			= StartOffset - StartRoadWidth * StartDirection * 0.5;
				StartRightOffset		= StartOffset + StartRoadWidth * StartDirection * 0.5;
				
				EndLeftOffset			= EndOffset - EndRoadWidth * EndDirection * 0.5;
				EndRightOffset			= EndOffset + EndRoadWidth * EndDirection * 0.5;
				
				--StartOffset		= math.min(math.max(StartOffset, StartLeftOffset + 0.1), StartRightOffset - 0.1);
				--EndOffset		= math.min(math.max(EndOffset, EndLeftOffset + 0.1), EndRightOffset - 0.1);
				
				local StartColour	= LanePalette[StartLaneType + 1];
				local EndColour		= LanePalette[EndLaneType + 1];
				
				--print(string.format("Start:\t%s", StartLaneType));
				--print(string.format("End:\t%s", EndLaneType));
				
				--print(string.format("Start\tOffset: 0x%08X, Width: 0x%08X", StartOffset, StartRoadWidth));
				--print(string.format("End\tOffset: 0x%08X, Width: 0x%08X", EndOffset, EndRoadWidth));
				
				local StartPosition		= StartNode.Position + StartRightVector * StartDirection * StartOffset;
				local EndPosition		= EndNode.Position + EndRightVector * EndDirection * EndOffset;
				
				local StartLeftPosition		= StartNode.Position + StartRightVector * (StartDirection * StartLeftOffset);
				local EndLeftPosition		= EndNode.Position + EndRightVector * EndDirection * EndLeftOffset;
				local StartRightPosition	= StartNode.Position + StartRightVector * StartDirection * StartRightOffset;
				local EndRightPosition		= EndNode.Position + EndRightVector * EndDirection * EndRightOffset;
				
				local LeftDistance	= math.max(Maths.Vector4.Magnitude(EndLeftPosition - StartLeftPosition), Epsilon);
				local RightDistance	= math.max(Maths.Vector4.Magnitude(EndRightPosition - StartRightPosition), Epsilon);
				
				LeftDistance		= LeftDistance / NodeDistance;
				RightDistance		= RightDistance / NodeDistance;
				
				StartLeftHandle		= StartLeftPosition + StartControl * LeftDistance;
				StartRightHandle	= StartRightPosition + StartControl * RightDistance;
				
				EndLeftHandle		= EndLeftPosition + EndControl * LeftDistance;
				EndRightHandle		= EndRightPosition + EndControl * RightDistance;
				
				local SplineMatrix	= Math.Matrix4:New2(StartPosition, StartHandle, EndHandle, EndPosition);
				local LeftSplineMatrix	= Math.Matrix4:New2(StartLeftPosition, StartLeftHandle, EndLeftHandle, EndLeftPosition);
				local RightSplineMatrix	= Math.Matrix4:New2(StartRightPosition, StartRightHandle, EndRightHandle, EndRightPosition);
				
				local LaneTypeEquality	= (StartLaneType == EndLaneType);
				
				for T = 0, SegmentResolution - 1, 1 do
					local t				= T / math.max(SegmentResolution - 1, 1);
					
					local LeftPosition;
					local RightPosition;
					
					if (HasCurvature ~= 0x00000000) then
						LeftPosition		= EvaluateSpline(LeftSplineMatrix, t);
						RightPosition		= EvaluateSpline(RightSplineMatrix, t);
					else
						LeftPosition		= Lerp(StartLeftPosition, EndLeftPosition, t);
						RightPosition		= Lerp(StartRightPosition, EndRightPosition, t);
					end;
					
					local R, G, B			= math.sqrt(StartColour[1]), math.sqrt(StartColour[2]), math.sqrt(StartColour[3]);
					
					if (LaneTypeEquality == false) then
						R			= math.sqrt(Lerp(StartColour[1], EndColour[1], t));
						G			= math.sqrt(Lerp(StartColour[2], EndColour[2], t));
						B			= math.sqrt(Lerp(StartColour[3], EndColour[3], t));
					end;
					
					VertexGroupCount		= VertexGroupCount + 1;
					
					v_String[VertexGroupCount]	= string.format("v\t%f %f %f %f %f %f", LeftPosition.X, LeftPosition.Y, LeftPosition.Z, R, G, B) .. "\n" .. string.format("v\t%f %f %f %f %f %f", RightPosition.X, RightPosition.Y, RightPosition.Z, R, G, B);
					
					if (T > 0) then
						--table.insert(l_String, string.format("l\t%i %i", #v_String - 1, #v_String));
						FaceGroupCount				= FaceGroupCount + 1;
						l_String[FaceGroupCount]		= string.format("f\t%i %i %i %i", VertexGroupCount * 2 - 3, VertexGroupCount * 2 - 2, VertexGroupCount * 2, VertexGroupCount * 2 - 1);
					else
						if (j <= 1) then
							FaceGroupCount			= FaceGroupCount + 1;
							l_String[FaceGroupCount]	= string.format("o\tSegment%i.Flags0x%04X", i - 1, Segment.Flags);
						end;
					end;
				end;
			end;
			
			if (i % 50 == 0) then
				local ElapsedTime	= os.clock() - StartTime;
				print(string.format("Segment #% 06i / % 06i Estimated Time Remaining: %f s", Segment.SegmentID, #Segments, (ElapsedTime / i) * #Segments - ElapsedTime));
			end;
		end;
		
		--print(string.format("UnkID [%i, %i]", MaxUnkID, MinUnkID));
		
		obj_string = obj_string .. string.rep("\n", math.min(#obj_string, 1) * 2);
		obj_string = obj_string .. table.concat(v_String, "\n");
		obj_string = obj_string .. string.rep("\n", math.min(#obj_string, 1) * 2);
		obj_string = obj_string .. table.concat(l_String, "\n");
		
		local __CGrd		= ObjectMain.CARP.CDat.CGrd.AbsoluteOffset;
		
		local OffsetZ, OffsetY, OffsetX = ResourceFile:Read(__CGrd + 0x00, fmt .. "f f f");
		local Scale		= ResourceFile:Read(__CGrd + 0x10, fmt .. "f");
		local ScaleInverse	= ResourceFile:Read(__CGrd + 0x14, fmt .. "f");
		local SizeX, SizeY	= ResourceFile:Read(__CGrd + 0x18, fmt .. "i4 i4");
		local MaxSize		= math.max(SizeX, SizeY);
		
		print(string.format("Location X <%f>\nLocation Y <%f>", OffsetX, OffsetZ));
		print(string.format("Resolution X <%i>\nResolution Y <%i>", SizeX * Scale, SizeY * Scale));
		print(string.format("Orthographic Scale <%f>", MaxSize * Scale));
		print(string.format("Shift X <(%i / %i) * 0.5>\nShift Y <(%i / %i) * -0.5>", SizeX, MaxSize, SizeY, MaxSize));
		
		local files		= {};
		table.insert(files, {FileName = "WRoadNetwork", FileType = "obj"; Data = obj_string});
		
		table.insert(FileOutputInventory.RoadNetworks, files);
		
		return true;
	else
		return false;
	end;
end;

return Loader_WRoadNetwork;