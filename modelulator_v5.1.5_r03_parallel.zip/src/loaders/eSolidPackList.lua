if (_ENV.BITMASK_REVOLUTION_VTXDESCANDFMT == nil) then
	_ENV.BITMASK_REVOLUTION_VTXDESCANDFMT		= 0x0000;
	_ENV.BITMASK_BAND_REVOLUTION_VTXDESCANDFMT	= 0xFFFF;
end;

local function Loader_eSolidPackList(bChunk)
	local FilePointer	= bChunk.Address;
	
	local fmt		= Config.BigEndian and ">" or "<";
	
	if (bChunk.ID == 0x80134000) then
		local SolidPackList		= {};
		SolidPackList.Address		= bChunk.Address;
		SolidPackList.Header		= {};
		SolidPackList.NameHashList	= {};
		SolidPackList.SolidInventory	= {};
		SolidPackList.StreamTable	= {};
		
		local PackListSize		= bChunk.Size;
		
		local xSolidList		= {};
		
		bChunk.Address			= bChunk.Address + 0x08;
		
		local function Loader_eSolidHeaderChunks()
			local ReturnAddress		= bChunk.Address + 0x00;
			
			if (bChunk.ID == 0x80134001) then
				local HeaderPointer	= bChunk.Address;
				local HeaderSize	= bChunk.Size;
				
				bChunk.Address		= bChunk.Address + 0x08;
				
				while (bChunk.Address - HeaderPointer - 0x08 < HeaderSize) do
					--print(string.format("%s (0x%08X)", bChunk, #bChunk));
					
					if (bChunk.ID == 0x00134002) then
						local SolidPackInfoPointer	= bChunk.Address + 0x08;
						local SolidPackInfoSize		= bChunk.Size;
						
						local AlignDiff		= bChunk:Align(0x10);
						bChunk.Address		= bChunk.Address - 0x08 - AlignDiff;
						
						SolidPackInfoPointer	= SolidPackInfoPointer + AlignDiff;
						SolidPackInfoSize	= SolidPackInfoSize - AlignDiff;
						
						SolidPackList.Header.Version		= ResourceFile:Read(SolidPackInfoPointer + 0x08, "<i4");
						SolidPackList.Header.NumSolids		= ResourceFile:Read(SolidPackInfoPointer + 0x0C, "<i4");
						SolidPackList.Header.FileName		= string.unpack("<z", ResourceFile:Read(SolidPackInfoPointer + 0x10, "<c56"), 1);
						SolidPackList.Header.Section		= string.unpack("<z", ResourceFile:Read(SolidPackInfoPointer + 0x48, "<c32"), 1);
						SolidPackList.Header.Alignment		= ResourceFile:Read(SolidPackInfoPointer + 0x70, "<B");
						
						--log_string = log_string .. string.rep("\n", math.min(#log_string, 1)) .. (string.format("Version: %i, NumSolids: %i\nFileName: %s\nSection: %s", SolidPackList.Header.Version, SolidPackList.Header.NumSolids, SolidPackList.Header.FileName, SolidPackList.Header.Section));
					elseif (bChunk.ID == 0x00134003) then
						local SolidHashListPointer	= bChunk.Address + 0x08;
						local SolidHashListSize		= bChunk.Size;
						local Count			= SolidHashListSize // 0x08;
						
						for i = 0, Count - 1 do
							local SolidHash_i = ResourceFile:Read(SolidHashListPointer + i * 0x08, "<I4");
							
							--[[
							log_string = log_string .. string.rep("\n", math.min(#log_string, 1));
							log_string = log_string .. (string.format("[%i]\teSolid_0x%08X", i, SolidHash_i));
							--]]
							
							table.insert(SolidPackList.NameHashList, SolidHash_i);
						end;
					elseif (bChunk.ID == 0x00134004) then
						local StreamTablePointer	= bChunk.Address + 0x08;
						local StreamTableSize		= bChunk.Size;
						
						while (StreamTablePointer - (bChunk.Address + 0x08) < StreamTableSize) do
							local StreamTableEntry	= {};
							
							if (_ENV.Config.Game.Value <= ModelulatorEnum.Game.UNDERGROUND.Value) then
								StreamTableEntry	=
								{
									NameHash	= ResourceFile:Read(StreamTablePointer + 0x00, "<I4");
									DataPointer	= ResourceFile:Read(StreamTablePointer + 0x04, "<I4");
									DataSize	= ResourceFile:Read(StreamTablePointer + 0x08, "<i4");
									Flags		= ResourceFile:Read(StreamTablePointer + 0x0C, "<I4");
									pUnk		= ResourceFile:Read(StreamTablePointer + 0x10, "<I4");
								};
								
								StreamTablePointer	= StreamTablePointer + 0x14;
							else
								StreamTableEntry	=
								{
									NameHash	= ResourceFile:Read(StreamTablePointer + 0x00, "<I4");
									DataPointer	= ResourceFile:Read(StreamTablePointer + 0x04, "<I4");
									DataSize	= ResourceFile:Read(StreamTablePointer + 0x08, "<i4");
									UncompSize	= ResourceFile:Read(StreamTablePointer + 0x0C, "<i4");
									Flags		= ResourceFile:Read(StreamTablePointer + 0x10, "<I4");
									pUnk		= ResourceFile:Read(StreamTablePointer + 0x14, "<I4");
								};
								
								StreamTablePointer	= StreamTablePointer + 0x18;
							end;
							
							table.insert(SolidPackList.StreamTable, StreamTableEntry);
						end;
					elseif (bChunk.ID == 0x80134008) then
						--[[
						local SolidPackContainerPointer		= bChunk.Address;
						
						bChunk.Address = bChunk.Address + 0x08;
						--]]
					end;
					
					bChunk:Next();
				end;
				
				bChunk.Address = ReturnAddress;
				
				return true;
			else
				return false;
			end;
		end;
		
		local function Loader_eSolidChunks()
			local ReturnAddress		= bChunk.Address + 0x00;
			
			if (bChunk.ID == 0x80134010) then
				local SolidPackPointer	= bChunk.Address;
				local SolidPackSize	= bChunk.Size;
				
				local __SolidObject	= {};
				local __Data		= {};
				local __Groups		= {};
				
				bChunk.Address		= bChunk.Address + 0x08;
				
				while (bChunk.Address - SolidPackPointer - 0x08 < SolidPackSize) do
					--[[
					log_string = log_string .. string.rep("\n", math.min(#log_string, 1));
					log_string = log_string .. (tostring(bChunk));
					--]]
					
					if (bChunk.ID == 0x00134011) then
						local SolidPointer	= bChunk.Address + 0x08;
						local SolidSize		= bChunk.Size;
						
						local AlignDiff		= bChunk:Align(0x10);
						bChunk.Address		= bChunk.Address - 0x08 - AlignDiff;
						
						SolidPointer		= SolidPointer + AlignDiff;
						SolidSize		= SolidSize - AlignDiff;
						
						local PivotMatrixOffset		= (SolidPackList.Header.Version == 0x1E) and 0x10 or 0x00;
						
						local SolidObject		=
						{
							Version			= ResourceFile:Read(SolidPointer + 0x0C, "<H");
							SolidFlags		= ResourceFile:Read(SolidPointer + 0x0E, "<H");
							NameHash		= ResourceFile:Read(SolidPointer + 0x10, "<I4");
							NumPolys		= ResourceFile:Read(SolidPointer + 0x14, "<h");
							NumUniqueVerts		= ResourceFile:Read(SolidPointer + 0x16, "<h");
							Unk0			= ResourceFile:Read(SolidPointer + 0x18, "<b");
							NumTextures		= ResourceFile:Read(SolidPointer + 0x19, "<b");
							NumLightMaterials	= ResourceFile:Read(SolidPointer + 0x1A, "<b");
							Unk1			= ResourceFile:Read(SolidPointer + 0x1B, "<b");
							Unk2			= ResourceFile:Read(SolidPointer + 0x1C, "<I4");
							
							PivotMatrix		=
							{
								v0		=
								{
									x	= ResourceFile:Read(SolidPointer + 0x40 + PivotMatrixOffset + 0x00, "<f");
									y	= ResourceFile:Read(SolidPointer + 0x40 + PivotMatrixOffset + 0x04, "<f");
									z	= ResourceFile:Read(SolidPointer + 0x40 + PivotMatrixOffset + 0x08, "<f");
									w	= ResourceFile:Read(SolidPointer + 0x40 + PivotMatrixOffset + 0x0C, "<f");
								};
								
								v1		=
								{
									x	= ResourceFile:Read(SolidPointer + 0x40 + PivotMatrixOffset + 0x10, "<f");
									y	= ResourceFile:Read(SolidPointer + 0x40 + PivotMatrixOffset + 0x14, "<f");
									z	= ResourceFile:Read(SolidPointer + 0x40 + PivotMatrixOffset + 0x18, "<f");
									w	= ResourceFile:Read(SolidPointer + 0x40 + PivotMatrixOffset + 0x1C, "<f");
								};
								
								v2		=
								{
									x	= ResourceFile:Read(SolidPointer + 0x40 + PivotMatrixOffset + 0x20, "<f");
									y	= ResourceFile:Read(SolidPointer + 0x40 + PivotMatrixOffset + 0x24, "<f");
									z	= ResourceFile:Read(SolidPointer + 0x40 + PivotMatrixOffset + 0x28, "<f");
									w	= ResourceFile:Read(SolidPointer + 0x40 + PivotMatrixOffset + 0x2C, "<f");
								};
								
								v3		=
								{
									x	= ResourceFile:Read(SolidPointer + 0x40 + PivotMatrixOffset + 0x30, "<f");
									y	= ResourceFile:Read(SolidPointer + 0x40 + PivotMatrixOffset + 0x34, "<f");
									z	= ResourceFile:Read(SolidPointer + 0x40 + PivotMatrixOffset + 0x38, "<f");
									w	= ResourceFile:Read(SolidPointer + 0x40 + PivotMatrixOffset + 0x3C, "<f");
								};
							};
							
							pTextureTable		= {};
							LightMaterialTable	= {};
						};
						
						-- only exists cos it is rather case specific
						local NameOffset	= 0x00;
						local NameSize		= 0x00;
						
						local IsMostWantedOrNewer	= (Config.Game.Value >= ModelulatorEnum.Game.MOSTWANTED.Value);
						local IsUnderground2		= (Config.Game == ModelulatorEnum.Game.UNDERGROUND2);
						
						if (SolidPackList.Header.Version < 0x1E)
						then
							if (IsMostWantedOrNewer)
							then
								NameOffset	= 0xA0;
								
								if (Config.Game == ModelulatorEnum.Game.PROSTREET)
								then
									NameOffset	= 0xA8;
								end;
								
								NameSize	= (SolidSize - NameOffset);
							else
								NameOffset	= 0x90;
								NameOffset	= NameOffset + ((SolidObject.Version > 0x11) and 0x04 or 0x00);
								
								if (Config.Game == ModelulatorEnum.Game.MOSTWANTED_DEMO)
								then
									NameOffset	= NameOffset + 0x0000000C;
								end;
								
								NameSize	= (SolidSize - NameOffset);
							end;
						else
							NameOffset		= 0xB0;
							NameSize		= (SolidSize - NameOffset);
						end;
						
						-- Solid names are C strings stored inside a larger fixed-size structure.
						-- Stop at the first NUL. The old code removed all NUL bytes from the
						-- entire remaining structure and accidentally appended binary fields to
						-- the name, causing garbled names and invalid Windows output paths.
						local RawSolidName = ResourceFile:Read(SolidPointer + NameOffset, "<c" .. NameSize);
						local NameTerminator = string.find(RawSolidName, "\x00", 1, true);
						if (NameTerminator ~= nil) then
							SolidObject.Name = string.sub(RawSolidName, 1, NameTerminator - 1);
						else
							SolidObject.Name = RawSolidName;
						end;
						
						--[[
						_ENV.hash_assoc = _ENV.hash_assoc or {};
						_ENV.hash_assoc[SolidPackList.Header.Section]	= _ENV.hash_assoc[SolidPackList.Header.Section] or {};
						_ENV.hash_assoc[SolidPackList.Header.Section][SolidObject.NameHash]	= string.format("%s-0x%08X", SolidPackList.Header.Section, SolidObject.NameHash);
						--]]
						
						local HashTestName	= 0xFFFFFFFF;
						
						for j = 1, #SolidObject.Name, 1
						do
							HashTestName = HashTestName * 0x21;
							HashTestName = HashTestName + string.byte(SolidObject.Name, j, j);
							HashTestName = HashTestName & 0xFFFFFFFF;
						end;
						
						local SectionName	= ((#_ENV.Stream.CurrentSection > 0) and _ENV.Stream.CurrentSection or SolidPackList.Header.Section);
						
						print(string.format("%s.0x%08X - %s\\%s%s", SectionName, SolidObject.NameHash, SectionName, SolidObject.Name, string.rep("...", (HashTestName ~= SolidObject.NameHash) and 1 or 0)));
						
						table.insert(SolidPackList.SolidInventory, SolidObject);
						
						__SolidObject = SolidPackList.SolidInventory[#SolidPackList.SolidInventory];
						
						--log_string = log_string .. string.rep("\n", math.min(#log_string, 1)) .. string.format("[0x%08X] (v%i.%i.%i) eSolid_0x%08X\n%s", i - 1, SolidObject.Version >> 0x3, (SolidObject.Version >> 0x1) & 0x3, SolidObject.Version & 0x1, SolidObject.NameHash, SolidObject.Name);
					elseif (bChunk.ID == 0x00134012)
					then
						local eTextureTablePointer	= bChunk.Address + 0x08;
						
						for j = 0, (__SolidObject.NumTextures - 1)
						do
							local eTextureEntry	=
							{
								NameHash	= ResourceFile:Read(eTextureTablePointer + j * 0x08, "<I4");
								pTextureInfo	= {};
							};
							
							--log_string = log_string .. string.rep("\n", math.min(#log_string, 1)) .. string.format("[0x%02X] eTexture_0x%08X", j, eTextureEntry.NameHash);
							
							table.insert(__SolidObject.pTextureTable, eTextureEntry);
						end;
					elseif (bChunk.ID == 0x00134013) then
						local LightMaterialTablePointer	= bChunk.Address + 0x08;
						
						for j = 0, __SolidObject.NumLightMaterials - 1 do
							local eLightMaterialEntry	=
							{
								NameHash	= ResourceFile:Read(LightMaterialTablePointer + j * 0x08, "<I4");
								LightMaterial	= {};
							};
							
							--log_string = log_string .. string.rep("\n", math.min(#log_string, 1)) .. string.format("[0x%02X] eLightMaterial_0x%08X", j, eLightMaterialEntry.NameHash);
							
							table.insert(__SolidObject.LightMaterialTable, eLightMaterialEntry);
						end;
					elseif (bChunk.ID == 0x80134100) then
						local SolidDataPointer	= bChunk.Address;
						local SolidDataSize	= bChunk.Size;
						
						bChunk.Address = bChunk.Address + 0x08;
						
						if (_ENV.Config.Pipeline == ModelulatorEnum.Pipeline.PSX2) then
							__Data		= PlatChunks.PSX2(bChunk, SolidPackList, SolidDataSize);
							__Groups	= xSolid.GenerateGroups.PSX2(__Data);
						end;
						
						if (_ENV.Config.Pipeline == ModelulatorEnum.Pipeline.GAMECUBE) then
							__Data		= PlatChunks.Gamecube(bChunk, SolidPackList, SolidDataSize);
							__Groups	= xSolid.GenerateGroups.Gamecube(__Data);
						end;
						
						if (_ENV.Config.Pipeline == ModelulatorEnum.Pipeline.REVOLUTION) then
							__Data		= PlatChunks.Revolution(bChunk, SolidPackList, SolidDataSize);
							__Groups	= xSolid.GenerateGroups.Revolution(__Data);
						end;
						
						--[[
						if (_ENV.Config.Pipeline == ModelulatorEnum.Pipeline.XBOX) then
							__Data		= PlatChunks.Xbox(bChunk, SolidPackList, SolidDataSize);
							__Groups	= xSolid.GenerateGroups.Xbox(__Data);
						end;
						--]]
						
						bChunk.Address = SolidDataPointer;
					end;
					
					bChunk:Next();
				end;
				
				---[[
				local xSolid	=
				{
					EcstasySolid	= __SolidObject;
					xSolidInfo	= __Data;
					xSolidGroups	= __Groups;
				};
				
				table.insert(xSolidList, xSolid);
				---]]
				
				bChunk.Address = ReturnAddress;
				
				return true;
			else
				return false;
			end;
		end;
		
		while (bChunk.Address < SolidPackList.Address + PackListSize) do
			Loader_eSolidHeaderChunks();
			
			if (#SolidPackList.StreamTable <= 0) then
				Loader_eSolidChunks();
			else
				break;
			end;
			
			bChunk:Next();
		end;
		
		if (#SolidPackList.StreamTable > 0) then
			local BCHUNK_COMPRESS_IN_PLACE_MAGIC	= 0x55441122;
			
			local TempResourceFile			= PhilLip2:CreateFile(ModelulatorTempPath());
			
			local function SwapResourceFiles()
				ResourceFile, TempResourceFile	= TempResourceFile, ResourceFile;
			end;
			
			for i = 1, #SolidPackList.StreamTable do
				local StreamTableEntry	= SolidPackList.StreamTable[i];
				
				local TempPointer	= StreamTableEntry.DataPointer + 0x00000000;
				
				if (_ENV.Config.Game.Value <= ModelulatorEnum.Game.UNDERGROUND.Value) then
					print(string.format("0x%08X 0x%08X 0x%08X 0x%08X", StreamTableEntry.NameHash, StreamTableEntry.DataPointer, StreamTableEntry.DataSize, StreamTableEntry.Flags));
				else
					print(string.format("0x%08X 0x%08X 0x%08X 0x%08X 0x%08X", StreamTableEntry.NameHash, StreamTableEntry.DataPointer, StreamTableEntry.DataSize, StreamTableEntry.UncompSize, StreamTableEntry.Flags));
				end;
				
				if (StreamTableEntry.Flags & 0x00000300 > 0x00000000) then
					TempResourceFile:Open("Write + (Binary)");
					
					if (StreamTableEntry.Flags & 0x00000300 == 0x00000100) then
						local UCompData			= Decompress(TempPointer + 0x00000000);
						
						TempResourceFile:Write(0x00000000, UCompData);
						UCompData:close();
					elseif (StreamTableEntry.Flags & 0x00000300 == 0x00000200) then
						while (TempPointer < (StreamTableEntry.DataPointer + StreamTableEntry.DataSize)) do
							-- Inspect the CURRENT block, not the first block of the stream entry.
							local ID		= ResourceFile:Read(TempPointer + 0x00000000, "<I4");
							
							if (ID == BCHUNK_COMPRESS_IN_PLACE_MAGIC) then
								local UCompSize			= ResourceFile:Read(TempPointer + 0x00000004, "<I4");
								local RawSize			= ResourceFile:Read(TempPointer + 0x00000008, "<I4");
								local UCompAddress		= ResourceFile:Read(TempPointer + 0x0000000C, "<I4");
								local RawAddress		= ResourceFile:Read(TempPointer + 0x00000010, "<I4");
								local Unk00			= ResourceFile:Read(TempPointer + 0x00000014, "<I4");
								
								--TempResourceFile:Write(~-(UCompAddress + UCompSize), "x", 0x00);
								
								local UCompData			= Decompress(TempPointer + 0x00000018);
								
								print(string.format("0x%08X 0x%08X // 0x%08X | 0x%08X", UCompAddress, UCompSize, TempResourceFile.Size, UCompData.size));
								
								TempResourceFile:Write(UCompAddress, UCompData);
								UCompData:close();
								
								TempPointer			= TempPointer + RawSize;
							else
								print("no compress in place marker found!");
								break;
							end;
						end;
					elseif (StreamTableEntry.Flags & 0x00000300 == 0x00000300) then
						error("pick one damn it!!! - somehow both compression flags got set", 0);
					else
						error("somehow NEITHER compression flag got set, but here we are", 0);
					end;
					
					bChunk.Address	= 0x00000000;
					
					SwapResourceFiles();
					
					while (bChunk.Address - 0x00 < ResourceFile.Size) do
						Loader_eSolidChunks();
						
						bChunk:Next();
					end;
					
					SwapResourceFiles();
					
					TempResourceFile:Close();
				else
					bChunk.Address		= StreamTableEntry.DataPointer;
					
					local EndAddress	= StreamTableEntry.DataPointer + StreamTableEntry.DataSize;
					
					while (bChunk.Address < EndAddress) do
						Loader_eSolidChunks();
						
						bChunk:Next();
					end;
				end;
			end;
			
			os.remove(TempResourceFile.Directory);
		end;
		
		bChunk.Address		= SolidPackList.Address;
		
		---[[
		local SectionName	= ((#_ENV.Stream.CurrentSection > 0) and _ENV.Stream.CurrentSection or SolidPackList.Header.Section);
						
		-- Prime the complete name map first, then export one solid per output job.
		-- One malformed DAE can no longer suppress every other solid in this pack.
		dae:generate_solid_name(xSolidList, SectionName);

		for _, SolidToExport in ipairs(xSolidList) do
			table.insert(_ENV.FileOutputList,
			{
				Inventory = "Solids";
				Output = {Function = dae.generate_solid_single, Arguments = {dae, SolidToExport, SectionName}};
			});
		end;

		-- Palette is isolated too, so palette generation cannot block solid DAEs.
		table.insert(_ENV.FileOutputList,
		{
			Inventory = "Solids";
			Output = {Function = dae.generate_solid_palette, Arguments = {dae, xSolidList, SectionName}};
		});

		if ((SolidPackList.Header.NumSolids or 0) > 0 and #xSolidList ~= SolidPackList.Header.NumSolids) then
			print(string.format("WARNING: solid count mismatch for section %s: header=%d parsed=%d", SectionName, SolidPackList.Header.NumSolids, #xSolidList));
		end;
		---]]
		
		--print(string.format("0x%04X 0x%04X", _ENV.BITMASK_REVOLUTION_VTXDESCANDFMT, _ENV.BITMASK_BAND_REVOLUTION_VTXDESCANDFMT));
		
		return true;
	else
		return false;
	end;
end;

return Loader_eSolidPackList;