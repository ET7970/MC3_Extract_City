local function Loader_eTexturePack(bChunk)
	local ReturnAddress	= bChunk.Address;
	
	if (bChunk.ID == 0xB3300000) then
		local eTexturePack			= {};
		eTexturePack.Header			= {};
		eTexturePack.TextureHashTable		= {};
		eTexturePack.TextureInfoTable		= {};
		eTexturePack.TextureInfoPlatInfoTable	= {};
		eTexturePack.StreamTable		= {};
		eTexturePack.DataHash			= 0xFFFFFFFF;
		
		local FastHash				= {};
		
		local eTexturePackInfoJSON		= "";
		
		local eTexturePackPointer	= bChunk.Address;
		local eTexturePackSize		= bChunk.Size;
		
		bChunk.Address	= bChunk.Address + 0x08;
		
		---[[
		for Offset = 0x00000000, eTexturePackSize - 0x00000004, 0x00000004 do
			local CurrentByte	= ResourceFile:Read(eTexturePackPointer + 0x08 + Offset, "<I4");
			eTexturePack.DataHash	= (eTexturePack.DataHash * 0x21 + CurrentByte) & 0xFFFFFFFF;
		end;
		---]]
		
		local AlignDiff			= bChunk.Size + 0x08;
		
		eTexturePackPointer		= eTexturePackPointer + 0x10 + AlignDiff;
		eTexturePackSize		= eTexturePackSize - 0x10 - AlignDiff;
		
		local eTexturePackInfoSize	= 0x00000000;
		
		while (bChunk.Address - eTexturePackPointer < eTexturePackSize) do
			if (bChunk.ID == 0xB3310000) then
				bChunk.Address		= bChunk.Address + 0x08;
				eTexturePackInfoSize	= bChunk.Size;
			end;
			
			if (bChunk.ID == 0x33310001) then
				local eTexturePackHeaderPointer	= bChunk.Address + 0x08;
				local eTexturePackHeaderSize	= bChunk.Size;
				
				local AlignDiff			= bChunk:Align(0x10);
				bChunk.Address			= bChunk.Address - 0x08 - AlignDiff;
				
				eTexturePackHeaderPointer	= eTexturePackHeaderPointer + AlignDiff;
				eTexturePackHeaderSize		= eTexturePackHeaderSize - AlignDiff;
				
				eTexturePack.Header.Version	= ResourceFile:Read(eTexturePackHeaderPointer + 0x00, "<i4");
				
				if (_ENV.Config.Game.Value < ModelulatorEnum.Game.UNDERGROUND.Value) then
					eTexturePack.Header.Name	= ResourceFile:Read(eTexturePackHeaderPointer + 0x04, "<c32");
					eTexturePack.Header.FileName	= ResourceFile:Read(eTexturePackHeaderPointer + 0x24, "<c60");
				else
					eTexturePack.Header.Name	= ResourceFile:Read(eTexturePackHeaderPointer + 0x04, "<c28");
					eTexturePack.Header.FileName	= ResourceFile:Read(eTexturePackHeaderPointer + 0x20, "<c64");
				end;
				
				eTexturePack.Header.FileNameHash= ResourceFile:Read(eTexturePackHeaderPointer + 0x60, "<I4");
				
				eTexturePack.Header.Name	= string.gsub(eTexturePack.Header.Name, "\x00", "");
				eTexturePack.Header.FileName	= string.gsub(eTexturePack.Header.FileName, "\x00", "");
				
				print(eTexturePack.Header.Name, eTexturePack.Header.FileName);
			elseif (bChunk.ID == 0x33310002) then
				local HashTablePointer		= bChunk.Address + 0x08;
				local HashTableSize		= bChunk.Size;
				
				local HashTableCount		= HashTableSize // 0x08;
				
				for i = 0, HashTableCount - 1 do
					local eTextureEntry	=
					{
						NameHash	= ResourceFile:Read(HashTablePointer + 0x00 + i * 0x08, "<I4");
						pTextureInfo	= -1;
					};
					
					--print(string.format("#%10i: eTexture_0x%08X", i, eTextureEntry.NameHash));
					
					eTexturePack.TextureHashTable[i + 1]	= eTextureEntry;
					FastHash[eTextureEntry.NameHash]	= i + 1;
				end;
			elseif (bChunk.ID == 0x33310003) then
				local StreamTablePointer	= bChunk.Address + 0x08;
				local StreamTableSize		= bChunk.Size;
				
				while (StreamTablePointer - (bChunk.Address + 0x08) < StreamTableSize) do
					local StreamTableEntry	= {};
					
					if (_ENV.Config.Game.Value <= ModelulatorEnum.Game.UNDERGROUND.Value) then
						StreamTableEntry	=
						{
							NameHash	= ResourceFile:Read(StreamTablePointer + 0x00, "<I4");
							DataPointer	= ResourceFile:Read(StreamTablePointer + 0x04, "<I4");
							DataSize	= ResourceFile:Read(StreamTablePointer + 0x08, "<i4");
							Flags		= ResourceFile:Read(StreamTablePointer + 0x0C, "<I4");
							pUnk		= ResourceFile:Read(StreamTablePointer + 0x10, "<I4");
						};
						
						StreamTablePointer	= StreamTablePointer + 0x14;
					else
						StreamTableEntry	=
						{
							NameHash	= ResourceFile:Read(StreamTablePointer + 0x00, "<I4");
							DataPointer	= ResourceFile:Read(StreamTablePointer + 0x04, "<I4");
							DataSize	= ResourceFile:Read(StreamTablePointer + 0x08, "<i4");
							UncompSize	= ResourceFile:Read(StreamTablePointer + 0x0C, "<i4");
							Flags		= ResourceFile:Read(StreamTablePointer + 0x10, "<I4");
							pUnk		= ResourceFile:Read(StreamTablePointer + 0x14, "<I4");
						};
						
						StreamTablePointer	= StreamTablePointer + 0x18;
					end;
					
					table.insert(eTexturePack.StreamTable, StreamTableEntry);
				end;
			elseif (bChunk.ID == 0x33310004) then
				local InfoTablePointer		= bChunk.Address + 0x08;
				local InfoTableSize		= bChunk.Size;
				
				local EndAddress		= InfoTablePointer + InfoTableSize;
				
				while (InfoTablePointer < EndAddress) do
					local eTextureInfo	= {};
					
					if (_ENV.Config.Game.Value <= ModelulatorEnum.Game.MOSTWANTED.Value) then
						eTextureInfo	=
						{
							Name			= "";
							NameHash		= ResourceFile:Read(InfoTablePointer + 0x24, "<I4");
							ClassNameHash		= ResourceFile:Read(InfoTablePointer + 0x28, "<I4");
							ImagePlacement		= ResourceFile:Read(InfoTablePointer + 0x30, "<i4");
							PalettePlacement	= ResourceFile:Read(InfoTablePointer + 0x34, "<i4");
							ImageSize		= ResourceFile:Read(InfoTablePointer + 0x38, "<i4");
							PaletteSize		= ResourceFile:Read(InfoTablePointer + 0x3C, "<i4");
							BaseImageSize		= ResourceFile:Read(InfoTablePointer + 0x40, "<i4");
							Width			= ResourceFile:Read(InfoTablePointer + 0x44, "<h");
							Height			= ResourceFile:Read(InfoTablePointer + 0x46, "<h");
							ShiftWidth		= ResourceFile:Read(InfoTablePointer + 0x48, "<B");
							ShiftHeight		= ResourceFile:Read(InfoTablePointer + 0x49, "<B");
							ImageCompressionType	= ResourceFile:Read(InfoTablePointer + 0x4A, "<B");
							PaletteCompressionType	= ResourceFile:Read(InfoTablePointer + 0x4B, "<B");
							NumPaletteEntries	= ResourceFile:Read(InfoTablePointer + 0x4C, "<h");
							NumMipMapLevels		= ResourceFile:Read(InfoTablePointer + 0x4E, "<b");
							TilableUV		= ResourceFile:Read(InfoTablePointer + 0x4F, "<b");
							BiasLevel		= ResourceFile:Read(InfoTablePointer + 0x50, "<b");
							RenderingOrder		= ResourceFile:Read(InfoTablePointer + 0x51, "<b");
							ScrollType		= ResourceFile:Read(InfoTablePointer + 0x52, "<b");
							UsedFlag		= ResourceFile:Read(InfoTablePointer + 0x53, "<b");
							ApplyAlphaSorting	= ResourceFile:Read(InfoTablePointer + 0x54, "<b");
							AlphaUsageType		= ResourceFile:Read(InfoTablePointer + 0x55, "<b");
							AlphaBlendType		= ResourceFile:Read(InfoTablePointer + 0x56, "<b");
							Flags			= ResourceFile:Read(InfoTablePointer + 0x57, "<B");
							ScrollTimeStep		= ResourceFile:Read(InfoTablePointer + 0x58, "<h");
							ScrollSpeedS		= ResourceFile:Read(InfoTablePointer + 0x5A, "<h");
							ScrollSpeedT		= ResourceFile:Read(InfoTablePointer + 0x5C, "<h");
							OffsetS			= ResourceFile:Read(InfoTablePointer + 0x5E, "<h");
							OffsetT			= ResourceFile:Read(InfoTablePointer + 0x60, "<h");
							ScaleS			= ResourceFile:Read(InfoTablePointer + 0x62, "<h");
							ScaleT			= ResourceFile:Read(InfoTablePointer + 0x64, "<h");
						};
						
						eTextureInfo.Name	= ResourceFile:Read(InfoTablePointer + 0x0C, "<c24");
						
						InfoTablePointer	= InfoTablePointer + 0x7C;
					else
						eTextureInfo	=
						{
							NameHash		= ResourceFile:Read(InfoTablePointer + 0x0C, "<I4");
							ClassNameHash		= ResourceFile:Read(InfoTablePointer + 0x10, "<I4");
							ImagePlacement		= ResourceFile:Read(InfoTablePointer + 0x14, "<i4");
							PalettePlacement	= ResourceFile:Read(InfoTablePointer + 0x18, "<i4");
							ImageSize		= ResourceFile:Read(InfoTablePointer + 0x1C, "<i4");
							PaletteSize		= ResourceFile:Read(InfoTablePointer + 0x20, "<i4");
							BaseImageSize		= ResourceFile:Read(InfoTablePointer + 0x24, "<i4");
							Width			= ResourceFile:Read(InfoTablePointer + 0x28, "<h");
							Height			= ResourceFile:Read(InfoTablePointer + 0x2A, "<h");
							ShiftWidth		= ResourceFile:Read(InfoTablePointer + 0x2C, "<B");
							ShiftHeight		= ResourceFile:Read(InfoTablePointer + 0x2D, "<B");
							ImageCompressionType	= ResourceFile:Read(InfoTablePointer + 0x2E, "<B");
							PaletteCompressionType	= ResourceFile:Read(InfoTablePointer + 0x2F, "<B");
							NumPaletteEntries	= ResourceFile:Read(InfoTablePointer + 0x30, "<h");
							NumMipMapLevels		= ResourceFile:Read(InfoTablePointer + 0x32, "<b");
							TilableUV		= ResourceFile:Read(InfoTablePointer + 0x33, "<b");
							BiasLevel		= ResourceFile:Read(InfoTablePointer + 0x34, "<b");
							RenderingOrder		= ResourceFile:Read(InfoTablePointer + 0x35, "<b");
							ScrollType		= ResourceFile:Read(InfoTablePointer + 0x36, "<b");
							UsedFlag		= ResourceFile:Read(InfoTablePointer + 0x37, "<b");
							ApplyAlphaSorting	= ResourceFile:Read(InfoTablePointer + 0x38, "<b");
							AlphaUsageType		= ResourceFile:Read(InfoTablePointer + 0x39, "<b");
							AlphaBlendType		= ResourceFile:Read(InfoTablePointer + 0x3A, "<b");
							Flags			= ResourceFile:Read(InfoTablePointer + 0x3B, "<B");
							ScrollTimeStep		= ResourceFile:Read(InfoTablePointer + 0x3C, "<h");
							ScrollSpeedS		= ResourceFile:Read(InfoTablePointer + 0x3E, "<h");
							ScrollSpeedT		= ResourceFile:Read(InfoTablePointer + 0x40, "<h");
							OffsetS			= ResourceFile:Read(InfoTablePointer + 0x42, "<h");
							OffsetT			= ResourceFile:Read(InfoTablePointer + 0x44, "<h");
							ScaleS			= ResourceFile:Read(InfoTablePointer + 0x46, "<h");
							ScaleT			= ResourceFile:Read(InfoTablePointer + 0x48, "<h");
							
							NameLength		= ResourceFile:Read(InfoTablePointer + 0x58, "<B");
							Name			= "";
						};
						
						eTextureInfo.Name		= ResourceFile:Read(InfoTablePointer + 0x59, "<c" .. eTextureInfo.NameLength);
						
						eTextureInfo.ScrollType		= 0;
						eTextureInfo.ScrollSpeedS	= 0;
						eTextureInfo.ScrollSpeedT	= 0;
						
						InfoTablePointer	= InfoTablePointer + ((0x59 + eTextureInfo.NameLength + 0x03) & -0x04);
					end;
					
					if (ModelulatorEnum.TextureCompressionType:GetEnumFromValue(eTextureInfo.ImageCompressionType) == nil) then
						print(string.format("0x%02X", eTextureInfo.ImageCompressionType));
					end;
					
					eTextureInfo.ImageCompressionType	= ModelulatorEnum.TextureCompressionType:GetEnumFromValue(eTextureInfo.ImageCompressionType);
					eTextureInfo.PaletteCompressionType	= ModelulatorEnum.TextureCompressionType:GetEnumFromValue(eTextureInfo.PaletteCompressionType);
					eTextureInfo.AlphaUsageType		= ModelulatorEnum.TextureAlphaUsageType:GetEnumFromValue(eTextureInfo.AlphaUsageType or 0);
					eTextureInfo.AlphaBlendType		= ModelulatorEnum.TextureAlphaBlendType:GetEnumFromValue(eTextureInfo.AlphaBlendType or 0);
					
					eTextureInfo.Name		= string.gsub(eTextureInfo.Name, "\x00", "");
					
					table.insert(eTexturePack.TextureInfoTable, eTextureInfo);
					
					local TextureHashIndex		= FastHash[eTextureInfo.NameHash];
					eTexturePack.TextureHashTable[TextureHashIndex].pTextureInfo	= #eTexturePack.TextureInfoTable;
				end;
			elseif (bChunk.ID == 0x33310005) then
				local TextureInfoPlatInfoPointer	= bChunk.Address + 0x08;
				local TextureInfoPlatInfoSize		= bChunk.Size;
				
				local EndAddress			= TextureInfoPlatInfoPointer + TextureInfoPlatInfoSize;
				
				--TextureInfoPlatInfoCount		= TextureInfoPlatInfoSize // 0x54;
				
				while (TextureInfoPlatInfoPointer < EndAddress) do
					local TextureInfoPlatInfo	=
					{
						ImageVramBlocksRequired		= ResourceFile:Read(TextureInfoPlatInfoPointer + 0x00, "<H");
						PaletteVramBlocksRequired	= ResourceFile:Read(TextureInfoPlatInfoPointer + 0x02, "<H");
						PixelStorageMode		= ResourceFile:Read(TextureInfoPlatInfoPointer + 0x04, "<B");
						ClutPixelStorageMode		= ResourceFile:Read(TextureInfoPlatInfoPointer + 0x05, "<B");
						TextureFx			= ResourceFile:Read(TextureInfoPlatInfoPointer + 0x06, "<B");
						AlphaBits			= ResourceFile:Read(TextureInfoPlatInfoPointer + 0x07, "<B");
						AlphaFix			= ResourceFile:Read(TextureInfoPlatInfoPointer + 0x08, "<B");
						MMag				= ResourceFile:Read(TextureInfoPlatInfoPointer + 0x09, "<B");
						MMin				= ResourceFile:Read(TextureInfoPlatInfoPointer + 0x0A, "<B");
						MipMapL				= ResourceFile:Read(TextureInfoPlatInfoPointer + 0x0B, "<B");
						MipMapK				= ResourceFile:Read(TextureInfoPlatInfoPointer + 0x0C, "<H");
						AlphaUsage			= ResourceFile:Read(TextureInfoPlatInfoPointer + 0x0E, "<B");
						Special				= ResourceFile:Read(TextureInfoPlatInfoPointer + 0x0F, "<B");
						ImageInfos			= {};
					};
					
					for j = 0, 6 do
						local ImageInfo		=
						{
							Width				= ResourceFile:Read(TextureInfoPlatInfoPointer + 0x10 + j * 0x08 + 0x00, "<H");
							Height				= ResourceFile:Read(TextureInfoPlatInfoPointer + 0x10 + j * 0x08 + 0x02, "<H");
							TextureBasePointerOffset	= ResourceFile:Read(TextureInfoPlatInfoPointer + 0x10 + j * 0x08 + 0x04, "<H");
							TextureBufferWidth		= ResourceFile:Read(TextureInfoPlatInfoPointer + 0x10 + j * 0x08 + 0x06, "<B");
							Is32BitSwizzled			= ResourceFile:Read(TextureInfoPlatInfoPointer + 0x10 + j * 0x08 + 0x07, "<B");
						};
						
						--ImageInfo.Is32BitSwizzled	= (ImageInfo.Is32BitSwizzled == 0x01);
						
						table.insert(TextureInfoPlatInfo.ImageInfos, ImageInfo);
					end;
					
					print(string.format("%s", ModelulatorEnum.PixelStorageMode:GetEnumFromValue(TextureInfoPlatInfo.PixelStorageMode) or TextureInfoPlatInfo.PixelStorageMode));
					
					TextureInfoPlatInfo.PixelStorageMode		= ModelulatorEnum.PixelStorageMode:GetEnumFromValue(TextureInfoPlatInfo.PixelStorageMode);
					TextureInfoPlatInfo.ClutPixelStorageMode	= ModelulatorEnum.PixelStorageMode:GetEnumFromValue(TextureInfoPlatInfo.ClutPixelStorageMode);
					
					table.insert(eTexturePack.TextureInfoPlatInfoTable, TextureInfoPlatInfo);
					
					TextureInfoPlatInfoPointer	= TextureInfoPlatInfoPointer + 0x54;
				end;
			end;
			
			local function UnpackTextures()
				local eTexturePackDataPointer	= bChunk.Address + 0x08;
				local eTexturePackDataSize	= bChunk.Size;
				
				local AlignDiff0		= bChunk:Align(0x80);
				bChunk.Address			= bChunk.Address - 0x08 - AlignDiff0;
				
				eTexturePackDataPointer		= eTexturePackDataPointer + AlignDiff0;
				eTexturePackDataSize		= eTexturePackDataSize - AlignDiff0;
				
				local file_output		= {};
				
				local eTextureInfoLast		= {};
				
				local SectionName		= (_ENV.Stream.CurrentSection ~= "") and _ENV.Stream.CurrentSection or eTexturePack.Header.Name;
				
				local eTextureInfoJSON		= {};
				
				for i = 1, #eTexturePack.TextureHashTable do
					local NameHash			= eTexturePack.TextureHashTable[i].NameHash;
					local eTextureInfo		= eTexturePack.TextureInfoTable[eTexturePack.TextureHashTable[i].pTextureInfo];
					local eTexturePlatInfo		= eTexturePack.TextureInfoPlatInfoTable[eTexturePack.TextureHashTable[i].pTextureInfo];
					
					local ImageCompressionType	= eTextureInfo.ImageCompressionType;
					local PaletteCompressionType	= eTextureInfo.PaletteCompressionType;
					
					if (_ENV.Config.Pipeline == ModelulatorEnum.Pipeline.PSX2) then
						print(string.format("eTexture_0x%08X\n\tImage:      0x%08X, %s;\n\tPalette:    0x%08X, %s;\n\tIsSwizzled: %s;\n\tResolution: %i x %i;\n\tAlphaUsage: %s;\n\tAlphaBlend: %s;\n\tScrollType: %s;\n\tScrollSpeedS:   %i;\n\tScrollSpeedT:   %i;", NameHash, eTextureInfo.ImagePlacement + eTexturePackDataPointer, ImageCompressionType.Name, eTextureInfo.PalettePlacement + eTexturePackDataPointer, PaletteCompressionType.Name, tostring(eTexturePlatInfo.ImageInfos[1].Is32BitSwizzled), eTextureInfo.Width, eTextureInfo.Height, eTextureInfo.AlphaUsageType.Name, eTextureInfo.AlphaBlendType.Name, eTextureInfo.ScrollType, eTextureInfo.ScrollSpeedS, eTextureInfo.ScrollSpeedT));
					else
						print(string.format("eTexture_0x%08X\n\tImage:      0x%08X, %s;\n\tPalette:    0x%08X, %s;\n\tIsSwizzled: %s;\n\tResolution: %i x %i;\n\tAlphaUsage: %s;\n\tAlphaBlend: %s;\n\tScrollType: %s;\n\tScrollSpeedS:   %i;\n\tScrollSpeedT:   %i;", NameHash, eTextureInfo.ImagePlacement + eTexturePackDataPointer, ImageCompressionType.Name, eTextureInfo.PalettePlacement + eTexturePackDataPointer, PaletteCompressionType.Name, tostring(true), eTextureInfo.Width, eTextureInfo.Height, eTextureInfo.AlphaUsageType.Name, eTextureInfo.AlphaBlendType.Name, eTextureInfo.ScrollType, eTextureInfo.ScrollSpeedS, eTextureInfo.ScrollSpeedT));
					end
					
					local TextureName		= string.format("0x%08X.TPK0x%08X.%s.%s", eTextureInfo.NameHash, eTexturePack.DataHash, SectionName, eTextureInfo.Name);
					
					table.insert(eTextureHashList, TextureName);
					table.insert(eTextureInfoJSON, string.format("{\"Texture\":%q,\"AlphaUsage\":%q,\"AlphaBlend\":%q}", TextureName .. ".png", eTextureInfo.AlphaUsageType.Name, eTextureInfo.AlphaBlendType.Name));
					
					local CLUTData		= "";
					local TextureData	= "";
					
					local BGRA32ImageData		= {};
					
					if (_ENV.Config.Pipeline == ModelulatorEnum.Pipeline.PSX2) then
						TextureData		= texture.PSX2:Get(eTexturePackDataPointer, eTextureInfo, eTexturePlatInfo);
						
						if (TextureData[1] == nil) then
							print(string.format("0x%08X", eTexturePackDataPointer));
						end;
						
						TextureData		= table.concat(TextureData, "");
						--BGRA32ImageData		= TextureData;
						
					elseif (_ENV.Config.Pipeline == ModelulatorEnum.Pipeline.GAMECUBE) then
						TextureData		= texture.GAMECUBE:Get(eTextureInfo.ImagePlacement + eTexturePackDataPointer, eTextureInfo.PalettePlacement + eTexturePackDataPointer, eTextureInfo.ImageCompressionType, eTextureInfo.Width, eTextureInfo.Height, eTextureInfo.AlphaUsageType, eTextureInfo.AlphaBlendType, eTextureInfoLast.AlphaUsageType, eTextureInfoLast.AlphaBlendType);
						--BGRA32ImageData		= TextureData;
						
						if (eTextureInfo.ImageCompressionType ~= ModelulatorEnum.TextureCompressionType.Tex8Bit) then
							eTextureInfoLast	= eTexturePack.TextureInfoTable[eTexturePack.TextureHashTable[i].pTextureInfo];
						end;
						
						--eTextureInfoLast	= eTexturePack.TextureInfoTable[eTexturePack.TextureHashTable[i].pTextureInfo];
					elseif (_ENV.Config.Pipeline == ModelulatorEnum.Pipeline.REVOLUTION) then
						TextureData		= texture.REVOLUTION:Get(eTextureInfo.ImagePlacement + eTexturePackDataPointer, eTextureInfo.PalettePlacement + eTexturePackDataPointer, eTextureInfo.ImageCompressionType, eTextureInfo.Width, eTextureInfo.Height, eTextureInfo.AlphaUsageType, eTextureInfo.AlphaBlendType, eTextureInfoLast.AlphaUsageType, eTextureInfoLast.AlphaBlendType);
						--BGRA32ImageData		= TextureData;
						
						if (eTextureInfo.ImageCompressionType ~= ModelulatorEnum.TextureCompressionType.Tex8Bit) then
							eTextureInfoLast	= eTexturePack.TextureInfoTable[eTexturePack.TextureHashTable[i].pTextureInfo];
						end;
					end;
					
					local dib_size			= 0x6C;
					local dib_width			= eTextureInfo.Width;
					local dib_height		= eTextureInfo.Height;
					local dib_numcolourplanes	= 0x0001;
					local dib_bpp			= 0x0020;
					local dib_pxarraycomp		= 0x00000003;
					local dib_rawsize		= (#TextureData);
					local dib_printwidth		= 0x00000000;
					local dib_printheight		= 0x00000000;
					local dib_numcolours		= 0x00000000;
					local dib_numicolours		= 0x00000000;
					local dib_mask_r		= 0x00FF0000;
					local dib_mask_g		= 0x0000FF00;
					local dib_mask_b		= 0x000000FF;
					local dib_mask_a		= 0xFF000000;
					local dib_lcs			= 0x73524742;
					local dib_gamma_r		= 0x00000000;
					local dib_gamma_g		= 0x00000000;
					local dib_gamma_b		= 0x00000000;
					
					local bmp_magic			= 0x4D42;
					local bmp_size			= 0x0E + dib_size + (#TextureData);
					local bmp_reserved		= 0x00000000;
					local bmp_indexoffset		= 0x0E + dib_size;
					
					local bmp_header		= string.pack("<H i4 I4 i4", bmp_magic, bmp_size, bmp_reserved, bmp_indexoffset);
					local dib_header		= string.pack("<i4 i4 i4 h h I4 i4 i4 i4 i4 i4 I4 I4 I4 I4 I4 xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx I4 I4 I4", dib_size, dib_width, dib_height, dib_numcolourplanes, dib_bpp, dib_pxarraycomp, dib_rawsize, dib_printwidth, dib_printheight, dib_numcolours, dib_numicolours, dib_mask_r, dib_mask_g, dib_mask_b, dib_mask_a, dib_lcs, dib_gamma_r, dib_gamma_g, dib_gamma_b);
					
					local bmp_data			= bmp_header .. dib_header .. TextureData;
					
					table.insert(file_output, {FileName = TextureName, FileType = "bmp"; Data = bmp_data});
				end;
				
				table.insert(FileOutputInventory.Textures, file_output);
				
				eTexturePackInfoJSON	= string.format("{\"Name\":%q,\"FileName\":%q,\"eTextureInfoList\":[%s]}", eTexturePack.Header.Name, eTexturePack.Header.FileName, table.concat(eTextureInfoJSON, ","));
				
				if (#eTextureHashList > 0) then
					table.insert(FileOutputInventory.Textures, {{FileName = string.format("eTexturePack.TPK0x%08X.%s", eTexturePack.DataHash, SectionName), FileType = "dae"; Data = dae:new_texturepack(eTextureHashList)}});
					table.insert(FileOutputInventory.Textures, {{FileName = string.format("eTexturePackInfo.TPK0x%08X.%s", eTexturePack.DataHash, SectionName), FileType = "json"; Data = eTexturePackInfoJSON}});
					eTextureHashList	= {};
				end;
			end;
			
			local function HandleTexturesA()
				local TempResourceFile		= PhilLip2:CreateFile(ModelulatorTempPath());
				TempResourceFile:Open("Write + (Binary)");
				
				local eTexturePackDataPointer	= (bChunk.Address + 0x08 + 0x7F) & -0x80;
				
				local DoSwap			= (#eTexturePack.StreamTable > 0);
				
				if (#eTexturePack.StreamTable > 0) then
					local BCHUNK_COMPRESS_IN_PLACE_MAGIC	= 0x55441122;
					local TempPointer			= eTexturePackDataPointer + 0x00;
					
					--print(string.format("0x%08X", eTexturePackDataPointer));
					
					local Pointers		= {};
					local NewPointer	= 0x00000000;
					
					local function ReadDecompressedTextureInfo(StreamTableEntry)
						local InfoTablePointer		= NewPointer + StreamTableEntry.UncompSize - 0x000000D0;
						
						--print(string.format("0x%08X", InfoTablePointer));
						
						local eTextureInfo			= {};
						
						if (_ENV.Config.Game.Value <= ModelulatorEnum.Game.MOSTWANTED.Value) then
							eTextureInfo	=
							{
								Name			= "";
								NameHash		= TempResourceFile:Read(InfoTablePointer + 0x24, "<I4");
								ClassNameHash		= TempResourceFile:Read(InfoTablePointer + 0x28, "<I4");
								ImagePlacement		= TempResourceFile:Read(InfoTablePointer + 0x30, "<i4");
								PalettePlacement	= TempResourceFile:Read(InfoTablePointer + 0x34, "<i4");
								ImageSize		= TempResourceFile:Read(InfoTablePointer + 0x38, "<i4");
								PaletteSize		= TempResourceFile:Read(InfoTablePointer + 0x3C, "<i4");
								BaseImageSize		= TempResourceFile:Read(InfoTablePointer + 0x40, "<i4");
								Width			= TempResourceFile:Read(InfoTablePointer + 0x44, "<h");
								Height			= TempResourceFile:Read(InfoTablePointer + 0x46, "<h");
								ShiftWidth		= TempResourceFile:Read(InfoTablePointer + 0x48, "<B");
								ShiftHeight		= TempResourceFile:Read(InfoTablePointer + 0x49, "<B");
								ImageCompressionType	= TempResourceFile:Read(InfoTablePointer + 0x4A, "<B");
								PaletteCompressionType	= TempResourceFile:Read(InfoTablePointer + 0x4B, "<B");
								NumPaletteEntries	= TempResourceFile:Read(InfoTablePointer + 0x4C, "<h");
								NumMipMapLevels		= TempResourceFile:Read(InfoTablePointer + 0x4E, "<b");
								TilableUV		= TempResourceFile:Read(InfoTablePointer + 0x4F, "<b");
								BiasLevel		= TempResourceFile:Read(InfoTablePointer + 0x50, "<b");
								RenderingOrder		= TempResourceFile:Read(InfoTablePointer + 0x51, "<b");
								ScrollType		= TempResourceFile:Read(InfoTablePointer + 0x52, "<b");
								UsedFlag		= TempResourceFile:Read(InfoTablePointer + 0x53, "<b");
								ApplyAlphaSorting	= TempResourceFile:Read(InfoTablePointer + 0x54, "<b");
								AlphaUsageType		= TempResourceFile:Read(InfoTablePointer + 0x55, "<b");
								AlphaBlendType		= TempResourceFile:Read(InfoTablePointer + 0x56, "<b");
								Flags			= TempResourceFile:Read(InfoTablePointer + 0x57, "<B");
								ScrollTimeStep		= TempResourceFile:Read(InfoTablePointer + 0x58, "<h");
								ScrollSpeedS		= TempResourceFile:Read(InfoTablePointer + 0x5A, "<h");
								ScrollSpeedT		= TempResourceFile:Read(InfoTablePointer + 0x5C, "<h");
								OffsetS			= TempResourceFile:Read(InfoTablePointer + 0x5E, "<h");
								OffsetT			= TempResourceFile:Read(InfoTablePointer + 0x60, "<h");
								ScaleS			= TempResourceFile:Read(InfoTablePointer + 0x62, "<h");
								ScaleT			= TempResourceFile:Read(InfoTablePointer + 0x64, "<h");
							};
							
							eTextureInfo.Name	= TempResourceFile:Read(InfoTablePointer + 0x0C, "<c24");
						else
							eTextureInfo	=
							{
								NameHash		= TempResourceFile:Read(InfoTablePointer + 0x0C, "<I4");
								ClassNameHash		= TempResourceFile:Read(InfoTablePointer + 0x10, "<I4");
								ImagePlacement		= TempResourceFile:Read(InfoTablePointer + 0x14, "<i4");
								PalettePlacement	= TempResourceFile:Read(InfoTablePointer + 0x18, "<i4");
								ImageSize		= TempResourceFile:Read(InfoTablePointer + 0x1C, "<i4");
								PaletteSize		= TempResourceFile:Read(InfoTablePointer + 0x20, "<i4");
								BaseImageSize		= TempResourceFile:Read(InfoTablePointer + 0x24, "<i4");
								Width			= TempResourceFile:Read(InfoTablePointer + 0x28, "<h");
								Height			= TempResourceFile:Read(InfoTablePointer + 0x2A, "<h");
								ShiftWidth		= TempResourceFile:Read(InfoTablePointer + 0x2C, "<B");
								ShiftHeight		= TempResourceFile:Read(InfoTablePointer + 0x2D, "<B");
								ImageCompressionType	= TempResourceFile:Read(InfoTablePointer + 0x2E, "<B");
								PaletteCompressionType	= TempResourceFile:Read(InfoTablePointer + 0x2F, "<B");
								NumPaletteEntries	= TempResourceFile:Read(InfoTablePointer + 0x30, "<h");
								NumMipMapLevels		= TempResourceFile:Read(InfoTablePointer + 0x32, "<b");
								TilableUV		= TempResourceFile:Read(InfoTablePointer + 0x33, "<b");
								BiasLevel		= TempResourceFile:Read(InfoTablePointer + 0x34, "<b");
								RenderingOrder		= TempResourceFile:Read(InfoTablePointer + 0x35, "<b");
								ScrollType		= TempResourceFile:Read(InfoTablePointer + 0x36, "<b");
								UsedFlag		= TempResourceFile:Read(InfoTablePointer + 0x37, "<b");
								ApplyAlphaSorting	= TempResourceFile:Read(InfoTablePointer + 0x38, "<b");
								AlphaUsageType		= TempResourceFile:Read(InfoTablePointer + 0x39, "<b");
								AlphaBlendType		= TempResourceFile:Read(InfoTablePointer + 0x3A, "<b");
								Flags			= TempResourceFile:Read(InfoTablePointer + 0x3B, "<B");
								ScrollTimeStep		= TempResourceFile:Read(InfoTablePointer + 0x3C, "<h");
								ScrollSpeedS		= TempResourceFile:Read(InfoTablePointer + 0x3E, "<h");
								ScrollSpeedT		= TempResourceFile:Read(InfoTablePointer + 0x40, "<h");
								OffsetS			= TempResourceFile:Read(InfoTablePointer + 0x42, "<h");
								OffsetT			= TempResourceFile:Read(InfoTablePointer + 0x44, "<h");
								ScaleS			= TempResourceFile:Read(InfoTablePointer + 0x46, "<h");
								ScaleT			= TempResourceFile:Read(InfoTablePointer + 0x48, "<h");
								
								NameLength		= TempResourceFile:Read(InfoTablePointer + 0x58, "<B");
								Name			= "";
							};
							
							eTextureInfo.Name		= TempResourceFile:Read(InfoTablePointer + 0x59, "<c" .. eTextureInfo.NameLength);
							
							eTextureInfo.ScrollType		= 0;
							eTextureInfo.ScrollSpeedS	= 0;
							eTextureInfo.ScrollSpeedT	= 0;
						end;
						
						if (ModelulatorEnum.TextureCompressionType:GetEnumFromValue(eTextureInfo.ImageCompressionType) == nil) then
							print(string.format("0x%02X", eTextureInfo.ImageCompressionType));
						end;
						
						eTextureInfo.ImageCompressionType	= ModelulatorEnum.TextureCompressionType:GetEnumFromValue(eTextureInfo.ImageCompressionType);
						eTextureInfo.PaletteCompressionType	= ModelulatorEnum.TextureCompressionType:GetEnumFromValue(eTextureInfo.PaletteCompressionType);
						eTextureInfo.AlphaUsageType		= ModelulatorEnum.TextureAlphaUsageType:GetEnumFromValue(eTextureInfo.AlphaUsageType or 0);
						eTextureInfo.AlphaBlendType		= ModelulatorEnum.TextureAlphaBlendType:GetEnumFromValue(eTextureInfo.AlphaBlendType or 0);
						
						eTextureInfo.Name			= string.gsub(eTextureInfo.Name, "\x00", "");
						
						table.insert(eTexturePack.TextureInfoTable, eTextureInfo);
						
						local TextureInfoPlatInfoPointer	= InfoTablePointer + 0x0000007C;
						
						local TextureInfoPlatInfo	=
						{
							ImageVramBlocksRequired		= TempResourceFile:Read(TextureInfoPlatInfoPointer + 0x00, "<H");
							PaletteVramBlocksRequired	= TempResourceFile:Read(TextureInfoPlatInfoPointer + 0x02, "<H");
							PixelStorageMode		= TempResourceFile:Read(TextureInfoPlatInfoPointer + 0x04, "<B");
							ClutPixelStorageMode		= TempResourceFile:Read(TextureInfoPlatInfoPointer + 0x05, "<B");
							TextureFx			= TempResourceFile:Read(TextureInfoPlatInfoPointer + 0x06, "<B");
							AlphaBits			= TempResourceFile:Read(TextureInfoPlatInfoPointer + 0x07, "<B");
							AlphaFix			= TempResourceFile:Read(TextureInfoPlatInfoPointer + 0x08, "<B");
							MMag				= TempResourceFile:Read(TextureInfoPlatInfoPointer + 0x09, "<B");
							MMin				= TempResourceFile:Read(TextureInfoPlatInfoPointer + 0x0A, "<B");
							MipMapL				= TempResourceFile:Read(TextureInfoPlatInfoPointer + 0x0B, "<B");
							MipMapK				= TempResourceFile:Read(TextureInfoPlatInfoPointer + 0x0C, "<H");
							AlphaUsage			= TempResourceFile:Read(TextureInfoPlatInfoPointer + 0x0E, "<B");
							Special				= TempResourceFile:Read(TextureInfoPlatInfoPointer + 0x0F, "<B");
							ImageInfos			= {};
						};
						
						for j = 0, 6 do
							local ImageInfo				=
							{
								Width				= TempResourceFile:Read(TextureInfoPlatInfoPointer + 0x10 + j * 0x08 + 0x00, "<H");
								Height				= TempResourceFile:Read(TextureInfoPlatInfoPointer + 0x10 + j * 0x08 + 0x02, "<H");
								TextureBasePointerOffset	= TempResourceFile:Read(TextureInfoPlatInfoPointer + 0x10 + j * 0x08 + 0x04, "<H");
								TextureBufferWidth		= TempResourceFile:Read(TextureInfoPlatInfoPointer + 0x10 + j * 0x08 + 0x06, "<B");
								Is32BitSwizzled			= TempResourceFile:Read(TextureInfoPlatInfoPointer + 0x10 + j * 0x08 + 0x07, "<B");
							};
							
							--ImageInfo.Is32BitSwizzled		= (ImageInfo.Is32BitSwizzled == 0x01);
							
							table.insert(TextureInfoPlatInfo.ImageInfos, ImageInfo);
						end;
						
						TextureInfoPlatInfo.PixelStorageMode		= ModelulatorEnum.PixelStorageMode:GetEnumFromValue(TextureInfoPlatInfo.PixelStorageMode);
						TextureInfoPlatInfo.ClutPixelStorageMode	= ModelulatorEnum.PixelStorageMode:GetEnumFromValue(TextureInfoPlatInfo.ClutPixelStorageMode);
						
						table.insert(eTexturePack.TextureInfoPlatInfoTable, TextureInfoPlatInfo);
					end;
					
					for i = 1, #eTexturePack.StreamTable do
						table.insert(Pointers, TempPointer + 0x00000000);
						
						local TempSize		= 0x00000000;
						local StreamTableEntry	= eTexturePack.StreamTable[i];
						
						TempResourceFile:Write(~-TempPointer, "x", 0x00);
						
						if (StreamTableEntry.Flags & 0x00000300 <= 0x00000000) then
							local Data	= PhilLip.file_create();
							Data.content	= {ResourceFile:Read(StreamTableEntry.DataPointer, StreamTableEntry.DataSize)};
							Data.size	= #Data.content;
							
							TempResourceFile:Write(0x00000000, Data);
							TempPointer	= (TempPointer + Data.size + 0x0000007F) & -0x00000080;
							TempSize	= TempSize + UCompData.size;
							
							Data:close();
						elseif (StreamTableEntry.Flags & 0x00000300 > 0x00000000) then
							TempPointer	= StreamTableEntry.DataPointer + 0x00000000;
							
							if (StreamTableEntry.Flags & 0x00000300 == 0x00000100) then
								local UCompData		= Decompress(TempPointer + 0x00000000);
								
								TempResourceFile:Write(NewPointer + 0x00000000, UCompData);
								
								TempPointer		= (TempPointer + UCompData.size + 0x0000007F) & -0x00000080;
								TempSize		= TempSize + UCompData.size;
								
								UCompData:close();
							elseif (StreamTableEntry.Flags & 0x00000300 == 0x00000200) then
								while (TempPointer < (StreamTableEntry.DataPointer + StreamTableEntry.DataSize)) do
									local ID			= ResourceFile:Read(StreamTableEntry.DataPointer + 0x00000000, "<I4");
									
									if (ID == BCHUNK_COMPRESS_IN_PLACE_MAGIC) then
										local UCompSize		= ResourceFile:Read(TempPointer + 0x00000004, "<I4");
										local RawSize		= ResourceFile:Read(TempPointer + 0x00000008, "<I4");
										local UCompAddress	= ResourceFile:Read(TempPointer + 0x0000000C, "<I4");
										local RawAddress	= ResourceFile:Read(TempPointer + 0x00000010, "<I4");
										local Unk00		= ResourceFile:Read(TempPointer + 0x00000014, "<I4");
										
										--TempResourceFile:Write(~-(UCompAddress + UCompSize), "x", 0x00);
										
										local UCompData		= Decompress(TempPointer + 0x00000018);
										
										print(string.format("0x%08X 0x%08X // 0x%08X | 0x%08X", UCompAddress, UCompSize, TempResourceFile.Size, UCompData.size));
										
										TempResourceFile:Write(NewPointer + UCompAddress, UCompData);
										UCompData:close();
										
										TempPointer		= TempPointer + RawSize;
										TempSize		= TempSize + UCompSize;
									else
										print("no compress in place marker found!");
										break;
									end;
								end;
							end;
						end;
						
						local TextureHashIndex		= FastHash[StreamTableEntry.NameHash];
						local TextureHash		= eTexturePack.TextureHashTable[TextureHashIndex];
						
						local ObjectOffsets		= NewPointer - eTexturePackDataPointer;
						
						if (TextureHash.pTextureInfo < 0) then
							ReadDecompressedTextureInfo(StreamTableEntry);
							TextureHash.pTextureInfo	= #eTexturePack.TextureInfoTable;
						end;
						
						local eTextureInfo		= eTexturePack.TextureInfoTable[TextureHash.pTextureInfo];
						
						if (eTextureInfo.PalettePlacement > eTextureInfo.ImagePlacement) then
							ObjectOffsets		= ObjectOffsets - eTextureInfo.ImagePlacement;
						else
							ObjectOffsets		= ObjectOffsets - eTextureInfo.PalettePlacement;
						end;
						
						eTextureInfo.PalettePlacement		= eTextureInfo.PalettePlacement + ObjectOffsets;
						eTextureInfo.ImagePlacement	= eTextureInfo.ImagePlacement + ObjectOffsets;
						
						eTexturePack.TextureInfoTable[TextureHash.pTextureInfo]	= eTextureInfo;
						eTexturePack.TextureHashTable[TextureHashIndex]		= TextureHash;
						
						NewPointer				= NewPointer + TempSize;
					end;
					
					--[[
					for i = 1, #Pointers do
						local Pointer		= Pointers[i];
						local TexturePointer	= eTexturePack.TextureInfoTable[i].ImagePlacement;
						print(string.format("0x%08X 0x%08X", Pointers[i] - eTexturePackDataPointer, TexturePointer));
					end;
					
					local AlignedPointer	= (TempPointer + 0x08 + 0x0FFF) & -0x1000;
					local PaddedSize	= (AlignedPointer - TempPointer) - 0x08;
					
					TempResourceFile:Write(TempPointer, "<I4<i4", 0x00000000, PaddedSize);
					TempResourceFile:Write(TempPointer + 0x08, string.rep("x", PaddedSize), 0x00);
					--]]
					
					TempPointer		= AlignedPointer;
				end;
				
				if (DoSwap) then
					ResourceFile, TempResourceFile = TempResourceFile, ResourceFile;
				end;
				
				--if (_ENV.Config.Pipeline == ModelulatorEnum.Pipeline.PSX2) then
					UnpackTextures();
				--end;
				
				if (DoSwap) then
					ResourceFile, TempResourceFile = TempResourceFile, ResourceFile;
				end;
				
				TempResourceFile:Close();
				
				os.remove(TempResourceFile.Directory);
			end;
			
			if (_ENV.Config.Game.Value > ModelulatorEnum.Game.UNDERGROUND2.Value) then
				if (bChunk.ID == 0xB3320000) then
					bChunk.Address = bChunk.Address + 0x08;
				end;
				
				if (bChunk.ID == 0x33320002) then
					HandleTexturesA();
				end;
			elseif (_ENV.Config.Game.Value >= ModelulatorEnum.Game.UNDERGROUND.Value) then
				if (bChunk.ID == 0xB3320000) then
					bChunk.Address = bChunk.Address + 0x08;
				end;
				
				if (bChunk.ID == 0x33320002) then
					HandleTexturesA();
				end;
			else
				--print("Test");
				
				if (bChunk.ID == 0x33320001) then
					HandleTexturesA();
				end;
			end;
			
			bChunk:Next();
		end;
		
		bChunk.Address = ReturnAddress;
		
		return true;
	else
		return false;
	end;
end;

return Loader_eTexturePack;