local program		= {};

---[[
require("src.util.bitwise");

_ENV.VIFcode		= require("src.util.VIFcode");
_ENV.PhilLip		= require("src.util.lib.phillip");		PhilLip:initialize();
_ENV.PhilLip2		= require("src.util.lib.PhilLip2");
--_ENV.bChunk		= require("src.util.legacy.ea_bchunk");
--_ENV.bHash		= require("src.util.legacy.ea_hash");
_ENV.Cleanums		= require("src.util.lib.cleanums");

_ENV.texture		= require("src.texture");
_ENV.dae		= require("src.dataformats.dae");

_ENV.xSolid		= require("src.util.xSolid.init");
_ENV.PlatChunks		= require("src.loaders.PlatChunksMain");

require("src.util.maths");
---]]

_ENV.Decompress		= require("src.util.decompress");
_ENV.ProgramInfo	= require("src.info");

-- Per-process temp root. Parallel launcher sets MODELULATOR_TEMP_DIR so
-- simultaneous Modelulator instances never share decompression scratch files.
_ENV.ModelulatorTempDirectory = os.getenv("MODELULATOR_TEMP_DIR") or ".\\temp";

_ENV.ModelulatorTempPath = function()
	local TempName = os.tmpname();
	TempName = string.match(TempName, "[^\\/]+$") or TempName;
	return string.format("%s\\%s", ModelulatorTempDirectory, TempName);
end;

_ENV.ModelulatorEnum	= Cleanums.new("ModelulatorEnum");
ModelulatorEnum:Add("Pipeline");
ModelulatorEnum:Add("Endian");
ModelulatorEnum:Add("Game");
ModelulatorEnum:Add("TextureCompressionType");
ModelulatorEnum:Add("TextureAlphaUsageType");
ModelulatorEnum:Add("TextureAlphaBlendType");
ModelulatorEnum:Add("PixelStorageMode");
ModelulatorEnum:Add("TextureFX");

ModelulatorEnum:Add("NavigationType");
ModelulatorEnum:Add("PathType");
ModelulatorEnum:Add("LaneType");

local function ParseEnumTable(__inout_Cleanum__EnumType, __enum__EnumTable)
	_ENV.__inout_Cleanum__EnumType = __inout_Cleanum__EnumType;
	
	local kvArray	= {};
	for k, v in pairs(__enum__EnumTable) do
		table.insert(kvArray, {tostring(k), tonumber(v)});
	end;
	
	local function vSort(a, b) return a[2] < b[2]; end;
	
	table.sort(kvArray, vSort);
	
	for _, kvItem in ipairs(kvArray) do
		_ENV.__inout_Cleanum__EnumType:Add(kvItem[1], kvItem[2]);
	end;
	
	_ENV.__inout_Cleanum__EnumType = nil;
	
	return;
end;

local __enum__Pipeline	=
{
	NONE		= -1;
	PSX		= 0;
	PSX2		= 1;
	GAMECUBE	= 2;
	XBOX		= 3;
	XENON		= 4;
	PC		= 5;
	REVOLUTION	= 6;
	PS3		= 7;
};

local __enum__Endian	=
{
	Little		= -1;
	Native		= 0;
	Big		= 1;
};

local __enum__Game	=
{
	NONE			= -1;
	NASCAR2001		= 0;	-- not a nfs game, but its a black box game so it gets to be here
	NASCARTHUNDER2002	= 1;	-- not a nfs game, but its a black box game so it gets to be here
	NASCARTHUNDER2003	= 2;	-- technically not a black box game, but it stems from NASCAR: Thunder 2002 which is a black box game so it gets to be here
	NASCARTHUNDER2004	= 3;	-- same situation as NASCAR: Thunder 2003, but i especially added it here cos the soundtrack had Three Days Grace which i found out more recently is a canadian band - interesting stuff!
	HOTPURSUIT2_A098	= 4;
	HOTPURSUIT2		= 5;
	UNDERGROUNDPROTO	= 6;
	UNDERGROUND		= 7;
	UNDERGROUND2		= 8;
	MOSTWANTED_DEMO		= 9;
	MOSTWANTED		= 10;
	CARBON			= 11;
	PROSTREET		= 12;
	NITRO			= 13;
	UNDERCOVER		= 14;	-- Wii version requires attention
	WORLD			= 15;
	--THERUN		= 16;	-- perhaps another time, felipe wants his cars
};

local __enum__TextureCompressionType	=
{
	Default			= 0x00;
	
	Tex4Bit			= 0x04;
	Tex8Bit			= 0x08;
	Tex16Bit		= 0x10;
	Tex24Bit		= 0x18;
	Tex32Bit		= 0x20;
	
	DXT			= 0x21;
	--S3TC			= 0x22;
	DXTC1			= 0x22;
	DXTC3			= 0x24;
	DXTC5			= 0x26;
	DXTN			= 0x27;
	L8			= 0x28;
	DXTC1_AIR		= 0x29;
	DXTC1_AIG		= 0x2A;
	DXTC1_AIB		= 0x2B;
	
	Tex16Bit_1555		= 0x11;
	Tex16Bit_565		= 0x12;
	--Tex16Bit_3555		= 0x13;	--# ???????????????
	
	I4			= 0x28;
	IA4			= 0x2C;
	
	I8			= 0x50;
	IA8			= 0x58;
	
	Tex8Bit_16		= 0x80;
	Tex8Bit_64		= 0x81;
	Tex8Bit_IA8		= 0x82;
	Tex4Bit_IA8		= 0x83;
	
	Tex4Bit_RGB24_A8	= 0x8C;
	Tex8Bit_RGB24_A8	= 0x8D;
	Tex4Bit_RGB16_A8	= 0x8E;
	Tex8Bit_RGB16_A8	= 0x8F;
	Tex8Bit_RGB16_A8_2	= 0x9F;
};

local function EncodePSM(Mod, Idx, Flg)
	local Result	= 0;
	
	Flg		= ((type(Flg) == "number") and (Flg ~= 0) or Flg) and 1 or 0;
	
	Result		= Result | AdjustWithMask(Idx, 3, 0, 0);
	Result		= Result | AdjustWithMask(Mod, 2, 0, 4);
	Result		= Result | AdjustWithMask(Flg, 1, 0, 3);
	
	return Result;
end;

--# not sure when you'd use PS-GPU24 for something like this, but it's there in the GS User's Manual
local __enum__PixelStorageMode	=
{
	PSMZ32			= EncodePSM(-1, 0, false);
	PSMZ24			= EncodePSM(-1, 1, false);
	PSMZ16			= EncodePSM(-1, 2, false);
	PSMZ16S			= EncodePSM(-1, 2, true);
	
	PSMCT32			= EncodePSM(0, 0, false);
	PSMCT24			= EncodePSM(0, 1, false);
	PSMCT16			= EncodePSM(0, 2, false);
	PSMCT16S		= EncodePSM(0, 2, true);
	
	PS_GPU24		= EncodePSM(1, 2, false);
	
	PSMT8			= EncodePSM(1, 3, false);
	PSMT8H			= EncodePSM(1, 3, true);
	
	PSMT4			= EncodePSM(1, 4, false);
	PSMT4HL			= EncodePSM(2, 4, false);
	PSMT4HH			= EncodePSM(2, 4, true);
};

local __enum__TextureFX		=
{
	Modulate		= 0;
	Decal			= 1;
	Highlight		= 2;
	Highlight2		= 3;
};

local __enum__TextureAlphaUsageType	=
{
	None			= 0;	-- AlphaTestEnable = FALSE; AlphaRef = 0x00; AlphaBlendEnable = FALSE;
	PunchThru		= 1;	-- AlphaTestEnable = TRUE; AlphaRef = 0x7F; AlphaBlendEnable = FALSE;
	Modulated		= 2;	-- AlphaTestEnable = FALSE;  AlphaRef = 0x00; AlphaBlendEnable = TRUE;
};

local __enum__TextureAlphaBlendType	=
{
	Default			= -1;
	SrcCopy			= 0;
	SrcBlend		= 1;
	SrcAdditive		= 2;
	SrcSubtractive		= 3;
	SrcOverbright		= 4;
	DestBlend		= 5;
	DestAdditive		= 6;
	DestSubtractive		= 7;
	DestOverbright		= 8;
};

local __enum__NavigationType	=
{
	None			= 0;
	Traffic			= 1;
	Highway			= 2;
	HighwayPattern		= 3;
	Direction		= 4;
	Path			= 5;
};

local __enum__PathType	=
{
	Cop			= 0;
	None			= 1; --# uh oh!!1!11!!! black box made a booboo!!1!1!!!11
	Racer			= 2;
	GPS			= 3;
	Player			= 4;
	Pathy			= 5;
	Chopper			= 6;
	RaceRoute		= 7;
	Traffic			= 8;
};

local __enum__LaneType		=
{
	Racing			= 0;
	Traffic			= 1;
	Drag			= 2;
	Cop			= 3;
	CopReckless		= 4;
	Reset			= 5;
	StartingGrid		= 6;
	Any			= 7;
	Max			= 8;
};

ParseEnumTable(ModelulatorEnum.Pipeline, __enum__Pipeline);
ParseEnumTable(ModelulatorEnum.Endian, __enum__Endian);
ParseEnumTable(ModelulatorEnum.Game, __enum__Game);
ParseEnumTable(ModelulatorEnum.TextureCompressionType, __enum__TextureCompressionType);
ParseEnumTable(ModelulatorEnum.TextureAlphaUsageType, __enum__TextureAlphaUsageType);
ParseEnumTable(ModelulatorEnum.TextureAlphaBlendType, __enum__TextureAlphaBlendType);
ParseEnumTable(ModelulatorEnum.PixelStorageMode, __enum__PixelStorageMode);
ParseEnumTable(ModelulatorEnum.TextureFX, __enum__TextureFX);
ParseEnumTable(ModelulatorEnum.NavigationType, __enum__NavigationType);
ParseEnumTable(ModelulatorEnum.PathType, __enum__PathType);
ParseEnumTable(ModelulatorEnum.LaneType, __enum__LaneType);

_ENV.Config		= {};
Config.Pipeline		= ModelulatorEnum.Pipeline.NONE;
Config.Game		= ModelulatorEnum.Game.NONE;
Config.BigEndian	= false;

_ENV.ResourceFile	= PhilLip2:CreateFile();
_ENV.TempResourceFile	= PhilLip2:CreateFile();

_ENV.CARP		= require("src.util.lib.CARP");

local function bStringHash(str)
	local Hash	= -1;
	
	for i = 1, #str do
		Hash = Hash * 0x21;
		Hash = Hash + string.byte(str, i, i);
	end;
	
	return Hash;
end;

local GamesArray	=
{
	{
		PublisherInfo		=
		{
			Publisher	= "Electronic Arts, Inc.";
			Label		= "EA Sports";
		};
		Developer		= "Black Box Games";
		Title			= "NASCAR 2001";
		Type			= ModelulatorEnum.Game.NASCAR2001;
		SupportedPipelines	=
		{
			ModelulatorEnum.Pipeline.PSX;
		};
	};
	{
		PublisherInfo		=
		{
			Publisher	= "Electronic Arts, Inc.";
			Label		= "EA Sports";
		};
		Developer		= "Black Box Games";
		Title			= "NASCAR Thunder 2002";
		Type			= ModelulatorEnum.Game.NASCARTHUNDER2002;
		SupportedPipelines	=
		{
			ModelulatorEnum.Pipeline.PSX;
		};
	};
	{
		PublisherInfo		=
		{
			Publisher	= "Electronic Arts, Inc.";
			Label		= "EA Sports";
		};
		Developer		= "Budcat Creations, LLC";
		Title			= "NASCAR Thunder 2003";
		Type			= ModelulatorEnum.Game.NASCARTHUNDER2003;
		SupportedPipelines	=
		{
			ModelulatorEnum.Pipeline.PSX;
		};
	};
	{
		PublisherInfo		=
		{
			Publisher	= "Electronic Arts, Inc.";
			Label		= "EA Sports";
		};
		Developer		= "EA Tiburon + Budcat Creations, LLC";
		Title			= "NASCAR Thunder 2004";
		Type			= ModelulatorEnum.Game.NASCARTHUNDER2004;
		SupportedPipelines	=
		{
			ModelulatorEnum.Pipeline.PSX;
		};
	};
	{
		PublisherInfo		=
		{
			Publisher	= "Electronic Arts, Inc.";
			Label		= "EA Games";
		};
		Developer		= "Black Box Games";
		Title			= "Need for Speed: Hot Pursuit 2";
		Type			= ModelulatorEnum.Game.HOTPURSUIT2;
		SupportedPipelines	=
		{
			ModelulatorEnum.Pipeline.PSX2;
		};
	};
	{
		PublisherInfo		=
		{
			Publisher	= "Electronic Arts, Inc.";
			Label		= "EA Games";
		};
		Developer		= "EA Black Box";
		Title			= "Need for Speed: Underground (Prototypes)";
		Type			= ModelulatorEnum.Game.UNDERGROUNDPROTO;
		SupportedPipelines	=
		{
			ModelulatorEnum.Pipeline.GAMECUBE;
			ModelulatorEnum.Pipeline.PSX2;
		};
	};
	{
		PublisherInfo		=
		{
			Publisher	= "Electronic Arts, Inc.";
			Label		= "EA Games";
		};
		Developer		= "EA Black Box";
		Title			= "Need for Speed: Underground";
		Type			= ModelulatorEnum.Game.UNDERGROUND;
		SupportedPipelines	=
		{
			ModelulatorEnum.Pipeline.GAMECUBE;
			ModelulatorEnum.Pipeline.PSX2;
		};
	};
	{
		PublisherInfo		=
		{
			Publisher	= "Electronic Arts, Inc.";
			Label		= "EA Games";
		};
		Developer		= "EA Black Box";
		Title			= "Need for Speed: Underground 2";
		Type			= ModelulatorEnum.Game.UNDERGROUND2;
		SupportedPipelines	=
		{
			ModelulatorEnum.Pipeline.GAMECUBE;
			ModelulatorEnum.Pipeline.PSX2;
		};
	};
	{
		PublisherInfo		=
		{
			Publisher	= "Electronic Arts, Inc.";
			Label		= "EA Games";
		};
		Developer		= "EA Black Box";
		Title			= "Need for Speed: Most Wanted (2005)";
		Type			= ModelulatorEnum.Game.MOSTWANTED;
		SupportedPipelines	=
		{
			ModelulatorEnum.Pipeline.PSX2;
		};
	};
	{
		PublisherInfo		=
		{
			Publisher	= "Electronic Arts, Inc.";
			Label		= "EA Games";
		};
		Developer		= "EA Black Box";
		Title			= "Need for Speed: Carbon";
		Type			= ModelulatorEnum.Game.CARBON;
		SupportedPipelines	=
		{
			ModelulatorEnum.Pipeline.PSX2;
		};
	};
	{
		PublisherInfo		=
		{
			Publisher	= "Electronic Arts, Inc.";
			Label		= "EA Games";
		};
		Developer		= "EA Black Box";
		Title			= "Need for Speed: ProStreet";
		Type			= ModelulatorEnum.Game.PROSTREET;
		SupportedPipelines	=
		{
			ModelulatorEnum.Pipeline.PSX2;
		};
	};
	{
		PublisherInfo		=
		{
			Publisher	= "Electronic Arts, Inc.";
			Label		= "EA Games";
		};
		Developer		= "EA Black Box";
		Title			= "Need for Speed: ProStreet";
		Type			= ModelulatorEnum.Game.PROSTREET;
		SupportedPipelines	=
		{
			ModelulatorEnum.Pipeline.PSX2;
		};
	};
	{
		PublisherInfo		=
		{
			Publisher	= "Electronic Arts, Inc.";
			Label		= "EA Games";
		};
		Developer		= "EA Montreal";
		Title			= "Need for Speed: Nitro";
		Type			= ModelulatorEnum.Game.NITRO;
		SupportedPipelines	=
		{
			ModelulatorEnum.Pipeline.REVOLUTION;
		};
	};
	{
		PublisherInfo		=
		{
			Publisher	= "Electronic Arts, Inc.";
			Label		= "EA Games";
		};
		Developer		= "EA Black Box";
		Title			= "Need for Speed: Undercover";
		Type			= ModelulatorEnum.Game.UNDERCOVER;
		SupportedPipelines	=
		{
			ModelulatorEnum.Pipeline.PSX2;
		};
	};
};

local PipelinesArray	=
{
	{
		Developer	= "None";
		PlatformName	= "None";
		MinGeneration	= 0;
		Type		= ModelulatorEnum.Pipeline.NONE;
		Endian		= ModelulatorEnum.Endian.Native;
	};
	{
		Developer	= "Sony Computer Entertainment";
		PlatformName	= "PlayStation";
		MinGeneration	= 5;
		Type		= ModelulatorEnum.Pipeline.PSX;
		Endian		= ModelulatorEnum.Endian.Little;
	};
	{
		Developer	= "Microsoft";
		PlatformName	= "Windows";
		MinGeneration	= 5;
		Type		= ModelulatorEnum.Pipeline.PC;
		Endian		= ModelulatorEnum.Endian.Little;
	};
	{
		Developer	= "Sony Computer Entertainment";
		PlatformName	= "PlayStation 2";
		MinGeneration	= 6;
		Type		= ModelulatorEnum.Pipeline.PSX2;
		Endian		= ModelulatorEnum.Endian.Little;
	};
	{
		Developer	= "Nintendo";
		PlatformName	= "GameCube";
		MinGeneration	= 6;
		Type		= ModelulatorEnum.Pipeline.GAMECUBE;
		Endian		= ModelulatorEnum.Endian.Big;
	};
	{
		Developer	= "Microsoft";
		PlatformName	= "Xbox";
		MinGeneration	= 6;
		Type		= ModelulatorEnum.Pipeline.XBOX;
		Endian		= ModelulatorEnum.Endian.Little;
	};
	{
		Developer	= "Microsoft";
		PlatformName	= "Xbox 360";
		MinGeneration	= 7;
		Type		= ModelulatorEnum.Pipeline.XENON;
		Endian		= ModelulatorEnum.Endian.Big;
	};
	{
		Developer	= "Sony Computer Entertainment";
		PlatformName	= "PlayStation 3";
		MinGeneration	= 7;
		Type		= ModelulatorEnum.Pipeline.PS3;
		Endian		= ModelulatorEnum.Endian.Big;
	};
	{
		Developer	= "Nintendo";
		PlatformName	= "Wii";
		MinGeneration	= 7;
		Type		= ModelulatorEnum.Pipeline.REVOLUTION;
		Endian		= ModelulatorEnum.Endian.Big;
	};
};

local Pipelines		= {};

local function SetupPipelines()
	for _, Item in pairs(PipelinesArray) do
		local PipelineName	= string.upper(Item.Type.Name);
		Pipelines[PipelineName]	= Item;
	end;
end;

SetupPipelines();

local function SetupPipeline(PipelineString)
	local PipelineObject	= Pipelines[string.upper(PipelineString)] or Pipelines.NONE;
	
	local PipelineEnum	= PipelineObject.Type;
	local EndianEnum	= PipelineObject.Endian;
	
	if (EndianEnum == ModelulatorEnum.Endian.Native) then
		local MagicNumber	= 0x12345678;
		local TestLittle	= string.unpack("=I4", string.pack("<I4", MagicNumber));
		local TestBig		= string.unpack("=I4", string.pack(">I4", MagicNumber));
		
		EndianEnum	= (TestLittle == MagicNumber) and ModelulatorEnum.Endian.Little or EndianEnum;
		EndianEnum	= (TestBig == MagicNumber) and ModelulatorEnum.Endian.Big or EndianEnum;
		
		if (EndianEnum == ModelulatorEnum.Endian.Native) then
			print(string.format("<(0x%08X) => 0x%08X", MagicNumber, TestLittle));
			print(string.format(">(0x%08X) => 0x%08X", MagicNumber, TestBig));
			print("... the fuck?");
		else
			return PipelineEnum, (EndianEnum == ModelulatorEnum.Endian.Big);
		end;
	end;
	
	print(PipelineEnum);
	print(EndianEnum);
	
	return PipelineEnum, (EndianEnum == ModelulatorEnum.Endian.Big);
end;

local obj_string	= "";
local fmt		= Config.BigEndian and ">" or "<";

local ProfileIndex

local function new_bChunk(Address)
	Address			= Address or 0x00000000;
	
	local bChunkProxy	= setmetatable({}, {});
	local bChunkMeta	= getmetatable(bChunkProxy);
	
	local Members		= {};
	Members.Address		= {Value = Address};
	Members.Alignment	= {ReadOnly = true; Value = 0x01};
	Members.Type		= {ReadOnly = true; Value = "bChunk"};
	Members.ID		= {ReadOnly = true, MemoryValue = true; Offset = 0x00, DataFormat = "< I4"};
	Members.Size		= {ReadOnly = true, MemoryValue = true; Offset = 0x04, DataFormat = "< i4"};
	Members.Align		= {ReadOnly = true};
	Members.IsNestedChunk	= {ReadOnly = true};
	Members.Next		= {ReadOnly = true};
	
	Members.Align.Value =
	function(self, al)
		local OldAddress = Members.Address.Value + 0x08;
		
		al = -al;
		Members.Address.Value = (Members.Address.Value + 0x08 + (~al)) & al;
		
		--print(string.format("Moved to: 0x%08X", Members.Address.Value));
		
		return Members.Address.Value - OldAddress;
	end;
	
	Members.IsNestedChunk.Value =
	function(self)
		local ID	= ResourceFile:Read(Members.Address.Value + Members.ID.Offset, Members.ID.DataFormat);
		
		return ((ID >> 0x1F) & 0x01 == 0x01);
	end;
	
	Members.Next.Value =
	function(self)
		local Size	= ResourceFile:Read(Members.Address.Value + Members.Size.Offset, Members.Size.DataFormat);
		Members.Address.Value = Members.Address.Value + 0x08 + Size;
		
		--print(string.format("Moved to: 0x%08X", Members.Address.Value));
		
		return;
	end;
	
	bChunkMeta.__newindex	=
	function(self, Key, Value)
		if ((Members[Key] ~= nil) and (not Members[Key].ReadOnly)) then
			Members[Key].Value = Value;
			
			if (Key == "Address") then
				--print(string.format("Moved to: 0x%08X", Members.Address.Value));
			end;
		end;
	end;
	
	bChunkMeta.__index	=
	function(self, Key)
		if (Members[Key] ~= nil) then
			if (Members[Key].MemoryValue) then
				return ResourceFile:Read(Members.Address.Value + Members[Key].Offset, Members[Key].DataFormat);
			else
				local Value = Members[Key].Value;
				return Members[Key].Value;
			end;
		end;
	end;
	
	bChunkMeta.__len	=
	function(self)
		return self.Size;
	end;
	
	bChunkMeta.__tostring	=
	function(self)
		return string.format("bChunk_0x%08X", self.ID);
	end;
	
	return bChunkProxy;
end;

--[[
legend
======================================
operation	meaning
A!		on A finished
A \ ...	from A enter branch
A / ...	from A exit branch
... -> B	

0xB3300000 \ 0xB3300000.0xB3310000
0xB3310000 -> 0xB3310000.0x33310001
0x33310001 -> 0x33310002
0x33310002 -> 0x33310003 | 0x33310004
0x33310003 -> 0x33310004
0x33310004 -> 0x33310005
0x33310005 /

{
	ID		= 0x80134000;
	Alignment	= 0x01;
	IsContainer	= 0x00;
	
	ParentNodeId	= 0x00000000;
	ChildNodeId	= {};
}
--]]

_ENV.FileOutputInventory		= {};
FileOutputInventory.Solids		= {};
FileOutputInventory.ScenerySections	= {};
FileOutputInventory.Textures		= {};
FileOutputInventory.RoadNetworks	= {};
FileOutputInventory.CollisionPacks	= {};

_ENV.eTextureHashList		= {};

local Loader_eTexturePack		= require("src.loaders.eTexturePack");
local Loader_eSolidPackList		= require("src.loaders.eSolidPackList");
local Loader_ScenerySection		= require("src.loaders.ScenerySection");
local Loader_WRoadNetwork		= require("src.loaders.WRoadNetwork");
local Loader_WCollisionPack		= require("src.loaders.WCollisionPack");
local Loader_TrackStreamer		= require("src.loaders.TrackStreamer");

local Loader_Legacy_eTexturePack	= require("src.loaders.Legacy.eTexturePack");
local Loader_Legacy_eSolidPackList	= require("src.loaders.Legacy.eSolidPackList");

local Loader_Nascar_bGeomPack		= require("src.loaders.NASCAR.bGeomPack");
local Loader_Nascar_bTexturePack	= require("src.loaders.NASCAR.bTexturePack");

_ENV.Track			= {}
_ENV.Track.Streaming		= {};

_ENV.Stream			= {};
_ENV.Stream.CurrentSection	= "";

_ENV.FileOutputList		= {};

local function FormatProgramTag(StringToPrefix)
	StringToPrefix			= StringToPrefix or "";
	
	local TimeStamp_ISO8601		= os.date("!%Y-%m-%dT%H:%M:%SZ");
	local Tag			= string.format("[%s] @ %s", ProgramInfo.Name, TimeStamp_ISO8601);
	local WhiteSpacePadding		= string.rep(" ", #Tag);
	local Separator			= " --\t";
	
	StringToPrefix			= string.gsub(StringToPrefix, "\n", "\n" .. "#" .. WhiteSpacePadding .. Separator);
	StringToPrefix			= "#" .. Tag .. Separator .. StringToPrefix;
	
	return StringToPrefix;
end;

local ErrorCount	= 0;
local SuccessCount	= 0;
local ProcessCount	= 0;

local ProcessErrors	= {};

-- Create all folders internally so helper Python scripts/batches do not need to.
local RequiredOutputDirectories =
{
	"CollisionPacks";
	"RoadNetworks";
	"ScenerySections";
	"Solids";
	"Textures";
	"logs";
};

local function EnsureDirectory(Directory)
	if ((Directory == nil) or (#Directory <= 0)) then
		return false;
	end;

	local Command = string.format('if not exist "%s" mkdir "%s" > nul 2> nul', Directory, Directory);
	local Success = os.execute(Command);
	return (Success == true) or (Success == 0);
end;

local function EnsureModelulatorDirectories(OPATH)
	-- Existing decompression code uses .\temp; create it automatically.
	EnsureDirectory(ModelulatorTempDirectory);
	EnsureDirectory(".\\logs");

	if ((OPATH ~= nil) and (#OPATH > 0)) then
		EnsureDirectory(OPATH);
		for _, DirectoryName in ipairs(RequiredOutputDirectories) do
			EnsureDirectory(string.format("%s\\%s", OPATH, DirectoryName));
		end;
	end;
end;

local function GenerateFileOutput(ProcessOnly, OPATH)
	if (not ProcessOnly) then
		EnsureModelulatorDirectories(OPATH);
	end;

	local ActiveFileOutputObject = nil;
	local function FileOutputListErrorHandler(...)
		print("FileOutputList Error:");
		print(...);

		local VarArgs = {...};
		local ErrorStrings = {};
		for i, Value in ipairs(VarArgs) do
			ErrorStrings[i] = tostring(Value);
		end;

		table.insert(ProcessErrors,
		{
			ProcessIndex = ProcessCount;
			Stage = "Generate";
			Inventory = (ActiveFileOutputObject and ActiveFileOutputObject.Inventory) or "Unknown";
			ErrorList = ErrorStrings;
		});

		ErrorCount = ErrorCount + 1;
	end;
	
	for i = 1, #_ENV.FileOutputList do
		local FileOutputObject = _ENV.FileOutputList[i];
		ActiveFileOutputObject = FileOutputObject;

		local Success, FileOutput = xpcall(FileOutputObject.Output.Function, FileOutputListErrorHandler, table.unpack(FileOutputObject.Output.Arguments));
		
		if (Success == true) then
			SuccessCount	= SuccessCount + 1;
			table.insert(FileOutputInventory[FileOutputObject.Inventory], FileOutput);
		end;
		
		ProcessCount		= ProcessCount + 1;
	end;
	
	if (not ProcessOnly) then
		local InventoryName;
		local filename;
		local filetype;
		local filedata;
		
		local function ProcessFile()
			local tempfiletype = filetype .. "";
			
			--(filetype == "bmp")
			local ofile = assert(io.open(string.format("%s\\%s\\%s.%s", OPATH, InventoryName, filename, filetype), "wb"));
			assert(ofile:write(filedata));
			assert(ofile:close());
			
			print(FormatProgramTag(string.format("%s\\%s.%s - Done!", InventoryName, filename, tempfiletype)));
			
			SuccessCount	= SuccessCount + 1;
		end;
		
		local function ProcessError(...)
			ErrorCount	= ErrorCount + 1;
			
			local VarArgs = {...};
			local ErrorString = "oh no, error(s)!";
			
			for i, v in pairs(VarArgs) do
				ErrorString = ErrorString .. "\n" .. string.format("[%s] : %s", i, v);
			end;
			
			table.insert(ProcessErrors, {ProcessIndex = ProcessCount, Inventory = InventoryName, FileType = filetype, Name = filename, Size = #filedata, ErrorList = VarArgs});
			
			print(FormatProgramTag(ErrorString));
		end;
		
		for _InventoryName, InventoryItem in pairs(FileOutputInventory) do
			InventoryName		= _InventoryName;
			
			for _j, file_output in pairs(InventoryItem) do
				for _i, file in pairs(file_output) do
					filename		= file.FileName;
					filetype		= file.FileType;
					filedata		= file.Data;
					
					--print(InventoryName, _j, _i, filename, filetype);
					
					local Success	= xpcall(ProcessFile, ProcessError);
					
					ProcessCount	= ProcessCount + 1;
				end;
			end;
			
			FileOutputInventory[InventoryName]	= {};
		end;
		
		local function ConvertBMPtoPNG()
			local powershell_call	= string.format("powershell -ExecutionPolicy Bypass -file \".\\PowerShell\\ConvertBMPtoPNG.ps1\" -OPath \"%s\\Textures\\*.bmp\" > nul 2> nul", OPATH);
			local powershell_prog = assert(io.popen(powershell_call, "r"));
			powershell_prog:read("*all");
			powershell_prog:close();
		end;
		
		ConvertBMPtoPNG();
		
		local function OOOOOHHHHBLACKBOXBABY()
			print(FormatProgramTag("OOOOOHHHH BLACKBOX BABY"));
			local powershell_call	= string.format("powershell -ExecutionPolicy Bypass -file \".\\PowerShell\\PlaySound.ps1\" -SoundFile \".\\Sound\\success.wav\" > nul 2> nul");
			local success = assert(io.popen(powershell_call, "rb"));
		end;
		
		print("");
		
		local ProcessDenominator = math.max(ProcessCount, 1);
		local StatsString = string.format("#Processes = %i\n#Successes = %i (%.2f%%)\n#Errors = %i (%.2f%%)", ProcessCount, SuccessCount, SuccessCount / ProcessDenominator * 100, ErrorCount, ErrorCount / ProcessDenominator * 100);

		print(FormatProgramTag(StatsString));

		-- Write a native Modelulator summary log so a helper batch is no longer
		-- required just to capture export failures.
		local LogPath = string.format("%s\\logs\\modelulator_%s.log", OPATH, os.date("%Y%m%d_%H%M%S"));
		local LogFile = io.open(LogPath, "wb");
		if (LogFile ~= nil) then
			LogFile:write(StatsString, "\r\n");
			if (#ProcessErrors > 0) then
				LogFile:write("\r\nErrors:\r\n");
				for _, ErrorEntry in ipairs(ProcessErrors) do
					local ErrorText = table.concat(ErrorEntry.ErrorList or {}, " | ");
					LogFile:write(string.format("[%s] inventory=%s name=%s type=%s : %s\r\n", tostring(ErrorEntry.Stage or "Write"), tostring(ErrorEntry.Inventory or "Unknown"), tostring(ErrorEntry.Name or ""), tostring(ErrorEntry.FileType or ""), ErrorText));
				end;
			end;
			LogFile:close();
		end;
		
		if ((SuccessCount / ProcessDenominator >= 1.0) and (os.getenv("MODELULATOR_NO_SOUND") ~= "1")) then
			local f = coroutine.create(OOOOOHHHHBLACKBOXBABY);
			coroutine.resume(f);
		end;
	end;
end;

local bChunk_CompressInPlaceMagic		= 0x55441122;

local function process(args, StreamerIndex)
	local ProcessOnly	= (args.PROCESSONLY.VALUE == true);
	
	local IPATH, OPATH	= args.INPUT.VALUE, args.OUTPUT.VALUE;
	
	ResourceFile.Directory	= IPATH;
	
	if (StreamerIndex ~= nil) then
		local TrackStreamerProfile	= Track.Streaming[StreamerIndex];
		ResourceFile:Open("Read (Binary)", TrackStreamerProfile.SectionAddress, math.min(TrackStreamerProfile.SectionSize, TrackStreamerProfile.CompressedSize));
		
		_ENV.Stream.CurrentSection	= TrackStreamerProfile.SectionName;
	else
		ResourceFile:Open("Read (Binary)");
		
		_ENV.Stream.CurrentSection	= "";
	end;
	
	print("will it work?");
	print("lets find out");
	
	local start_time			= os.time();
	
	Config.Game				= ModelulatorEnum.Game[args.GAME.VALUE] or ModelulatorEnum.Game.NONE;
	Config.Pipeline, Config.BigEndian	= SetupPipeline(args.PIPELINE.VALUE);
	
	if ((Config.Pipeline == ModelulatorEnum.Pipeline.NONE) or (Config.Game == ModelulatorEnum.Game.NONE)) then
		return;
	end;
	
	--print("durr");
	
	local FilePointer	= 0x00000000;
	
	local Triangles 	= {};
	
	fmt = Config.BigEndian and ">" or "<";
	
	if (not ProcessOnly) then
		EnsureModelulatorDirectories(OPATH);
	else
		EnsureDirectory(ModelulatorTempDirectory);
	end;

	local CompressionType	=
	{
		0x57574152;
		0x504D4F43;
		0x5A4C444A;
		0x46465548;
		0x4B504652;
	};
	
	local function CheckIsCompressedFile()
		local TestHeaderValue	= 0x40404040;
		local TestFlagsValue	= 0xFFFFEFFC;
		
		local Header		= ResourceFile:Read(FilePointer + 0x00000000, "<I4");
		local Flags		= ResourceFile:Read(FilePointer + 0x00000004, "<I4");
		local UnpackedSize	= ResourceFile:Read(FilePointer + 0x00000008, "<I4");
		local Size		= ResourceFile:Read(FilePointer + 0x0000000C, "<I4");
		
		local MightBeValid	=
		{
			Header		= (Header & TestHeaderValue == TestHeaderValue);
			Flags		= (Flags & TestFlagsValue == 0x00000000);
			UnpackedSize	= (math.abs(UnpackedSize - ResourceFile.Size) <= 0x10);
			Size		= (math.abs(Size - ResourceFile.Size) <= 0x10);
		};
		
		local PossiblyValidString = "";
		PossiblyValidString = PossiblyValidString .. string.rep("\n", math.min(#PossiblyValidString, 1)) .. string.format("Header: %s", tostring(MightBeValid.Header));
		PossiblyValidString = PossiblyValidString .. string.rep("\n", math.min(#PossiblyValidString, 1)) .. string.format("Flags: %s", tostring(MightBeValid.Flags));
		PossiblyValidString = PossiblyValidString .. string.rep("\n", math.min(#PossiblyValidString, 1)) .. string.format("UnpackedSize: %s", tostring(MightBeValid.UnpackedSize));
		PossiblyValidString = PossiblyValidString .. string.rep("\n", math.min(#PossiblyValidString, 1)) .. string.format("Size: %s", tostring(MightBeValid.Size));
		
		print(PossiblyValidString);
		
		local IsValid		= false;
		
		if (MightBeValid.Header and MightBeValid.Flags and MightBeValid.Size) then
			for i = 1, #CompressionType do
				if (Header == CompressionType[i]) then
					IsValid	= true;
					break;
				end;
			end;
		end;
		
		return IsValid;
	end;
	
	---[[
	local IsCompressedFile	= CheckIsCompressedFile();
	
	local CompResourceFile;
	
	if (IsCompressedFile == true) then
		CompResourceFile	= PhilLip2:CreateFile(ModelulatorTempPath());
		CompResourceFile:Open("Write + (Binary)");
		CompResourceFile:Write(0x00000000, Decompress(ResourceFile, FilePointer));
		
		ResourceFile, CompResourceFile	= CompResourceFile, ResourceFile;
	end;
	---]]
	
	if (ResourceFile:Read(FilePointer, "<I4") == bChunk_CompressInPlaceMagic) then
		IsCompressedFile	= true;
		
		CompResourceFile	= PhilLip2:CreateFile(ModelulatorTempPath());
		CompResourceFile:Open("Write + (Binary)");
		
		local TempAddress	= FilePointer + 0x00000000;
		
		while (TempAddress < ResourceFile.Size) do
			local ID		= ResourceFile:Read(TempAddress + 0x00000000, "<I4");
			local Size		= ResourceFile:Read(TempAddress + 0x00000004, "<i4");
			
			if (ID == bChunk_CompressInPlaceMagic) then
				local CompressedSize		= ResourceFile:Read(TempAddress + 0x00000008, "<i4");
				local Address			= ResourceFile:Read(TempAddress + 0x0000000C, "<I4");
				local ReturnAddress		= ResourceFile:Read(TempAddress + 0x00000010, "<I4");
				local Reserved			= ResourceFile:Read(TempAddress + 0x00000014, "<I4");
				
				CompResourceFile:Write(Address, Decompress(ResourceFile, TempAddress + 0x00000018));
				
				TempAddress			= TempAddress + CompressedSize;
			else
				TempAddress			= TempAddress + 0x00000008 + Size;
			end;
		end;
		
		ResourceFile, CompResourceFile	= CompResourceFile, ResourceFile;
	end;
	
	CARP.ResourceFile		= _ENV.ResourceFile;
	
	local __bChunk			= new_bChunk(FilePointer);
	
	local bChunkMap			= {};
	bChunkMap.All			= {};
	
	local LoaderTable		= {};
	local Mapper			= {};
	
	local MapperA			=
	{
		[0x80030100]		= "bGeomPack";
		[0x80030014]		= "bTexturePack";
	};
	
	local MapperB			=
	{
		[0xB0300001]		= "eTexturePack";
		[0x80034000]		= "eSolidPackList";
		[0x80034100]		= "ScenerySection";
	};
	
	local MapperC			=
	{
		[0xB3300000]		= "eTexturePack";
		[0x80134000]		= "eSolidPackList";
		[0x80034100]		= "ScenerySection";
		[0x0003B800]		= "WRoadNetwork";
		[0x0003B801]		= "WCollisionPack";
	};
	
	local function MapperFunc()
		local CurrentChunk	= bChunkMap.All[#bChunkMap.All];
		local Map		= Mapper[CurrentChunk.ID];
		
		if ((Map ~= nil) and (bChunkMap[Map] ~= nil)) then
			table.insert(bChunkMap[Map], CurrentChunk);
		end;
	end;
	
	local function FillerFunc()
		return;
	end;
	
	local function FillerA()
		LoaderTable	=
		{
			{
				bChunkList	= bChunkMap.bGeomPack;
				LoaderFunction	= Loader_Nascar_bGeomPack;
			};
			{
				bChunkList	= bChunkMap.bTexturePack;
				LoaderFunction	= Loader_Nascar_bTexturePack;
			};
		};
		
		print(FormatProgramTag(string.format("#bGeomPacks = %i", #bChunkMap.bGeomPack)));
	end;
	
	local function FillerB()
		LoaderTable	=
		{
			{
				bChunkList	= bChunkMap.eSolidPackList;
				LoaderFunction	= Loader_Legacy_eSolidPackList;
			};
			{
				bChunkList	= bChunkMap.ScenerySection;
				LoaderFunction	= Loader_ScenerySection;
			};
			{
				bChunkList	= bChunkMap.eTexturePack;
				LoaderFunction	= Loader_Legacy_eTexturePack;
			};
			
		};
		
		print(FormatProgramTag(string.format("#eTexturePacks = %i", #bChunkMap.eTexturePack)));
		print(FormatProgramTag(string.format("#eSolidPackLists = %i", #bChunkMap.eSolidPackList)));
		print(FormatProgramTag(string.format("#ScenerySections = %i", #bChunkMap.ScenerySection)));
	end;
	
	local function FillerC()
		LoaderTable	=
		{
			{
				bChunkList	= bChunkMap.WRoadNetwork;
				LoaderFunction	= Loader_WRoadNetwork;
			};
			{
				bChunkList	= bChunkMap.WCollisionPack;
				LoaderFunction	= Loader_WCollisionPack;
			};
			{
				bChunkList	= bChunkMap.eTexturePack;
				LoaderFunction	= Loader_eTexturePack;
			};
			{
				bChunkList	= bChunkMap.eSolidPackList;
				LoaderFunction	= Loader_eSolidPackList;
			};
			{
				bChunkList	= bChunkMap.ScenerySection;
				LoaderFunction	= Loader_ScenerySection;
			};
			{
				bChunkList	= bChunkMap.All;
				LoaderFunction	= Loader_TrackStreamer;
			};
		};
		
		print(FormatProgramTag(string.format("#eTexturePacks = %i", #bChunkMap.eTexturePack)));
		print(FormatProgramTag(string.format("#eSolidPackLists = %i", #bChunkMap.eSolidPackList)));
		print(FormatProgramTag(string.format("#ScenerySections = %i", #bChunkMap.ScenerySection)));
	end;
	
	if (Config.Game.Value <= ModelulatorEnum.Game.NASCARTHUNDER2004.Value) then
		bChunkMap.bGeomPack		= {};
		bChunkMap.bTexturePack		= {};
		
		Mapper				= MapperA;
		FillerFunc			= FillerA;
	elseif (Config.Game.Value <= ModelulatorEnum.Game.HOTPURSUIT2.Value) then
		bChunkMap.eTexturePack		= {};
		bChunkMap.eSolidPackList	= {};
		bChunkMap.ScenerySection	= {};
		
		Mapper				= MapperB;
		FillerFunc			= FillerB;
	else
		bChunkMap.eTexturePack		= {};
		bChunkMap.eSolidPackList	= {};
		bChunkMap.ScenerySection	= {};
		bChunkMap.WRoadNetwork		= {};
		bChunkMap.WCollisionPack	= {};
		
		Mapper				= MapperC;
		FillerFunc			= FillerC;
	end;
	
	while (__bChunk.Address < ResourceFile.Size) do
		table.insert(bChunkMap.All, new_bChunk(__bChunk.Address));
		
		MapperFunc();
		
		print(string.format("0x%08X / 0x%08X", __bChunk.Address, ResourceFile.Size));
		__bChunk:Next();
	end;
	
	---[[
	FillerFunc();
	
	for _, LoaderE in pairs(LoaderTable) do
		for i = 1, #LoaderE.bChunkList do
			local CurrentChunk	= LoaderE.bChunkList[i];
			
			--print(string.format("[bChunk_0x%08X]", CurrentChunk.ID));
			
			local Success		= LoaderE.LoaderFunction(CurrentChunk);
			
			print(string.format("bChunk_0x%08X: %s", CurrentChunk.ID, tostring(Success)));
		end;
	end;
	---]]
	
	for i, v in pairs(FileOutputInventory) do
		print(string.format("#%s = %i", i, #v));
	end;
	
	--[[
	local log_file = assert(io.open(string.format(".\\log_%i.txt", start_time), "wb"));
	log_file:write(log_string);
	log_file:flush();
	log_file:close();
	--]]
	
	if ((IsCompressedFile == true) and (CompResourceFile ~= nil)) then
		CompResourceFile, ResourceFile	= ResourceFile, CompResourceFile;
		CompResourceFile:Close();
	end;
	
	ResourceFile:Close();
end;

local RequiredArgsList	=
{
	{
		{
			i = "Input";
			o = "Output";
		};
		"TrackFile";
		"StreamFile";
		"Pipeline";
		"Game";
	};
	{
		{
			i = "Input";
			o = "Output";
		};
		"TrackFile";
		"Pipeline";
		"Game";
	};
	{
		{
			i = "Input";
			o = "Output";
		};
		"Pipeline";
		"Game";
	};
	{
		{
			i = "Input";
			o = "Output";
		};
		"InputArray";
		"Pipeline";
		"Game";
	};
};

local function getrequired(args)
	local ProcessOnly		= (args.PROCESSONLY.VALUE == true);
	
	local MeetsRequirements		= false;
	local Index			= -1;
	
	for i = 1, #RequiredArgsList do
		MeetsRequirements	= true;
		
		for j = 1, #RequiredArgsList[i] do
			local ReqArgEType		= string.lower(type(RequiredArgsList[i][j]));
			if ((ReqArgEType == "table") and (RequiredArgsList[i][j].i ~= nil) and (RequiredArgsList[i][j].o ~= nil)) then
				MeetsRequirements	= MeetsRequirements and args[string.upper(RequiredArgsList[i][j].i)].USED;
				MeetsRequirements	= MeetsRequirements and (args[string.upper(RequiredArgsList[i][j].o)].USED or ProcessOnly);
			elseif (ReqArgEType == "string") then
				MeetsRequirements	= MeetsRequirements and args[string.upper(RequiredArgsList[i][j])].USED;
			end;
		end;
		
		if (MeetsRequirements) then
			Index		= i;
			break;
		end;
	end;
	
	return MeetsRequirements, Index;
end;

function program:run(args)
	local Success, Index		= getrequired(args);
	
	if ((Success == true) and (Index > 0)) then
		local ReqArgs		= RequiredArgsList[Index];
		
		local I, O		= args[string.upper(ReqArgs[1].i)], args[string.upper(ReqArgs[1].o)];
		
		if (args.STREAMFILE.USED == false) then
			args.STREAMFILE.VALUE		= "STREAM" .. args.TRACKFILE.VALUE;
			args.STREAMFILE.USED		= true;
		end;
		
		if (args.INPUTARRAY.USED == true) then
			local INPUTDIR			= I.VALUE;
			local INPUTS			= args.INPUTARRAY.VALUES;
			
			for i = 1, #INPUTS do
				args.INPUT.VALUE	= INPUTDIR .. "\\" .. INPUTS[i];
				
				process(args);
				
				args.INPUT.VALUE	= "";
			end;
		else
			if ((args.TRACKFILE.USED == true) and (args.STREAMFILE.USED == true)) then
				local INPUTDIR		= "" .. I.VALUE;
				
				args.INPUT.VALUE	= INPUTDIR .. "\\" .. args.TRACKFILE.VALUE;
				process(args);
				
				args.INPUT.VALUE	= INPUTDIR .. "\\" .. args.STREAMFILE.VALUE;
				
				for i = 1, #Track.Streaming do
					local function ProcessSection()
						print(string.format("ID: 0x%08X | Address: 0x%08X | Size: 0x%08X // %s", Track.Streaming[i].SectionID, Track.Streaming[i].SectionAddress, Track.Streaming[i].SectionSize, Track.Streaming[i].SectionName));
						
						if (Track.Streaming[i].FileIndex == 0x00000001) then
							process(args, i);
						end;
					end;
					
					local co	= coroutine.create(ProcessSection);
					coroutine.resume(co);
				end;
			else
				process(args);
			end;
		end;
		
		local co = coroutine.create(GenerateFileOutput);
		coroutine.resume(co, args.PROCESSONLY.VALUE, O.VALUE);
	end;
end;

return program;