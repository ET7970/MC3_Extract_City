local program		= {};

---[[
_ENV.VIFcode		= require("src.util.VIFcode");
_ENV.PhilLip		= require("src.util.lib.phillip");		PhilLip:initialize();
_ENV.PhilLip2		= require("src.util.lib.PhilLip2");
--_ENV.bChunk		= require("src.util.legacy.ea_bchunk");
--_ENV.bHash		= require("src.util.legacy.ea_hash");
_ENV.Cleanum		= require("src.util.lib.cleanums");
---]]

_ENV.ResourceFile	= PhilLip2:CreateFile();

local Decompress	= require("src.util.decompress");

local function MainDecompressionTest(args)
	for i = 1, #args.INPUTARRAY.VALUES do
		ResourceFile.Directory	= string.format("%s\\%s", args.INPUT.VALUE, args.INPUTARRAY.VALUES[i]);
		ResourceFile:Open("Read (Binary)");
		
		local OutFileName	= string.gsub(args.INPUTARRAY.VALUES[i], "%.%w*", ".bin");
		local OutFilePhilLip	= Decompress(ResourceFile, 0x00000000);
		
		local OutFile		= assert(io.open(string.format("%s\\%s", args.OUTPUT.VALUE, OutFileName), "wb"));
		OutFile:write(table.concat(OutFilePhilLip.content, ""));
		OutFile:close();
		
		OutFilePhilLip:close();
		
		ResourceFile:Close();
	end;
end;

local function new_bChunk(Address)
	Address			= Address or 0x00000000;
	
	local bChunkProxy	= setmetatable({}, {});
	local bChunkMeta	= getmetatable(bChunkProxy);
	
	local Members		= {};
	Members.Address		= {Value = Address};
	Members.Alignment	= {ReadOnly = true; Value = 0x01};
	Members.Type		= {ReadOnly = true; Value = "bChunk"};
	Members.ID		= {ReadOnly = true, MemoryValue = true; Offset = 0x00, DataFormat = "< I4"};
	Members.Size		= {ReadOnly = true, MemoryValue = true; Offset = 0x04, DataFormat = "< i4"};
	Members.Align		= {ReadOnly = true};
	Members.IsNestedChunk	= {ReadOnly = true};
	Members.Next		= {ReadOnly = true};
	
	Members.Align.Value =
	function(self, al)
		local OldAddress = Members.Address.Value + 0x08;
		
		al = -al;
		Members.Address.Value = (Members.Address.Value + 0x08 + (~al)) & al;
		
		return Members.Address.Value - OldAddress;
	end;
	
	Members.IsNestedChunk.Value =
	function(self)
		local ID	= ResourceFile:Read(Members.Address.Value + Members.ID.Offset, Members.ID.DataFormat);
		
		return ((ID >> 0x1F) & 0x1 == 0x1);
	end;
	
	Members.Next.Value =
	function(self)
		local Size	= ResourceFile:Read(Members.Address.Value + Members.Size.Offset, Members.Size.DataFormat);
		Members.Address.Value = Members.Address.Value + 0x08 + Size;
		
		return;
	end;
	
	bChunkMeta.__newindex	=
	function(self, Key, Value)
		if ((Members[Key] ~= nil) and (not Members[Key].ReadOnly)) then
			Members[Key].Value = Value;
		end;
	end;
	
	bChunkMeta.__index	=
	function(self, Key)
		if (Members[Key] ~= nil) then
			if (Members[Key].MemoryValue) then
				return ResourceFile:Read(Members.Address.Value + Members[Key].Offset, Members[Key].DataFormat);
			else
				local Value = Members[Key].Value;
				return Members[Key].Value;
			end;
		end;
	end;
	
	bChunkMeta.__len	=
	function(self)
		return self.Size;
	end;
	
	bChunkMeta.__tostring	=
	function(self)
		return string.format("bChunk_0x%08X", self.ID);
	end;
	
	return bChunkProxy;
end;

local function DecompressInPlace(args)
	local BCHUNK_NULL			= 0x00000000;
	local BCHUNK_APT_PACKAGE		= 0x0003A100;
	local BCHUNK_COMPRESS_IN_PLACE_MAGIC	= 0x55441122;
	
	local FilePointer			= 0x00000000;
	
	local function Align(x, al)
		return (x + ~-al) & -al;
	end;
	
	for i = 1, #args.INPUTARRAY.VALUES do
		TempResourceFile	= PhilLip.file_create();
		
		ResourceFile.directory	= string.format("%s\\%s", args.INPUT.VALUE, args.INPUTARRAY.VALUES[i]);
		ResourceFile:open();
		
		local __bChunk			= new_bChunk(FilePointer);
		
		local bChunkMap			= {};
		bChunkMap.APTPackage		= {};
		bChunkMap.CompressInPlace	= {};
		bChunkMap.All			= {};
		
		while (__bChunk.Address < ResourceFile.size) do
			table.insert(bChunkMap.All, new_bChunk(__bChunk.Address));
			
			if (__bChunk.ID == BCHUNK_APT_PACKAGE) then
				table.insert(bChunkMap.APTPackage, bChunkMap.All[#bChunkMap.All]);
			elseif (__bChunk.ID == BCHUNK_COMPRESS_IN_PLACE_MAGIC) then
				table.insert(bChunkMap.CompressInPlace, bChunkMap.All[#bChunkMap.All]);
			end;
			
			if (__bChunk.ID ~= BCHUNK_COMPRESS_IN_PLACE_MAGIC) then
				__bChunk:Next();
			else
				local CompSize		= ResourceFile:Read(__bChunk.Address + 0x08, "<I4");
				__bChunk.Address	= __bChunk.Address + CompSize;
			end;
		end;
		
		local TempPointer			= 0x00000000;
		
		--[[
		for i = 1, #bChunkMap.APTPackage do
			local APTPackage		= bChunkMap.APTPackage[i];
			
			local DataPointer		= APTPackage.Address + 0x08;
			local RawData			= Decompress(DataPointer);
			
			print(#RawData.content);
			
			TempResourceFile:write_data(TempPointer, "<c" .. RawData.size + 1, table.concat(RawData.content, ""));
			TempResourceFile.size		= TempResourceFile.size;
			
			TempPointer			= TempPointer + RawData.size;
			
			local AlignedPointer		= Align(TempPointer + 0x10, 0x800);
			local AlignDiff			= AlignedPointer - TempPointer;
			
			TempResourceFile:write_data(AlignedPointer - 1, "x", 0x00);
			TempResourceFile:write_data(TempPointer, "<I4i4", BCHUNK_NULL, AlignDiff - 0x08);
			
			TempPointer			= AlignedPointer;
		end;
		--]]
		
		local OutFileExtension	= string.match(args.INPUTARRAY.VALUES[i], "%.%w*");
		
		local OutFileName	= string.format("RAWW_%s", args.INPUTARRAY.VALUES[i]);
		
		local OutFile		= assert(io.open(string.format("%s\\%s", args.OUTPUT.VALUE, OutFileName), "wb"));
		OutFile:write(table.concat(TempResourceFile.content, ""));
		OutFile:close();
		
		ResourceFile:close();
	end;
end;

function program:run(args)
	local ShouldRun		= true;
	ShouldRun		= ShouldRun and (args.INPUT.USED);
	ShouldRun		= ShouldRun and (args.INPUTARRAY.USED);
	ShouldRun		= ShouldRun and (args.OUTPUT.USED);
	
	print(os.time());
	
	if (not ShouldRun) then
		return;
	end;
	
	--DecompressInPlace(args);
	
	MainDecompressionTest(args);
end;

return program;