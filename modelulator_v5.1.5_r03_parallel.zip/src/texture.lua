require("src.util.texture.Global");

local Texture		= {};
Texture.PSX2		= require("src.util.texture.PSX2");
Texture.DXTC1		= require("src.util.texture.DXTC1");
Texture.GAMECUBE	= require("src.util.texture.Gamecube");
Texture.REVOLUTION	= require("src.util.texture.Revolution");

Texture.Legacy		= {};
Texture.Legacy.PSX2	= require("src.util.texture.Legacy.PSX2");

return Texture;