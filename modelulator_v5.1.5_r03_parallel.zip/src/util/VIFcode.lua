local VIFcode			= {};
VIFcode.CMD			= {};

VIFcode.CMD.FieldStrings =
{
	"NOP";
	"STCYCL";
	"OFFSET";
	"BASE";
	"ITOP";
	"STMOD";
	"MSKPATH3";
	"MARK";
	"FLUSHE";
	"FLUSH";
	"FLUSHA";
	"MSCAL";
	"MSCALF";
	"MSCNT";
	"STMASK";
	"STROW";
	"STCOL";
	"MPG";
	"DIRECT";
	"DIRECTHL";
	"UNPACK";
	"???";
};

VIFcode.CMD.FormatStrings =
{
	"S32";
	"S16";
	"S8";
	"V2_32";
	"V2_16";
	"V2_8";
	"V3_32";
	"V3_16";
	"V3_8";
	"V4_32";
	"V4_16";
	"V4_8";
	"V4_5";
	"*Error*";
};

VIFcode.CMD.FieldStringLookup =
{
	[0x00]	= 0x00;
	
	[0x01]	= 0x01;
	
	[0x02]	= 0x02;
	[0x03]	= 0x03;
	[0x04]	= 0x04;
	
	[0x05]	= 0x05;
	
	[0x06]	= 0x06;
	[0x07]	= 0x07;
	
	[0x10]	= 0x08;
	[0x11]	= 0x09;
	[0x13]	= 0x0A;
	
	[0x14]	= 0x0B;
	[0x15]	= 0x0C;
	[0x17]	= 0x0D;
	
	[0x20]	= 0x0E;
	[0x30]	= 0x0F;
	[0x31]	= 0x10;
	
	[0x4A]	= 0x11;
	
	[0x50]	= 0x12;
	[0x51]	= 0x13;
	
	[0x60]	= 0x14;
};

VIFcode.CMD.FormatStringLookup =
{
	[0x0]	= 0x0;
	[0x1]	= 0x1;
	[0x2]	= 0x2;
	
	[0x4]	= 0x3;
	[0x5]	= 0x4;
	[0x6]	= 0x5;
	
	[0x8]	= 0x6;
	[0x9]	= 0x7;
	[0xA]	= 0x8;
	
	[0xC]	= 0x9;
	[0xD]	= 0xA;
	[0xE]	= 0xB;
	
	[0xF]	= 0xC;
};

-- NOP
VIFcode.CMD[0x00]	=
(
	function(CMD, NUM, IMM)
		return {};
	end
);

-- STCYCL
VIFcode.CMD[0x01]	=
(
	function(CMD, NUM, IMM)
		return
		{
			(IMM >> 0x08) & 0xFF;	-- WL
			(IMM) & 0xFF;		-- CL
		};
	end
);

-- OFFSET
VIFcode.CMD[0x02]	=
(
	function(CMD, NUM, IMM)
		return
		{
			IMM & 0x3F; -- OFFSET
		};
	end
);

-- BASE
VIFcode.CMD[0x03]	=
(
	function(CMD, NUM, IMM)
		return
		{
			IMM & 0x3F; -- BASE
		};
	end
);

-- ITOP
VIFcode.CMD[0x04]	=
(
	function(CMD, NUM, IMM)
		return
		{
			IMM & 0x3F; -- ADDR
		};
	end
);

-- STMOD
VIFcode.CMD[0x05]	=
(
	function(CMD, NUM, IMM)
		return
		{
			IMM & 0x03; -- MODE
		};
	end
);

-- MSKPATH3
VIFcode.CMD[0x06]	=
(
	function(CMD, NUM, IMM)
		return
		{
			(IMM >> 0x0F) & 0x01; -- MODE
		};
	end
);

-- MARK
VIFcode.CMD[0x07]	=
(
	function(CMD, NUM, IMM)
		return
		{
			IMM; -- MARK
		};
	end
);

-- FLUSHE
VIFcode.CMD[0x10]	=
(
	function(CMD, NUM, IMM)
		return {};
	end
);

-- FLUSH
VIFcode.CMD[0x11]	=
(
	function(CMD, NUM, IMM)
		return {};
	end
);

-- FLUSHA
VIFcode.CMD[0x13]	=
(
	function(CMD, NUM, IMM)
		return {};
	end
);

-- MSCAL
VIFcode.CMD[0x14]	=
(
	function(CMD, NUM, IMM)
		return
		{
			string.format("0x%08X", IMM << 0x03); -- EXECADDR
		};
	end
);

-- MSCALF
VIFcode.CMD[0x15]	=
(
	function(CMD, NUM, IMM)
		return
		{
			string.format("0x%08X", IMM << 0x03); -- EXECADDR
		};
	end
);

-- MSCNT
VIFcode.CMD[0x17]	=
(
	function(CMD, NUM, IMM)
		return {};
	end
);

-- STMASK
VIFcode.CMD[0x20]	=
(
	function(CMD, NUM, IMM)
		return {};
	end
);

-- STROW
VIFcode.CMD[0x30]	=
(
	function(CMD, NUM, IMM)
		return {};
	end
);

-- STCOL
VIFcode.CMD[0x31]	=
(
	function(CMD, NUM, IMM)
		return {};
	end
);

-- MPG
VIFcode.CMD[0x4A]	=
(
	function(CMD, NUM, IMM)
		return
		{
			(NUM > 0) and NUM or 0x100;	-- SIZE
			IMM << 0x03;			-- LOADADDR
		};
	end
);

-- DIRECT
VIFcode.CMD[0x50]	=
(
	function(CMD, NUM, IMM)
		return
		{
			(IMM > 0) and IMM or 0x10000; -- SIZE
		};
	end
);

-- DIRECTHL
VIFcode.CMD[0x51]	=
(
	function(CMD, NUM, IMM)
		return
		{
			(IMM > 0) and IMM or 0x10000; -- SIZE
		};
	end
);

-- UNPACK
VIFcode.CMD[0x60]	=
(
	function(CMD, NUM, IMM)
		return
		{
			VIFcode.CMD.FormatStrings[(VIFcode.CMD.FormatStringLookup[CMD & 0xF] or 0xD) + 0x1];	-- FORMAT
			NUM;										-- SIZE
			(IMM >> 0x0F) & 0x01 == 0x01;							-- FLG
			(IMM >> 0x0E) & 0x01 == 0x01;							-- USN
			string.format("0x%04X", (IMM & 0x3F) * 0x10);					-- ADDR
		};
	end
);


function VIFcode:ReadInstruction(InputInstruction)
	local CMD	= (InputInstruction >> 0x18) & 0x7F;
	local NUM	= (InputInstruction >> 0x10) & 0xFF;
	local IMM	= (InputInstruction) & 0xFFFF;
	
	local isUNPACK	= (CMD & 0x60 == 0x60);
	
	local FieldStringIndex = 0x15;
	
	if (isUNPACK) then
		FieldStringIndex = VIFcode.CMD.FieldStringLookup[CMD & 0x60] or 0x15;
	else
		FieldStringIndex = VIFcode.CMD.FieldStringLookup[CMD] or 0x15;
	end;
	
	local p_str = "";
	p_str = p_str .. string.format("[%02X %02X %04X]", CMD, NUM, IMM);
	
	local inst_str_tbl = {};
	
	local CMDFunction = isUNPACK and VIFcode.CMD[CMD & 0x60] or VIFcode.CMD[CMD];
	local CMDReturn = (CMDFunction ~= nil) and CMDFunction(CMD, NUM, IMM) or {};
	
	for i, v in pairs(CMDReturn) do
		table.insert(inst_str_tbl, tostring(v));
	end;
	
	local inst_str = table.concat(inst_str_tbl, ", ");
	inst_str = string.format("%s(%s)", VIFcode.CMD.FieldStrings[FieldStringIndex + 0x01], inst_str);
	
	p_str = p_str .. " => " .. inst_str;
	
	--print(inst_str);
	
	return CMD, NUM, IMM;
end;

--[[
VIFcode:ReadInstruction(0x6E018000);
VIFcode:ReadInstruction(0x6C01C001);
VIFcode:ReadInstruction(0x6C12C002);
VIFcode:ReadInstruction(0x6C0CC020);
VIFcode:ReadInstruction(0x6F18C034);
VIFcode:ReadInstruction(0x14000000);
VIFcode:ReadInstruction(0x00000000);
--]]

return VIFcode;