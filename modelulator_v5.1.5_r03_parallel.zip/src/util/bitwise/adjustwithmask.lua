local ONE		= 0x0000000000000001;
local MINUS_ONE		= 0xFFFFFFFFFFFFFFFF;

--# src: Source
--# msw: Mask Source Width
--# msp: Mask Source Position
--# adj: Adjustment

local function AdjustWithMask(src, msw, msp, adj)
	src	= src or (~MINUS_ONE);
	msw	= msw or (~MINUS_ONE);
	msp	= msp or (~MINUS_ONE);
	adj	= adj or (~MINUS_ONE);
	
	return ((src >> msp) & ~(MINUS_ONE << msw)) << adj;
end;

return AdjustWithMask;