local function AlignPowerOfTwoMax(x)
	while (x ~= (x & -x)) do
		x	= -(~x & -x);
	end;
	
	return x;
end;

return AlignPowerOfTwoMax;