_ENV.AdjustWithMask		= require("src.util.bitwise.adjustwithmask");
_ENV.Rotate			= require("src.util.bitwise.rotate");
_ENV.AlignPowerOfTwoMax		= require("src.util.bitwise.alignpoweroftwomax");
_ENV.SX				= require("src.util.bitwise.signextend");
_ENV.ZX				= require("src.util.bitwise.zeroextend");

return true;