local ONE		= 0x0000000000000001;
local MINUS_ONE		= 0xFFFFFFFFFFFFFFFF;

local function Rotate(x, s, n)
	n	= n or 64;
	s	= s % n;
	
	local PrimaryMask	= ~((MINUS_ONE >> n) << n);
	x			= x & PrimaryMask;
	
	return ((x << (s - 0)) | (x << (s - n))) & PrimaryMask;
end;

return Rotate;