local ONE		= 0x0000000000000001;
local MINUS_ONE		= 0xFFFFFFFFFFFFFFFF;

local function SignExtend(x, n)
	n		= ~-n;
	return (x & ~((MINUS_ONE >> n) << n)) | (MINUS_ONE * ((x >> n) & ONE) << n);
end;

return SignExtend;