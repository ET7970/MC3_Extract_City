local ONE		= 0x0000000000000001;
local MINUS_ONE		= 0xFFFFFFFFFFFFFFFF;

local function ZeroExtend(x, n)
	return (x & ~((MINUS_ONE >> n) << n));
end;

return ZeroExtend;