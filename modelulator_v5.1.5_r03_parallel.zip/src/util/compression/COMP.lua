local COMP		= {};

--# rewritten in Lua, originally from QuickBMS by Luigi Auriemma
function COMP.Decompress(ResourceFile, __in, __in_sz, __out, __out_sz)
	__in		= __in + 0x10;
	__in_sz		= __in_sz - 0x10;
	
	local __in_l	= __in + __in_sz;
	local __out_l	= __out + __out_sz;
	local __o	= __out;
	local __flags	= 0x00000001;
	
	local output	= PhilLip.file_create();
	
	while ((true) and (__o < __out_l)) do
		if (__flags == 0x00000001) then
			__in_flag	= ResourceFile:Read(__in + 0x0000, "<B") or 0x00;
			__in_flag	= __in_flag | ((ResourceFile:Read(__in + 0x0001, "<B") or 0x00) << 08);
			
			flags	= __in_flag | 0x00010000;
			__in	= __in + 0x0002;
		end;
		
		local num_cycles	= ((__in <= __in_l - 0x04) and 0xF or 0x0);
		
		for cycles = 0x00, num_cycles do
			if (flags & 0x00000001 == 0x00000001) then
				local c		= ResourceFile:Read(__in + 0x0000, "<B") or 0x00;
				local back_ptr	= __o - ((ResourceFile:Read(__in + 0x0001, "<B") or 0x00) | ((c & 0xF0) << 04));
				
				__in		= __in + 0x0002;
				
				for j = 0x00, ((c & 0x0F) + 0x02) do
					if (__o + 1 > __out_l) then
						break;
					end;
					
					output.content[__o + 1] = output.content[back_ptr + 1] or output.content[__o + 1];
					
					__o		= __o + 0x01;
					back_ptr	= back_ptr + 0x01;
				end;
			else
				if (__o < __out_l) then
					output.content[__o + 1] = string.pack("<B", (ResourceFile:Read(__in + 0x0000, "<B") or 0x00)) or output.content[__o + 1];
					
					__o		= __o + 0x01;
					__in		= __in + 0x01;
				end;
			end;
			
			flags		= flags >> 0x01;
		end;
	end;
	
	print(string.format("0x%08X / 0x%08X", __in, __in_l));
	
	output.size = #output.content;
	
	print(string.format("0x%08X", __o - __out));
	
	return output;
end;

return COMP;