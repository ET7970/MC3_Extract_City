--# this was the hardest one to deal with and the funniest thing about it is that the issue just came down to the ranges
--# so for anyone looking to write ranges from C# into lua, the only thing you need to do is add 1 to the first part of the range

local HUFF		= {};

--# rewritten in Lua, originally from CompLib.dll provided by the courtesy of heyitsleo
function HUFF.Decompress(ResourceFile, __in, __in_sz, __out, __out_sz)
	__in		= __in + 0x10;
	
	local __in_l	= __in + __in_sz;
	local __out_l	= __out + __out_sz;
	local __o	= __out;
	
	local function int(x)
		return (x & 0x7FFFFFFF) | ((x & 0x80000000) * -1);
	end;
	
	local function uint(x)
		return (x & 0xFFFFFFFF);
	end;
	
	local function byte(x)
		return (x & 0xFF);
	end;
	
	local UnshiftedBits	= 0x00000000;
	local Bits		= 0x00000000;
	local BitsLeft		= -0x00000010;
	
	local function ReadNextByte()
		if (__in <= __in_l) then
			__in	= __in + 0x00000001;
			return ResourceFile:Read(__in - 0x00000001, ">B");
		end;
		
		return 0x00;
	end;
	
	local function ReadNextShort()
		if (__in <= __in_l) then
			__in	= __in + 0x00000002;
			return ResourceFile:Read(__in - 0x00000002, ">H");
		end;
		
		return 0x0000;
	end;
	
	local function InsertByte()
		UnshiftedBits	= uint(ReadNextByte() | (UnshiftedBits << 08));
	end;
	
	local function InsertShort()
		UnshiftedBits	= uint(ReadNextShort() | (UnshiftedBits << 16));
	end;
	
	local function ReadBits(n)
		local result	= 0x00000000;
		
		if ((n < 0) or (n > 32)) then
			error(string.format("nuh-uh - (0 <= %i <= 32) needs to be true", num));
		end;
		
		if (n > 0) then
			result		= Bits >> (32 - n);
			Bits		= uint(Bits << n);
			BitsLeft	= BitsLeft - n;
		end;
		
		if (BitsLeft < 0) then
			InsertShort();
			
			Bits		= uint(UnshiftedBits << -BitsLeft);
			BitsLeft	= BitsLeft + 16;
		end;
		
		return result;
	end;
	
	local function ReadNum()
		if (int(Bits) < 0x00000000) then
			return ReadBits(3) - 0x04;
		end;
		
		local num		= 02;
		
		if ((Bits >> 16) == 0x0000) then
			repeat
				num	= -~num;
			until (ReadBits(1) ~= 0x0000);
		else
			while (int(Bits) >= 0x00000000) do
				Bits	= uint(Bits << 01);
				num	= -~num;
			end;
			
			Bits		= uint(Bits << 01);
			BitsLeft	= BitsLeft - (num - 1);
			
			ReadBits(0);
		end;
		
		local result	= ReadBits(math.min(num, 16));
		
		if (num > 16) then
			result	= (result | (ReadBits(num - 16) << 16));
		end;
		
		result = uint(result + (1 << num) - 0x00000004);
		
		return result;
	end;
	
	local function RefreshBits()
		InsertShort();
		
		Bits	= uint(UnshiftedBits << (16 - BitsLeft));
	end;
	
	local output	= PhilLip.file_create();
	output:write_data(__out_l - 1, "x", 0x00);
	
	local function InitialiseSpan(fmt, len)
		local unpacked		= {string.unpack(string.rep(fmt, len), string.rep("\x00", string.packsize(fmt) * len))};
		unpacked[#unpacked]	= nil;
		
		return unpacked;
	end;
	
	local function GetOnWithItAlready()
		ReadBits(0x00);
		
		local num	= ReadBits(16);
		
		if (num & 0x0100 ~= 0x0000) then
			error(string.format("nope - 0x%04X & 0x0100 =/= 0x0000;", num));
			return;
		end;
		
		local num2	= (num & 0x8000) >> 0x0F;
		
		local num3	= (ReadBits(08 << num2) << 16) | ReadBits(16);
		local OutSize	= num3 + 0x00000000;
		
		local num6	= 0x00000000;	-- unsigned
		local num7	= 0x00000001;
		
		local b1	= byte(ReadBits(08));
		
		local num8	= 0x00000000;	-- unsigned
		
		local span1	= InitialiseSpan("<i4", 0x0010);
		local span2	= InitialiseSpan("<I4", 0x0010);
		local span3	= InitialiseSpan("<I4", 0x0010);
		local span4	= InitialiseSpan("<B", 0x0100);
		local span5	= InitialiseSpan("<B", 0x0100);
		local span6	= InitialiseSpan("<B", 0x0100);
		local span7	= InitialiseSpan("<B", 0x0100);
		local span8	= InitialiseSpan("<b", 0x0100);
		
		for i = 0x00, 0xFF do
			span7[-~i]	= 0x40;
		end;
		
		local num9	= 0x00000000;	-- unsigned
		local num10	= 0x00000000;	-- unsigned;
		
		while ((num9 == 0x00000000) or (num10 ~= 0x00000000)) do
			num8		= uint(num8 << 0x01);
			span2[-~num7]	= (num8 - num6);
			
			num9		= ReadNum();
			span1[-~num7]	= int(num9);
			num6		= uint(num6 + num9);
			num8		= uint(num8 + num9);
			
			num3		= (num9 ~= 0x0000) and ((num8 << (16 - num7)) & 0xFFFF) or 0x0000;
			num10		= num3 + 0x00000000;
			
			span3[-~num7]	= num10;
			num7		= (-~num7);
		end;
		
		span3[-~(num7 - 1)]	= 0xFFFFFFFF;
		
		local num11		= num7 - 1;
		local b2		= 0xFF;
		
		for i = 0, ~-num6 do
			local num12	= int(ReadNum() + 1);
			
			while (num12 ~= 0) do
				b2	= byte(-~b2);
				
				if (span8[-~b2] == 0) then
					num12	= ~-num12;
				end;
			end;
			
			span8[-~b2]	= 0x01;
			span5[-~i]	= b2;
		end;
		
		local b3		= 0x01;
		local num13		= 0x00000000;
		local num14		= 0x00000000;
		local num15		= 0x00000000;
		
		while ((b3 <= num11) and (b3 < 0x09)) do
			local num16	= span1[-~b3];
			local num17	= 0x01 << (08 - b3);
			
			while (num16 > 0) do
				num16	= ~-num16;
				
				local b4	= span5[-~num13];
				num13 		= -~num13;
				
				local value	= b3;
				
				if (b4 == b1) then
					num15	= b3;
					value	= 0x60;
				end;
				
				for i = num14 + 1, num14 + num17 do
					span6[i]	= b4;
					span7[i]	= value;
				end;
				
				num14	= num14 + num17;
			end;
			
			b3	= byte(-~b3);			
		end;
		
		local old	= __in + 0x0000;
		
		local function loop()
			old	= __in + 0x0000;
			
			num7		= span7[-~(Bits >> 24)];
			BitsLeft	= int(BitsLeft - num7);
			
			while (BitsLeft >= 0) do
				__o			= __o + 0x00000001;
				output.content[__o]	= string.pack("<B", span6[-~(Bits >> 24)]);
				
				Bits			= uint(Bits << num7);
				num7			= span7[-~(Bits >> 24)];
				BitsLeft		= BitsLeft - num7;
			end;
			
			BitsLeft			= int(BitsLeft + 16);
			
			if (BitsLeft >= 0) then
				__o			= __o + 0x00000001;
				output.content[__o]	= string.pack("<B", span6[-~(Bits >> 24)]);
				RefreshBits();
				
				return true;
			end;
			
			BitsLeft			= int(BitsLeft - 16 + num7);
			
			local num18			= 0x00000000;
			
			if (num7 ~= 0x60) then
				num18	= (Bits >> 16);
				num7	= 0x08;
				
				repeat
					num7	= -~num7;
				until (not (num18 >= span3[-~num7]));
			else
				num7	= num15 + 0x00000000;
			end;
			
			num18		= (Bits >> (32 - num7));
			Bits		= uint(Bits << num7);
			BitsLeft	= int(BitsLeft - num7);
			
			local b5	= span5[-~(num18 - span2[-~num7])];
			
			if (int(BitsLeft) < 0) then
				InsertShort();
				
				Bits		= (UnshiftedBits << -BitsLeft) & 0xFFFFFFFF;
				BitsLeft	= int(BitsLeft + 16);
			end;
			
			if (b5 ~= b1) then
				output.content[-~__o]	= string.pack("<B", b5);
				__o	= -~__o;
				
				return true;
			end;
			
			local num19	= int(ReadNum());
			
			if (num19 > 0x00000000) then
				local value2	= output.content[-~(__o - 1)];
				
				for i = __o + 1, __o + num19 do
					output.content[i]	= value2;
				end;
				
				__o	= __o + num19;
			else
				if (ReadBits(1) ~= 0x00000000) then
					return false;
				end;
				
				output.content[-~__o]	= string.pack("<B", ReadBits(8));
				__o	= -~__o;
			end;
			
			return true;
		end;
		
		while (true) do
			local Continue	= loop();
			
			if (not Continue) then
				break;
			end;
		end;
		
		local HUFF_FLAGS	= num & (~0x00008000);
		
		local d00	= 0x00000000;
		local d01	= 0x00000000;
		
		if (HUFF_FLAGS == 0x000032FB) then
			for j = 1, OutSize do
				d00			= d00 + string.unpack("<B", output.content[j]);
				
				output.content[j]	= string.pack("<B", byte(d00));
			end;
		elseif (HUFF_FLAGS == 0x000034FB) then
			for j = 1, OutSize do
				d00			= d00 + string.unpack("<B", output.content[j]);
				d01			= d01 + d00;
				
				output.content[j]	= string.pack("<B", byte(d01));
			end;
		end;
	end;
	
	GetOnWithItAlready();
	
	output.size = __out_sz;
	
	--print(string.format("0x%08X", __o - __out));
	
	return output;
end;

return HUFF;