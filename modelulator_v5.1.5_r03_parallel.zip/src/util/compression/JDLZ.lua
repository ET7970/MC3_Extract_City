local JDLZ		= {};

--# rewritten in Lua, originally from QuickBMS by Luigi Auriemma
function JDLZ.Decompress(ResourceFile, __in, __in_sz, __out, __out_sz)
	__in		= __in + 0x10;
	__in_sz		= __in_sz - 0x10;
	
	local __in_l	= __in + __in_sz;
	local __out_l	= __out + __out_sz;
	local __o	= __out;
	local __flags1	= 0x00000001;
	local __flags2	= 0x00000001;
	
	local output	= PhilLip.file_create();
	
	while ((__in < __in_l) and (__o < __out_l)) do
		if (__flags1 == 0x00000001) then
			__flags1	= ResourceFile:Read(__in, "<B") | 0x00000100;
			__in		= __in + 0x0001;
		end;
		
		if (__flags2 == 0x00000001) then
			__flags2	= ResourceFile:Read(__in, "<B") | 0x00000100;
			__in		= __in + 0x0001;
		end;
		
		if (__flags1 & 0x00000001 == 0x00000001) then
			local f2_odd	= (__flags2 & 0x01);
			local f2_even	= (f2_odd ~ 0x01);
			
			local t		= 0x00000001 | (f2_even << 0x04);
			local length	= 0x00000003;
			
			local a		= ResourceFile:Read(__in + 0x0000, "<B");
			local b		= ResourceFile:Read(__in + 0x0001, "<B");
			
			local mask0	= (0x0F | (f2_even << 0x4));
			local mask1	= mask0 ~ 0xFF;
			
			local __shift	= 0x03 + (f2_odd);
			
			local a0	= a & mask0;
			local a1	= b | ((a & mask1) << __shift);
			
			t		= t + a0 * f2_odd + a1 * f2_even;
			length		= length + a0 * f2_even + a1 * f2_odd;
			
			__in		= __in + 0x0002;
			
			if ((__o - t) < __out) then
				return;
			end;
			
			for i = 1, length do
				if ((__o + 1) > __out_l) then
					break;
				end;
				
				output.content[__o + 1] = output.content[__o - t + 1];
				__o	= __o + 1;
			end;
			
			__flags2	= __flags2 >> 0x01;
		else
			if (__o < __out_l) then
				output.content[__o + 1] = string.pack("<B", ResourceFile:Read(__in + 0x0000, "<B"));
				__o	= __o + 1;
				__in	= __in + 1;
			end;
		end;
		
		__flags1	= __flags1 >> 0x01;
	end;
	
	--print(string.format("0x%08X", __o - __out));
	
	output.size = #output.content;
	
	return output;
end;

return JDLZ;