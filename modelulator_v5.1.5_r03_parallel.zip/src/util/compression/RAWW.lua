local RAWW		= {};

--# i completely forgot about this one
function RAWW.Decompress(ResourceFile, __in, __in_sz, __out, __out_sz)
	__in		= __in + 0x10;
	__in_sz		= __in_sz - 0x10;
	
	local __in_l	= __in + __in_sz;
	local __out_l	= __out + __out_sz;
	local __o	= __out;
	
	local function int(x)
		return (x & 0x7FFFFFFF) | ((x & 0x80000000) * -1);
	end;
	
	local function uint(x)
		return (x & 0xFFFFFFFF);
	end;
	
	local function byte(x)
		return (x & 0xFF);
	end;
	
	local output	= PhilLip.file_create();
	
	for Address = __in, ~-__in_l, 0x00000001 do
		local Byte		= string.pack(">B", ResourceFile:Read(Address, ">B"));
		
		out			= -~out;
		output.content[out]	= Byte;
	end;
	
	output.size	= __out_sz;
	
	return output;
end;

return RAWW;