local RFPK		= {};

--# rewritten in Lua, originally from CompLib.dll provided by the courtesy of heyitsleo
function RFPK.Decompress(__in, __in_sz, __out, __out_sz)
	__in		= __in + 0x10;
	
	local __in_l	= __in + __in_sz;
	local __out_l	= __out + __out_sz;
	local __o	= __out;
	
	local function int(x)
		return (x & 0x7FFFFFFF) | ((x & 0x80000000) * -1);
	end;
	
	local function uint(x)
		return (x & 0xFFFFFFFF);
	end;
	
	local function byte(x)
		return (x & 0xFF);
	end;
	
	local output	= PhilLip.file_create();
	
	output.size	= #output.content;
	
	return output;
end;

return RFPK;