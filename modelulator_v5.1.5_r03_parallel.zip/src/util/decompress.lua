local Compression	=
{
	RAWW		= require("src.util.compression.RAWW");
	COMP		= require("src.util.compression.COMP");
	JDLZ		= require("src.util.compression.JDLZ");
	HUFF		= require("src.util.compression.HUFF");
	RFPK		= require("src.util.compression.RFPK");
};

local function Decompress(ResourceFile, Address)
	Address			= Address or 0x00000000;
	
	local CompHeader	= ResourceFile:Read(Address + 0x00, "<c4");
	local CompFlag		= ResourceFile:Read(Address + 0x04, "<B");
	local CompHeaderSize	= ResourceFile:Read(Address + 0x05, "<B");
	local CompUnk		= ResourceFile:Read(Address + 0x06, "<H");
	local UncompSize	= ResourceFile:Read(Address + 0x08, "<I4");
	local CompSize		= ResourceFile:Read(Address + 0x0C, "<I4");
	
	print(string.format("%s 0x%02X 0x%02X 0x%02X 0x%08X 0x%08X", CompHeader, CompFlag, CompHeaderSize, CompUnk, UncompSize, CompSize));
	
	if (Compression[CompHeader]) then
		return Compression[CompHeader].Decompress(ResourceFile, Address, CompSize, 0x00000000, UncompSize);
	end;
end;

return Decompress;