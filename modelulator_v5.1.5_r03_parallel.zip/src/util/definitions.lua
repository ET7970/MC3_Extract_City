--[[
FLAGs are a means of setting booleans - they work on the principle that
they hold a predetermined or default boolean value *VALUE*,
their presence in the prompt is a boolean value *USED*,
and that the resultant boolean value *RESULT* is the evaluated as:
RESULT = (VALUE != USED)
In other words:
If you make a request about a flag that hasn't been put up, it's likely because you want it put up;
If you make a request about a flag that is already up, it's likely because you want to take it down.

Flags use a forward slash (/) as a prefix,
which you can also think of as the base of a flag if it helps you remember.

example:
// FLAG0 = false;
// FLAG1 = true;

>run				// FLAG0 = false; FLAG1 = true;
>run /FLAG0			// FLAG0 = true;  FLAG1 = true;
>run /FLAG1			// FLAG0 = false; FLAG1 = false;
>run /FLAG0 /FLAG1		// FLAG0 = true;  FLAG1 = false;

This principle extends into somewhat of an "extra feature",
which is that if more than one instance of a flag is present in the prompt,
the value of that flag will flip that many times.
This is to keep the code simpler and to make tinkering with
the tool a bit more flexible (like debugging).

example:
// FLAG0 = false;

>run /FLAG0			// FLAG0 = true;
>run /FLAG0 /FLAG0		// FLAG0 = false;
>run /FLAG0 /FLAG0 /FLAG0	// FLAG0 = true;

You should probably do this as little as possible to avoid clutter.
--]]

--[[
PARAMETERs are a way of setting more specific values -
in the case of most command line programs, they will often
make use of Input / Output parameters.

Parameters are prefixed with a single dash (-),
which should be pretty familiar to linux users
and to any who has used a command line program before.

example:
// Input	= "";
// Output	= "";

>run -i .\Folder			// Input = ".\\Folder";	 Output = "";
>run -o .\Folder			// Input = "";		 Output = ".\\Folder";
>run -i .\Folder1 -o .\Folder2	// Input = ".\\Folder1";	 Output = ".\\Folder2";

The thing about parameters that you have to look out for is spaces,
because spaces are seen as a separator in a command prompt.

example:
// Input	= "";
// Output	= "";

>run -i Desktop\Porn -o Desktop\Also Porn		 // Input = "Desktop\\Porn";	 Output = "Desktop\\Also";
>run -i .\Folder 1 -o .\Folder 2			 // Input = ".\\Folder";	 Output = ".\\Folder";
>run -i C:\Program Files -o C:\Program Files (x86) // Input = "C:\\Program";	 Output = "C:\\Program";

As shown above, the directories with spaces in them result in
the names getting truncated down to the ones without any spaces -
On top of that, because spaces are separators for arguments in a command prompt,
this leads to you putting in more arguments than you may have intended, and you are greeted
either by a funny error, for instance, about how "Porn" is not a recognized / valid command,
or by a vaguely condescending and generic message such as: "The system cannot find the path specified."

This can be easily remedied by making use of "quotation marks",
which act as a "container" of sorts for values and allow for spaces.
These quotation marks will then be removed before the arguments are passed to the program.

example:
// Input	= "";
// Output	= "";

>run -i Desktop\Porn -o "Desktop\Also Porn"		// Input = "Desktop\\Porn";     Output = "Desktop\\Also Porn";
>run -i "C:\Program Files" -o "C:\Program Files (x86)"	// Input = "C:\\Program Files"; Output = "C:\\Program Files (x86)";
>run -i ".\Folder1" -o ".\Folder2"				// Input = ".\\Folder1";        Output = ".\\Folder2";

You can also use quotes when there aren't any spaces in the directory,
though it's recommended that you use them anyway for consistency.
--]]

--[[
ARRAYPARAMETERs are an extension of PARAMETERs -
whereas parameters take in only one value,
array parameters can take in multiple values, and
they are particularly helpful if you're using a system
that takes in or requires multiple inputs / outputs.

Array parameters are prefixed with a plus sign (+),
which was chosen to indicate that you're adding a value to a given array.

example:
// InputArray		= {};
// OutputArray	= {};

>run \
+ia ".\BoobaPictures\ladyboob00.jpg" \
+oa ".\BoobaPictures\ladyboob00.png"
/*
InputArray	=
{
	[1]	= ".\\BoobaPictures\\ladyboob00.jpg"
};
OutputArray	=
{
	[1]	= ".\\BoobaPictures\\ladyboob00.png"
};
*/

The above example demonstrates how values get put into tables,
rather than the values being put into strings, which can only hold one value.

This helps to eliminate the need for possible alternative methods,
such as modifying regular parameters to take in more than one value
by using a separator in the input value -- Which works okay if you have
no problem putting more restrictions on valid characters within file names.

example:
// InputArray		= {};
// Output		= "";
>run \
+ia "C:\Program Files (x86)\Want For Torque\Global\InGameA.bun" \
+ia "C:\Program Files (x86)\Want For Torque\Global\InGameB.bun" \
-o ".\OutputFiles\Textures\\Global\*.png"
/*
InputArray	=
{
	[1]	= "C:\\Program Files (x86)\\Want For Torque\\Global\InGameA.bun",
	[2]	= "C:\\Program Files (x86)\\Want For Torque\\Global\InGameB.bun"
};
Output		= ".\\Output\\Global\\Textures\\*.png";
*/

As shown above, we have a mix of multiple inputs and one output,
where the multiple inputs allow us to make use of specific files.
Since the output value covers both the file directory and naming scheme
with the use of a wildcard, using an array is not required and actually
helps to reduce the number of arguments.

However, typing the directory name for each input is a bit of a long process.
To make this much easier for users, you can another mix
of regular parameters and array parameters by utilising
Input as a path, and InputArray as a list of files.

example:
// Input	= "";
// InputArray	= {};
// Output	= "";
>run \
-i "C:\Program Files (x86)\Want For Torque\Global" \
+ia "InGameA.bun" \
+ia "InGameB.bun" \
-o ".\OutputFiles\Textures\\Global\*.png"
/*
Input		= "C:\\Program Files (x86)\\Want For Torque\\Global";
InputArray	=
{
	[1]	= "InGameA.bun",
	[2]	= "InGameB.bun"
};
Output		= ".\\Output\\Global\\Textures\\*.png";
*/

Input could also do what Output does and make use of a wildcard,
though thats a lesson for another time.

For a large number of specific files in different directories,
you'd be better off using a batch script to generate the arguments
for that and passing them off to the program -- Truth be told,
you should already be doing that to begin with.
--]]

--[[
COMMENTs are just comments.
While very out of place for a command line program,
comments are implemented for convenience to use as
markers, notes, and for debugging purposes.
They do end up getting passed to the program, though they
aren't really used for anything on their own -
That's something left up to the creator of the program you're using.
In some cases, a comment may be printed to the console.

Comments are prefixed by (#), which is either
a pound sign, an octothorpe, a number sign, a hash-tag, a crosshatch,
or just about any other version that was not listed here.
Due to its generic nature, the symbol can also be seen as a blank slate / canvas,
which the prefix is meant to reflect.

example:
// Input		= "";
// Output		= "";

>run #-i -o C:\Folder		// Input = "";		Output = "C:\Folder";
>run -i #-o C:\Folder		// Input = "C:\\Folder";	Output = "";
>run #-i #-o C:\Folder	// Input = "";		Output = "";

// PrintComments	= false;

>run #/PrintComments		// PrintComments = false;	// heh
>run /PrintComments #Hello	// PrintComments = true;
Hello

you can also use comments in tandem with quotation marks for some cool stuff

example:
// PrintComments	= false;

>run #"some clever title" /PrintComments	// PrintComments = true;
some clever title
>run #"this flag represents my shame" #/PrintComments #"all hidden away"	// PrintComments = false;

oh btw if a program uses this and isnt open source, dont trust it
even if it is open source, you should prolly check just to be safe
--]]

--[[
## BONUS ##
you can have more than one prefix
that means you can do something like ---------------input or ///////////////help
and itll still work as normal

if you have an assortment of different prefixes, then the front-most prefix is used
that means -/#input is the same as -input
--]]

--[[
-- C++
enum struct LuaType
{
	LUA_TYPE_NIL		= 0;
	LUA_TYPE_BOOLEAN	= 1;
	LUA_TYPE_NUMBER	= 2;
	LUA_TYPE_STRING	= 3;
	LUA_TYPE_FUNCTION	= 4;
	LUA_TYPE_USERDATA	= 5;
	LUA_TYPE_THREAD	= 6;
	LUA_TYPE_TABLE	= 7;
	NUM_LUA_TYPES		= 8;
};

-- am i gonna use this
bool UseEnumAs_SomeSortOfReference = true;
--bool UseEnumAs_AnActualThing	 = ((math.random(0, 1) != math.random(0, 1)) ? math.random(0, 1) : math.random(0, 1)) == math.random(0, 1);
bool UseEnumAs_AnActualThing		= false;
--]]

local Definitions =
{
	Types			=
	{
		{
			NAME	= {"FLAG", "FLAGS"};
			PREFIX	= "/";
			STRUCT	=
			{
				"NAME";
				"DESC";
				"TAGS";
				"USED";
				"VALUE";
			};
			INFO	=
			{
				"NAME";
				--"USED";
				"VALUE";
			};
			SYNTAX	= "[%s<%s>]";
		};
		{
			NAME	= {"PARAMETER", "PARAMETERS"};
			PREFIX	= "-";
			STRUCT	=
			{
				"NAME";
				"DESC";
				"TAGS";
				"VALUETYPE";
				"REQUIRED";
				"USED";
				"VALID";
				"VALUE";
			};
			INFO	=
			{
				"NAME";
				--"USED";
				"VALID";
				"VALUE";
			};
			SYNTAX	= "[%s<%s> <value>]";
		};
		{
			NAME	= {"ARRAYPARAMETER", "ARRAYPARAMETERS"};
			PREFIX	= "+";
			STRUCT	=
			{
				"NAME";
				"DESC";
				"TAGS";
				"VALUETYPE";
				"REQUIRED";
				"USED";
				"VALUES";
			};
			INFO	=
			{
				"NAME";
				--"USED";
				"VALUES";
			};
			SYNTAX	= "[%s<%s> <value>]";
		};
		{
			NAME	= {"COMMENT", "COMMENTS"};
			PREFIX	= "#";
			SYNTAX	= "[%s<%s>]";
		};
	};
	Items			=
	{
		FLAG		=
		{
			{
				NAME		= "ShowHelp";
				DESC		= "Display Help Screen";
				TAGS		= {"?", "help", "showhelp", "show-help"};
				USED		= false;
				VALUE		= false;
			};
			{
				NAME		= "ShowTypes";
				DESC		= "Display List of Argument Types";
				TAGS		= {"t", "types", "showtypes", "show-types"};
				USED		= false;
				VALUE		= false;
			};
			{
				NAME		= "ShowInfo";
				DESC		= "Show Input Info";
				TAGS		= {"i", "info", "showinfo", "show-info"};
				USED		= false;
				VALUE		= false;
			};
			{
				NAME		= "PrintComments";
				DESC		= "Writes any Comments to the Output (Console)";
				TAGS		= {"pc", "print-comments"};
				USED		= false;
				VALUE		= false;
			};
			{
				NAME		= "LoadTest";
				DESC		= "loads test program";
				TAGS		= {"test", "loadtest", "load-test"};
				USED		= false;
				VALUE		= false;
			};
			{
				NAME		= "Clear";
				DESC		= "Clears Console before Running the Program";
				TAGS		= {"cl", "cls", "clr", "clear", "clearscreen"};
				USED		= false;
				VALUE		= false;
			};
			-- USER
			{
				NAME		= "Build";
				DESC		= "Shows build information of the tool you're using";
				TAGS		= {"b", "build"};
				USED		= false;
				VALUE		= false;
			};
			{
				NAME		= "ProcessOnly";
				DESC		= "Only Processes the Data; Does Not Produce Output";
				TAGS		= {"po", "process-only"};
				USED		= false;
				VALUE		= false;
			};
		};
		PARAMETER	=
		{
			{
				NAME		= "Help";
				DESC		= "Gives Help with Syntax";
				TAGS		= {"?", "help"};
				VALUETYPE	= "Argument | ArgumentType";
				REQUIRED	= false;
				USED		= false;
				VALID		= {};
				VALUE		= "";
			};
			{
				NAME		= "Input";
				DESC		= "Sets Input File Path";
				TAGS		= {"i", "in", "input"};
				VALUETYPE	= "Path";
				REQUIRED	= true;
				USED		= false;
				VALID		= {};
				VALUE		= "";
			};
			{
				NAME		= "Output";
				DESC		= "Sets Output File Path";
				TAGS		= {"o", "out", "output"};
				VALUETYPE	= "Path";
				REQUIRED	= true;
				USED		= false;
				VALID		= {};
				VALUE		= "";
			};
			-- USER
			{
				NAME		= "UserParam";
				DESC		= "generic user parameter\n(does nothing)";
				TAGS		= {"user-param", "userparam"};
				VALUETYPE	= "whatever";
				REQUIRED	= false;
				USED		= false;
				VALID		= {};
				VALUE		= "";
			};
			{
				NAME		= "Pipeline";
				DESC		= "Sets Pipeline";
				TAGS		= {"p", "pipeline"};
				VALUETYPE	= "ModelulatorEnum.Pipeline";
				REQUIRED	= true;
				USED		= false;
				VALID		= {"GAMECUBE", "PC", "PSX", "PSX2", "PS3", "REVOLUTION", "XBOX", "XENON"};
				VALUE		= "";
			};
			{
				NAME		= "Game";
				DESC		= "Sets EA Black Box NFS Game";
				TAGS		= {"g", "game"};
				VALUETYPE	= "ModelulatorEnum.Game";
				REQUIRED	= true;
				USED		= false;
				VALID		= {"NASCAR2001", "NASCARTHUNDER2002", "NASCARTHUNDER2003", "NASCARTHUNDER2004", "HOTPURSUIT2_A098", "HOTPURSUIT2", "UNDERGROUNDPROTO", "UNDERGROUND", "UNDERGROUND2", "MOSTWANTED_DEMO", "MOSTWANTED", "CARBON", "PROSTREET", "NITRO", "UNDERCOVER", "WORLD"};
				VALUE		= "";
			};
			{
				NAME		= "StreamFile";
				DESC		= "Sets Input Stream File";
				TAGS		= {"stream-file", "streamfile", "stream"};
				VALUETYPE	= "FileName";
				REQUIRED	= true;
				USED		= false;
				VALID		= {};
				VALUE		= "";
			};
			{
				NAME		= "TrackFile";
				DESC		= "(Use with Streaming Files) Sets Input Track File";
				TAGS		= {"track-file", "trackfile", "track"};
				VALUETYPE	= "FileName";
				REQUIRED	= true;
				USED		= false;
				VALID		= {};
				VALUE		= "";
			};
		};
		ARRAYPARAMETER	=
		{
			{
				NAME		= "InputArray";
				DESC		= "Sets the List of Input Files";
				TAGS		= {"i", "in", "input"};
				VALUETYPE	= "Path";
				REQUIRED	= true;
				USED		= false;
				VALUES		= {};
			};
			{
				NAME		= "OutputArray";
				DESC		= "Sets the List of Output Files";
				TAGS		= {"o", "out", "output"};
				VALUETYPE	= "Path";
				REQUIRED	= true;
				USED		= false;
				VALUES		= {};
			};
		};
	};
};

return Definitions;