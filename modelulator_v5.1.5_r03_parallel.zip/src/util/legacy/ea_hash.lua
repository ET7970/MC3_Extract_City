local hash = {};

hash.bin =
function(str, len)
	len = len or #str;
	str = str .. string.char(0);
	
	local EAX = 0;
	local ECX = 0;
	local CL = 0;
	local EDX = 1;
	
	local function fix32()
		EAX = EAX & 0xFFFFFFFF;
		ECX = ECX & 0xFFFFFFFF;
		CL = (CL & 0xFF) | ((CL & 0x80) * (~0x1));
		EDX = EDX & 0xFFFFFFFF;
	end;
	
	CL = string.byte(string.sub(str,EDX,EDX));
	
	EAX = EAX | 0xFFFFFFFF;
	if (CL~=0x0) then
		while (true) do
			EAX = EAX * 0x21; fix32();
			ECX = CL; fix32();
			EAX = EAX + ECX; fix32();
			EDX = EDX + 1; fix32();
			CL = string.byte(str,EDX+1,EDX+1); fix32();
			if (EDX >= len + 1) then break; end;
		end;
	end;
	
	return EAX;
end;

hash.vlt =
function(str)
	local len = #str;
	
	local ECX = 0x00000000;
	local EAX = 0xABCDEF00;
	local EDX = len+0x0;
	local EDI = 0x9E3779B9;
	local EBP = EDX+0x0;
	local EBX = EDI+0x0;
	local ESI = EAX+0x0;
	
	local function fix32()
		EAX = EAX & 0xFFFFFFFF;
		EBX = EBX & 0xFFFFFFFF;
		ECX = ECX & 0xFFFFFFFF;
		EDX = EDX & 0xFFFFFFFF;
		ESI = ESI & 0xFFFFFFFF;
		EDI = EDI & 0xFFFFFFFF;
		EBP = EBP & 0xFFFFFFFF;
	end;
	
	if (EDX>0xB) then
		EAX = 0xAAAAAAAB * EDX;
		EDX = ((EAX & 0xFFFFFFFF00000000) >> 0x20);
		EAX = EAX & 0xFFFFFFFF;
		
		EDX = EDX >> 0x3; fix32();
		
		local savedEDX = EDX+0x0;
		
		while (true) do
			EAX = string.byte(str,ECX+0x8,ECX+0x8); fix32();
			
			EDX = string.byte(str,ECX+0x7,ECX+0x7); fix32();
			EAX = (EAX << 0x8) + EDX;
			
			EDX = string.byte(str,ECX+0x6,ECX+0x6); fix32();
			EAX = (EAX << 0x8) + EDX;
			
			EDX = string.byte(str,ECX+0x5,ECX+0x5); fix32();
			EDX = EDX + EDI;
			EAX = (EAX << 0x8); fix32();
			
			EDI = EDX + EAX; fix32();
			
			EAX = string.byte(str,ECX+0xC,ECX+0xC); fix32();
			EDX = string.byte(str,ECX+0xB,ECX+0xB); fix32();
			EAX = (EAX << 0x8) + EDX; fix32();
			
			EDX = string.byte(str,ECX+0xA,ECX+0xA); fix32();
			EAX = (EAX << 0x8) + EDX; fix32();
			
			EDX = string.byte(str,ECX+0x9,ECX+0x9); fix32();
			EDX = EDX + ESI; fix32();
			EAX = (EAX << 0x8); fix32();
			
			ESI = EDX + EAX; fix32();
			
			EAX = string.byte(str,ECX+0x4,ECX+0x4) or 0; fix32();
			EDX = string.byte(str,ECX+0x3,ECX+0x3); fix32();
			EAX = (EAX << 0x8) + EDX; fix32();
			
			EDX = string.byte(str,ECX+0x2,ECX+0x2); fix32();
			EAX = (EAX << 0x8) + EDX; fix32();
			
			EDX = string.byte(str,ECX+0x1,ECX+0x1); fix32();
			EAX = (EAX << 0x8) + EDX; fix32();
			
			EAX = EAX - ESI - EDI; fix32();
			
			EDI = EDI - ESI; fix32();
			
			EDX = ESI >> 0xD; fix32();
			
			EAX = (EAX + EBX); fix32();
			EAX = EAX ~ EDX; fix32();
			
			EDI = EDI - EAX; fix32();
			EDX = EAX + 0x0; fix32();
			EDX = EDX << 0x8; fix32();
			EDI = EDI ~ EDX; fix32();
			
			ESI = ESI - EDI; fix32();
			ESI = ESI - EAX; fix32();
			
			EDX = EDI >> 0xD; fix32();
			ESI = ESI ~ EDX; fix32();
			
			EAX = EAX - ESI; fix32();
			EAX = EAX - EDI; fix32();
			EDX = ESI >> 0xC; fix32();
			EAX = EAX ~ EDX; fix32();
			
			EDI = EDI - ESI; fix32();
			EDI = EDI - EAX; fix32();
			EDX = EAX << 0x10; fix32();
			EDI = EDI ~ EDX; fix32();
			
			ESI = ESI - EDI; fix32();
			ESI = ESI - EAX; fix32();
			EDX = EDI >> 0x5; fix32();
			ESI = ESI ~ EDX; fix32();
			
			EAX = EAX - ESI; fix32();
			EAX = EAX - EDI; fix32();
			EDX = ESI >> 0x3; fix32();
			EAX = EAX ~ EDX; fix32();
			
			EDI = EDI - ESI; fix32();
			EBX = EAX + 0x0; fix32();
			EAX = EAX << 0xA; fix32();
			EDI = EDI - EBX; fix32();
			EDI = EDI ~ EAX; fix32();
			
			EAX = savedEDX; fix32();
			
			ESI = ESI - EDI; fix32();
			EDX = EDI; fix32();
			ESI = ESI - EBX; fix32();
			EDX = EDX >> 0xF; fix32();
			ESI = ESI ~ EDX; fix32();
			
			ECX = ECX + 0xC; fix32();
			EBP = EBP - 0xC; fix32();
			EAX = EAX - 0x1; fix32();
			
			savedEDX = EAX; fix32();
			
			if (savedEDX==0) then break; end
		end;
		EDX = len;
	end;
	
	ESI = ESI + EDX; fix32();
	EBP = EBP - 0x1; fix32();
	
	local switch = {};
	switch[0xA] = function()
		EAX = string.byte(string.sub(str,ECX+0xB,ECX+0xB)); fix32();
		EAX = EAX << 0x18; fix32();
		ESI = ESI + EAX; fix32();
	end;
	switch[0x9] = function()
		EDX = string.byte(string.sub(str,ECX+0xA,ECX+0xA)); fix32();
		EDX = EDX << 0x10; fix32();
		ESI = ESI + EDX; fix32();
	end;
	switch[0x8] = function()
		EAX = string.byte(string.sub(str,ECX+0x9,ECX+0x9)); fix32();
		EAX = EAX << 0x8; fix32();
		ESI = ESI + EAX; fix32();
	end;
	switch[0x7] = function()
		EDX = string.byte(string.sub(str,ECX+0x8,ECX+0x8)); fix32();
		EDX = EDX << 0x18;
		EDI = EDI + EDX; fix32();
	end;
	switch[0x6] = function()
		EAX = string.byte(string.sub(str,ECX+0x7,ECX+0x7)); fix32();
		EAX = EAX << 0x10;
		EDI = EDI + EAX; fix32();
	end;
	switch[0x5] = function()
		EDX = string.byte(string.sub(str,ECX+0x6,ECX+0x6)); fix32();
		EDX = EDX << 0x8; fix32();
		EDI = EDI + EDX; fix32();
	end;
	switch[0x4] = function()
		EAX = string.byte(string.sub(str,ECX+0x5,ECX+0x5)); fix32();
		EDI = EDI + EAX; fix32();
	end;
	switch[0x3] = function()
		EDX = string.byte(string.sub(str,ECX+0x4,ECX+0x4)); fix32();
		EDX = EDX << 0x18; fix32();
		EBX = EBX + EDX; fix32();
	end;
	switch[0x2] = function()
		EAX = string.byte(string.sub(str,ECX+0x3,ECX+0x3)); fix32();
		EAX = EAX << 0x10; fix32();
		EBX = EBX + EAX; fix32();
	end;
	switch[0x1] = function()
		EDX = string.byte(string.sub(str,ECX+0x2,ECX+0x2)); fix32();
		EDX = EDX << 0x8; fix32();
		EBX = EBX + EDX; fix32();
	end;
	switch[0x0] = function()
		EAX = string.byte(string.sub(str,ECX+0x1,ECX+0x1)); fix32();
		EBX = EBX + EAX; fix32();
	end;
	switch[-0x1] = function()
		EBX = EBX - ESI; fix32();
		EBX = EBX - EDI; fix32();
		EDI = EDI - ESI; fix32();
		ECX = ESI; fix32();
		ECX = ECX >> 0xD; fix32();
		EBX = EBX ~ ECX; fix32();

		EDI = EDI - EBX; fix32();
		EDX = EBX; fix32();
		EDX = EDX << 0x8; fix32();
		EDI = EDI ~ EDX; fix32();

		ESI = ESI - EDI; fix32();
		ESI = ESI - EBX; fix32();
		EAX = EDI; fix32();
		EAX = EAX >> 0xD; fix32();
		ESI = ESI ~ EAX; fix32();

		EBX = EBX - ESI; fix32();
		EBX = EBX - EDI; fix32();
		EDI = EDI - ESI; fix32();
		ECX = ESI; fix32();
		ECX = ECX >> 0xC; fix32();
		EBX = EBX ~ ECX; fix32();

		EDI = EDI - EBX; fix32();
		EDX = EBX; fix32();
		EDX = EDX << 0x10; fix32();
		EDI = EDI ~ EDX; fix32();

		ESI = ESI - EDI; fix32();
		EAX = EDI; fix32();
		ESI = ESI - EBX; fix32();
		EAX = EAX >> 0x5; fix32();
		ESI = ESI ~ EAX; fix32();

		EAX = ESI; fix32();

		EBX = EBX - EAX; fix32();
		EBX = EBX - EDI; fix32();
		ECX = EAX; fix32();
		EDI = EDI - EAX; fix32();
		ECX = ECX >> 0x3; fix32();
		EBX = EBX ~ ECX; fix32();

		EDI = EDI - EBX; fix32();
		EDX = EBX; fix32();
		EDX = EDX << 0xA; fix32();
		EDI = EDI ~ EDX; fix32();

		EAX = EAX - EDI; fix32();
		EAX = EAX - EBX; fix32();
		EDI = EDI >> 0xF; fix32();
		EAX = EAX ~ EDI; fix32();
	end;
	
	if (EBP>0xA) then
		switch[-0x1]();
		return EAX;
	end;
	
	while (true) do
		switch[EBP]();
		if (EBP==0xFFFFFFFF) then return EAX; end
		EBP = EBP - 1;
	end;
end;

return hash;