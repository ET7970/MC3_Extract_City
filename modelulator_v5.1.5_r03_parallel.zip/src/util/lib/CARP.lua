local CARP		= {};
CARP.ResourceFile	= nil;

local Category		= {};

function Category:Category(ID, Info, Size, Count, Offset)
	if (_ENV.Config.BigEndian) then
		local InfoRev = 0x00;
		
		for i = 0x00, 0x07 do
			InfoRev	= InfoRev << 0x01;
			InfoRev	= InfoRev | (Info & 0x01);
			Info	= Info >> 0x01;
		end;
		
		Info = InfoRev;
	end;
	
	--print(string.format("0x%02X", Info));
	
	local Struct	=
	{
		Index		= -1;
		
		IsHeader	= false;
		IsContainer	= false;
		NumSubheaders	= 0;
		
		ID		= ID;
		
		Info		= Info;
		
		Size		= Size;
		Count		= Count;
		Offset		= Offset;
		
		AbsoluteOffset	= 0x00000000;
		
		--Items		= {};
	};
	
	if (Info & 0x01 == 0x01) then
		Struct.Index	= (ID & 0x7FFF) | (-1 * (ID & 0x8000));
		Struct.ID	= string.pack(">H", (ID >> 0x10) & 0xFFFF);
	else
		Struct.ID	= string.pack(">I4", ID);
	end;
	
	if ((Info & 0x08 == 0x08) or (Info & 0x10 == 0x10) or (Info & 0xE0 > 0)) then
		Struct.IsContainer	= true;
		Struct.IsHeader		= (Info & 0x08 == 0x08);
		Struct.NumSubheaders	= (_ENV.Config.BigEndian == true) and Struct.Size or ((Info & 0xE0) >> 5);
		
		Struct.Offset		= Offset << ((Info & 0x02) * 0x02);
	end;
	
	return Struct;
end;

function CARP:Read(Address, Base)
	Base = Base or 0x00000000;
	
	local fmt = _ENV.Config.BigEndian and ">" or "<";
	
	if ((CARP.ResourceFile == nil) or ((CARP.ResourceFile ~= nil) and ((CARP.ResourceFile.Type ~= "PhilLip2File") or (CARP.ResourceFile.Size <= 0x00000000)))) then
		return;
	end;
	
	if ((Address == nil) or (CARP.ResourceFile:Read(Address, fmt .. "I4") ~= 0x43415250)) then
		print("not a resource pack!");
		return;
	end;
	
	local CARPPointer	= 0x00000000 + Address;
	local BasePointer	= 0x00000000 + Address;
	local CARPObject	= {};
	
	local Hierarchy		= {};
	local SubHeaders	= 0;
	
	while (true) do
		local NumHierarchy			= #Hierarchy;
		
		local ID, Info, Size, Count, Offset	= CARP.ResourceFile:Read(CARPPointer, fmt .. "I4 B i3 i4 I4");
		local NewCategory			= Category:Category(ID, Info, Size, Count, Offset - Base);
		
		local RelativeToAddress			= 0x00000000;
		local RelativityMode			= (NewCategory.Info >> 0x1) & 0x1;
		
		RelativeToAddress			= RelativeToAddress | (CARPPointer * (RelativityMode ~ 0x0));
		RelativeToAddress			= RelativeToAddress | (BasePointer * (RelativityMode ~ 0x1));
		
		SubHeaders				= SubHeaders + NewCategory.NumSubheaders;
		
		NewCategory.AbsoluteOffset		= RelativeToAddress + NewCategory.Offset;
		
		if (NewCategory.Index >= 0) then
			print(string.format("Offset@x%08X|", NewCategory.AbsoluteOffset) .. string.rep("\t", NumHierarchy) .. string.format("%s[%i] : 0x%02X 0x%06X 0x%08X", NewCategory.ID, NewCategory.Index, NewCategory.Info, NewCategory.Size, NewCategory.Count));
		else
			print(string.format("Offset@x%08X|", NewCategory.AbsoluteOffset) .. string.rep("\t", NumHierarchy) .. string.format("%s : 0x%02X 0x%06X 0x%08X", NewCategory.ID, NewCategory.Info, NewCategory.Size, NewCategory.Count));
		end;
		
		local Parent	= (#Hierarchy <= 0) and CARPObject or Hierarchy[1].obj;
		
		if ((NewCategory.Index ~= nil) and (NewCategory.Index >= 0)) then
			if (Parent[NewCategory.ID] == nil) then
				Parent[NewCategory.ID]	= {};
			end;
			
			Parent[NewCategory.ID][NewCategory.Index + 1]	= NewCategory;
		else
			Parent[NewCategory.ID]		= NewCategory;
		end;
		
		if ((NewCategory.IsContainer) and ((NewCategory.Count > 0) or (NewCategory.NumSubheaders > 0))) then
			table.insert(Hierarchy, 1, {obj = NewCategory, ptr = CARPPointer, cnt = NewCategory.Count + 0});
			CARPPointer = NewCategory.AbsoluteOffset;
		else
			if (NumHierarchy > 0) then
				if (Hierarchy[1].cnt > 0) then
					Hierarchy[1].cnt = Hierarchy[1].cnt - 1;
					
					if (Hierarchy[1].cnt <= 0) then
						repeat
							if ((Hierarchy[1].obj.IsHeader) and (SubHeaders > 0)) then
								CARPPointer = Hierarchy[1].ptr;
								SubHeaders = SubHeaders - 1;
								table.remove(Hierarchy, 1);
								break;
							end;
							
							CARPPointer = Hierarchy[1].ptr;
							table.remove(Hierarchy, 1);
						until (#Hierarchy <= 0) or (Hierarchy[1].cnt > 0);
					end;
				else
					SubHeaders = SubHeaders - 1;
				end;
			end;
			
			CARPPointer = CARPPointer + 0x10;
			
			if (#Hierarchy > 0) then
				if ((Hierarchy[1].obj.ID == "CARP") and ((Hierarchy[1].cnt <= 0) and (SubHeaders <= 0))) then
					break;
				end;
			end;
		end;
		
		--[[
		if (NewCategory.Index ~= nil) then
			
		end;
		--]]
		
		if ((#Hierarchy <= 0) and (SubHeaders <= 0)) then
			print("nothing!");
			print(string.format("#Hierarchy = %i\nSubHeaders = %i", #Hierarchy, SubHeaders));
			break;
		end;
	end;
	
	return CARPObject;
end;

return CARP;