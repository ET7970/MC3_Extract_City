local Enums		= Cleanums.new("ChunkRegistry.Enums");

Enums:Add("Extraction");
Enums.Extraction:Add("Flags", true);
Enums.Extraction.Flags:Add("SizeType",		0x00000001 << 00);
Enums.Extraction.Flags:Add("StorageType",	0x00000001 << 01);
Enums.Extraction.Flags:Add("StorageType",	0x00000001 << 02);

return Enums;