--[[
/*
 * COPYRIGHT NOTICE, DISCLAIMER, and LICENSE
 * =========================================
 *
 * PNG Reference Library License version 2
 * ---------------------------------------
 *
 *  * Copyright (c) 1995-2023 The PNG Reference Library Authors.
 *  * Copyright (c) 2018-2023 Cosmin Truta.
 *  * Copyright (c) 2000-2002, 2004, 2006-2018 Glenn Randers-Pehrson.
 *  * Copyright (c) 1996-1997 Andreas Dilger.
 *  * Copyright (c) 1995-1996 Guy Eric Schalnat, Group 42, Inc.
 *
 * The software is supplied "as is", without warranty of any kind,
 * express or implied, including, without limitation, the warranties
 * of merchantability, fitness for a particular purpose, title, and
 * non-infringement.  In no event shall the Copyright owners, or
 * anyone distributing the software, be liable for any damages or
 * other liability, whether in contract, tort or otherwise, arising
 * from, out of, or in connection with the software, or the use or
 * other dealings in the software, even if advised of the possibility
 * of such damage.
 *
 * Permission is hereby granted to use, copy, modify, and distribute
 * this software, or portions hereof, for any purpose, without fee,
 * subject to the following restrictions:
 *
 *  1. The origin of this software must not be misrepresented; you
 *     must not claim that you wrote the original software.  If you
 *     use this software in a product, an acknowledgment in the product
 *     documentation would be appreciated, but is not required.
 *
 *  2. Altered source versions must be plainly marked as such, and must
 *     not be misrepresented as being the original software.
 *
 *  3. This Copyright notice may not be removed or altered from any
 *     source or altered source distribution.
 *
 *
 * PNG Reference Library License version 1 (for libpng 0.5 through 1.6.35)
 * -----------------------------------------------------------------------
 *
 * libpng versions 1.0.7, July 1, 2000, through 1.6.35, July 15, 2018 are
 * Copyright (c) 2000-2002, 2004, 2006-2018 Glenn Randers-Pehrson, are
 * derived from libpng-1.0.6, and are distributed according to the same
 * disclaimer and license as libpng-1.0.6 with the following individuals
 * added to the list of Contributing Authors:
 *
 *     Simon-Pierre Cadieux
 *     Eric S. Raymond
 *     Mans Rullgard
 *     Cosmin Truta
 *     Gilles Vollant
 *     James Yu
 *     Mandar Sahastrabuddhe
 *     Google Inc.
 *     Vadim Barkov
 *
 * and with the following additions to the disclaimer:
 *
 *     There is no warranty against interference with your enjoyment of
 *     the library or against infringement.  There is no warranty that our
 *     efforts or the library will fulfill any of your particular purposes
 *     or needs.  This library is provided with all faults, and the entire
 *     risk of satisfactory quality, performance, accuracy, and effort is
 *     with the user.
 *
 * Some files in the "contrib" directory and some configure-generated
 * files that are distributed with libpng have other copyright owners, and
 * are released under other open source licenses.
 *
 * libpng versions 0.97, January 1998, through 1.0.6, March 20, 2000, are
 * Copyright (c) 1998-2000 Glenn Randers-Pehrson, are derived from
 * libpng-0.96, and are distributed according to the same disclaimer and
 * license as libpng-0.96, with the following individuals added to the
 * list of Contributing Authors:
 *
 *     Tom Lane
 *     Glenn Randers-Pehrson
 *     Willem van Schaik
 *
 * libpng versions 0.89, June 1996, through 0.96, May 1997, are
 * Copyright (c) 1996-1997 Andreas Dilger, are derived from libpng-0.88,
 * and are distributed according to the same disclaimer and license as
 * libpng-0.88, with the following individuals added to the list of
 * Contributing Authors:
 *
 *     John Bowler
 *     Kevin Bracey
 *     Sam Bushell
 *     Magnus Holmgren
 *     Greg Roelofs
 *     Tom Tanner
 *
 * Some files in the "scripts" directory have other copyright owners,
 * but are released under this license.
 *
 * libpng versions 0.5, May 1995, through 0.88, January 1996, are
 * Copyright (c) 1995-1996 Guy Eric Schalnat, Group 42, Inc.
 *
 * For the purposes of this copyright and license, "Contributing Authors"
 * is defined as the following set of individuals:
 *
 *     Andreas Dilger
 *     Dave Martindale
 *     Guy Eric Schalnat
 *     Paul Schmidt
 *     Tim Wegner
 *
 * The PNG Reference Library is supplied "AS IS".  The Contributing
 * Authors and Group 42, Inc. disclaim all warranties, expressed or
 * implied, including, without limitation, the warranties of
 * merchantability and of fitness for any purpose.  The Contributing
 * Authors and Group 42, Inc. assume no liability for direct, indirect,
 * incidental, special, exemplary, or consequential damages, which may
 * result from the use of the PNG Reference Library, even if advised of
 * the possibility of such damage.
 *
 * Permission is hereby granted to use, copy, modify, and distribute this
 * source code, or portions hereof, for any purpose, without fee, subject
 * to the following restrictions:
 *
 *  1. The origin of this source code must not be misrepresented.
 *
 *  2. Altered versions must be plainly marked as such and must not
 *     be misrepresented as being the original source.
 *
 *  3. This Copyright notice may not be removed or altered from any
 *     source or altered source distribution.
 *
 * The Contributing Authors and Group 42, Inc. specifically permit,
 * without fee, and encourage the use of this source code as a component
 * to supporting the PNG file format in commercial products.  If you use
 * this source code in a product, acknowledgment is not required but would
 * be appreciated.
 *
 * END OF COPYRIGHT NOTICE, DISCLAIMER, and LICENSE.
 *
 * TRADEMARK
 * =========
 *
 * The name "libpng" has not been registered by the Copyright owners
 * as a trademark in any jurisdiction.  However, because libpng has
 * been distributed and maintained world-wide, continually since 1995,
 * the Copyright owners claim "common-law trademark protection" in any
 * jurisdiction where common-law trademark is recognized.
 */
--]]

local Cleanum		= require("src.util.lib.cleanums");
local PNG		= Cleanum.new("PNG");

PNG:Add("TextCompression");
PNG.TextCompression:Add("Text_None_Write", -3);
PNG.TextCompression:Add("Text_zTxt_Write", -2);
PNG.TextCompression:Add("Text_None", -1);
PNG.TextCompression:Add("Text_zTxt", 0);
PNG.TextCompression:Add("iTxt_None", 1);
PNG.TextCompression:Add("iTxt_zTxt", 2);

PNG:Add("AlignmentType");
PNG.AlignmentType:Add("None", 0);
PNG.AlignmentType:Add("Always", 1);
PNG.AlignmentType:Add("Offset", 2);
PNG.AlignmentType:Add("Size", 3);

PNG:Add("OperationFlags");
PNG.OperationFlags:SetOp("<<=", 1);
PNG.OperationFlags:Add("HaveIHDR",		0x0001);
PNG.OperationFlags:Add("HavePLTE",		0x0002);
PNG.OperationFlags:Add("HaveIDAT",		0x0004);
PNG.OperationFlags:Add("AfterIDAT",		0x0008);
PNG.OperationFlags:Add("HaveIEND",		0x0010);
--PNG.OperationFlags:Add("UNUSEDx0020",		0x0020);
--PNG.OperationFlags:Add("UNUSEDx0040",		0x0040);
--PNG.OperationFlags:Add("UNUSEDx0080",		0x0080);
PNG.OperationFlags:Add("HaveChunkHeader",	0x0100);
PNG.OperationFlags:Add("WroteTime",		0x0200);
PNG.OperationFlags:Add("WroteInfoBeforePLTE",	0x0400);
PNG.OperationFlags:Add("GrayBackground",	0x0800);
PNG.OperationFlags:Add("HavePNGSignature",	0x1000);
PNG.OperationFlags:Add("HaveChunkAfterIDAT",	0x2000);
--PNG.OperationFlags:Add("UNUSEDx4000",		0x4000);
PNG.OperationFlags:Add("IsReadStruct",		0x8000);

PNG:Add("TransformationFlags");
PNG.TransformationFlags:SetOp("<<=", 1);
PNG.TransformationFlags:Add("BGR",		0x00000001);
PNG.TransformationFlags:Add("Interlace",	0x00000002);
PNG.TransformationFlags:Add("Pack",		0x00000004);
PNG.TransformationFlags:Add("Shift",		0x00000008);
PNG.TransformationFlags:Add("SwapBytes",	0x00000010);
PNG.TransformationFlags:Add("InvertMono",	0x00000020);
PNG.TransformationFlags:Add("Quantize",		0x00000040);
PNG.TransformationFlags:Add("Compose",		0x00000080);
PNG.TransformationFlags:Add("BackgroundExpand",	0x00000100);
PNG.TransformationFlags:Add("Expand16",		0x00000200);
PNG.TransformationFlags:Add("Chop16to8",	0x00000400);
PNG.TransformationFlags:Add("RGBA",		0x00000800);
PNG.TransformationFlags:Add("Expand",		0x00001000);
PNG.TransformationFlags:Add("Gamma",		0x00002000);
PNG.TransformationFlags:Add("GrayToRGB",	0x00004000);
PNG.TransformationFlags:Add("Filler",		0x00008000);
PNG.TransformationFlags:Add("PackSwap",		0x00010000);
PNG.TransformationFlags:Add("SwapAlpha",	0x00020000);
PNG.TransformationFlags:Add("StripAlpha",	0x00040000);
PNG.TransformationFlags:Add("InvertAlpha",	0x00080000);
PNG.TransformationFlags:Add("UserTransform",	0x00100000);
PNG.TransformationFlags:Add("RGBToGrayError",	0x00200000);
PNG.TransformationFlags:Add("RGBToGrayWarn",	0x00400000);
PNG.TransformationFlags:Add("RGBToGray",	0x00600000);
PNG.TransformationFlags:Add("EncodeAlpha",	0x00800000);
PNG.TransformationFlags:Add("AddAlpha",		0x01000000);
PNG.TransformationFlags:Add("ExpandtRNS",	0x02000000);
PNG.TransformationFlags:Add("Scale16to8",	0x04000000);
--PNG.TransformationFlags:Add("UNUSEDx08000000",	0x08000000);
--PNG.TransformationFlags:Add("UNUSEDx10000000",	0x10000000);
--PNG.TransformationFlags:Add("UNUSEDx20000000",	0x20000000);
--PNG.TransformationFlags:Add("UNUSEDx40000000",	0x40000000);