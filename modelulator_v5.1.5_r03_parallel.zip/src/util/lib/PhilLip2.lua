local PhilLip2		= {};

local function CreateMembers()
	local Members		= {};
	
	local MembersProxy	= setmetatable({}, {});
	local MembersMeta	= getmetatable(MembersProxy);
	
	function MembersMeta:__call()
		return Members;
	end;
	
	function MembersMeta:__index(Key)
		return rawget(Members, Key);
	end;
	
	function MembersMeta:__newindex(Key, Value)
		return rawset(Members, Key, Value);
	end;
	
	return MembersProxy;
end;

function PhilLip2:CreateFile(Directory)
	local NewFileProxy	= setmetatable({}, {});
	local NewFileMeta	= getmetatable(NewFileProxy);
	
	local Content		= nil;
	
	local Members		= CreateMembers();
	Members.Type		= "PhilLip2File";
	Members.Directory	= (Directory ~= nil) and Directory or "";
	Members.Size		= 0x00000000;
	Members.Base		= 0x00000000;
	
	local ReadOnly		=
	{
		["Type"]	= true;
		["Content"]	= true;
		["Directory"]	= false;
		["Size"]	= true;
		["Base"]	= true;
	};
	
	function Members:Open(Mode, SectionAddress, SectionSize)
		if (Members.Directory == "") then
			Content	= io.tmpfile();
			return;
		end;
		
		if (Mode ~= nil) then
			Mode	= string.gsub(string.lower(Mode), "([%a])%a*", "%1");
			Mode	= string.gsub(Mode, "([^arwb+])", "");
			
			local IOMode		= string.match(Mode, "[arw]") or "";
			local UpdateMode	= string.match(Mode, "[+]") or "";
			local Binary		= string.match(Mode, "[b]") or "";
			
			Mode			= IOMode .. UpdateMode .. Binary;
		end;
		
		Content		= assert(io.open(Members.Directory, Mode));
		
		Members.Base	= SectionAddress or 0x00000000;
		Members.Size	= Content:seek("end");
		
		if (SectionSize ~= nil) then
			Members.Size	= math.min(Members.Size, SectionSize);
		end;
	end;
	
	function Members:Flush()
		Content:flush();
	end;
	
	function Members:Close()
		Content:close();
		Content 		= nil;
		
		Members.Base		= 0x00000000;
		Members.Size		= 0x00000000;
	end;
	
	function Members:Read(Address, Format, MaxSize)
		if (Address >= Members.Size) then
			return;
		end;
		
		if (type(Format) == "string") then
			if (MaxSize == nil) then
				MaxSize = (string.match(Format, "[sz]") ~= nil) and 0xFF or string.packsize(Format);
			end;
			
			Content:seek("set", Members.Base + Address);
			local Data	= {string.unpack(Format, Content:read(MaxSize))};
			
			return table.unpack(Data, 1, #Data - 1);
		elseif (type(Format) == "number") then
			Content:seek("set", Members.Base + Address);
			
			local Data	= {};
			
			for i = 1, Format do
				Data[i] = Content:read(1);
			end;
			
			return table.unpack(Data);
		end;
	end;
	
	function Members:Write(Address, Format, ...)
		Content:seek("set", Members.Base + Address);
		
		if (type(Format) == "string") then
			Content:write(string.pack(Format, ...));
		elseif ((type(Format) == "table") and (Format.__type == "file")) then
			for i = 1, #Format.content do
				Content:write(Format.content[i]);
			end;
		end;
		
		Members.Size	= Content:seek("end");
	end;
	
	function Members:Append(Format, ...)
		return Members:Write(Members.Size, Format, ...);
	end;
	
	function NewFileMeta.__index(this, Key)
		return Members[Key];
	end;
	
	function NewFileMeta.__newindex(this, Key, Value)
		if ((ReadOnly[Key] ~= true) and (ReadOnly[Key] ~= nil)) then
			Members[Key]	= Value;
		end;
		
		return Members[Key];
	end;
	
	return NewFileProxy;
end;

return PhilLip2;