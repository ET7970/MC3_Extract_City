-- Cleanums - Cleanups for your Enums | Clean Enums
-- utility for much cleaner storage of enumerators
-- helps in being less cluttered while being friendly to those who are used to the regular enum system
-- heavily based on Roblox's enum system

local _Cleanums		= {};
local _Cleanum		= {};
local _CleanumItem	= {};

local Abstracts		= {};

local function initialise()
	CleanumsBaseProxy	= setmetatable({}, {});
	CleanumBaseProxy	= setmetatable({}, {});
	CleanumItemBaseProxy	= setmetatable({}, {});
	
	CleanumsBaseMeta	= getmetatable(CleanumsBaseProxy);
	CleanumBaseMeta		= getmetatable(CleanumBaseProxy);
	CleanumItemBaseMeta	= getmetatable(CleanumItemBaseProxy);
	
	function CleanumsBaseMeta.__index(self, key) end;
	function CleanumsBaseMeta.__newindex(self, key, value) end;
	
	CleanumsBaseMeta.__name		= "Cleanums";
	CleanumsBaseMeta.__metatable	= {};
	
	function CleanumBaseMeta.__index(self, key) end;
	function CleanumBaseMeta.__newindex(self, key, value) end;
	
	CleanumBaseMeta.__name		= "Cleanum";
	CleanumBaseMeta.__metatable	= {};
	
	function CleanumItemBaseMeta.__index(self, key) end;
	function CleanumItemBaseMeta.__newindex(self, key, value) end;
	
	CleanumItemBaseMeta.__name	= "CleanumItem";
	CleanumItemBaseMeta.__metatable	= {};
	
	Abstracts.Cleanums		= CleanumsBaseProxy;
	Abstracts.Cleanum		= CleanumBaseProxy;
	Abstracts.CleanumItem		= CleanumItemBaseProxy;
end;

initialise();

local old_typeof	= type;

if (typeof ~= nil) then
	old_typeof	= typeof;
end;

function typeof(v)
	if (v == Abstracts.Cleanums) then
		return "Cleanums";
	elseif (v == Abstracts.Cleanum) then
		return "Cleanum";
	elseif (v == Abstracts.CleanumItem) then
		return "CleanumItem";
	end;
	
	return old_typeof(v);
end;

function _CleanumItem.new(CleanumType, Name, Value)
	local CleanumItem_proxy	= setmetatable({}, {});
	local CleanumItem_mt	= getmetatable(CleanumItem_proxy);
	
	local Properties	= {};
	
	Properties.Name		= Name;
	Properties.Value	= Value;
	Properties.CleanumType	= CleanumType;
	
	function CleanumItem_mt.__tostring(self)
		return string.format("%s.%s", tostring(CleanumType), Name);
	end;
	
	CleanumItem_mt.__name	= "CleanumItem";
	
	function CleanumItem_mt.__eq(a, b)
		local self, Object	= (rawequal(a, CleanumItem_proxy) and a or b), (rawequal(b, CleanumItem_proxy) and a or b);
		
		-- essentially it checks to see if its an abstract
		if (string.match(tostring(Object), CleanumItem_mt.__name .. ":") ~= nil) then
			return true;
		end;
		
		if (typeof(Object) == "CleanumItem") then
			return (self.Value == Object.Value);
		elseif (typeof(Object) == "number") then
			return (self.Value == Object);
		elseif (typeof(Object) == "string") then
			return (self.Value == tonumber(Object));
		end;
		
		return rawequal(self, Object);
	end;
	
	function CleanumItem_mt.__index(self, key)
		return Properties[key];
	end;
	
	function CleanumItem_mt.__newindex(self, key, value)
		return;
	end;
	
	--CleanumItem_mt.__name		= Name;
	--CleanumItem_mt.__type		= Name;
	
	--setmetatable(CleanumItem_proxy, CleanumItem_mt);
	
	CleanumItem_mt.__metatable	= "The metatable is locked";
	
	return CleanumItem_proxy;
end;

function _Cleanum.new(CleanumsContainer, CleanumType)
	local Cleanum_proxy	= setmetatable({}, {});
	local Cleanum_mt	= getmetatable(Cleanum_proxy);
	
	local KeyValues		= {};
	local Methods		= {};
	local Items		= {};
	
	local IndexValue	= 0;
	local TempValue		= 1;
	local ValueOp		= "++";
	
	local ValueOpTypes	=
		{
			["="]	= function() IndexValue = IndexValue; end;
			["++"]	= function() IndexValue = IndexValue + 1; end;
			["--"]	= function() IndexValue = IndexValue - 1; end;
			["+="]	= function() IndexValue = IndexValue + TempValue; end;
			["-="]	= function() IndexValue = IndexValue - TempValue; end;
			["*="]	= function() IndexValue = IndexValue * TempValue; end;
			["/="]	= function() IndexValue = IndexValue / TempValue; end;
			["<<="]	= function() IndexValue = IndexValue << TempValue; end;
			[">>="]	= function() IndexValue = IndexValue >> TempValue; end;
		};
	
	function Methods.Add(self, Name, Value)
		if (KeyValues[Name] ~= nil) then
			print(string.format("Enumerator %s of type %s already exists", Name, tostring(self)));
			return;
		end;
		
		if ((type(Value) == "number") or (Value == nil)) then
			if (Value == nil) then
				Value		= IndexValue;
			else
				IndexValue	= Value;
			end;
		
			table.insert(Items, _CleanumItem.new(Cleanum_proxy, Name, Value));
			
			if (ValueOpTypes[ValueOp] ~= nil) then
				ValueOpTypes[ValueOp]();
			end;
		elseif ((type(Value) == "boolean") and (Value == true)) then
			table.insert(Items, _Cleanum.new(Cleanum_proxy, Name));
		end;
		
		KeyValues[Name]		= Items[#Items];
		
		return;
	end;
	
	function Methods.SetOp(self, vo, vt)
		ValueOp		= vo or ValueOp;
		TempValue	= vt or TempValue;
	end;
	
	function Methods.GetEnumItems(self)
		return Items;
	end;
	
	function Methods.GetEnumFromValue(self, Value)
		local matches = {};
		
		for _, CleanumItem in pairs(Items) do
			if (CleanumItem.Value == nil) then
				local Results	= {CleanumItem:GetEnumFromValue(Value)};
				matches		= table.move(Results, 1, #Results, #matches + 1, matches);
			else
				if (CleanumItem.Value == Value) then
					table.insert(matches, CleanumItem);
				end;
			end;
		end;
		
		return table.unpack(matches);
	end;
	
	function Cleanum_mt.__tostring(self)
		return string.format("%s.%s", tostring(CleanumsContainer), CleanumType);
	end;
	
	Cleanum_mt.__name	= "Cleanum";
	
	function Cleanum_mt.__len(self)
		return #Items;
	end;
	
	function Cleanum_mt.__eq(a, b)
		local self, Object	= (rawequal(a, Cleanum_proxy) and a or b), (rawequal(b, Cleanum_proxy) and a or b);
		
		-- essentially it checks to see if its an abstract
		if (string.match(tostring(Object), Cleanum_mt.__name .. ":") ~= nil) then
			return true;
		end;
		
		return rawequal(self, Object);
	end;
	
	function Cleanum_mt.__index(self, key)
		return KeyValues[key] or Methods[key];
	end;
	
	function Cleanum_mt.__newindex(self, key, value)
		return;
	end;
	
	--setmetatable(Cleanum_proxy, Cleanum_mt);
	
	Cleanum_mt.__metatable	= "The metatable is locked";
	
	return Cleanum_proxy;
end;

function _Cleanums.new(Name)
	local Cleanums_proxy	= setmetatable({}, {});
	local Cleanums_mt	= getmetatable(Cleanums_proxy);
	
	local KeyValues		= {};
	local Methods		= {};
	local Enums		= {};
	
	function Methods.Add(self, CleanumType)
		if (KeyValues[CleanumType] ~= nil) then
			print(string.format("Enumerator Type %s already exists", CleanumType));
			return;
		end;
		
		table.insert(Enums, _Cleanum.new(Cleanums_proxy, CleanumType));
		KeyValues[CleanumType] = Enums[#Enums];
	end;
	
	function Methods.GetEnums(self)
		return Enums;
	end;
	
	Cleanums_mt.__name	= "Cleanums";
	
	function Cleanums_mt.__tostring(self)
		return Name;
	end;
	
	function Cleanums_mt.__eq(a, b)
		local self, Object	= (rawequal(a, Cleanums_proxy) and a or b), (rawequal(b, Cleanums_proxy) and a or b);
		
		-- essentially it checks to see if its an abstract
		if (string.match(tostring(Object), Cleanums_mt.__name .. ":") ~= nil) then
			return true;
		end;
		
		return rawequal(self, Object);
	end;
	
	function Cleanums_mt.__index(self, key)
		return KeyValues[key] or Methods[key];
	end;
	
	function Cleanums_mt.__newindex(self, key, value)
		return;
	end;
	
	--setmetatable(Cleanums_proxy, Cleanums_mt);
	
	Cleanums_mt.__metatable	= "The metatable is locked";
	
	return Cleanums_proxy;
end;

_Cleanums.Classes	= debug.upvalueid(_Cleanums.new, 1);

return _Cleanums;