//int:t1=r1;00000000000000000000000000000000020000000000;00000000000000000000000000000000017777777777;
//char:t2=r2;0;127;
//long int:t3=r1;00000000000000000000001000000000000000000000;00000000000000000000000777777777777777777777;
//unsigned int:t4=r1;00000000000000000000000000000000000000000000;00000000000000000000000000000000037777777777;
//long unsigned int:t5=r1;00000000000000000000000000000000000000000000;00000000000000000000001777777777777777777777;
//long long int:t6=r1;00000000000000000000001000000000000000000000;00000000000000000000000777777777777777777777;
//long long unsigned int:t7=r1;00000000000000000000000000000000000000000000;00000000000000000000001777777777777777777777;
//short int:t8=r8;-32768;32767;
//short unsigned int:t9=r9;0;65535;
//signed char:t10=r10;-128;127;
//unsigned char:t11=r11;0;255;
//__int128_t:t12=r1;02000000000000000000000000000000000000000000;01777777777777777777777777777777777777777777;
//__uint128_t:t13=r1;00000000000000000000000000000000000000000000;03777777777777777777777777777777777777777777;
//float:t14=r1;4;0;
//double:t15=r1;8;0;
//long double:t16=r1;8;0;
//complex int:t17=s8real:1,0,32;imag:1,32,32;;
//complex float:t18=r18;4;0;
//complex double:t19=r19;8;0;
//complex long double:t20=r20;8;0
//bool:t21=@s32;-16;
//void:t22=22
//__wchar_t:t23=r1;00000000000000000000000000000000020000000000;00000000000000000000000000000000017777777777;
//__vtbl_ptr_type:t24=s8__delta:8,0,16;__index:8,16,16;__pfn:25=*22,32,32;__delta2:8,32,16

//int8:t26=10
//uint8:t27=11
//int16:t28=8
//uint16:t29=9
//int32:t30=1
//uint32:t31=4
//uint64:t33=5
//int128:t34=35=r1;02000000000000000000000000000000000000000000;01777777777777777777777777777777777777777777;
//uint128:t36=37=r1;00000000000000000000000000000000000000000000;03777777777777777777777777777777777777777777;

//u_int:t289=4

struct bNode
{
	bNode*		Next;
	bNode*		Prev;
};

struct bList
{
	bNode		HeadNode;
};

// bTNode<bPNode>:Tt73=s8!1,020,38;

struct bVector3
{
	float		x;
	float		y;
	float		z;
};

struct bVector4
{
	float		x;
	float		y;
	float		z;
	float		w;
};

struct bMatrix4
{
	bVector4	v0;
	bVector4	v1;
	bVector4	v2;
	bVector4	v3;
};

enum struct eStripDataFlags
{
	ESDF_HAS_XYZ	= 1;
	ESDF_HAS_RGBA	= 2;
	ESDF_HAS_NORM	= 4;
	ESDF_HAS_ST0	= 16;
	ESDF_HAS_ST1	= 32;
	ESDF_HAS_ST2	= 64;
	ESDF_HAS_ST3	= 128;
};

struct eStripEntry
{
	signed char	TextureNumber;
	unsigned short	TextureWidthScale;
	unsigned short	TextureHeightScale;
	eStripData *	Data;
	unsigned short	DataQWordSize;
	unsigned short	Flags;
	bVector3	AABBMin;
	unsigned char	PolyGroupNumber;
	unsigned char	NumVerts;
	unsigned char	NumPolys;
	signed char	LightMaterialIndex;
	bVector3	AABBMax;
	unsigned short	OriginalFlags;
	unsigned short	pad;
	signed short	Nx;
	signed short	Ny;
	signed short	Nz;
	signed short	Nt;
	float		MaterialDensity;
	signed short	MipMapK;
	signed char	MipMapL;
	unsigned char	Padding;
};

struct eSolid
{
	uint32		NameHash;
	int32		Version;
	char[0x18]	Name;
	uint32		ExternalRigidAnimationNameHash;
	t3344		pVertexAnimator;
	uint16		Flags;
	uint16		StripFlags;
	int16		NumStrips;
	int16		NumPolys;
	int16		NumVerts;
	int16		NumOriginalVerts;
	int32		SizeofStripEntryData;
	bVector4	AABBMin;
	bVector4	AABBMax;
	bMatrix4	PivotMatrix;
	t3155		AnimationTree;
	t3210		pRigidAnimation;
	int16		NumTextureTableEntries;
	int16		NumLightMaterials;
	eStripEntry*	StripEntryTable;
	uint8*		StripEntryDataStart;
	t3137		pTextureTable;
	t4436		LightMaterialTable;
};

