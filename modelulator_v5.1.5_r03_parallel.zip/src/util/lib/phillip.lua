-- ## phillip (pron.: filib) ##






--#
local phillip = {};
phillip.file_list = {};
phillip.file_main = phillip.file_list[1];




--#
phillip.wait=
function(ms)
	local ProcessMsgFuncExists = (processMessages ~= nil);
	
	local ts = os.clock();
	local f =
	coroutine.create
	(
		function()
			while((os.clock() - ts) * 1000 < ms) do
				--# this was originally used in cheat engine before i began using it in standalone lua
				--# its no longer used, though itll remain just for the sake of compatibility
				if (ProcessMsgFuncExists) then
					processMessages();
				end;
			end;
		end
	);
	coroutine.resume(f);
	
	return (os.clock() - ts) * 1000;
end;

--#
local Cleanum		= require("src.util.lib.cleanums");
phillip.PhilLipEnum	= Cleanum.new("PhilLipEnum");
phillip.PhilLipEnum:Add("bool");
phillip.PhilLipEnum.bool:Add("nil",	-1);
phillip.PhilLipEnum.bool:Add("false",	0);
phillip.PhilLipEnum.bool:Add("true",	1);




--[[
--# /!\ deprecated /!\ - use PhilLipEnum.bool instead!
phillip.int=
function(x)
	local funcs =
	{
		["number"] = function(n) return math.floor(n); end;
		["boolean"] = function(n) return n and 0x1 or 0x0; end;
	};
	if (funcs[type(x)] ~= nil) then return funcs[type(x)](x); end;
end;


--# /!\ deprecated /!\ - use PhilLipEnum.bool instead!
phillip.bool=
function(x)
	local funcs =
	{
		["number"] = function(n) return x == 0x1; end;
	};
	if (funcs[type(x)] ~= nil) then return funcs[type(x)](x); end;
end;



--# /!\ deprecated /!\ - use developer defined function instead!
--phillip.align=function(address,al)return(address+al-0x1)&-al;end;
--]]

--#
phillip.file_create=
function(dir)
	local new_file		= setmetatable({}, {});
	
	new_file.__type		= "file";
	new_file.content	= {};
	new_file.directory	= dir or "";
	new_file.isopen		= false;
	new_file.size		= 0x00000000;
	
	new_file.__index	= {};
	
	function new_file:open(Address, Size)
		Address		= Address or 0x00000000;
		Size		= Size or "*all";
		
		if ((self.isopen == true) or (self.directory == "")) then return; end;
		local file	= assert(io.open(self.directory, "rb"));
		file:seek("set", Address);
		local cont	= file:read(Size);
		file:close();
		
		local SectorSize	= 0x00008000;
		
		for i = 1, #cont do
			table.insert(self.content, string.pack("<B", string.unpack("<B", cont, i)));
		end;
		
		cont		= "";
		
		self.size	= #self.content;
		self.isopen	= true;
	end;
	
	function new_file:close();
		self.content	= {};
		self.size	= 0x00000000;
		self.isopen	= false;
	end;
	--[[
	function new_file:read_byte(address)		return string.unpack("<B", self.content, 0x1);	end;
	function new_file:read_short(address)		return string.unpack("<H", self.content, 0x1);	end;
	function new_file:read_int(address)		return string.unpack("<I4", self.content, 0x1);	end;
	function new_file:read_string(address)		return string.unpack("z", self.content, 0x1);	end;
	function new_file:read_float(address)		return string.unpack("<f", self.content, 0x1);	end;
	function new_file:read_bytes(address, len)	return string.unpack("c"..len, self.content, 0x1);	end;
	--]]
	function new_file:read_data(address, data)
		local UnpackedData	= {string.unpack(data, table.concat(self.content, "", 0x1 + address, address + string.packsize(data)), 0x1)};
		return table.unpack(UnpackedData, 1, #UnpackedData - 1);
	end;
	
	function new_file:write_data(address, data, ...)
		local datastring	= string.pack(data, ...);
		
		for i = 1, string.packsize(data) do
			self.content[address + i] = string.unpack("<c1", datastring, i);
		end;
		
		if (address > self.size) then
			local siz		= self.size;
			for i = siz + 1, address do
				self.content[i]	= "\x00";
			end
		end;
		
		self.size	= #self.content;
	end;
	
	return new_file;
end;








--#
function phillip:initialize()
	for i, v in pairs(phillip) do _ENV[i] = v; end;
	--print("## LOADED PHILLIP.LUA ##");
end;



--# return
--print("## ! LOADED phillip.LUA ! ##");
return phillip;





--# END