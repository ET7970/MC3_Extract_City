local struct		= {};
local typedef		= require("src.util.typedef");

function struct.new(Name)
	local struct_proxy	= setmetatable({}, {});
	local struct_meta	= getmetatable(struct_proxy);
	
	local Members		= {};
	local Structure		= {};
	
	Members.__type		= Name;
	
	function Members[Name](self, PhilLipFile, Address)
		if ((PhilLipFile ~= nil))
	end;
	
	--# structured much like debug symbols are
	function Members.Add(self, Key, Type, Offset, Size)
		local StructureMember	=
		{
			Key	= Key;
			Type	= typedef[Type];
			Offset	= Offset;
			Size	= Size;
			Value	= nil;
		};
		
		
	end;
end;

return struct;