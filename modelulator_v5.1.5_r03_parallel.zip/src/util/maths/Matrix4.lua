Maths.Matrix4		= {};

local function CreateMembers()
	local Proxy		= setmetatable({}, {});
	local Meta		= getmetatable(Proxy);
	
	local Member		=
	{
		Count		= 0;
		Item		= {};
		LookUp		= {};
	};
	
	function Member.Define(Type, Key, Value, Read, Write)
		local Definition	=
		{
			Index		= -1;
			
			Key		= Key;
			Value		= Value;
			
			Access		=
			{
				Type	= Type or "any";
				Read	= (Read ~= nil) and Read or true;
				Write	= (Write ~= nil) and Write or true;
			};
		};
		
		Member.Count		= Member.Count + 1;
		
		local Index		= Member.LookUp[Key] or Member.Count;
		
		Definition.Index	= Index;
		
		Member.Item[Index]	= Definition;
		Member.LookUp[Key]	= Index;
	end;
	
	function Member:Get(Key)
		local Index		= self.LookUp[Key];
		
		if (Index == nil) then
			return;
		end;
		
		return self.Item[Index];
	end;
	
	function Meta.__index(self, Key)
		local Definition	= Member:Get(Key);
		
		if (Definition == nil) then
			return;
		end;
		
		if (Definition.Access.Read == true) then
			return Definition.Value;
		end;
	end;
	
	function Meta.__newindex(self, Key, Value)
		local Definition	= Member:Get(Key);
		
		if (Definition == nil) then
			return;
		end;
		
		if (Definition.Access.Write == false) then
			return;
		end;
		
		if ((Definition.Access.Type == "any") or (type(Value) == Definition.Access.Type)) then
			Member.Item[Definition.Index].Value	= Value;
		end
	end;
	
	return Proxy, Meta, Member;
end;

function Maths.Matrix4.Determinant(This)
	local Result		= 0;
	
	Result			= Result + (This.V0.X * This.V1.Y - This.V1.X * This.V0.Y) * (This.V2.Z * This.V3.W - This.V3.Z * This.V2.W) + (This.V2.X * This.V3.Y - This.V3.X * This.V2.Y) * (This.V0.Z * This.V1.W - This.V1.Z * This.V0.W);
	Result			= Result + (This.V0.X * This.V1.Z - This.V1.X * This.V0.Z) * (This.V2.W * This.V3.Y - This.V3.W * This.V2.Y) + (This.V2.X * This.V3.Z - This.V3.X * This.V2.Z) * (This.V0.W * This.V1.Y - This.V1.W * This.V0.Y);
	Result			= Result + (This.V0.X * This.V1.W - This.V1.X * This.V0.W) * (This.V2.Y * This.V3.Z - This.V3.Y * This.V2.Z) + (This.V2.X * This.V3.W - This.V3.X * This.V2.W) * (This.V0.Y * This.V1.Z - This.V1.Y * This.V0.Z);
	
	return Result;
end;

function Maths.Matrix4.Transpose(This)
	return Maths.Matrix4.new(Maths.Vector4.new(This.V0.X, This.V1.X, This.V2.X, This.V3.X), Maths.Vector4.new(This.V0.Y, This.V1.Y, This.V2.Y, This.V3.Y), Maths.Vector4.new(This.V0.Z, This.V1.Z, This.V2.Z, This.V3.Z), Maths.Vector4.new(This.V0.W, This.V1.W, This.V2.W, This.V3.W));
end;

function Maths.Matrix4.Multiply(This, That)
	if ((This.Type == "Matrix4") and (That.Type == "Matrix4")) then
		That		= That:Transpose();
		
		local NewV0	= Maths.Vector4.new(This.V0:DotProduct(That.V0), This.V0:DotProduct(That.V1), This.V0:DotProduct(That.V2), This.V0:DotProduct(That.V3));
		local NewV1	= Maths.Vector4.new(This.V1:DotProduct(That.V0), This.V1:DotProduct(That.V1), This.V1:DotProduct(That.V2), This.V1:DotProduct(That.V3));
		local NewV2	= Maths.Vector4.new(This.V2:DotProduct(That.V0), This.V2:DotProduct(That.V1), This.V2:DotProduct(That.V2), This.V2:DotProduct(That.V3));
		local NewV3	= Maths.Vector4.new(This.V3:DotProduct(That.V0), This.V3:DotProduct(That.V1), This.V3:DotProduct(That.V2), This.V3:DotProduct(That.V3));
		
		return Maths.Matrix4.new(NewV0, NewV1, NewV2, NewV3);
	elseif ((This.Type == "Vector4") and (That.Type == "Matrix4")) then
		That		= That:Transpose();
		
		local NewX	= This:DotProduct(That.V0);
		local NewY	= This:DotProduct(That.V1);
		local NewZ	= This:DotProduct(That.V2);
		local NewW	= This:DotProduct(That.V3);
		
		return Maths.Vector4.new(NewX, NewY, NewZ, NewW);
	elseif ((This.Type == "Matrix4") and (That.Type == "Vector4")) then
		local NewX	= This.V0:DotProduct(That);
		local NewY	= This.V1:DotProduct(That);
		local NewZ	= This.V2:DotProduct(That);
		local NewW	= This.V3:DotProduct(That);
		
		return Maths.Vector4.new(NewX, NewY, NewZ, NewW);
	end;
end;

function Maths.Matrix4.IsMatrix4(This)
	return (type(This) == "table") and ((This.Type == "Matrix4") or (This == Maths.Matrix4));
end;

local function SetupTemporaryMatrix4(Value)
	local Type		= (type(Value) == "table") and (Value.Type or type(Value)) or type(Value);
	
	if (Type == "Matrix4") then
		return {Value.V0.X, Value.V0.Y, Value.V0.Z, Value.V0.W, Value.V1.X, Value.V1.Y, Value.V1.Z, Value.V1.W, Value.V2.X, Value.V2.Y, Value.V2.Z, Value.V2.W, Value.V3.X, Value.V3.Y, Value.V3.Z, Value.V3.W};
	elseif (Type == "number") then
		return {Value, Value, Value, Value, Value, Value, Value, Value, Value, Value, Value, Value, Value, Value, Value, Value};
	end;
end;

function Maths.Matrix4.Operation(Operation, A, B)
	if ((Operation == "*") and ((Maths.Matrix4.IsMatrix4(A) or Maths.Vector4.IsVector4(A)) and (Maths.Matrix4.IsMatrix4(B) or Maths.Vector4.IsVector4(B)))) then
		return Maths.Matrix4.Multiply(A, B);
	end;
	
	local AValues		= SetupTemporaryMatrix4(A);
	local BValues		= SetupTemporaryMatrix4(B);
	local CValues		= {};
	
	for i = 1, 4 do
		CValues[i]	= Maths.Operation.Get(Operation, AValues[i], BValues[i]);
	end;
	
	return Maths.Matrix4.new(table.unpack(CValues));
end;

function Maths.Matrix4.new(V0, V1, V2, V3)
	local Proxy, Meta, Member	= CreateMembers();
	
	Member.Define("string", "Type", "Matrix4", true, false);
	Member.Define("any", "V0", V0 or Maths.Vector4.new(), true, true);
	Member.Define("any", "V1", V1 or Maths.Vector4.new(), true, true);
	Member.Define("any", "V2", V2 or Maths.Vector4.new(), true, true);
	Member.Define("any", "V3", V3 or Maths.Vector4.new(), true, true);
	Member.Define("function", "Determinant", Maths.Matrix4.Determinant, true, false);
	
	function Meta.__add(a, b)
		return Maths.Matrix4.Operation("+", a, b);
	end;
	
	function Meta.__sub(a, b)
		return Maths.Matrix4.Operation("-", a, b);
	end;
	
	function Meta.__mul(a, b)
		return Maths.Matrix4.Operation("*", a, b);
	end;
	
	function Meta.__div(a, b)
		--return Maths.Matrix4.Operation("/", a, b);
	end;
	
	function Meta.__eq(a, b)
		return Maths.Matrix4.Operation("==", a, b);
	end;
	
	Meta.__metatable		= "The metatable is locked";
	
	return Proxy;
end;

return true;