Maths.Operation		=
{
	[1]		=
	{
		["#"]	= function(X) return #X; end;
		["-"]	= function(X) return -X; end;
		["~"]	= function(X) return ~X; end;
	};
	
	[2]		=
	{
		["+"]	= function(A, B) return A + B; end;
		["-"]	= function(A, B) return A - B; end;
		["*"]	= function(A, B) return A * B; end;
		["%"]	= function(A, B) return A % B; end;
		["^"]	= function(A, B) return A ^ B; end;
		["/"]	= function(A, B) return A / B; end;
		
		["//"]	= function(A, B) return A // B; end;
		["&"]	= function(A, B) return A & B; end;
		["|"]	= function(A, B) return A | B; end;
		["~"]	= function(A, B) return A ~ B; end;
		["<<"]	= function(A, B) return A << B; end;
		[">>"]	= function(A, B) return A >> B; end;
		
		["=="]	= function(A, B) return A == B; end;
		["<"]	= function(A, B) return A < B; end;
		["<="]	= function(A, B) return A <= B; end;
	};
};

function Maths.Operation.Get(Operation, ...)
	local Arguments		= {...};
	
	if ((Maths.Operation[#Arguments] == nil) or (Maths.Operation[#Arguments][Operation] == nil)) then
		return;
	end;
	
	local Success, Result	= pcall(Maths.Operation[#Arguments][Operation], ...);
	
	return Result;
end;

return true;