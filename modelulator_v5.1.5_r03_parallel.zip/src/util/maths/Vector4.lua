Maths.Vector4		= {};

local function CreateMembers()
	local Proxy		= setmetatable({}, {});
	local Meta		= getmetatable(Proxy);
	
	local Member		=
	{
		Count		= 0;
		Item		= {};
		LookUp		= {};
	};
	
	function Member.Define(Type, Key, Value, Read, Write)
		local Definition	=
		{
			Index		= -1;
			
			Key		= Key;
			Value		= Value;
			
			Access		=
			{
				Type	= Type or "any";
				Read	= (Read ~= nil) and Read or true;
				Write	= (Write ~= nil) and Write or true;
			};
		};
		
		Member.Count		= Member.Count + 1;
		
		local Index		= Member.LookUp[Key] or Member.Count;
		
		Definition.Index	= Index;
		
		Member.Item[Index]	= Definition;
		Member.LookUp[Key]	= Index;
	end;
	
	function Member:Get(Key)
		local Index		= self.LookUp[Key];
		
		if (Index == nil) then
			return;
		end;
		
		return self.Item[Index];
	end;
	
	function Meta.__index(self, Key)
		local Definition	= Member:Get(Key);
		
		if (Definition == nil) then
			return;
		end;
		
		if (Definition.Access.Read == true) then
			return Definition.Value;
		end;
	end;
	
	function Meta.__newindex(self, Key, Value)
		local Definition	= Member:Get(Key);
		
		if (Definition == nil) then
			return;
		end;
		
		if (Definition.Access.Write == false) then
			return;
		end;
		
		if ((Definition.Access.Type == "any") or (type(Value) == Definition.Access.Type)) then
			Member.Item[Definition.Index].Value	= Value;
		end
	end;
	
	return Proxy, Meta, Member;
end;

function Maths.Vector4.Magnitude(This)
	return math.sqrt(This.X * This.X + This.Y * This.Y + This.Z * This.Z + This.W * This.W);
end;

function Maths.Vector4.Sum(This)
	return This.X + This.Y + This.Z + This.W;
end;

function Maths.Vector4.DotProduct(A, B)
	return A.X * B.X + A.Y * B.Y + A.Z * B.Z + A.W * B.W;
end;

function Maths.Vector4.CrossProduct(A, B, C)
	return
	Maths.Vector4.new
	(
		A.Y * (B.Z * C.W - B.W * C.Z) - A.Z * (B.Y * C.W - B.W * C.Y) + A.W * (B.Y * C.Z - B.Z * C.Y),
		-A.X * (B.Z * C.W - B.W * C.Z) + A.Z * (B.X * C.W - B.W * C.X) - A.W * (B.X * C.Z - B.Z * C.X),
		A.X * (B.Y * C.W - B.W * C.Y) - A.Y * (B.X * C.W - B.W * C.X) + A.W * (B.X * C.Y - B.Y * C.X),
		-A.X * (B.Z * C.Y - B.Y * C.Z) + A.Y * (B.X * C.Z - B.Z * C.X) - A.Z * (B.X * C.Y - B.Y * C.X)
	);
end;

function Maths.Vector4.Normalise(This)
	local Magnitude		= math.sqrt(This.X * This.X + This.Y * This.Y + This.Z * This.Z + This.W * This.W);
	
	if (Magnitude > 0) then
		Magnitude	= 1 / Magnitude;
	end;
	
	return This * Magnitude;
end;

function Maths.Vector4.IsVector4(This)
	return (type(This) == "table") and ((This.Type == "Vector4") or (This == Maths.Vector4));
end;

local function SetupTemporaryVector4(Value)
	local Type		= (type(Value) == "table") and (Value.Type or type(Value)) or type(Value);
	
	if (Type == "Vector4") then
		return {Value.X, Value.Y, Value.Z, Value.W};
	elseif (Type == "number") then
		return {Value, Value, Value, Value};
	end;
end;

function Maths.Vector4.Operation(Operation, A, B)
	if ((Operation == "*") and (Maths.Matrix4.IsMatrix4(B) == true)) then
		return Maths.Matrix4.Multiply(A, B);
	end;
	
	local AValues		= SetupTemporaryVector4(A);
	local BValues		= SetupTemporaryVector4(B);
	local CValues		= {};
	
	for i = 1, 4 do
		CValues[i]	= Maths.Operation.Get(Operation, AValues[i], BValues[i]);
	end;
	
	return Maths.Vector4.new(table.unpack(CValues));
end;

function Maths.Vector4.new(X, Y, Z, W)
	local Proxy, Meta, Member	= CreateMembers();
	
	Member.Define("string", "Type", "Vector4", true, false);
	Member.Define("any", "X", X or 0, true, true);
	Member.Define("any", "Y", Y or 0, true, true);
	Member.Define("any", "Z", Z or 0, true, true);
	Member.Define("any", "W", W or 0, true, true);
	Member.Define("function", "Magnitude", Maths.Vector4.Magnitude, true, false);
	Member.Define("function", "Sum", Maths.Vector4.Sum, true, false);
	Member.Define("function", "DotProduct", Maths.Vector4.DotProduct, true, false);
	Member.Define("function", "CrossProduct", Maths.Vector4.CrossProduct, true, false);
	Member.Define("function", "Normalise", Maths.Vector4.Normalise, true, false);
	
	function Meta.__add(A, B)
		return Maths.Vector4.new(A.X + B.X, A.Y + B.Y, A.Z + B.Z, A.W + B.W);
	end;
	
	function Meta.__sub(A, B)
		return Maths.Vector4.new(A.X - B.X, A.Y - B.Y, A.Z - B.Z, A.W - B.W);
	end;
	
	function Meta.__mul(A, B)
		if (type(A) == "number") then
			return Maths.Vector4.new(A * B.X, A * B.Y, A * B.Z, A * B.W);
		elseif (type(B) == "number") then
			return Maths.Vector4.new(A.X * B, A.Y * B, A.Z * B, A.W * B);
		elseif (Maths.Vector4.IsVector4(B) == true) then
			return Maths.Vector4.new(A.X * B.X, A.Y * B.Y, A.Z * B.Z, A.W * B.W);
		elseif (Maths.Matrix4.IsMatrix4(A) or Maths.Matrix4.IsMatrix4(B)) then
			return Maths.Matrix4.Multiply(A, B);
		end;
	end;
	
	function Meta.__div(A, B)
		return Maths.Vector4.Operation("/", A, B);
	end;
	
	function Meta.__pow(A, B)
		return Maths.Vector4.Operation("^", A, B);
	end;
	
	function Meta.__mod(A, B)
		return Maths.Vector4.new(A.X % B, A.Y % B, A.Z % B, A.W % B);
	end;
	
	function Meta.__eq(A, B)
		return rawequal(A, B) or rawequal(B, Maths.Vector4);
	end;
	
	Meta.__metatable		= "The metatable is locked";
	
	return Proxy;
end;

return true;