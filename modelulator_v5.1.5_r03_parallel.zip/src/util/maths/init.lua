_ENV.Maths		= {};

require("src.util.maths.Operation");
require("src.util.maths.Vector4");
require("src.util.maths.Matrix4");

return Maths;