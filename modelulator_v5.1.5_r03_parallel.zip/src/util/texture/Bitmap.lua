local Bitmap			= {};

function Bitmap.Generate()
	
end;

return Bitmap;