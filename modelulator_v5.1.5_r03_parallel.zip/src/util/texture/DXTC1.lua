local DXTC1		= {};

function DXTC1:Get(tex_offset, w, h)
	local Image		= {};
	local ImageDataSize	= (w * h) >> 0x01;
	local DataOffset	= tex_offset + 0x00000000;
	
	for i = 1, w * h do
		Image[i]	= string.pack(">I4", 0x00000000);
	end;
	
	for i = 0x00, ~-(ImageDataSize >> 0x03) do
		local pbi			= (((i >> 0x02) << 0x01) | (i & 0x01)) << 0x02;
		local pbx			= (pbi % w);
		local pby			= ((pbi // w) << 0x03) + (((i >> 0x01) & 0x01) << 0x02);
		
		local c0_val			= ResourceFile:Read(DataOffset + 0x00, ">H");
		local c1_val			= ResourceFile:Read(DataOffset + 0x02, ">H");
		
		local clut			= {};
		local clut_val			= ResourceFile:Read(DataOffset + 0x04, ">I4");
		for y = 4, 1, -1 do
			clut[y]			= {};
			for x = 4, 1, -1 do
				clut[y][x]	= clut_val & 0x03;
				clut_val	= clut_val >> 0x02;
			end;
		end;
		
		local c			= {};
		c[0]			= RGB565ToRGBATable(c0_val);
		c[1]			= RGB565ToRGBATable(c1_val);
		c[2]			= {};
		c[3]			= {};
		
		if (c0_val > c1_val) then
			for comp = 1, 4 do
				c[2][comp]	= math.floor((c[0][comp] * 2 + c[1][comp] * 1) / 3 + 0.5);
				c[3][comp]	= math.floor((c[0][comp] * 1 + c[1][comp] * 2) / 3 + 0.5);
			end;
		else
			for comp = 1, 4 do
				c[2][comp]	= math.floor((c[0][comp] * 1 + c[1][comp] * 1) / 2 + 0.5);
				c[3][comp]	= 0x00;
			end;
		end;
		
		for y = 1, 4 do
			for x = 1, 4 do
				local curRGBATable	= c[clut[y][x]];
				
				local bx, by		= ~-x, ~-y;
				local px, py		= pbx + bx, pby + by;
				py			= h - py - 1;
				local pi		= -~((px % w) + py * w);
				
				Image[pi]		= PackRGBATable(curRGBATable);
			end;
		end;
		
		DataOffset		= DataOffset + 0x08;
	end;
	
	return table.concat(Image, "");
end;

return DXTC1;