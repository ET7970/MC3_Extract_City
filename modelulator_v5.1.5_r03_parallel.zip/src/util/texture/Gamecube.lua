local GAMECUBE		= {};
local DXTC1		= require("src.util.texture.DXTC1");

function GAMECUBE:Get(tex_offset, pal_offset, TexComp, w, h, AlphaUsageType, AlphaBlendType, LastAlphaUsageType, LastAlphaBlendType)
	if (TexComp == ModelulatorEnum.TextureCompressionType.DXTC1) then
		return DXTC1:Get(tex_offset, w, h);
	end;
	
	local Image		= {};
	
	if (TexComp == ModelulatorEnum.TextureCompressionType.Tex8Bit) then
		local DataOffset	= 0x00000000;
		ImageDataSize		= (w * h);
		
		for i = 0x00, ~-(ImageDataSize >> 0x05) do
			local pbi	= i << 0x03;
			local pbx	= (pbi % w);
			local pby	= (pbi // w) << 0x02;
			
			for y = 0x0, 0x3 do
				for x = 0x0, 0x7 do
					local cli		= ResourceFile:Read(tex_offset + DataOffset + (x + y * 0x08) * 0x01, ">B");
					local curRGBATable	= RGB5A3ToRGBATable(ResourceFile:Read(pal_offset + cli * 0x02, ">H"));
					
					local px, py		= pbx + x, pby + y;
					py			= h - py - 1;
					local pi		= -~(px + py * w);
					Image[pi]		= PackRGBATable(curRGBATable);
				end;
			end;
			
			DataOffset			= DataOffset + 0x20;
		end;
	elseif (TexComp == ModelulatorEnum.TextureCompressionType.Tex16Bit) then
		DataOffset		= 0x00000000;
		ImageDataSize		= (w * h) << 0x01;
		
		for i = 0x00, ~-(ImageDataSize >> 0x05) do
			local pbi	= (i << 0x02);
			local pbx	= (pbi % w);
			local pby	= (pbi // w) << 0x02;
			
			for y = 0x0, 0x3 do
				for x = 0x0, 0x3 do
					local curRGBATable	= RGB5A3ToRGBATable(ResourceFile:Read(tex_offset + DataOffset + (x + y * 0x04) * 0x02, ">H"));
					
					local px, py		= pbx + x, pby + y;
					py			= h - py - 1;
					local pi		= -~(px + py * w);
					Image[pi]		= PackRGBATable(curRGBATable);
				end;
			end;
			
			DataOffset			= DataOffset + 0x20;
		end;
	end;
	
	return table.concat(Image, "");
end;

return GAMECUBE;