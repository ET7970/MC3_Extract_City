function _ENV.PackRGBATable(RGBATable)
	local R, G, B, A = table.unpack(RGBATable);
	
	return string.pack(">BBBB", B, G, R, A);
end;

function _ENV.RGB565ToRGBATable(Value)
	local B		= (Value >> 0x00) & 0x1F;
	local G		= (Value >> 0x05) & 0x3F;
	local R		= (Value >> 0x0B) & 0x1F;
	local A		= 0xFF;
	
	R		= math.floor((R / 0x1F) * 0xFF + 0.5);
	G		= math.floor((G / 0x3F) * 0xFF + 0.5);
	B		= math.floor((B / 0x1F) * 0xFF + 0.5);
	
	return {R, G, B, A};
end;

function _ENV.RGB5551ToRGBATable(Value)
	local B		= (Value >> 0x00) & 0x1F;
	local G		= (Value >> 0x05) & 0x1F;
	local R		= (Value >> 0x0A) & 0x1F;
        local A		= (Value >> 0x0F) & 0x01;
	
	R		= math.floor((R / 0x1F) * 0xFF + 0.5);
        G		= math.floor((G / 0x1F) * 0xFF + 0.5);
        B		= math.floor((B / 0x1F) * 0xFF + 0.5);
        A		= math.floor((A / 0x01) * 0xFF + 0.5);
	
	return {R, G, B, A};
end;

function _ENV.RGB4444ToRGBATable(Value)
	local B		= (Value >> 0x00) & 0x0F;
	local G		= (Value >> 0x04) & 0x0F;
	local R		= (Value >> 0x08) & 0x0F;
        local A		= (Value >> 0x0C) & 0x0F;
	
	R		= math.floor((R / 0x0F) * 0xFF + 0.5);
        G		= math.floor((G / 0x0F) * 0xFF + 0.5);
        B		= math.floor((B / 0x0F) * 0xFF + 0.5);
        A		= math.floor((A / 0x0F) * 0xFF + 0.5);
	
	return {R, G, B, A};
end;

function _ENV.IA8ToRGBATable(Value)
	local I		= (Value >> 0x00) & 0xFF;
	local A		= (Value >> 0x08) & 0xFF;
	
	I		= math.floor((I / 0xFF) * 0xFF + 0.5);
        A		= math.floor((A / 0xFF) * 0xFF + 0.5);
	
	return {I, I, I, A};
end;

-- # derived from: https://github.com/trashbyte/LibGC/blob/8a4b5bf6fa02cf613d4655b2b06a0d95f2087632/src/Texture/ColorConversion.cs#L117C0-L141C0
function _ENV.RGB5A3ToRGBATable(Value)
	local HasAlpha	= ((~Value >> 0x0F) & 0x01);
	
	local RGBsiz	= 0x05 - HasAlpha;
	local RGBmask	= 0xFF >> (0x8 - RGBsiz);
	local Amask	= 0xFF >> ~-((0x4 - HasAlpha) << 0x01);
	
	local B		= (Value >> (RGBsiz * 0x00)) & RGBmask;
	local G		= (Value >> (RGBsiz * 0x01)) & RGBmask;
	local R		= (Value >> (RGBsiz * 0x02)) & RGBmask;
        local A		= (Value >> (RGBsiz * 0x03)) & Amask;
	
	R		= math.floor((R / RGBmask) * 0xFF + 0.5);
        G		= math.floor((G / RGBmask) * 0xFF + 0.5);
        B		= math.floor((B / RGBmask) * 0xFF + 0.5);
        A		= math.floor((A / Amask) * 0xFF + 0.5);
	A		= A | (-(HasAlpha ~ 0x01) & 0xFF);
	
	return {R, G, B, A};
end;

return true;