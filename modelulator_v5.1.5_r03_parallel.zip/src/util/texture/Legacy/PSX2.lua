local PSX2		= {};
PSX2.Swizzle		= {};

function PSX2.Swizzle.PSMT4(PixelIndex, ModeFlag)
	local Result	= 0x00;
	
	local AX, AY	= (PixelIndex >> 00) & 0x01, (PixelIndex >> 01) & 0x01;
	local BX, BY	= (PixelIndex >> 02) & 0x01, (PixelIndex >> 03) & 0x01;
	local CX, CY	= (PixelIndex >> 04) & 0x01, (PixelIndex >> 05) & 0x01;
	local DX	= (PixelIndex >> 06) & 0x01;
	
	Result		= Result ~ (DX << 00);
	Result		= Result ~ (BY << 01);
	Result		= Result ~ (CX << 02);
	Result		= Result ~ (AX << 03);
	Result		= Result ~ (AY << 04);
	Result		= Result ~ (BX << 05);
	Result		= Result ~ (AX << 07);
	
	Result		= Result ~ (CY << (03 + 03 * (ModeFlag and 1 or 0)));
	
	Result		= Result >> (ModeFlag and 0 or 1);
	Result		= Result ~ (DX << 05);
	
	Result		= Result & 0x7F;
	
	return Result;
end;

function PSX2.Swizzle.PSMT8(PixelIndex, ModeFlag)
	local Result	= 0x00;
	
	local AX, AY	= (PixelIndex >> 00) & 0x01, (PixelIndex >> 01) & 0x01;
	local BX, BY	= (PixelIndex >> 02) & 0x01, (PixelIndex >> 03) & 0x01;
	local CX, CY	= (PixelIndex >> 04) & 0x01, (PixelIndex >> 05) & 0x01;
	
	Result		= Result ~ (AX << 00);
	Result		= Result ~ (CY << 01);
	Result		= Rotate(Result, 05 + 01 * (ModeFlag and 1 or 0), 7);
	
	Result		= Result ~ (BX << (00 + 04 * (ModeFlag and 1 or 0)));
	Result		= Result ~ (CX << (02 + 03 * (ModeFlag and 1 or 0)));
	
	Result		= Result ~ (BY << 01);
	Result		= Result ~ (AX << 02);
	Result		= Result ~ (AY << 03);
	Result		= Result ~ (CY << 04);
	
	Result		= Result & 0x3F;
	
	return Result;
end;

function PSX2.Swizzle.PSMT16(PixelIndex, ModeFlag)
	local Result	= 0x00;
	
	local AX, AY	= (PixelIndex >> 00) & 0x01, (PixelIndex >> 01) & 0x01;
	local BX, BY	= (PixelIndex >> 02) & 0x01, (PixelIndex >> 03) & 0x01;
	local CX	= (PixelIndex >> 04) & 0x01;
	
	Result		= Result ~ (AY << 00);
	Result		= Result ~ (BX << 01);
	Result		= Result ~ (BY << 02);
	Result		= Result ~ (AX << 03);
	
	Result		= Rotate(Result, 2 * (ModeFlag and 1 or 0), 4);
	
	Result		= Result ~ (CX << 04);
	
	Result		= Result & 0x1F;
	
	return Result;
end;

function PSX2.Swizzle.PSMT32(PixelIndex, ModeFlag)
	local Result	= 0x00;
	local AX, AY	= (PixelIndex >> 00) & 0x01, (PixelIndex >> 01) & 0x01;
	local BX, BY	= (PixelIndex >> 02) & 0x01, (PixelIndex >> 03) & 0x01;
        
	Result		= Result ~ (AY << 00);
	Result		= Result ~ (BX << 01);
	Result		= Result ~ (BY << 02);
	Result		= Rotate(Result, 02 + 01 * (ModeFlag and 1 or 0), 3);
	
	Result		= Result << 01;
	Result		= Result ~ (AX << 00);
	
	Result		= Result & 0x0F;
	
	return Result;
end;

function PSX2.Swizzle.BlockAddress(BlockIndex, SwapXY, FlipXY, Shifted)
	local Result		= 0x00000000;
	
	if (type(SwapXY) == "boolean") then
		SwapXY		= (SwapXY == true) and 1 or 0;
	elseif (type(SwapXY) == "number") then
		SwapXY		= (SwapXY ~= 0) and 1 or 0;
	end;
	
	SwapXY			= (SwapXY << 00) ~ (SwapXY << 01);
	
	BlockIndex		= Rotate(BlockIndex, SwapXY, 05);
	
	local AX, AY		= (BlockIndex >> 00) & 0x00000001, (BlockIndex >> 03) & 0x00000001;
	local BX, BY		= (BlockIndex >> 01) & 0x00000001, (BlockIndex >> 04) & 0x00000001;
	local CX		= (BlockIndex >> 02) & 0x00000001;
	
	Result			= Result ~ (BX << 00);
	Result			= Result ~ (BY << 01);
	Result			= Result ~ (CX << 02);
	
	Result			= Rotate(Result, 01 * (Shifted and 1 or 0), 03);
	
	Result			= Result ~ ((0x00000003 * (FlipXY and 1 or 0)) << 01);
	
	Result			= Result << 02;
	Result			= Result ~ (AX << 00);
	Result			= Result ~ (AY << 01);
	
	Result			= Result & 0x0000001F;
	
	return Result;
end;

PSX2.Swizzle.FunctionTable	=
{
	[32]			= PSX2.Swizzle.PSMT32;
	[24]			= PSX2.Swizzle.PSMT32;
	[16]			= PSX2.Swizzle.PSMT16;
	[8]			= PSX2.Swizzle.PSMT8;
	[4]			= PSX2.Swizzle.PSMT4;
};

local ModeFlagControl		= true;

function PSX2.RWBuffer(ImageData, RWMode, PixelStorageMode, BitDepth, Width, Height)
	RWMode				= string.lower(RWMode);
	
	local Scale			= (32 // BitDepth);
	local ScaleMask			= ~-Scale;
	
	local ScaleX			= -~(AdjustWithMask(ScaleMask, 1, 2, 1) | AdjustWithMask(ScaleMask, 1, 0, 0));
	local ScaleY			= -~(AdjustWithMask(ScaleMask, 1, 3, 1) | AdjustWithMask(ScaleMask, 1, 1, 0));
	
	local Data			= {};
	local DebugTrace		= {};
	
	local PhysicalWidth, PhysicalHeight			= Width // ScaleY, Height // ScaleX;
	
	local PhysicalBufferWidth, PhysicalBufferHeight	= AlignPowerOfTwoMax(PhysicalWidth), AlignPowerOfTwoMax(PhysicalHeight);
	local BufferWidth, BufferHeight			= AlignPowerOfTwoMax(Width), AlignPowerOfTwoMax(Height);
	
	--print(string.format("%i x %i -> %i x %i", Width, Height, BufferWidth, BufferHeight));
	
	for y = 0, ~-PhysicalBufferHeight do
		for x = 0, ~-PhysicalBufferWidth do
			Data[x + y * PhysicalBufferWidth + 1]	= 0x00000000;
		end;
	end;
	
	local TypeIndex			= AdjustWithMask(PixelStorageMode.Value, 3, 0);
	local TypeMode			= AdjustWithMask(PixelStorageMode.Value, 2, 4);
	local TypeFlag			= AdjustWithMask(PixelStorageMode.Value, 1, 3) ~= 0x00;
	
	local SwapXY			= (((TypeMode == 0) or (TypeMode == 3)) and (TypeIndex == 2)) or ((TypeMode == 1) and (TypeIndex == 4));
	local ZBuffer			= (TypeMode == 3);
	local Shifted			= ((TypeMode == 0) or (TypeMode == 3)) and (TypeIndex == 2) and (TypeFlag == true);
	
	local PixelCount		= 16 * Scale;
	
	local ColumnWidth		= 8 * ScaleX;
	local ColumnHeight		= 2 * ScaleY;
	
	local BlockHeight		= 4;
	local BlockWidth		= 1;
	
	local PageHeight		= 0x00000001 << (01 * (SwapXY and 1 or 0));
	local PageWidth			= PageHeight ~ 0x03;
	
	PageWidth			= PageWidth << 02;
	PageHeight			= PageHeight << 02;
	
	local TextureBufferWidth	= Width // (PageWidth * BlockWidth * ColumnWidth);
	
	local PSMTSwizzleFunction	= PSX2.Swizzle.FunctionTable[BitDepth];
	
	local InputAddress		= 0x00000000;
	local FromOffsetW		= 0;
	
	for i = 0, ~-(BufferWidth * BufferHeight) do
		local Y			= i // BufferWidth;
		local X			= i - Y * BufferWidth;
		
		local PageX		= X // (PageWidth * BlockWidth * ColumnWidth);
		local PageY		= Y // (PageHeight * BlockHeight * ColumnHeight);
		local Page		= PageX + PageY * TextureBufferWidth;
		
		local PX		= X - PageX * (PageWidth * BlockWidth * ColumnWidth);
		local PY		= Y - PageY * (PageHeight * BlockHeight * ColumnHeight);
		
		local BlockX		= PX // (BlockWidth * ColumnWidth);
		local BlockY		= PY // (BlockHeight * ColumnHeight);
		local Block		= PSX2.Swizzle.BlockAddress(BlockX + BlockY * PageWidth, SwapXY, ZBuffer, Shifted);
		
		local BX		= PX - BlockX * (BlockWidth * ColumnWidth);
		local BY		= PY - BlockY * (BlockHeight * ColumnHeight);
		
		local ColumnX		= BX // (ColumnWidth);
		local ColumnY		= BY // (ColumnHeight);
		local Column		= ColumnX * 0 + ColumnY * 1;
		
		local CX		= BX - ColumnX * (ColumnWidth);
		local CY		= BY - ColumnY * (ColumnHeight);
		
		local Pixel		= PSMTSwizzleFunction(CX + CY * ColumnWidth, ModeFlagControl);
		
		local Word		= (Pixel // (Scale));
		local Offset		= (Pixel & (ScaleMask));
		
		if (BitDepth < 16) then
			Word		= Word ~ ((Column & 0x00000001) << 02);
		end;
		
		Word			= (Rotate(Word >> 01, -1, 3) << 01) | (Word & 0x00000001);
		
		local OutputAddress	= ((Page << 11) | (Block << 06) | (Column << 04) | (Word << 00));
		
		local AddressA, AddressB	= 0x00000000, 0x00000000;
		
		local FromOffset, ToOffset	= 0, 0;
		
		if (RWMode == "read") then
			AddressA, AddressB	= (InputAddress), (OutputAddress);
			FromOffset, ToOffset	= (Offset), i & ScaleMask;
		elseif (RWMode == "write") then
			AddressA, AddressB	= (OutputAddress), (InputAddress);
			FromOffset, ToOffset	= i & ScaleMask, (Offset);
		end;
		
		local FromPage		= AdjustWithMask(AddressB, 10, 11);
		local FromBlock		= AdjustWithMask(AddressB, 05, 06);
		local FromColumn	= AdjustWithMask(AddressB, 02, 04);
		local FromWord		= AdjustWithMask(AddressB, 04, 00);
		
		local ToPage		= AdjustWithMask(AddressA, 10, 11);
		local ToBlock		= AdjustWithMask(AddressA, 05, 06);
		local ToColumn		= AdjustWithMask(AddressA, 02, 04);
		local ToWord		= AdjustWithMask(AddressA, 04, 00);
		
		local FromY		= (AddressB * Scale + FromOffset) // BufferWidth;
		local FromX		= (AddressB * Scale + FromOffset) - FromY * BufferWidth;
		
		local ToY		= (AddressA * Scale + ToOffset) // BufferWidth;
		local ToX		= (AddressA * Scale + ToOffset) - ToY * BufferWidth;
		
		local InputData		= ImageData[-~AddressB];
		local PixelData		= 0x00000000;
		
		if (RWMode == "read") then
			PixelData	= AdjustWithMask(InputData, BitDepth, BitDepth * Offset, BitDepth * FromOffsetW);
		elseif (RWMode == "write") then
			PixelData	= AdjustWithMask(InputData, BitDepth, BitDepth * FromOffsetW, BitDepth * Offset);
		end;
		
		Data[-~AddressA]		= (Data[-~AddressA] or 0x00000000) | PixelData;
		
		FromOffsetW			= -~FromOffsetW;
		
		if ((FromOffsetW > 0x00000000) and (FromOffsetW & ScaleMask == 0x00000000)) then
			InputAddress		= -~InputAddress;
		end;
		
		FromOffsetW			= FromOffsetW & ScaleMask;
	end;
	
	return Data;
end;

function PSX2.PackRGBATable(RGBATable)
	local R, G, B, A	= table.unpack(RGBATable);
	
	if (math.max((A << 0x1) - ((A ~ 0x1) & 0x1), 0) <= 0xFF) then
		A		= math.max((A << 0x1) - ((A ~ 0x1) & 0x1), 0);
	end;
	
	return string.pack("<BBBB", B, G, R, A);
end;

function PSX2:Get(DataPointer, TextureInfo, TexturePlatInfo)
	local Input, Output;
	
	TexturePlatInfo		= (TexturePlatInfo ~= nil) and TexturePlatInfo or TextureInfo;
	
	local Buffer		= {};
	local CLUT		= {};
	
	local Address0		= 0x00000000;
	local Address1		= 0x00000000;
	
	local BufferWidth	= 1 << TextureInfo.ShiftWidth;
	local BufferHeight	= 1 << TextureInfo.ShiftHeight;
	
	Input			= {};
	Output			= {};
	
	local DataRemainder	= BufferWidth * BufferWidth - TextureInfo.Width * TextureInfo.Height;
	local WidthRemainder	= ((~-BufferWidth) & TextureInfo.Width);
	
	if (TexturePlatInfo.BitDepth == nil) then
		local Idx			= AdjustWithMask(TexturePlatInfo.PixelStorageMode.Value, 3, 0, 0);
		TexturePlatInfo.BitDepth	= 32 >> math.max(Idx - 1, 0);
	end;
	
	local Scale		= (32 // TexturePlatInfo.BitDepth);
	local ScaleMask		= ~-Scale;
	
	for i = 0x0000, ~-(TextureInfo.BaseImageSize >> 02) do
		table.insert(Input, ResourceFile:Read(DataPointer + TextureInfo.ImagePlacement + (i << 02), "<I4"));
	end;
	
	local ScaleX		= -~(AdjustWithMask(ScaleMask, 1, 2, 1) | AdjustWithMask(ScaleMask, 1, 0, 0));
	local ScaleY		= -~(AdjustWithMask(ScaleMask, 1, 3, 1) | AdjustWithMask(ScaleMask, 1, 1, 0));
	
	local TypeIndex		= AdjustWithMask(TexturePlatInfo.PixelStorageMode.Value, 3, 0);
	local TypeMode		= AdjustWithMask(TexturePlatInfo.PixelStorageMode.Value, 2, 4);
	local TypeFlag		= AdjustWithMask(TexturePlatInfo.PixelStorageMode.Value, 1, 3) ~= 0x00;
	
	if (TextureInfo.PaletteSize > 0x00000000) then
		for i = 0, ~-(TextureInfo.PaletteSize >> 02) do
			local X, Y		= (i >> 03) & 0x00000001, (i >> 04) & 0x00000001;
			
			local Flip		= (X ~ Y);
			Flip			= Flip * ((TypeIndex == 3) and 0x00000001 or 0x00000000);
			Flip			= ((Flip << 00) | (Flip << 01));
			
			local Destination	= i ~ (Flip << 03);
			local RGBATable		= {ResourceFile:Read(DataPointer + TextureInfo.PalettePlacement + (Destination << 02), "<BBBB")};
			
			CLUT[-~i]		= PSX2.PackRGBATable(RGBATable);
		end;
	end;
	
	local Swizzled		= (TexturePlatInfo.ImageInfos[1].Is32BitSwizzled ~= 00);
	
	if (Swizzled == true) then
		Buffer		= PSX2.RWBuffer(Input, "Write", ModelulatorEnum.PixelStorageMode.PSMCT32, 32, TextureInfo.Width // ScaleY, TextureInfo.Height // ScaleX);
		Input		= PSX2.RWBuffer(Buffer, "Read", TexturePlatInfo.PixelStorageMode, TexturePlatInfo.BitDepth, TextureInfo.Width, TextureInfo.Height);
	end;
	
	if (TexturePlatInfo.BitDepth < 16) then
		for p = 1, #Input do
			for o = 0, ScaleMask do
				local i		= AdjustWithMask(Input[p], TexturePlatInfo.BitDepth, TexturePlatInfo.BitDepth * o);
				local c		= CLUT[-~i];
				local d		= (~-p) * Scale + o;
				
				Output[-~d]	= CLUT[-~i];
			end;
		end;
	else
		for p = 1, #Input do
			local c			= Input[p];
			local R, G, B, A	= (c >> (08 * 0)) & 0xFF, (c >> (08 * 1)) & 0xFF, (c >> (08 * 2)) & 0xFF, (c >> (08 * 3)) & 0xFF;
			
			if (math.max((A << 0x1) - ((A ~ 0x1) & 0x1), 0) <= 0xFF) then
				A		= math.max((A << 0x1) - ((A ~ 0x1) & 0x1), 0);
			end;
			
			Output[p]		= PackRGBATable({R, G, B, A});
		end;
	end;
	
	if (Swizzled == true) then
		Input, Output		= Output, {};
		
		for y = 0, ~-TextureInfo.Height do
			for x = 0, ~-TextureInfo.Width do
				local Source		= x + y * (BufferWidth);
				local Destination	= x + y * (TextureInfo.Width);
				Output[-~Destination]	= Input[-~Source];
			end;
		end;
	end;
	
	local function FlipY()
		Input, Output			= Output, {};
		
		for i = 0, ~-#Input do
			local x			= (i % TextureInfo.Width);
			local y			= i - x;
			
			Output[#Input - i]	= Input[-~(TextureInfo.Width - x - 1 + y)];
		end;
	end;
	
	FlipY();
	
	return Output;
end;

return PSX2;