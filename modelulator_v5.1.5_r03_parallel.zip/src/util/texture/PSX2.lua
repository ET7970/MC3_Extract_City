local PSX2		= {};

function PSX2.PackRGBATable(RGBATable)
	local R, G, B, A	= table.unpack(RGBATable);
	
	if (math.max((A << 0x1) - ((A ~ 0x1) & 0x1), 0) <= 0xFF) then
		A		= math.max((A << 0x1) - ((A ~ 0x1) & 0x1), 0);
	end;
	
	return string.pack("<BBBB", B, G, R, A);
end;

function PSX2:Get(DataPointer, TextureInfo, TexturePlatInfo)
	local TextureOffset	= DataPointer + TextureInfo.ImagePlacement;
	local IsSwizzled	= (TexturePlatInfo.ImageInfos[1].Is32BitSwizzled ~= 0);
	local BitDepth		= 32 >> math.max(AdjustWithMask(TexturePlatInfo.PixelStorageMode.Value, 3, 0, 0) - 1, 0);
	local Width		= TextureInfo.Width;
	local Height		= TextureInfo.Height;
	local ShiftWidth	= TextureInfo.ShiftWidth;
	local ShiftHeight	= TextureInfo.ShiftHeight;
	
	local Scale		= (32 // BitDepth);
	local ScaleMask		= ~-Scale;
	
	local is4bit		= (BitDepth == 4);
	
	local Input		= {};
	local Output		= {};
	
	local CLUT		= {};
	
	local TypeIndex		= AdjustWithMask(TexturePlatInfo.PixelStorageMode.Value, 3, 0);
	local TypeMode		= AdjustWithMask(TexturePlatInfo.PixelStorageMode.Value, 2, 4);
	local TypeFlag		= AdjustWithMask(TexturePlatInfo.PixelStorageMode.Value, 1, 3) ~= 0x00;
	
	if (TextureInfo.PaletteSize > 0x00000000) then
		for i = 0, ~-(TextureInfo.PaletteSize >> 02) do
			local X, Y		= (i >> 03) & 0x00000001, (i >> 04) & 0x00000001;
			
			local Flip		= (X ~ Y);
			Flip			= Flip * ((TypeIndex == 3) and 0x00000001 or 0x00000000);
			Flip			= ((Flip << 00) | (Flip << 01));
			
			local Destination	= i ~ (Flip << 03);
			local RGBATable		= {ResourceFile:Read(DataPointer + TextureInfo.PalettePlacement + (Destination << 02), "<BBBB")};
			
			CLUT[-~i]		= PSX2.PackRGBATable(RGBATable);
		end;
	end;
	
	local BufferWidth	= 1 << ShiftWidth;
	local BufferHeight	= 1 << ShiftHeight;
	
	local Index		= 0;
	
	for y = 0x0000, BufferHeight - 0x0001 do
		Index		= y << ShiftWidth;
		
		for x = 0x0000, BufferWidth - 0x0001 do
			Index		= Index + 1;
			
			Input[Index]	= 0x00;
			Output[Index]	= 0x00;
		end;
	end;
	
	local WidthRemainder	= ((~-BufferWidth) & Width);
	
	for y = 0, Height - 1 do
		for x = 0, Width - 1 do
			local Mask	= 0xFF;
			local Shift	= 0x00;
			local Address0	= x + y * Width;
			
			if (is4bit) then
				Address0 = (x + y * Width) >> 0x01;
				Shift	= (x & 0x1) * 0x04;
				Mask	= 0x0F << Shift;
				--print(string.format("0x%08X", Address0));
			end;
			
			local Address1	= x + (y & (~0x1)) * BufferWidth + (y & 0x1) * Width;
			
			if ((Width & 0x1F ~= 0x00) or (WidthRemainder ~= 0x00)) then
				Address1	= x + y * BufferWidth;
			end
			
			Input[Address1 + 1] = (ResourceFile:Read(Address0 + TextureOffset, "<B") & Mask) >> Shift;
		end;
	end;
	
	Address0 = 0x00000000;
	Address1 = 0x00000000;
	
	local BHMask		= ~(~-BufferWidth);
	
	if (IsSwizzled and ((Width & 0x1F == 0x00) or (WidthRemainder == 0x00) or (Width == 0x0010))) then
		for y = 0x000, BufferHeight - 1 do
			local TempValue01	= ((y & 0x02) >> 01) | ((y & 0x02) << 03);
			local TempValue02	= ((y & 0x04) << 02);
			
			Address0		= y << ShiftWidth;
			Address1		= ((y & -0x04) | ((y & 0x01) << 01)) << ShiftWidth;
			
			for x = 0x000, BufferWidth - 1 do
				Address0	= (Address0 & BHMask) | x;
				
				Address1	= ((Address1 & BHMask) | ((x & 0x07) << 02) | ((x & 0x08) >> 02) | ((x >> 04) << 05)) ~ TempValue01 ~ TempValue02;
				
				if (Output[Address0 + 1] == nil) then
					print("Address0", Address0);
				end;
				
				if (Input[Address1 + 1] == nil) then
					print("Address1", Address1);
				end;
				
				Output[Address0 + 1] = Input[Address1 + 1];
				--Address1 = Address1 + 0x1;
			end;
		end;
	else
		for y = 0x000, BufferHeight - 1 do
			for x = 0x000, BufferWidth - 1 do
				Address0 = x + y * BufferWidth;
				
				if (Output[Address0 + 1] == nil) then
					print("Address0", Address0);
				end;
				
				Output[Address0 + 1] = Input[Address0 + 1];
				--Address1 = Address1 + 0x1;
			end;
		end;
	end;
	
	Input, Output		= Output, {};
	
	if (BitDepth < 16) then
		for p = 1, #Input do
			local i		= Input[p];
			Output[p]	= CLUT[-~i];
		end;
	else
		for p = 1, #Input do
			local c			= Input[p];
			local R, G, B, A	= (c >> (08 * 0)) & 0xFF, (c >> (08 * 1)) & 0xFF, (c >> (08 * 2)) & 0xFF, (c >> (08 * 3)) & 0xFF;
			
			if (math.max((A << 0x1) - ((A ~ 0x1) & 0x1), 0) <= 0xFF) then
				A		= math.max((A << 0x1) - ((A ~ 0x1) & 0x1), 0);
			end;
			
			Output[p]		= PackRGBATable({R, G, B, A});
		end;
	end;
	
	local function FlipY()
		Input, Output			= Output, {};
		
		for y = Height - 1, 0, -1 do
			Output			= table.move(Input, 1 + y * BufferWidth, Width / 2 + y * BufferWidth, #Output + 1, Output);
			Output			= table.move(Input, 1 + BufferWidth / 2 + y * BufferWidth, Width / 2 + BufferWidth / 2 + y * BufferWidth, #Output + 1, Output);
		end;
	end;
	
	FlipY();
	
	--Input, Output = Output, Input;
	
	--print(#Output);
	
	return Output;
end;

return PSX2;