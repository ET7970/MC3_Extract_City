local REVOLUTION	= {};
local DXTC1		= require("src.util.texture.DXTC1");

function REVOLUTION:Get(TextureOffset, PaletteOffset, TexComp, w, h, AlphaUsageType, AlphaBlendType, LastAlphaUsageType, LastAlphaBlendType)
	if (TexComp == ModelulatorEnum.TextureCompressionType.DXTC1) then
		return DXTC1:Get(TextureOffset, w, h);
	end;
	
	local Image		= {};
	
	if (TexComp == ModelulatorEnum.TextureCompressionType.Tex4Bit) then
		local DataOffset	= 0x00000000;
		ImageDataSize		= (w * h) << -01;
		
		for i = 0x00, ~-(ImageDataSize >> 05) do
			local pbi	= i << 03;
			local pbx	= (pbi % w);
			local pby	= (pbi // w) << 03;
			
			for y = 0x0, 0x7 do
				for x = 0x0, 0x7 do
					local off		= (x + y * 0x08);
					local cli		= ResourceFile:Read(TextureOffset + DataOffset + (off << -01), ">B");
					cli			= AdjustWithMask(cli, 04, 04 * ((~off) & 0x01));
					local curRGBATable	= RGB5A3ToRGBATable(ResourceFile:Read(PaletteOffset + cli * 0x02, ">H"));
					
					local px, py		= pbx + x, pby + y;
					py			= h - py - 1;
					local pi		= -~(px + py * w);
					Image[pi]		= PackRGBATable(curRGBATable);
				end;
			end;
			
			DataOffset			= DataOffset + 0x20;
		end;
	elseif (TexComp == ModelulatorEnum.TextureCompressionType.Tex8Bit) then
		local DataOffset	= 0x00000000;
		ImageDataSize		= (w * h) << 00;
		
		for i = 0x00, ~-(ImageDataSize >> 05) do
			local pbi	= i << 03;
			local pbx	= (pbi % w);
			local pby	= (pbi // w) << 02;
			
			for y = 0x0, 0x3 do
				for x = 0x0, 0x7 do
					local cli		= ResourceFile:Read(TextureOffset + DataOffset + ((x + y * 0x08) << 00), ">B");
					local curRGBATable	= RGB5A3ToRGBATable(ResourceFile:Read(PaletteOffset + cli * 0x02, ">H"));
					
					local px, py		= pbx + x, pby + y;
					py			= h - py - 1;
					local pi		= -~(px + py * w);
					Image[pi]		= PackRGBATable(curRGBATable);
				end;
			end;
			
			DataOffset			= DataOffset + 0x20;
		end;
	elseif (TexComp == ModelulatorEnum.TextureCompressionType.Tex16Bit) then
		DataOffset		= 0x00000000;
		ImageDataSize		= (w * h) << 01;
		
		for i = 0x00, ~-(ImageDataSize >> 05) do
			local pbi	= (i << 02);
			local pbx	= (pbi % w);
			local pby	= (pbi // w) << 02;
			
			for y = 0x0, 0x3 do
				for x = 0x0, 0x3 do
					local curRGBATable	= RGB5A3ToRGBATable(ResourceFile:Read(TextureOffset + DataOffset + ((x + y * 0x04) << 01), ">H"));
					
					local px, py		= pbx + x, pby + y;
					py			= h - py - 1;
					local pi		= -~(px + py * w);
					Image[pi]		= PackRGBATable(curRGBATable);
				end;
			end;
			
			DataOffset			= DataOffset + 0x20;
		end;
	elseif (TexComp == ModelulatorEnum.TextureCompressionType.Tex32Bit) then
		DataOffset		= 0x00000000;
		ImageDataSize		= (w * h) << 02;
		
		for i = 0x00, ~-(ImageDataSize >> 05) do
			local pbi	= (i << 01);
			local pbx	= (pbi % w);
			local pby	= (pbi // w) << 02;
			
			for y = 0x0, 0x1 do
				for x = 0x0, 0x3 do
					local curRGBATable	= RGB5A3ToRGBATable(ResourceFile:Read(TextureOffset + DataOffset + ((x + y * 0x02) << 02), ">H"));
					
					local px, py		= pbx + x, pby + y;
					py			= h - py - 1;
					local pi		= -~(px + py * w);
					Image[pi]		= PackRGBATable(curRGBATable);
				end;
			end;
			
			DataOffset			= DataOffset + 0x20;
		end;
	elseif (TexComp == ModelulatorEnum.TextureCompressionType.Tex8Bit_RGB24_A8) then
		DataOffset		= 0x00000000;
		ImageDataSize		= w * h;
		
		for i = 0x00, ~-(ImageDataSize >> 05) do
			local pbi	= i << 03;
			local pbx	= (pbi % w);
			local pby	= (pbi // w) << 02;
			
			for y = 0x0, 0x3 do
				for x = 0x0, 0x7 do
					local cli		= ResourceFile:Read(TextureOffset + DataOffset + ((x + y * 0x08) << 00), ">B");
					
					local A			= (ResourceFile:Read(PaletteOffset + cli * 0x02 + 0x0000 + 0x00, ">B"));
					local R			= (ResourceFile:Read(PaletteOffset + cli * 0x02 + 0x0000 + 0x01, ">B"));
					local G			= (ResourceFile:Read(PaletteOffset + cli * 0x02 + 0x0200 + 0x00, ">B"));
					local B			= (ResourceFile:Read(PaletteOffset + cli * 0x02 + 0x0200 + 0x01, ">B"));
					
					local curRGBATable	= {R, G, B, A};
					
					local px, py		= pbx + x, pby + y;
					py			= h - py - 1;
					local pi		= -~(px + py * w);
					
					Image[pi]		= PackRGBATable(curRGBATable);
				end;
			end;
			
			DataOffset			= DataOffset + 0x20;
		end;
	elseif (TexComp == ModelulatorEnum.TextureCompressionType.IA8) then
		local DataOffset	= 0x00000000;
		ImageDataSize		= (w * h) << 01;
		
		for i = 0x00, ~-(ImageDataSize >> 05) do
			local pbi	= i << 02;
			local pbx	= (pbi % w);
			local pby	= (pbi // w) << 02;
			
			for y = 0x0, 0x3 do
				for x = 0x0, 0x3 do
					local curRGBATable	= IA8ToRGBATable(ResourceFile:Read(TextureOffset + DataOffset + ((x + y * 0x04) << 01), ">H"));
					
					local px, py		= pbx + x, pby + y;
					py			= h - py - 1;
					local pi		= -~(px + py * w);
					
					Image[pi]		= PackRGBATable(curRGBATable);
				end;
			end;
			
			DataOffset		= DataOffset + 0x20;
		end;
	end;
	
	return table.concat(Image, "");
end;

return REVOLUTION;