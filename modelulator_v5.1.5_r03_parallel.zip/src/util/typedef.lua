local typedef		= {};

-- base types
typedef["int"]			= "i4";
typedef["unsigned int"]		= "I4";
typedef["long int"]		= "i8";
typedef["long unsigned int"]	= "I8";
typedef["short int"]		= "i2";
typedef["short unsigned int"]	= "I2";
typedef["char"]			= "c";
typedef["signed char"]		= "i1";
typedef["unsigned char"]	= "I1";
typedef["float"]		= "f";
typedef["double"]		= "d";
typedef["bool"]			= "I1";

-- yes this is actually how void gets defined
typedef["void"]			= typedef["void"];

-- beauty types
typedef["int8"]			= typedef["signed char"];
typedef["uint8"]		= typedef["unsigned char"];
typedef["int16"]		= typedef["short int"];
typedef["uint16"]		= typedef["short unsigned int"];
typedef["uint16"]		= typedef["short unsigned int"];
typedef["int32"]		= typedef["int"];
typedef["uint32"]		= typedef["unsigned int"];
typedef["int64"]		= typedef["long int"];
typedef["uint64"]		= typedef["long unsigned int"];

return typedef;