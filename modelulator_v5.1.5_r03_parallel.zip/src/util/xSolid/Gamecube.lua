-- [GAMECUBE] Generate xSolid Groups

local function align(x, al)
	al = -al;
	return (x + ~al) & al;
end;

local function GenerateGroups(GamecubeData)
	local Groups		= {};
	
	local v			= {};
	local vt		= {};
	local vn		= {};
	local vc		= {};
	local f			= {};
	
	local idx_vert		= 0;
	local num_vert_total	= 0;
	local num_poly_total	= 0;
	
	for k = 1, GamecubeData.NumStrips do
		local g		=
		{
			STRIPENTRY	= GamecubeData.StripEntryTable[k];
			VERTICES	= {};
			UV		= {{}, {}, {}, {}, {}, {}, {}, {}};
			RGBA		= {{}, {}};
			NORMALS		= {};
			INDICES		= {};
		};
		
		v			= {};
		vt			= {};
		vn			= {};
		vc			= {};
		f			= {};
		
		local eStripEntry	= g.STRIPENTRY;
		local DataAddress	= GamecubeData.StripDataPointer + eStripEntry.DataOffset;
		local NumVerts		= eStripEntry.NumVerts;
		local NumPolys		= eStripEntry.NumPolys;
		
		local Offset		= 0x0000;
		
		for j = 0x00, NumVerts - 0x01 do
			local idx_v, idx_c, idx_t = 0, 0, 0;
			local _x, _y, _z, _u, _v, _r, _g, _b, _a = 0, 0, 0, 0, 0, 0, 0, 0, 0;
			
			if (eStripEntry.VtxDescAndFmt == 0x01) then
				idx_v	= ResourceFile:Read(DataAddress + Offset + 0x00 * 0x02, ">H");
				idx_c	= ResourceFile:Read(DataAddress + Offset + 0x02 * 0x02, ">H");
				idx_t	= ResourceFile:Read(DataAddress + Offset + 0x03 * 0x02, ">H");
				
				_x	= ResourceFile:Read(GamecubeData.StripDataPointer + GamecubeData.DataOffset0 + idx_v * 0x0C + 0x00, ">f");
				_y	= ResourceFile:Read(GamecubeData.StripDataPointer + GamecubeData.DataOffset0 + idx_v * 0x0C + 0x04, ">f");
				_z	= ResourceFile:Read(GamecubeData.StripDataPointer + GamecubeData.DataOffset0 + idx_v * 0x0C + 0x08, ">f");
				
				_u	= ResourceFile:Read(GamecubeData.StripDataPointer + GamecubeData.DataOffset3 + idx_t * 0x04 + 0x00, ">h") / 4096;
				_v	= ResourceFile:Read(GamecubeData.StripDataPointer + GamecubeData.DataOffset3 + idx_t * 0x04 + 0x02, ">h") / 4096;
				
				_r	= ResourceFile:Read(GamecubeData.StripDataPointer + GamecubeData.DataOffset2 + idx_c * 0x04 + 0x00, ">B");
				_g	= ResourceFile:Read(GamecubeData.StripDataPointer + GamecubeData.DataOffset2 + idx_c * 0x04 + 0x01, ">B");
				_b	= ResourceFile:Read(GamecubeData.StripDataPointer + GamecubeData.DataOffset2 + idx_c * 0x04 + 0x02, ">B");
				_a	= ResourceFile:Read(GamecubeData.StripDataPointer + GamecubeData.DataOffset2 + idx_c * 0x04 + 0x03, ">B");
				
				Offset	= Offset + 0x08;
			elseif (eStripEntry.VtxDescAndFmt == 0x02) then
				idx_v	= ResourceFile:Read(DataAddress + Offset + 0x00, ">B");
				idx_c	= ResourceFile:Read(DataAddress + Offset + 0x02, ">B");
				idx_t	= ResourceFile:Read(DataAddress + Offset + 0x03, ">B");
				
				_x	= ResourceFile:Read(GamecubeData.StripDataPointer + GamecubeData.DataOffset0 + idx_v * 0x0C + 0x00, ">f");
				_y	= ResourceFile:Read(GamecubeData.StripDataPointer + GamecubeData.DataOffset0 + idx_v * 0x0C + 0x04, ">f");
				_z	= ResourceFile:Read(GamecubeData.StripDataPointer + GamecubeData.DataOffset0 + idx_v * 0x0C + 0x08, ">f");
				
				_u	= ResourceFile:Read(GamecubeData.StripDataPointer + GamecubeData.DataOffset3 + idx_t * 0x04 + 0x00, ">h") / 4096;
				_v	= ResourceFile:Read(GamecubeData.StripDataPointer + GamecubeData.DataOffset3 + idx_t * 0x04 + 0x02, ">h") / 4096;
				
				_r	= ResourceFile:Read(GamecubeData.StripDataPointer + GamecubeData.DataOffset2 + idx_c * 0x04 + 0x00, ">B");
				_g	= ResourceFile:Read(GamecubeData.StripDataPointer + GamecubeData.DataOffset2 + idx_c * 0x04 + 0x01, ">B");
				_b	= ResourceFile:Read(GamecubeData.StripDataPointer + GamecubeData.DataOffset2 + idx_c * 0x04 + 0x02, ">B");
				_a	= ResourceFile:Read(GamecubeData.StripDataPointer + GamecubeData.DataOffset2 + idx_c * 0x04 + 0x03, ">B");
				
				Offset	= Offset + 0x04;
			end;
			
			table.insert(v, {_x, _y, _z});
			table.insert(vt, {_u, _v});
			table.insert(vc, {_r, _g, _b, _a});
		end;
		
		local Face		= 1;
		
		for i = 0x02, NumPolys + 0x01 do
			local a0, b0, c0 = i - 1 - Face, i - 1, i - 1 + Face;
			table.insert(f, {a0 + idx_vert, b0 + idx_vert, c0 + idx_vert});
				
			Face		= -Face;
		end;
		
		num_poly_total		= num_poly_total + NumPolys;
		num_vert_total		= num_vert_total + NumVerts;
		
		idx_vert		= idx_vert + NumVerts;
		
		g.VERTICES		= v;
		g.UV			= {vt, {}, {}, {}, {}, {}, {}, {}};
		g.RGBA			= {vc, {}};
		g.NORMALS		= vn;
		g.INDICES		= f;
		table.insert(Groups, g);
	end;
	
	return Groups;
end;

return GenerateGroups;