-- [PSX2] Generate xSolid Groups

local function GenerateGroups(PSX2Data)
	local Precision		=
	(
		(
			(_ENV.Config.Game == ModelulatorEnum.Game.UNDERCOVER)
			or
			(_ENV.Config.Game == ModelulatorEnum.Game.PROSTREET)
			or
			(_ENV.Config.Game == ModelulatorEnum.Game.MOSTWANTED_DEMO)
		)
		and
		(5000.0)
		or
		(256.0)
	);
	
	 --# default: 256.0
	
	-- # first try!
	local function up_isvalidformat(up_type)
		if (up_type & 0xF0 ~= 0x60) then return; end;
		
		local v = (up_type >> 0x3) & 0x1;
		local n = (up_type >> 0x2) & 0x1;
		local V = (up_type >> 0x1) & 0x1;
		local l = (up_type >> 0x0) & 0x1;
		
		return v & n & V & l == V & l;
	end;
	
	local function align(x, al)
		al = -al;
		return (x + ~al) & al;
	end;
	
	local function up_data(data_addr, up_type, up_size)
		if (not up_isvalidformat(up_type)) then return 0x00; end;
		
		local vn	= (up_type >> 0x2) & 0x3;
		local vl	= (up_type >> 0x0) & 0x3;
		
		local data_len	= align((0x08 >> vl) * (vn + 1) * up_size >> 0x01, 0x04);
		
		local data	= {};
		local o		= 0x00;
		
		data.cntC	= up_size;
		data.cntR	= vn + 0x01;
		data.vn		= vn;
		data.vl		= vl;
		data.Address	= data_addr;
		
		if (vn & vl == 0x03) then
			for C = 0x00, data.cntC - 0x01 do
				data[C] = data[C] or {};
				
				local RGBA = ResourceFile:Read(data_addr + o * 0x02, "<H");
				
				local R = (RGBA >> 0x00) & 0x1F;
				local G = (RGBA >> 0x05) & 0x1F;
				local B = (RGBA >> 0x0A) & 0x1F;
				local A = (RGBA >> 0x0F) & 0x01;
				
				data[C][0x00] = R << 0x03;
				data[C][0x01] = G << 0x03;
				data[C][0x02] = B << 0x03;
				data[C][0x03] = A * 0x7F;
				
				o = o + 0x01;
			end;
		else
			for C = 0x00, data.cntC - 0x01 do
				data[C] = data[C] or {};
				
				for R = 0x00, data.cntR - 0x01 do
					local b = ResourceFile:Read(data_addr + o * (0x04 >> vl), "<i" .. (0x04 >> vl)) & 0xFFFFFFFF;
					data[C][R] = b;
					
					o = o + 0x01;
				end;
			end;
		end;
		
		return data_len, data;
	end;
	
	local num_vertices		= 0;
	local heading			= {[0] = 0x00, [1] = 0x00, [2] = 0x00, [3] = 0x00};
	local tri_cull			= {[0] = 0x00000000, [1] = 0x00000000, [2] = 0x00000000, [3] = 0x00000000};
	
	-- # and heres the Modelulator
	
	local idx_vert			= 0;
	local num_vert_total		= 0;
	local num_poly_total		= 0;
	
	--local faces = "";
	
	local Groups = {};
	
	local num_vertices		= 0;
	local cnt_vert			= 0;
	local cnt_uv			= 0;
	local cnt_rgba			= 0;
	
	local reg			= 0x00;
	
	if (Config.Game == ModelulatorEnum.Game.MOSTWANTED_DEMO)
	then
		reg			= -0x01;
	end;
	
	-- # a bounding box that has an existing reference, though cant exist physically
	local BoundingBox	= {};
	BoundingBox.Min		= {math.huge, math.huge, math.huge};
	BoundingBox.Max		= {-math.huge, -math.huge, -math.huge};
	
	-- # im with stupid ^
	local minv 		= {math.huge, math.huge, math.huge};
	local maxv		= {-math.huge, -math.huge, -math.huge};
	
	local v			= {};
	local vt		= {};
	local vn		= {};
	local vc		= {};
	local f			= {};
	
	PSX2Data.Mode		= (PSX2Data.Mode or PlatChunks.Enum["PSX2/Mode"].Standard);
	
	if (PSX2Data.Mode == PlatChunks.Enum["PSX2/Mode"].Standard) then
		local data_buffer_table = {};
		
		for i = 1, PSX2Data.NumStrips do
			local eStripEntry	= PSX2Data.StripEntryTable[i];
			
			local eStripData_pt	= eStripEntry.Data or (eStripEntry.DataQWordOffset << 4);
			local eStripData_sz	= eStripEntry.DataQWordSize << 4;
			
			eStripData_pt		= eStripData_pt + PSX2Data.StripDataPointer;
			
			--[[
			local fmt_s = string.format(fmt_s_eStripEntry, table.unpack(d));
			fmt_s = string.upper(string.format("0x%04X\t\t%s", i - 1, fmt_s));
			fmt_s = string.gsub(fmt_s, "[^%x]", string.lower);
			
			--print(fmt_s);
			
			--print(string.format("eStripEntry[0x%04X]", i - 0x1));
			--]]
			
			local o = 0x0000;
			
			table.insert(data_buffer_table, {});
			
			while (o < eStripData_sz) do
				local inst = ResourceFile:Read(eStripData_pt + o, "<I4");
				local CMD, NUM, IMM = VIFcode:ReadInstruction(inst);
				
				o = o + 0x04;
				
				if (CMD & 0xF0 == 0x60) then
					local p_len, p_dat = up_data(eStripData_pt + o, CMD, NUM);
					table.insert(data_buffer_table[i], p_dat);
					
					o = o + p_len;
				end;
			end;
		end;
		
		local PackedDataOperations	= {};
		PackedDataOperations.Index	= 0;
		
		PackedDataOperations[0]		=
		function(section)
			if (_ENV.Config.Game == ModelulatorEnum.Game.PROSTREET) then
				num_vertices		= section[0][2];
			else
				num_vertices		= section[0][0];
			end;
			
			heading			= section[0];
			
			return true;
		end;
		
		PackedDataOperations[1]		=
		function(section)
			tri_cull		= section[0];
			
			return true;
		end;
		
		local CompressedVerts		= false;
		
		PackedDataOperations[2]		=
		function(section)
			if (_ENV.Config.Game.Value > ModelulatorEnum.Game.HOTPURSUIT2.Value) then
				local min_x, max_x = section[0x00][0x00], section[0x01][0x00];
				local min_y, max_y = section[0x00][0x01], section[0x01][0x01];
				local min_z, max_z = section[0x00][0x02], section[0x01][0x02];
				
				min_x = string.unpack("<f", string.pack("<I4", min_x));
				min_y = string.unpack("<f", string.pack("<I4", min_y));
				min_z = string.unpack("<f", string.pack("<I4", min_z));
				
				max_x = string.unpack("<f", string.pack("<I4", max_x));
				max_y = string.unpack("<f", string.pack("<I4", max_y));
				max_z = string.unpack("<f", string.pack("<I4", max_z));
				
				BoundingBox.Min	= {min_x, min_y, min_z};
				BoundingBox.Max	= {max_x, max_y, max_z};
				
				return true;
			else
				PackedDataOperations.Index	= PackedDataOperations.Index + 1;
				
				return PackedDataOperations[PackedDataOperations.Index](section);
			end;
		end;
		
		PackedDataOperations[3]
		=
		function(section)
			local Register_Colour		= 0x02;
			local Register_Normal		= 0x03;
			
			if (_ENV.Config.Game == ModelulatorEnum.Game.MOSTWANTED_DEMO)
			then
				Register_Colour		= 0x03;
				Register_Normal		= 0x02;
			end;
			
			if (reg == -0x01)
			then
				print
				(
					string.format
					(
						"0x%08X, 0x%08X, 0x%08X, 0x%08X",
						section[0][0],
						section[1][0],
						section[2][0],
						section[3][0]
					)
				);
				
				reg = reg + 1;
			elseif (reg == 0x00)
			then
				ExtraVerts = num_vertices & 0x3;
				
				for C = 0x00, (section.cntC // 0x03) - 0x01
				do
					for R = 0x00, section.cntR - 0x01
					do
						local x = section[C * 0x03 + 0x00][R];
						local y = section[C * 0x03 + 0x01][R];
						local z = section[C * 0x03 + 0x02][R];
						
						local vn = section.vn;
						local vl = section.vl;
						
						local comp = ((0x04 >> vl) == 0x02);
						
						CompressedVerts		= comp;
						
						if (comp)
						then
							x = string.unpack("<I4", string.pack("<I4", x)) / Precision;
							y = string.unpack("<I4", string.pack("<I4", y)) / Precision;
							z = string.unpack("<I4", string.pack("<I4", z)) / Precision;
						else
							x = string.unpack("<f", string.pack("<I4", x));
							y = string.unpack("<f", string.pack("<I4", y));
							z = string.unpack("<f", string.pack("<I4", z));
						end;
						
						--obj_text = obj_text .. string.rep("\n", math.min(#obj_text, 1));
						--obj_text = obj_text .. string.format("v %s %s %s", x, y, z);
						table.insert(v, {x, y, z});
						
						minv[1] = math.min(minv[1], x);
						minv[2] = math.min(minv[2], y);
						minv[3] = math.min(minv[3], z);
						
						maxv[1] = math.max(maxv[1], x);
						maxv[2] = math.max(maxv[2], y);
						maxv[3] = math.max(maxv[3], z);
					end;
				end;
				
				--print(string.format("0x%08X", section.Address));
				--print(string.format("0x%02X, 0x%02X", num_vertices, #v));
				
				reg = reg + ((#v < num_vertices) and 0x00 or 0x01);
			elseif (reg == 0x01)
			then
				if (#vt >= num_vertices)
				then
					reg = reg + 1;
				else
					local vn = section.vn;
					local vl = section.vl;
					
					ExtraUV = num_vertices & 0x1;
					if ((math.max(num_vertices - #vt, 0) <= ExtraUV) and (ExtraUV > 0))
					then
						local u = section[0x00][0x00];
						local v = section[0x00][0x01];
						
						if ((v == nil) and (section[0x01] ~= nil))
						then
							v = section[0x01][0x00];
						end;
						
						local comp = ((0x04 >> vl) == 0x02);
						
						if (comp)
						then
							u = string.unpack("<i4", string.pack("<I4", u)) / 4096;
							v = string.unpack("<i4", string.pack("<I4", v)) / 4096;
						else
							u = string.unpack("<f", string.pack("<I4", u));
							v = string.unpack("<f", string.pack("<I4", v));
						end;
						
						--obj_text = obj_text .. string.rep("\n", math.min(#obj_text, 1));
						--obj_text = obj_text .. string.format("vt %s %s", u, v);
						table.insert(vt, {u, v});
						
						reg = reg + 0x01;
					else
						for C = 0x00, section.cntC - 0x01
						do
							for R = 0x00, 0x01
							do
								local u = section[C][R * 0x2 + (0x0 + R) * 0x1];
								local v = section[C][R * 0x2 + (0x1 - R) * 0x1];
								
								local comp = ((0x04 >> vl) == 0x02);
								
								if (comp)
								then
									u = string.unpack("<i4", string.pack("<I4", u)) / 4096;
									v = string.unpack("<i4", string.pack("<I4", v)) / 4096;
								else
									u = string.unpack("<f", string.pack("<I4", u));
									v = string.unpack("<f", string.pack("<I4", v));
								end;
								
								--obj_text = obj_text .. string.rep("\n", math.min(#obj_text, 1));
								--obj_text = obj_text .. string.format("vt %s %s", u, v);
								table.insert(vt, {u, v});
							end;
						end;
						
						reg = reg + ((#vt < num_vertices) and 0x00 or 0x01);
					end;
				end;
			elseif (reg == Register_Colour)
			then
				for C = 0x00, section.cntC - 0x01
				do
					local R = section[C][0x00] & 0xFF;
					local G = section[C][0x01] & 0xFF;
					local B = section[C][0x02] & 0xFF;
					local A = section[C][0x03] & 0xFF;
					
					table.insert(vc, {R, G, B, A});
				end;
				
				reg = reg + ((#vc < num_vertices) and 0x00 or 0x01);
			elseif (reg == Register_Normal) then
				if (section.cntC ~= nil)
				then
					for C = 0x00, (section.cntC // 0x03) - 0x01
					do
						for R = 0x00, section.cntR - 0x01
						do
							local x = section[C * 0x03 + 0x00][R];
							local y = section[C * 0x03 + 0x01][R];
							local z = section[C * 0x03 + 0x02][R];
							
							x = string.unpack("<i4", string.pack("<I4", x)) / 127;
							y = string.unpack("<i4", string.pack("<I4", y)) / 127;
							z = string.unpack("<i4", string.pack("<I4", z)) / 127;
							
							
							if (#vn < num_vertices)
							then
								--print(x / 127, y / 127, z / 127);
								table.insert(vn, {x, y, z});
							end;
						end;
					end;
					
					reg = reg + ((#vn < num_vertices) and 0x00 or 0x01);
				else
					reg = reg + 0x01;
				end;
			elseif (reg >= 0x04) then
				reg = 0xFF;
				
				return true;
			end;
			
			return false;
		end;
		
		for k = 1, PSX2Data.NumStrips do
			local uncomp_flag	= 0x00;
			
			-- # saved
			local g		=
			{
				STRIPENTRY		= PSX2Data.StripEntryTable[k];
				VERTICES		= {};
				UV			= {{}, {}, {}, {}, {}, {}, {}, {}};
				RGBA			= {{}, {}};
				NORMALS			= {};
				INDICES			= {};
			};
			
			v				= {};
			vt				= {};
			vn				= {};
			vc				= {};
			f				= {};
			
			CompressedVerts			= false;
			
			reg				= 0x00;
			
			BoundingBox.Min			= {math.huge, math.huge, math.huge};
			BoundingBox.Max			= {-math.huge, -math.huge, -math.huge};
			
			minv				= {math.huge, math.huge, math.huge};
			maxv				= {-math.huge, -math.huge, -math.huge};
			
			PackedDataOperations.Index	= 0;
			
			for i = 0, #data_buffer_table[k] - 1 do
				--local cmd	= data_buffer_table[data_buffer_index][i * 2 + 1];
				local section	= data_buffer_table[k][i + 1];
				
				--print(string.format("[%i] 0x%08X", i, section.Address));
				--local CMD, NUM, IMM = cmd[1], cmd[2], cmd[3];
				
				local result = PackedDataOperations[PackedDataOperations.Index](section);
				
				PackedDataOperations.Index = PackedDataOperations.Index + (result and 1 or 0);
			end;
			
			local delta = 0.01;
			
			--[[
			if (_ENV.Config.Game == ModelulatorEnum.Game.MOSTWANTED_DEMO)
			then
				delta = 0.01;
			end;
			--]]
			
			delta = string.unpack("<f", string.pack("<f", delta));
			
			--[[
			print(string.format("Found:\t<%f, %f, %f>", (maxv[1] - minv[1]), (maxv[2] - minv[2]), (maxv[3] - minv[3])));
			print(string.format("\t<%f, %f, %f>", (maxv[1] + minv[1]) / 2.0, (maxv[2] + minv[2]) / 2.0, (maxv[3] + minv[3]) / 2.0));
			print(string.format("Given:\t<%f, %f, %f>", BoundingBox.Max[1] - BoundingBox.Min[1] - delta * 0, BoundingBox.Max[2] - BoundingBox.Min[2] - delta * 0, BoundingBox.Max[3] - BoundingBox.Min[3] - delta * 0));
			print(string.format("\t<%f, %f, %f>", (BoundingBox.Max[1] + BoundingBox.Min[1]) / 2.0 , (BoundingBox.Max[2] + BoundingBox.Min[2]) / 2.0, (BoundingBox.Max[3] + BoundingBox.Min[3]) / 2.0));
			--]]
			--print(string.format("\t<%f, %f, %f>", (BoundingBox.Max[1] + BoundingBox.Min[1]) / 2.0, (BoundingBox.Max[2] + BoundingBox.Min[2]) / 2.0, (BoundingBox.Max[3] + BoundingBox.Min[3]) / 2.0));
			
			if
			(
				(_ENV.Config.Game.Value >= ModelulatorEnum.Game.MOSTWANTED_DEMO.Value)
				and
				(CompressedVerts)
			)
			then
				local BoundingBoxMax
				=
				{
					math.floor((BoundingBox.Max[1] - delta) * Precision) / Precision + delta,
					math.floor((BoundingBox.Max[2] - delta) * Precision) / Precision + delta,
					math.floor((BoundingBox.Max[3] - delta) * Precision) / Precision + delta
				};
				
				local BoundingBoxMin
				=
				{
					math.floor((BoundingBox.Min[1] + delta) * Precision) / Precision - delta,
					math.floor((BoundingBox.Min[2] + delta) * Precision) / Precision - delta,
					math.floor((BoundingBox.Min[3] + delta) * Precision) / Precision - delta
				};
				
				for i = 1, #v
				do
					v[i][1]
					=
					(
						(
							(
								(v[i][1] - minv[1])
								/
								(maxv[1] - minv[1] + delta * 2)
							)
							*
							(BoundingBoxMax[1] - BoundingBoxMin[1])
						)
						+
						(BoundingBoxMin[1] + delta)
					);
					
					v[i][2]
					=
					(
						(
							(
								(v[i][2] - minv[2])
								/
								(maxv[2] - minv[2] + delta * 2)
							)
							*
							(BoundingBoxMax[2] - BoundingBoxMin[2])
						)
						+
						(BoundingBoxMin[2] + delta)
					);
					
					v[i][3]
					=
					(
						(
							(
								(v[i][3] - minv[3])
								/
								(maxv[3] - minv[3] + delta * 2)
							)
							*
							(BoundingBoxMax[3] - BoundingBoxMin[3])
						)
						+
						(BoundingBoxMin[3] + delta)
					);
				end;
			end;
			
			-- # this is where the magic is done
			-- # there is prolly a better way to do all this
			
			local NumVerts, Mode;
			
			if (_ENV.Config.Game == ModelulatorEnum.Game.PROSTREET) then
				NumVerts	= heading[2];
				Mode		= heading[3];
			else
				NumVerts	= heading[0];
				Mode		= heading[1];
			end;
			-- # "Mode" is most likely not the actual name for this - it may actually be "NumLoops"
			-- # regardless, i chose to use the name "Mode" because i thought it was a better descriptor for whats going on here
			
			local UseUpper		= (Mode & 0x04);
			local DownerSide	= (-(-~(Mode & 0x03) >> 02) << (UseUpper >> 02)) & 0x03;
			local UpperSide		= ~-UseUpper;
			
			if (tri_cull[0x03] == nil) then
				if (DownerSide > 0) then
					DownerSide	= ~-DownerSide;
				end;
				
				if (UpperSide > 0) then
					UpperSide	= ~-UpperSide;
				end;
			end;
			
			-- # oppa! (i got it figured out)
			local config		= {DownerSide, UpperSide};
			
			local downer, upper	= tri_cull[config[1]] or 0x00000000, tri_cull[config[2]] or 0x00000000;
			
			-- # SUPER complicated bit-merging bullshit (now even harder to follow!)
			local hi_downer		= downer >> 18;
			local lo_downer		= downer & 0x7FFF;
			local hi_downer_swap	= hi_downer ~ (lo_downer & 0x1E);
			
			local hi_upper_swap	= ((upper >> 02) | (-~Mode >> 01)) & 0x04;
			
			local new_downer	= (lo_downer << 04) | (hi_downer_swap >> 01);
			local new_upper		= (upper >> 02) ~ (((hi_downer_swap >> 01) & 0x07) << 13) ~ (hi_upper_swap << 18);
			
			local mask		= new_downer << (((Mode - 0x03) << 02) - 0x03);
			
			if (UseUpper > 0x00) then
				mask		= (mask & (-1 << 13)) | (new_upper & 0x3FFF);
			end;
			
			mask			= mask << ((0x07 - Mode) << 02);
			
			-- # yeah... truncate it...
			-- # come on... you know you want to...
			-- # ... do it...
			mask			= mask & (-1 << (32 - NumVerts));
			
			-- # naahhh dont print it
			-- # should be fine
			--print(string.format("0x%08X", mask));
			
			local NumPolys			= 0;
			local Face			= 1; -- face direction
			
			for i = 0x00, NumVerts - 0x01 do
				local a0, b0, c0 = i - 1 - Face, i - 1, i - 1 + Face;
				
				if (((mask >> (31 - i)) & 0x01) == 0x00) then
					table.insert(f, {a0 + idx_vert, b0 + idx_vert, c0 + idx_vert});
					
					Face		= -Face;
					NumPolys	= NumPolys + 1;
				else
					Face		= 1;
				end;
			end;
			
			num_poly_total		= num_poly_total + NumPolys;
			num_vert_total		= num_vert_total + NumVerts;
			
			idx_vert		= idx_vert + NumVerts;
			
			g.VERTICES		= v;
			g.UV			= {vt, {}, {}, {}, {}, {}, {}, {}};
			g.RGBA			= {vc, {}};
			g.NORMALS		= vn;
			g.INDICES		= f;
			table.insert(Groups, g);
		end;
	end;
	
	if (PSX2Data.Mode == PlatChunks.Enum["PSX2/Mode"].Morph) then
		local InitialGroup			=
		{
			STRIPENTRY			=
			{
				PolyGroupNumber		= 0;
				TextureIndex		= -1;
				LightMaterialIndex	= -1;
			};
			VERTICES		= {};
			UV			= {{}, {}, {}, {}, {}, {}, {}, {}};
			RGBA			= {{}, {}};
			NORMALS			= {};
		};
		
		for i = 0, PSX2Data.VertexCount - 1 do
			--# this is the current address of the crook... (hi)
			local VertexDataAddress		= PSX2Data.Morph.VertexDataPointer + i * 0x00000030;
			
			InitialGroup.VERTICES[i + 1]	= {ResourceFile:Read(VertexDataAddress + 0x00000000, "< fff", 0x0000000C)};
			InitialGroup.UV[1][i + 1]	= {ResourceFile:Read(VertexDataAddress + 0x0000000C, "< ff", 0x00000008)};
			InitialGroup.NORMALS[i + 1]	= {ResourceFile:Read(VertexDataAddress + 0x00000014, "< fff", 0x0000000C)};
		end;
		
		table.insert(Groups, InitialGroup);
		
		if (PSX2Data.Morph.StripIndexPointer == nil) then
			return Groups;
		end;
		
		for i = 1, PSX2Data.NumStrips do
			local g		=
			{
				STRIPENTRY		= PSX2Data.StripEntryTable[i];
				UV			= {{}, {}, {}, {}, {}, {}, {}, {}};
				RGBA			= {{}, {}};
				NORMALS			= {};
				INDICES			= {};
				LINES			= {};
			};
			
			local IndexCount		= g.STRIPENTRY.NumVerts;
			local IndexOffset		= ResourceFile:Read(PSX2Data.Morph.StripIndexOffsetPointer + (i - 1) * 0x00000002, "< h", 0x00000002);
			local IndexStrip		= {ResourceFile:Read(PSX2Data.Morph.StripIndexPointer + IndexOffset * 0x00000002, "< " .. string.rep("h", IndexCount), 0x00000002 * IndexCount)};
			
			g.LINES				= IndexStrip;
			
			--[[
			if (IndexCount % 3 == 0) then
				for j = 0, IndexCount / 3 - 1 do
					local a			= IndexStrip[3 * j + 1];
					local b			= IndexStrip[3 * j + 2];
					local c			= IndexStrip[3 * j + 3];
					g.INDICES[j + 1]	= {a, b, c};
				end;
			else
				for j = 0, IndexCount - 2 do
					local a			= IndexStrip[j + 1];
					local b			= IndexStrip[j + 2];
					g.INDICES[j + 1]	= {a, b, a};
				end;
			end;
			--]]
			
			table.insert(Groups, g);
		end;
	end;
	
	return Groups;
end;

return GenerateGroups;