-- [PSX (NASCAR)] Generate xSolid Groups

local function GenerateGroups(bGeomEntry)
	local Groups		= {};
	
	local idx_vert		= 0;
	local num_vert_total	= 0;
	local num_poly_total	= 0;
	
	local Scale		= (0x01 << bGeomEntry.Scale);
	
	for i = 1, bGeomEntry.NumStrips do
		local g			=
		{
			STRIPENTRY	= bGeomEntry.StripEntryTable[i];
			VERTICES	= {};
			UV		= {{}, {}, {}, {}, {}, {}, {}, {}};
			RGBA		= {{}, {}};
			NORMALS		= {};
			INDICES		= {};
		};
		
		local v			= {};
		local vt		= {};
		local vn		= {};
		local vc		= {};
		local f			= {};
		
		local NumVerts		= 4;
		local NumPolys		= 2;
		
		local bGeomStrip	= g.STRIPENTRY;
		
		for j = 0, 3 do
			local pXYZ	= bGeomEntry.DataPointer + bGeomEntry.DataOffsets.XYZ + (bGeomStrip.DataIndices.XYZ + bGeomStrip.VertexIndices[-~j]) * 0x08;
			local pST	= bGeomEntry.DataPointer + bGeomEntry.DataOffsets.ST + bGeomStrip.DataIndices.ST * 0x08 + (j * 0x02);
			local pRGBA	= bGeomEntry.DataPointer + bGeomEntry.DataOffsets.RGBA + bGeomStrip.DataIndices.RGBA * 0x08 + (j * 0x02) * ((bGeomStrip.Flags >> 0x04) & 0x01);
			
			local XYZ_Data	= {ResourceFile:Read(pXYZ, "<hhh")};
			local ST_Data	= {ResourceFile:Read(pST, "<BB")};
			local RGBA_Data	= ResourceFile:Read(pRGBA, "<H") ~ 0x8000;
			
			local XYZ	= {};
			local ST	= {};
			local RGBA	= {};
			
			XYZ[1]		= XYZ_Data[1] * Scale / 0x7FFF;
			XYZ[2]		= XYZ_Data[2] * Scale / 0x7FFF;
			XYZ[3]		= XYZ_Data[3] * Scale / 0x7FFF;
			
			ST[1]		= ST_Data[1] / 0x80;
			ST[2]		= 1.0 - ST_Data[2] / 0x80;
			
			local STP	= (((RGBA_Data >> 0x0F) & 0x01) / 0x01);
			
			RGBA[1]		= (((RGBA_Data >> 0x00) & 0x1F) / 0x1F) * 0xFF;
			RGBA[2]		= (((RGBA_Data >> 0x05) & 0x1F) / 0x1F) * 0xFF;
			RGBA[3]		= (((RGBA_Data >> 0x0A) & 0x1F) / 0x1F) * 0xFF;
			RGBA[4]		= (((RGBA_Data >> 0x0F) & 0x01) / 0x01) * 0x7F;
			
			table.insert(v, XYZ);
			table.insert(vt, ST);
			table.insert(vc, RGBA);
			
			table.insert(f, {idx_vert + 0, idx_vert + 1, idx_vert + 2});
			table.insert(f, {idx_vert + 2, idx_vert + 3, idx_vert + 0});
		end;
		
		num_poly_total		= num_poly_total + NumPolys;
		num_vert_total		= num_vert_total + NumVerts;
		
		idx_vert		= idx_vert + NumVerts;
		
		g.VERTICES		= v;
		g.UV			= {vt, {}, {}, {}, {}, {}, {}, {}};
		g.RGBA			= {vc, {}};
		g.NORMALS		= vn;
		g.INDICES		= f;
		
		table.insert(Groups, g);
	end;
	
	return Groups;
end;

return GenerateGroups;