-- [REVOLUTION] Generate xSolid Groups

local function align(x, al)
	al = -al;
	return (x + ~al) & al;
end;

--

local Cleanums			= require("src.util.lib.cleanums");

local RevolutionEnum		= Cleanums.new("RevolutionEnum");
RevolutionEnum:Add("GXPrimitiveType");
RevolutionEnum.GXPrimitiveType:Add("Quad");
RevolutionEnum.GXPrimitiveType:Add("QuadStrip");	-- # this one is redundant and not actually defined, but i'm gonna keep it just in case
RevolutionEnum.GXPrimitiveType:Add("Triangle");
RevolutionEnum.GXPrimitiveType:Add("TriangleStrip");
RevolutionEnum.GXPrimitiveType:Add("TriangleFan");
RevolutionEnum.GXPrimitiveType:Add("Line");
RevolutionEnum.GXPrimitiveType:Add("LineStrip");
RevolutionEnum.GXPrimitiveType:Add("Points");

RevolutionEnum:Add("GXAttributeComponentType");
RevolutionEnum.GXAttributeComponentType:SetOp("=");
RevolutionEnum.GXAttributeComponentType:Add("POS_XY",	0x0);
RevolutionEnum.GXAttributeComponentType:Add("POS_XYZ",	0x1);
RevolutionEnum.GXAttributeComponentType:Add("NRM_XYZ",	0x0);
RevolutionEnum.GXAttributeComponentType:Add("NRM_NBT",	0x1);
RevolutionEnum.GXAttributeComponentType:Add("NRM_NBT3",	0x2);
RevolutionEnum.GXAttributeComponentType:Add("CLR_RGB",	0x0);
RevolutionEnum.GXAttributeComponentType:Add("CLR_RGBA",	0x1);
RevolutionEnum.GXAttributeComponentType:Add("TEX_S",	0x0);
RevolutionEnum.GXAttributeComponentType:Add("TEX_ST",	0x1);

RevolutionEnum:Add("GXAttributeComponentFormat");
RevolutionEnum.GXAttributeComponentFormat:SetOp("=");
RevolutionEnum.GXAttributeComponentFormat:Add("U8",		0x0);
RevolutionEnum.GXAttributeComponentFormat:Add("S8",		0x1);
RevolutionEnum.GXAttributeComponentFormat:Add("U16",		0x2);
RevolutionEnum.GXAttributeComponentFormat:Add("S16",		0x3);
RevolutionEnum.GXAttributeComponentFormat:Add("F32",		0x4);
RevolutionEnum.GXAttributeComponentFormat:Add("RGB565",		0x0);
RevolutionEnum.GXAttributeComponentFormat:Add("RGB8",		0x1);
RevolutionEnum.GXAttributeComponentFormat:Add("RGBX8",		0x2);
RevolutionEnum.GXAttributeComponentFormat:Add("RGBA4",		0x3);
RevolutionEnum.GXAttributeComponentFormat:Add("RGBA6",		0x4);
RevolutionEnum.GXAttributeComponentFormat:Add("RGBA8",		0x5);

RevolutionEnum:Add("GXVertexAttributeInputType");
RevolutionEnum.GXVertexAttributeInputType:Add("None");
RevolutionEnum.GXVertexAttributeInputType:Add("Direct");
RevolutionEnum.GXVertexAttributeInputType:Add("Index8");
RevolutionEnum.GXVertexAttributeInputType:Add("Index16");

RevolutionEnum:Add("GXVertexAttributeType");
RevolutionEnum.GXVertexAttributeType:Add("PTNMTXIDX");
RevolutionEnum.GXVertexAttributeType:Add("TEX0MTXIDX");
RevolutionEnum.GXVertexAttributeType:Add("TEX1MTXIDX");
RevolutionEnum.GXVertexAttributeType:Add("TEX2MTXIDX");
RevolutionEnum.GXVertexAttributeType:Add("TEX3MTXIDX");
RevolutionEnum.GXVertexAttributeType:Add("TEX4MTXIDX");
RevolutionEnum.GXVertexAttributeType:Add("TEX5MTXIDX");
RevolutionEnum.GXVertexAttributeType:Add("TEX6MTXIDX");
RevolutionEnum.GXVertexAttributeType:Add("TEX7MTXIDX");
RevolutionEnum.GXVertexAttributeType:Add("POS");
RevolutionEnum.GXVertexAttributeType:Add("NRM");
RevolutionEnum.GXVertexAttributeType:Add("CLR0");
RevolutionEnum.GXVertexAttributeType:Add("CLR1");
RevolutionEnum.GXVertexAttributeType:Add("TEX0");
RevolutionEnum.GXVertexAttributeType:Add("TEX1");
RevolutionEnum.GXVertexAttributeType:Add("TEX2");
RevolutionEnum.GXVertexAttributeType:Add("TEX3");
RevolutionEnum.GXVertexAttributeType:Add("TEX4");
RevolutionEnum.GXVertexAttributeType:Add("TEX5");
RevolutionEnum.GXVertexAttributeType:Add("TEX6");
RevolutionEnum.GXVertexAttributeType:Add("TEX7");
RevolutionEnum.GXVertexAttributeType:Add("POSMTXARRAY");
RevolutionEnum.GXVertexAttributeType:Add("NRMMTXARRAY");
RevolutionEnum.GXVertexAttributeType:Add("TEXMTXARRAY");
RevolutionEnum.GXVertexAttributeType:Add("LIGHTARRAY");
RevolutionEnum.GXVertexAttributeType:Add("NBT");
RevolutionEnum.GXVertexAttributeType:Add("NULL", 0xFF);

--

local ComponentTypeStrideTable	=
{
	[RevolutionEnum.GXAttributeComponentType.POS_XY]	= 0x02;
	[RevolutionEnum.GXAttributeComponentType.POS_XYZ]	= 0x03;
	[RevolutionEnum.GXAttributeComponentType.NRM_XYZ]	= 0x03;
	[RevolutionEnum.GXAttributeComponentType.NRM_NBT]	= 0x09;
	[RevolutionEnum.GXAttributeComponentType.NRM_NBT3]	= 0x09;
	[RevolutionEnum.GXAttributeComponentType.CLR_RGB]	= 0x01;
	[RevolutionEnum.GXAttributeComponentType.CLR_RGBA]	= 0x01;
	[RevolutionEnum.GXAttributeComponentType.TEX_S]		= 0x01;
	[RevolutionEnum.GXAttributeComponentType.TEX_ST]	= 0x02;
};

local ComponentFormatTable	=
{
	[RevolutionEnum.GXAttributeComponentFormat.U8] =
	{
		Format		= ">B";
	};
	[RevolutionEnum.GXAttributeComponentFormat.S8] =
	{
		Format		= ">b";
	};
	[RevolutionEnum.GXAttributeComponentFormat.U16] =
	{
		Format		= ">H";
	};
	[RevolutionEnum.GXAttributeComponentFormat.S16] =
	{
		Format		= ">h";
	};
	[RevolutionEnum.GXAttributeComponentFormat.F32] =
	{
		Format		= ">f";
	};
	[RevolutionEnum.GXAttributeComponentFormat.RGB565] =
	{
		Format		= ">I2";
		R		= {0x00, 0x05};
		G		= {0x05, 0x06};
		B		= {0x0B, 0x05};
	};
	[RevolutionEnum.GXAttributeComponentFormat.RGB8] =
	{
		Format		= ">I3";
		R		= {0x00, 0x08};
		G		= {0x08, 0x08};
		B		= {0x10, 0x08};
	};
	[RevolutionEnum.GXAttributeComponentFormat.RGBX8] =
	{
		Format		= ">I4";
		R		= {0x00, 0x08};
		G		= {0x08, 0x08};
		B		= {0x10, 0x08};
	};
	[RevolutionEnum.GXAttributeComponentFormat.RGBA4] =
	{
		Format		= ">I2";
		R		= {0x00, 0x04};
		G		= {0x04, 0x04};
		B		= {0x08, 0x04};
		A		= {0x0C, 0x04};
	};
	[RevolutionEnum.GXAttributeComponentFormat.RGBA6] =
	{
		Format		= ">I3";
		R		= {0x00, 0x06};
		G		= {0x06, 0x06};
		B		= {0x0C, 0x06};
		A		= {0x12, 0x06};
	};
	[RevolutionEnum.GXAttributeComponentFormat.RGBA8] =
	{
		Format		= ">I4";
		R		= {0x00, 0x08};
		G		= {0x08, 0x08};
		B		= {0x10, 0x08};
		A		= {0x18, 0x08};
	};
};

--

local VertexFormatTable =
{
	[0x0016]	=
	{
		[0x00]	=
		{
			{
				Attribute		= RevolutionEnum.GXVertexAttributeType.POS;
				ComponentType		= RevolutionEnum.GXAttributeComponentType.POS_XYZ;
				ComponentFormat		= RevolutionEnum.GXAttributeComponentFormat.F32;
				Fraction		= 0x00;
			};
			{
				Attribute		= RevolutionEnum.GXVertexAttributeType.CLR0;
				ComponentType		= RevolutionEnum.GXAttributeComponentType.CLR_RGBA;
				ComponentFormat		= RevolutionEnum.GXAttributeComponentFormat.RGBA8;
				Fraction		= 0x00;
			};
			{
				Attribute		= RevolutionEnum.GXVertexAttributeType.TEX0;
				ComponentType		= RevolutionEnum.GXAttributeComponentType.TEX_ST;
				ComponentFormat		= RevolutionEnum.GXAttributeComponentFormat.F32;
				Fraction		= 0x00;
			};
		};
		[0x01]	=
		{
			{
				Attribute		= RevolutionEnum.GXVertexAttributeType.POS;
				ComponentType		= RevolutionEnum.GXAttributeComponentType.POS_XYZ;
				ComponentFormat		= RevolutionEnum.GXAttributeComponentFormat.F32;
				Fraction		= 0x00;
			};
			{
				Attribute		= RevolutionEnum.GXVertexAttributeType.CLR0;
				ComponentType		= RevolutionEnum.GXAttributeComponentType.CLR_RGBA;
				ComponentFormat		= RevolutionEnum.GXAttributeComponentFormat.RGBA8;
				Fraction		= 0x00;
			};
			{
				Attribute		= RevolutionEnum.GXVertexAttributeType.TEX0;
				ComponentType		= RevolutionEnum.GXAttributeComponentType.TEX_ST;
				ComponentFormat		= RevolutionEnum.GXAttributeComponentFormat.S16;
				Fraction		= 0x0B;
			};
		};
		[0x02]	=
		{
			{
				Attribute		= RevolutionEnum.GXVertexAttributeType.POS;
				ComponentType		= RevolutionEnum.GXAttributeComponentType.POS_XYZ;
				ComponentFormat		= RevolutionEnum.GXAttributeComponentFormat.S16;
				Fraction		= 0x0B;
			};
			{
				Attribute		= RevolutionEnum.GXVertexAttributeType.NRM;
				ComponentType		= RevolutionEnum.GXAttributeComponentType.NRM_XYZ;
				ComponentFormat		= RevolutionEnum.GXAttributeComponentFormat.S8;
				Fraction		= 0x06;
			};
			{
				Attribute		= RevolutionEnum.GXVertexAttributeType.CLR0;
				ComponentType		= RevolutionEnum.GXAttributeComponentType.CLR_RGBA;
				ComponentFormat		= RevolutionEnum.GXAttributeComponentFormat.RGBA8;
				Fraction		= 0x00;
			};
			{
				Attribute		= RevolutionEnum.GXVertexAttributeType.CLR1;
				ComponentType		= RevolutionEnum.GXAttributeComponentType.CLR_RGBA;
				ComponentFormat		= RevolutionEnum.GXAttributeComponentFormat.RGBA8;
				Fraction		= 0x00;
			};
			{
				Attribute		= RevolutionEnum.GXVertexAttributeType.TEX0;
				ComponentType		= RevolutionEnum.GXAttributeComponentType.TEX_ST;
				ComponentFormat		= RevolutionEnum.GXAttributeComponentFormat.S16;
				Fraction		= 0x0B;
			};
		};
		[0x03]	=
		{
			{
				Attribute		= RevolutionEnum.GXVertexAttributeType.POS;
				ComponentType		= RevolutionEnum.GXAttributeComponentType.POS_XYZ;
				ComponentFormat		= RevolutionEnum.GXAttributeComponentFormat.S16;
				Fraction		= 0x08;
			};
			{
				Attribute		= RevolutionEnum.GXVertexAttributeType.CLR0;
				ComponentType		= RevolutionEnum.GXAttributeComponentType.CLR_RGBA;
				ComponentFormat		= RevolutionEnum.GXAttributeComponentFormat.RGBA8;
				Fraction		= 0x00;
			};
			{
				Attribute		= RevolutionEnum.GXVertexAttributeType.TEX0;
				ComponentType		= RevolutionEnum.GXAttributeComponentType.TEX_ST;
				ComponentFormat		= RevolutionEnum.GXAttributeComponentFormat.S16;
				Fraction		= 0x0B;
			};
		};
		[0x04]	=
		{
			{
				Attribute		= RevolutionEnum.GXVertexAttributeType.POS;
				ComponentType		= RevolutionEnum.GXAttributeComponentType.POS_XYZ;
				ComponentFormat		= RevolutionEnum.GXAttributeComponentFormat.F32;
				Fraction		= 0x00;
			};
			{
				Attribute		= RevolutionEnum.GXVertexAttributeType.NRM;
				ComponentType		= RevolutionEnum.GXAttributeComponentType.NRM_XYZ;
				ComponentFormat		= RevolutionEnum.GXAttributeComponentFormat.F32;
				Fraction		= 0x00;
			};
			{
				Attribute		= RevolutionEnum.GXVertexAttributeType.CLR0;
				ComponentType		= RevolutionEnum.GXAttributeComponentType.CLR_RGBA;
				ComponentFormat		= RevolutionEnum.GXAttributeComponentFormat.RGBA4;
				Fraction		= 0x00;
			};
			{
				Attribute		= RevolutionEnum.GXVertexAttributeType.TEX0;
				ComponentType		= RevolutionEnum.GXAttributeComponentType.TEX_ST;
				ComponentFormat		= RevolutionEnum.GXAttributeComponentFormat.S16;
				Fraction		= 0x0B;
			};
		};
		[0x05]	=
		{
			{
				Attribute		= RevolutionEnum.GXVertexAttributeType.POS;
				ComponentType		= RevolutionEnum.GXAttributeComponentType.POS_XYZ;
				ComponentFormat		= RevolutionEnum.GXAttributeComponentFormat.F32;
				Fraction		= 0x00;
			};
			{
				Attribute		= RevolutionEnum.GXVertexAttributeType.NRM;
				ComponentType		= RevolutionEnum.GXAttributeComponentType.NRM_XYZ;
				ComponentFormat		= RevolutionEnum.GXAttributeComponentFormat.S8;
				Fraction		= 0x06;
			};
			{
				Attribute		= RevolutionEnum.GXVertexAttributeType.CLR0;
				ComponentType		= RevolutionEnum.GXAttributeComponentType.CLR_RGBA;
				ComponentFormat		= RevolutionEnum.GXAttributeComponentFormat.RGBA8;
				Fraction		= 0x00;
			};
			{
				Attribute		= RevolutionEnum.GXVertexAttributeType.TEX0;
				ComponentType		= RevolutionEnum.GXAttributeComponentType.TEX_ST;
				ComponentFormat		= RevolutionEnum.GXAttributeComponentFormat.S16;
				Fraction		= 0x0B;
			};
		};
		[0x06]	=
		{
			{
				Attribute		= RevolutionEnum.GXVertexAttributeType.POS;
				ComponentType		= RevolutionEnum.GXAttributeComponentType.POS_XYZ;
				ComponentFormat		= RevolutionEnum.GXAttributeComponentFormat.F32;
				Fraction		= 0x00;
			};
			{
				Attribute		= RevolutionEnum.GXVertexAttributeType.CLR0;
				ComponentType		= RevolutionEnum.GXAttributeComponentType.CLR_RGBA;
				ComponentFormat		= RevolutionEnum.GXAttributeComponentFormat.RGBA8;
				Fraction		= 0x00;
			};
			{
				Attribute		= RevolutionEnum.GXVertexAttributeType.TEX0;
				ComponentType		= RevolutionEnum.GXAttributeComponentType.TEX_ST;
				ComponentFormat		= RevolutionEnum.GXAttributeComponentFormat.F32;
				Fraction		= 0x00;
			};
			{
				Attribute		= RevolutionEnum.GXVertexAttributeType.TEX1;
				ComponentType		= RevolutionEnum.GXAttributeComponentType.TEX_ST;
				ComponentFormat		= RevolutionEnum.GXAttributeComponentFormat.F32;
				Fraction		= 0x00;
			};
		};
	};
	[0x001C]	=
	{
		[0x00]	=
		{
			{
				Attribute		= RevolutionEnum.GXVertexAttributeType.POS;
				ComponentType		= RevolutionEnum.GXAttributeComponentType.POS_XYZ;
				ComponentFormat		= RevolutionEnum.GXAttributeComponentFormat.F32;
				Fraction		= 0x00;
			};
			{
				Attribute		= RevolutionEnum.GXVertexAttributeType.CLR0;
				ComponentType		= RevolutionEnum.GXAttributeComponentType.CLR_RGBA;
				ComponentFormat		= RevolutionEnum.GXAttributeComponentFormat.RGBA8;
				Fraction		= 0x00;
			};
			{
				Attribute		= RevolutionEnum.GXVertexAttributeType.TEX0;
				ComponentType		= RevolutionEnum.GXAttributeComponentType.TEX_ST;
				ComponentFormat		= RevolutionEnum.GXAttributeComponentFormat.F32;
				Fraction		= 0x00;
			};
			{
				Attribute		= RevolutionEnum.GXVertexAttributeType.TEX1;
				ComponentType		= RevolutionEnum.GXAttributeComponentType.TEX_ST;
				ComponentFormat		= RevolutionEnum.GXAttributeComponentFormat.F32;
				Fraction		= 0x00;
			};
			{
				Attribute		= RevolutionEnum.GXVertexAttributeType.TEX2;
				ComponentType		= RevolutionEnum.GXAttributeComponentType.TEX_ST;
				ComponentFormat		= RevolutionEnum.GXAttributeComponentFormat.F32;
				Fraction		= 0x00;
			};
			{
				Attribute		= RevolutionEnum.GXVertexAttributeType.TEX3;
				ComponentType		= RevolutionEnum.GXAttributeComponentType.TEX_ST;
				ComponentFormat		= RevolutionEnum.GXAttributeComponentFormat.F32;
				Fraction		= 0x00;
			};
			{
				Attribute		= RevolutionEnum.GXVertexAttributeType.TEX4;
				ComponentType		= RevolutionEnum.GXAttributeComponentType.TEX_ST;
				ComponentFormat		= RevolutionEnum.GXAttributeComponentFormat.F32;
				Fraction		= 0x00;
			};
			{
				Attribute		= RevolutionEnum.GXVertexAttributeType.TEX5;
				ComponentType		= RevolutionEnum.GXAttributeComponentType.TEX_ST;
				ComponentFormat		= RevolutionEnum.GXAttributeComponentFormat.F32;
				Fraction		= 0x00;
			};
			{
				Attribute		= RevolutionEnum.GXVertexAttributeType.TEX6;
				ComponentType		= RevolutionEnum.GXAttributeComponentType.TEX_ST;
				ComponentFormat		= RevolutionEnum.GXAttributeComponentFormat.F32;
				Fraction		= 0x00;
			};
			{
				Attribute		= RevolutionEnum.GXVertexAttributeType.TEX7;
				ComponentType		= RevolutionEnum.GXAttributeComponentType.TEX_ST;
				ComponentFormat		= RevolutionEnum.GXAttributeComponentFormat.F32;
				Fraction		= 0x00;
			};
		};
		[0x01]	=
		{
			{
				Attribute		= RevolutionEnum.GXVertexAttributeType.POS;
				ComponentType		= RevolutionEnum.GXAttributeComponentType.POS_XYZ;
				ComponentFormat		= RevolutionEnum.GXAttributeComponentFormat.F32;
				Fraction		= 0x00;
			};
			{
				Attribute		= RevolutionEnum.GXVertexAttributeType.NRM;
				ComponentType		= RevolutionEnum.GXAttributeComponentType.NRM_XYZ;
				ComponentFormat		= RevolutionEnum.GXAttributeComponentFormat.S8;
				Fraction		= 0x06;
			};
			{
				Attribute		= RevolutionEnum.GXVertexAttributeType.CLR0;
				ComponentType		= RevolutionEnum.GXAttributeComponentType.CLR_RGBA;
				ComponentFormat		= RevolutionEnum.GXAttributeComponentFormat.RGBA8;
				Fraction		= 0x00;
			};
			{
				Attribute		= RevolutionEnum.GXVertexAttributeType.TEX0;
				ComponentType		= RevolutionEnum.GXAttributeComponentType.TEX_ST;
				ComponentFormat		= RevolutionEnum.GXAttributeComponentFormat.S16;
				Fraction		= 0x0B;
			};
			{
				Attribute		= RevolutionEnum.GXVertexAttributeType.TEX1;
				ComponentType		= RevolutionEnum.GXAttributeComponentType.TEX_ST;
				ComponentFormat		= RevolutionEnum.GXAttributeComponentFormat.S16;
				Fraction		= 0x0B;
			};
			{
				Attribute		= RevolutionEnum.GXVertexAttributeType.TEX2;
				ComponentType		= RevolutionEnum.GXAttributeComponentType.TEX_ST;
				ComponentFormat		= RevolutionEnum.GXAttributeComponentFormat.S16;
				Fraction		= 0x0B;
			};
			{
				Attribute		= RevolutionEnum.GXVertexAttributeType.TEX3;
				ComponentType		= RevolutionEnum.GXAttributeComponentType.TEX_ST;
				ComponentFormat		= RevolutionEnum.GXAttributeComponentFormat.S16;
				Fraction		= 0x0B;
			};
		};
		[0x03]	=
		{
			{
				Attribute		= RevolutionEnum.GXVertexAttributeType.POS;
				ComponentType		= RevolutionEnum.GXAttributeComponentType.POS_XYZ;
				ComponentFormat		= RevolutionEnum.GXAttributeComponentFormat.S16;
				Fraction		= 0x08;
			};
			{
				Attribute		= RevolutionEnum.GXVertexAttributeType.NRM;
				ComponentType		= RevolutionEnum.GXAttributeComponentType.NRM_XYZ;
				ComponentFormat		= RevolutionEnum.GXAttributeComponentFormat.S8;
				Fraction		= 0x06;
			};
			{
				Attribute		= RevolutionEnum.GXVertexAttributeType.CLR0;
				ComponentType		= RevolutionEnum.GXAttributeComponentType.CLR_RGBA;
				ComponentFormat		= RevolutionEnum.GXAttributeComponentFormat.RGBA8;
				Fraction		= 0x00;
			};
			{
				Attribute		= RevolutionEnum.GXVertexAttributeType.TEX0;
				ComponentType		= RevolutionEnum.GXAttributeComponentType.TEX_ST;
				ComponentFormat		= RevolutionEnum.GXAttributeComponentFormat.S16;
				Fraction		= 0x0B;
			};
			{
				Attribute		= RevolutionEnum.GXVertexAttributeType.TEX1;
				ComponentType		= RevolutionEnum.GXAttributeComponentType.TEX_ST;
				ComponentFormat		= RevolutionEnum.GXAttributeComponentFormat.S16;
				Fraction		= 0x0B;
			};
			{
				Attribute		= RevolutionEnum.GXVertexAttributeType.TEX2;
				ComponentType		= RevolutionEnum.GXAttributeComponentType.TEX_ST;
				ComponentFormat		= RevolutionEnum.GXAttributeComponentFormat.S16;
				Fraction		= 0x0B;
			};
			{
				Attribute		= RevolutionEnum.GXVertexAttributeType.TEX3;
				ComponentType		= RevolutionEnum.GXAttributeComponentType.TEX_ST;
				ComponentFormat		= RevolutionEnum.GXAttributeComponentFormat.S16;
				Fraction		= 0x0B;
			};
		};
		[0x04]	=
		{
			{
				Attribute		= RevolutionEnum.GXVertexAttributeType.POS;
				ComponentType		= RevolutionEnum.GXAttributeComponentType.POS_XYZ;
				ComponentFormat		= RevolutionEnum.GXAttributeComponentFormat.F32;
				Fraction		= 0x00;
			};
			{
				Attribute		= RevolutionEnum.GXVertexAttributeType.NRM;
				ComponentType		= RevolutionEnum.GXAttributeComponentType.NRM_XYZ;
				ComponentFormat		= RevolutionEnum.GXAttributeComponentFormat.F32;
				Fraction		= 0x00;
			};
			{
				Attribute		= RevolutionEnum.GXVertexAttributeType.CLR0;
				ComponentType		= RevolutionEnum.GXAttributeComponentType.CLR_RGBA;
				ComponentFormat		= RevolutionEnum.GXAttributeComponentFormat.RGBA8;
				Fraction		= 0x00;
			};
			{
				Attribute		= RevolutionEnum.GXVertexAttributeType.TEX0;
				ComponentType		= RevolutionEnum.GXAttributeComponentType.TEX_ST;
				ComponentFormat		= RevolutionEnum.GXAttributeComponentFormat.S16;
				Fraction		= 0x0B;
			};
		};
		[0x05]	=
		{
			{
				Attribute		= RevolutionEnum.GXVertexAttributeType.POS;
				ComponentType		= RevolutionEnum.GXAttributeComponentType.POS_XYZ;
				ComponentFormat		= RevolutionEnum.GXAttributeComponentFormat.F32;
				Fraction		= 0x00;
			};
			{
				Attribute		= RevolutionEnum.GXVertexAttributeType.NBT;
				ComponentType		= RevolutionEnum.GXAttributeComponentType.NRM_NBT;
				ComponentFormat		= RevolutionEnum.GXAttributeComponentFormat.F32;
				Fraction		= 0x00;
			};
			{
				Attribute		= RevolutionEnum.GXVertexAttributeType.TEX0;
				ComponentType		= RevolutionEnum.GXAttributeComponentType.TEX_ST;
				ComponentFormat		= RevolutionEnum.GXAttributeComponentFormat.S16;
				Fraction		= 0x0B;
			};
		};
	};
};

local idx_vert		= 0;
local num_vert_total	= 0;
local num_poly_total	= 0;

local NameTable		=
{
	[1]		= "Position";
	[2]		= "Normal";
	[3]		= "Colour";
	[4]		= "TextureCoordinate";
};

local GenerateFaces	= {};

local v			= {};
local vn		= {};
local vc0		= {};
local vc1		= {};
local vt0		= {};
local vt1		= {};
local vt2		= {};
local vt3		= {};
local vt4		= {};
local vt5		= {};
local vt6		= {};
local vt7		= {};
local f			= {};

local StorageTable	=
{
	[0]		= {};
	[1]		= v;
	[2]		= vn;
	[3]		= vc0;
	[4]		= vc1;
	[5]		= vt0;
	[6]		= vt1;
	[7]		= vt2;
	[8]		= vt3;
	[9]		= vt4;
	[10]		= vt5;
	[11]		= vt6;
	[12]		= vt7;
	[13]		= f;
};

function GenerateFaces.Quad(i)
	if (i & 0x03 == 0x03) then
		table.insert(StorageTable[13], {idx_vert - 0, idx_vert - 1, idx_vert - 2});
		table.insert(StorageTable[13], {idx_vert - 2, idx_vert - 3, idx_vert + 0});
		
		num_poly_total	= num_poly_total + 2;
		num_vert_total	= num_vert_total + 4;
		idx_vert	= idx_vert + 4;
	end;
end;

function GenerateFaces.QuadStrip(i)
	if (i < 0x04) then
		if (i & 0x03 == 0x03) then
			table.insert(StorageTable[13], {idx_vert - 0, idx_vert - 1, idx_vert - 2});
			table.insert(StorageTable[13], {idx_vert - 2, idx_vert - 3, idx_vert + 0});
			
			num_poly_total	= num_poly_total + 2;
		end;
	else
		if (i & 0x01 == 0x01) then
			table.insert(StorageTable[13], {idx_vert - 0, idx_vert - 1, idx_vert - 2});
			table.insert(StorageTable[13], {idx_vert - 2, idx_vert - 3, idx_vert + 0});
			
			num_poly_total	= num_poly_total + 2;
		end;
	end;
end;

function GenerateFaces.Triangle(i)
	if ((-~i) % 0x03 == 0x00) then
		table.insert(StorageTable[13], {idx_vert - 2, idx_vert - 1, idx_vert - 0});
		
		num_poly_total	= num_poly_total + 1;
	end;
end;

function GenerateFaces.TriangleStrip(i)
	if (i > 0x01) then
		local Face	= 0x01 - ((i & 0x01) << 0x01);
		
		table.insert(StorageTable[13], {idx_vert - 1 - Face, idx_vert - 1, idx_vert - 1 + Face});
		
		num_poly_total	= num_poly_total + 1;
	end;
end;

local TriangleFanBase		= 0;
function GenerateFaces.TriangleFan(i)
	if (i > 0x01) then
		table.insert(StorageTable[13], {idx_vert - i, idx_vert - 1, idx_vert - 0});
		
		num_poly_total	= num_poly_total + 1;
	end;
end;

local function GetVertexData(PlatInfo)
	local VertexFormatVersion	= VertexFormatTable[PlatInfo.Version];
	
	local InputTypesList		= {};
	
	for i = 1, 4 do
		InputTypesList[i]	=
		{
			Name		= NameTable[i];
			Pointer		= PlatInfo.StripDataPointer + PlatInfo[string.format("DataOffset%i", ~-i)];
			InputType	= RevolutionEnum.GXVertexAttributeInputType.None;
		};
	end;
	
	local VertexDescriptorList	=
	{
		{
			Attribute	= RevolutionEnum.GXVertexAttributeType.POS;
			Type		= InputTypesList[1];
			Storage		= 1;
		};
		{
			Attribute	= RevolutionEnum.GXVertexAttributeType.NRM;
			Type		= InputTypesList[2];
			Storage		= 2;
		};
		{
			Attribute	= RevolutionEnum.GXVertexAttributeType.NBT;
			Type		= InputTypesList[2];
			Storage		= 0;
		};
		{
			Attribute	= RevolutionEnum.GXVertexAttributeType.CLR0;
			Type		= InputTypesList[3];
			Storage		= 3;
		};
		{
			Attribute	= RevolutionEnum.GXVertexAttributeType.CLR1;
			Type		= InputTypesList[3];
			Storage		= 4;
		};
		{
			Attribute	= RevolutionEnum.GXVertexAttributeType.TEX0;
			Type		= InputTypesList[4];
			Storage		= 5;
		};
		{
			Attribute	= RevolutionEnum.GXVertexAttributeType.TEX1;
			Type		= InputTypesList[4];
			Storage		= 6;
		};
		{
			Attribute	= RevolutionEnum.GXVertexAttributeType.TEX2;
			Type		= InputTypesList[4];
			Storage		= 7;
		};
		{
			Attribute	= RevolutionEnum.GXVertexAttributeType.TEX3;
			Type		= InputTypesList[4];
			Storage		= 8;
		};
	};
	
	if (PlatInfo.Version == 0x0016) then
		return;
	end;
	
	if (PlatInfo.Version == 0x001C) then
		local function ProcessStrip(StripEntry)
			local VertexFormat		= (StripEntry.VtxDescAndFmt & 0x0007);
			local IsIndexed			= (StripEntry.VtxDescAndFmt & 0x0008) > 0x0000;
			
			for i = 0x00, 0x03 do
				local Type		= InputTypesList[-~i].InputType.Value;
				
				if (Type == 0x00) then
					Type	= -~Type;
					
					if (IsIndexed == true) then
						Type	= -~Type;
						
						if (((StripEntry.VtxDescAndFmt >> (0x04 + i)) & 0x01) > 0x00) then
							Type	= -~Type;
						end;
					end;
					
					InputTypesList[-~i].InputType	= RevolutionEnum.GXVertexAttributeInputType:GetEnumFromValue(Type);
				end;
			end;
			
			local VertexData		= {};
			
			for i = 1, #VertexDescriptorList do
				local AttributeIndex	= VertexDescriptorList[i].Attribute.Value - 0x02;
				
				if (AttributeIndex - 0x08 < 0x00) then
					table.insert(VertexData, VertexDescriptorList[i]);
				else
					local IsUsedBit		= AttributeIndex;
					IsUsedBit		= IsUsedBit - ((VertexDescriptorList[i].Attribute == RevolutionEnum.GXVertexAttributeType.NBT) and 0x08 or 0x00);
					
					if (((StripEntry.VtxDescAndFmt >> IsUsedBit) & 0x01) > 0x00) then
						table.insert(VertexData, VertexDescriptorList[i]);
					end;
				end;
			end;
			
			local DataStartPointer		= PlatInfo.StripDataPointer + StripEntry.DataOffset;
			local DataOffset		= 0x000000000;
			
			while (DataOffset < StripEntry.DataDisplayListSize) do
				local Opcode		= ResourceFile:Read(DataStartPointer + DataOffset, ">B");
				
				if (Opcode & 0xC0 == 0x80) then
					local __PrimitiveType	= RevolutionEnum.GXPrimitiveType:GetEnumFromValue((Opcode >> 0x03) & 0x07);
					local __VertexFormat	= (Opcode & 0x07);
					
					DataOffset		= DataOffset + 0x01;
					
					local Count		= ResourceFile:Read(DataStartPointer + DataOffset, ">H");
					
					DataOffset		= DataOffset + 0x02;
					
					--print(string.format("0x%08X\tGXDraw (%s, VertexFormat%i) [0x%04X]", DataStartPointer + DataOffset - 0x03, __PrimitiveType.Name, __VertexFormat, Count));
					
					local VertexFormatEntry	= VertexFormatVersion[__VertexFormat];
					
					for i = 0, ~-Count do
						for VertexDataIndex = 1, #VertexData do
							local CurrentVertexData		= VertexData[VertexDataIndex];
							local VertexFormatAttribute;
							local DataPointer;
							
							for j = 1, #VertexFormatEntry do
								if (VertexFormatEntry[j].Attribute == CurrentVertexData.Attribute) then
									VertexFormatAttribute	= VertexFormatEntry[j];
									break;
								end;
							end;
							
							if (CurrentVertexData.Type.InputType ~= RevolutionEnum.GXVertexAttributeInputType.None) then
								local AttributeData	= {};
								
								local DataSize		= ~-CurrentVertexData.Type.InputType.Value;
								
								local ComponentFormat	= ComponentFormatTable[VertexFormatAttribute.ComponentFormat];
								
								local AttributeSize	= string.packsize(ComponentFormat.Format);
								local AttributeStride	= ComponentTypeStrideTable[VertexFormatAttribute.ComponentType];
								
								table.insert(AttributeData, {CurrentVertexData.Type.Name});
								
								if (CurrentVertexData.Type.InputType == RevolutionEnum.GXVertexAttributeInputType.Direct) then
									DataSize	= DataSize + AttributeSize * AttributeStride;
									DataPointer	= DataStartPointer + DataOffset;
								else
									local Index	= ResourceFile:Read(DataStartPointer + DataOffset, ">I" .. DataSize);
									DataPointer	= CurrentVertexData.Type.Pointer + Index * AttributeSize * AttributeStride;
								end;
								
								local IsColourValue	= false;
								IsColourValue		= IsColourValue or (ComponentFormat.Format == RevolutionEnum.GXAttributeComponentType.CLR_RGB);
								IsColourValue		= IsColourValue or (ComponentFormat.Format == RevolutionEnum.GXAttributeComponentType.CLR_RGBA);
								
								if (IsColourValue == true) then
									local CurrentValue	= ResourceFile:Read(DataPointer, ComponentFormat.Format);
									
									local R			= ((CurrentValue >> ComponentFormat.R[1]) & ~-(0x01 << ComponentFormat.R[2])) / (~-(0x01 << ComponentFormat.R[2]));
									local G			= ((CurrentValue >> ComponentFormat.G[1]) & ~-(0x01 << ComponentFormat.G[2])) / (~-(0x01 << ComponentFormat.G[2]));
									local B			= ((CurrentValue >> ComponentFormat.B[1]) & ~-(0x01 << ComponentFormat.B[2])) / (~-(0x01 << ComponentFormat.B[2]));
									local A			= 0.5;
										
									if (ComponentFormat.A ~= nil) then
										A		= ((CurrentValue >> ComponentFormat.A[1]) & ~-(0x01 << ComponentFormat.A[2])) / (~-(0x01 << ComponentFormat.A[2]));
									end;
									
									AttributeData		= {math.floor(R * 0xFF + 0.5), math.floor(G * 0xFF + 0.5), math.floor(B * 0xFF + 0.5), math.floor(A * 0xFF + 0.5)};
								else
									for j = 0, ~-AttributeStride do
										local CurrentValue	= ResourceFile:Read(DataPointer + AttributeSize * j, ComponentFormat.Format);
										CurrentValue		= CurrentValue / (0x01 << VertexFormatAttribute.Fraction);
										
										AttributeData[-~j]	= CurrentValue;
									end;
									
									--print(table.concat(AttributeData, ", "));
								end;
								
								--print(CurrentVertexData.Storage);
								table.insert(StorageTable[CurrentVertexData.Storage], AttributeData);
								
								DataOffset	= DataOffset + DataSize;
							end;
						end;
						
						if (GenerateFaces[__PrimitiveType.Name] ~= nil) then
							GenerateFaces[__PrimitiveType.Name](i);
						end;
						
						idx_vert	= idx_vert + 1;
						num_vert_total	= num_vert_total + 1;
					end;
				else
					DataOffset		= DataOffset + 0x01;
				end;
			end;
		end;
		
		return ProcessStrip;
	end;
end;

local function GenerateGroups(RevolutionData)
	local Groups		= {};
	
	v			= {};
	vt			= {};
	vn			= {};
	vc			= {};
	f			= {};
	
	idx_vert		= 0;
	num_vert_total		= 0;
	num_poly_total		= 0;
	
	local ProcessStrip	= GetVertexData(RevolutionData);
	
	for k = 1, RevolutionData.NumStrips do
		if (RevolutionData.StripDataPointer ~= 0xFFFFFFFF) then
			local g		=
			{
				STRIPENTRY	= RevolutionData.StripEntryTable[k];
				VERTICES	= {};
				UV		= {{}, {}, {}, {}, {}, {}, {}, {}};
				RGBA		= {{}, {}};
				NORMALS		= {};
				INDICES		= {};
			};
			
			StorageTable[1]		= {};
			StorageTable[2]		= {};
			StorageTable[3]		= {};
			StorageTable[4]		= {};
			StorageTable[5]		= {};
			StorageTable[6]		= {};
			StorageTable[7]		= {};
			StorageTable[8]		= {};
			StorageTable[9]		= {};
			StorageTable[10]	= {};
			StorageTable[11]	= {};
			StorageTable[12]	= {};
			StorageTable[13]	= {};
			
			local eStripEntry	= g.STRIPENTRY;
			local DataAddress	= RevolutionData.StripDataPointer + eStripEntry.DataOffset;
			local NumVerts		= eStripEntry.NumVerts;
			local NumPolys		= eStripEntry.NumPolys;
			
			local Offset		= 0x00;
			
			--[[
			local DataString	= "";
			
			while (Offset < eStripEntry.DataDisplayListSize) do
				local Byte	= ResourceFile:Read(DataAddress + Offset, ">B");
				
				if (Offset & 0x1F == 0x00) then
					DataString	= DataString .. string.rep("\n", math.min(#DataString, 1));
				else
					DataString	= DataString .. string.rep(" ", math.min(#DataString, 1));
				end;
				DataString	= DataString .. string.format("%02X", Byte);
				
				Offset		= Offset + 0x01;
			end;
			
			print(DataString);
			--]]
			
			--print(string.format("0x%08X 0x%04X 0x%04X", DataAddress, eStripEntry.NumVerts, eStripEntry.VtxDescAndFmt));
			
			ProcessStrip(eStripEntry);
			--print("#VERTICES", #StorageTable[1]);
			
			g.VERTICES		= StorageTable[1];
			g.NORMALS		= StorageTable[2];
			g.RGBA			= {StorageTable[3], StorageTable[4]};
			g.UV			= {StorageTable[5], StorageTable[6], StorageTable[7], StorageTable[8], StorageTable[9], StorageTable[10], StorageTable[11], StorageTable[12]};
			g.INDICES		= StorageTable[13];
			table.insert(Groups, g);
		end;
	end;
	
	return Groups;
end;

return GenerateGroups;