-- [XBOX] Generate xSolid Groups

local function align(x, al)
	al = -al;
	return (x + ~al) & al;
end;

local function GenerateGroups(XboxData)
	local Groups		= {};
	
	local v			= {};
	local vt		= {};
	local vn		= {};
	local vc		= {};
	local f			= {};
	
	local idx_vert		= 0;
	local num_vert_total	= 0;
	local num_poly_total	= 0;
	
	local MeshEntryDataPointer	= XboxData.MeshEntryDataPointer;
	
	for k = 1, XboxData.NumMeshEntries do
		local g		=
		{
			MESHENTRY	= XboxData.MeshEntryTable[k];
			VERTICES	= {};
			UV		= {{}, {}, {}, {}, {}, {}, {}, {}};
			RGBA		= {{}, {}};
			NORMALS		= {};
			INDICES		= {};
		};
		
		v			= {};
		vt			= {};
		vn			= {};
		vc			= {};
		f			= {};
		
		local eMeshEntry		= g.MESHENTRY;
		local VertexDataPointer		= eMeshEntry.VertexDataPointer;
		
		local NumVerts			= eMeshEntry.NumVerts;
		local NumPolys			= eMeshEntry.NumPolys;
		
		local Offset		= 0x0000;
		
		for j = 0x00, NumVerts - 0x01 do
			
			if (eMeshEntry.VtxDescAndFmt == 0x01) then
				idx_v	= ResourceFile:Read(DataAddress + Offset + 0x00 * 0x02, ">H");
				idx_c	= ResourceFile:Read(DataAddress + Offset + 0x02 * 0x02, ">H");
				idx_t	= ResourceFile:Read(DataAddress + Offset + 0x03 * 0x02, ">H");
				
				_x	= ResourceFile:Read(DataAddress + GamecubeData.DataOffset0 + idx_v * 0x0C + 0x00, ">f");
				_y	= ResourceFile:Read(DataAddress + GamecubeData.DataOffset0 + idx_v * 0x0C + 0x04, ">f");
				_z	= ResourceFile:Read(DataAddress + GamecubeData.DataOffset0 + idx_v * 0x0C + 0x08, ">f");
				
				_u	= ResourceFile:Read(DataAddress + GamecubeData.DataOffset3 + idx_t * 0x04 + 0x00, ">h") / 4096;
				_v	= ResourceFile:Read(DataAddress + GamecubeData.DataOffset3 + idx_t * 0x04 + 0x02, ">h") / 4096;
				
				_r	= ResourceFile:Read(DataAddress + GamecubeData.DataOffset2 + idx_c * 0x04 + 0x00, ">B");
				_g	= ResourceFile:Read(DataAddress + GamecubeData.DataOffset2 + idx_c * 0x04 + 0x01, ">B");
				_b	= ResourceFile:Read(DataAddress + GamecubeData.DataOffset2 + idx_c * 0x04 + 0x02, ">B");
				_a	= ResourceFile:Read(DataAddress + GamecubeData.DataOffset2 + idx_c * 0x04 + 0x03, ">B");
				
				Offset	= Offset + 0x08;
			end;
			
			table.insert(v, {_x, _y, _z});
			table.insert(vt, {_u, _v});
			table.insert(vc, {_r, _g, _b, _a});
		end;
		
		local Face		= 1;
		
		for i = 0x02, NumPolys + 0x01 do
			local a0, b0, c0 = i - 1 - Face, i - 1, i - 1 + Face;
			table.insert(f, {a0 + idx_vert, b0 + idx_vert, c0 + idx_vert});
				
			Face		= -Face;
		end;
		
		num_poly_total		= num_poly_total + NumPolys;
		num_vert_total		= num_vert_total + NumVerts;
		
		idx_vert		= idx_vert + NumVerts;
		
		g.VERTICES		= v;
		g.UV			= {vt, {}, {}, {}, {}, {}, {}, {}};
		g.RGBA			= {vc, {}};
		g.NORMALS		= vn;
		g.INDICES		= f;
		table.insert(Groups, g);
	end;
	
	return Groups;
end;

return GenerateGroups;