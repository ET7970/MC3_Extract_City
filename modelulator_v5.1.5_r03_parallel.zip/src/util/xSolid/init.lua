local xSolid				= {};
xSolid.GenerateGroups			= {};
xSolid.GenerateGroups.PSX_NASCAR	= require("src.util.xSolid.PSX_NASCAR");
xSolid.GenerateGroups.PSX2		= require("src.util.xSolid.PSX2");
xSolid.GenerateGroups.Gamecube		= require("src.util.xSolid.Gamecube");
xSolid.GenerateGroups.Revolution	= require("src.util.xSolid.Revolution");
xSolid.GenerateGroups.Xbox		= require("src.util.xSolid.Xbox");

-- man at work!
-- expect heavy delays or something like that

return xSolid;