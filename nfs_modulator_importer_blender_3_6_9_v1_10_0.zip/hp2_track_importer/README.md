# NFS Modulator Importer — Blender 3.6.x

Version 1.10.0 keeps the platform/game profile architecture from v1.8 and adds recursive Modelulator resource-root discovery plus explicit missing-solid diagnostics.

## Implemented profiles

- `PSX2 / HOTPURSUIT2`
- `PSX2 / UNDERGROUND2`

The add-on directory is intentionally still named `hp2_track_importer` so an install over older versions remains compatible with saved Blender preferences/scenes and the legacy operator id.

## Paths in v1.10

The UI now uses two path inputs:

- **Primary bundle root** — the actual geometry bundle, for example `...\\TRACKS\\STREAML4RF.BUN`. The bundle may directly contain `CollisionPacks`, `RoadNetworks`, `ScenerySections`, `Solids`, `Textures`. Selecting its `Solids` folder itself is also accepted.
- **Additional/global roots** — optional roots separated by `;`, for example `...\\FRONTEND;...\\GLOBAL;...\\TRACKS\\LOC4DYNTEX.BIN`.

Every selected root is searched recursively for these five Modelulator resource directories:

`CollisionPacks`, `RoadNetworks`, `ScenerySections`, `Solids`, `Textures`.

This means both of these layouts work without manually pointing at `Textures`:

```text
STREAML4RF.BUN/
  Solids/
  Textures/
  ScenerySections/
  ...
```

```text
GLOBAL/
  DYNTEX.BIN/
    Textures/
```

Texture lookup uses every discovered `Textures` directory. The primary bundle supplies the active `ScenerySections`; when a referenced DAE is absent from its own `Solids`, every discovered additional `Solids` directory is searched as a fallback before that placement is reported missing.

Legacy v1.7/v1.8 path properties are retained internally so old `.blend` files can still feed their saved roots into the new search.

## Missing-solid diagnostics

Both HP2 and UG2 now count ScenerySections entries whose referenced DAE does not exist. HP2 previously skipped these silently and incorrectly reported zero missing source instances.

After a scan/import Blender receives a text datablock named:

`NFS Modulator Import Diagnostics`

It lists:

- all discovered Modelulator resource folders;
- imported/scanned placement counts;
- missing texture count;
- every missing referenced solid hash/group/name and its section(s).

The root collection also stores the diagnostics as `nfs_modulator_diagnostics` JSON.

## Underground 2 (PS2)

Choose `PSX2 / UNDERGROUND2` and normally keep **Use ScenerySections placement** enabled for track/world bundles.

Modelulator 5.1.5 can append bytes from the following structure field to UG2 readable solid names. The UG2 profile repairs those names only in temporary DAE copies used by Blender; extracted files are not modified.

If ScenerySections references a solid that Modelulator did not export into `Solids/`, the placement is reported as missing instead of crashing or silently disappearing.

## Hot Pursuit 2 (PS2)

Choose `PSX2 / HOTPURSUIT2`. Existing `TRACKBxx.LZC` workflows remain supported. For the PS2 split-texture layout, selecting a track bundle such as `TRACKS\TRACKB13.LZC` now automatically discovers the matching `TRACKS\TEX13LOCATION.BIN`, `TRACKS\TEX13TRACK.BIN`, plus recursively scanned `GLOBAL` and `FRONTEND` folders under the same export root. **Additional/global roots** is optional and remains available for unusual/custom layouts.

Texture lookup prioritizes the primary bundle, then the matching LOCATION pack, matching TRACK pack, GLOBAL, FRONTEND, and finally other manually supplied roots. This avoids another track's texture pack winning because of filesystem sort order.

The HP2 parser now reports missing referenced DAE files instead of silently skipping them.

## Architecture

Game-specific parsers live under `importers/`:

```text
importers/
  common.py
  psx2/
    hotpursuit2.py
    underground2.py
```

`importers/__init__.py` contains the profile registry and the requested future platform/game namespaces.

Platforms:
`GAMECUBE, PC, PSX, PSX2, PS3, REVOLUTION, XBOX, XENON`.

Games:
`NASCAR2001, NASCARTHUNDER2002, NASCARTHUNDER2003, NASCARTHUNDER2004, HOTPURSUIT2_A098, HOTPURSUIT2, UNDERGROUNDPROTO, UNDERGROUND, UNDERGROUND2, MOSTWANTED_DEMO, MOSTWANTED, CARBON, PROSTREET, NITRO, UNDERCOVER, WORLD`.

## Compatibility

- Blender target: 3.6.x.
- Legacy operator id `hp2.import_track` is preserved.
- Legacy `hp2_*` metadata aliases remain alongside generic `nfs_modulator_*` properties.
