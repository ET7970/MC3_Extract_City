from __future__ import annotations


bl_info = {
    "name": "NFS Modulator Importer",
    "author": "OpenAI Codex",
    "version": (1, 10, 0),
    "blender": (3, 6, 0),
    "location": "File > Import > NFS Modulator Importer",
    "description": "Imports NFS Modulator exports through platform/game profiles with linked instances and canonical materials",
    "category": "Import-Export",
}

import json
import os
import re
import subprocess
import sys
import tempfile
from pathlib import Path

import bpy
from bpy.app.handlers import persistent
from bpy_extras.io_utils import ImportHelper
from bpy.props import BoolProperty, EnumProperty, IntProperty, StringProperty
from bpy.types import Operator, Panel, PropertyGroup
from mathutils import Matrix

try:
    from .importers import PROFILES
    from .importers.common import resolve_bundle_root
except ImportError:  # Allows local syntax/testing execution outside package context.
    from importers import PROFILES
    from importers.common import resolve_bundle_root


ADDON_TAG = "nfs_modulator_importer_v2"
LEGACY_ADDON_TAGS = ("hp2_track_importer_v1",)
ROOT_COLLECTION_NAME = "NFS Modulator Import"
PROTOTYPE_COLLECTION_NAME = "NFS Modulator Prototypes (hidden)"
DIAGNOSTICS_TEXT_NAME = "NFS Modulator Import Diagnostics"
LEGACY_ROOT_COLLECTION_NAME = "HP2 Track Import"
LEGACY_PROTOTYPE_COLLECTION_NAME = "HP2 Prototypes (hidden)"
HASH_RE = re.compile(r"TEX0x([0-9A-Fa-f]{8})")
MISSING_HASH_RE = re.compile(r"MISSING_([0-9A-Fa-f]{8})")

PLATFORM_ITEMS = tuple((platform, platform, "") for platform in sorted({key[0] for key in PROFILES}))
GAME_ITEMS = tuple((game, game.replace("HOTPURSUIT2", "Hot Pursuit 2").replace("UNDERGROUND2", "Underground 2"), "")
                   for game in sorted({key[1] for key in PROFILES}))


def _is_addon_data(id_block):
    return bool(id_block.get(ADDON_TAG) or any(id_block.get(tag) for tag in LEGACY_ADDON_TAGS))


def _profile_supported(settings):
    return (settings.platform, settings.game) in PROFILES


def _norm_path(value: str) -> str:
    return os.path.normcase(os.path.abspath(os.path.normpath(value)))


def _collection(name: str, parent=None):
    collection = bpy.data.collections.get(name)
    if collection is None:
        collection = bpy.data.collections.new(name)
        (parent or bpy.context.scene.collection).children.link(collection)
    elif parent is not None and collection not in parent.children:
        parent.children.link(collection)
    return collection


def _unlink_from_all_collections(obj):
    for collection in tuple(obj.users_collection):
        collection.objects.unlink(obj)


def _remove_collection_tree(collection):
    for child in tuple(collection.children):
        _remove_collection_tree(child)
    for obj in tuple(collection.objects):
        bpy.data.objects.remove(obj, do_unlink=True)
    bpy.data.collections.remove(collection)


def _clear_previous_import():
    for collection_name in (ROOT_COLLECTION_NAME, PROTOTYPE_COLLECTION_NAME,
                            LEGACY_ROOT_COLLECTION_NAME, LEGACY_PROTOTYPE_COLLECTION_NAME):
        collection = bpy.data.collections.get(collection_name)
        if collection:
            _remove_collection_tree(collection)
    for material in tuple(bpy.data.materials):
        if _is_addon_data(material):
            bpy.data.materials.remove(material, do_unlink=True)
    for image in tuple(bpy.data.images):
        if _is_addon_data(image):
            bpy.data.images.remove(image, do_unlink=True)
    for mesh in tuple(bpy.data.meshes):
        if _is_addon_data(mesh) and mesh.users == 0:
            bpy.data.meshes.remove(mesh)


def _texture_hash(material_name: str):
    match = HASH_RE.search(material_name or "")
    return match.group(1).upper() if match else None


def _friendly_id(prefix, label, texture_hash=None):
    label = re.sub(r"[^A-Za-z0-9_\-]+", "_", (label or "UNKNOWN")).strip("_")
    suffix = ("__0x" + texture_hash.upper()) if texture_hash else ""
    return prefix + "_" + (label or "UNKNOWN") + suffix


def _hex_key(value):
    value = str(value or "").upper().replace("0X", "")
    return "0x" + value.zfill(8) if value else ""


def _solid_key_properties(solid_hash, friendly_name):
    solid_key = _hex_key(solid_hash)
    return {
        "nfs_solid_key": solid_key,
        "nfs_solid_key2": solid_key,
        "nfs_solid_key3": solid_key,
        "nfs_original_solid_key": solid_key,
        "nfs_original_solid_key2": solid_key,
        "nfs_original_solid_key3": solid_key,
        "nfs_mesh_name": friendly_name,
    }


def _minimal_nfs_annotation_properties(solid_hash, friendly_name):
    """The non-file minimal annotation contract used by nfs_map_editor.

    ``nfs_instance_flags`` is deliberately present even when zero.  Its
    presence tells the Map Editor's "Initialize new mesh" operator that this
    object was imported with an authoritative solid key, so it must not merge
    Blender's ``.001`` name suffixes and replace the key with a name hash.
    """
    solid_key = _hex_key(solid_hash)
    return {
        **_solid_key_properties(solid_hash, friendly_name),
        "nfs_instance_flags": 0,
        "nfs_original_instance_flags": 0,
        "nfs_instance_flags_str": "None",
        "nfs_original_instance_flags_str": "None",
        "nfs_flag1": 0,
        "nfs_flag2": 0,
        "nfs_checksum": solid_key,
        "nfs_solid_is_windy": 0,
        "nfs_original_solid_is_windy": 0,
        "nfs_use_custom_bbox": 0,
        "nfs_matched": True,
        "nfs_file_match_status": "nfs_modulator_imported",
    }


def _remove_legacy_solid_key(id_block):
    """Remove the pre-v1.6 non-standard key without touching HP2 source data."""
    for prop_name in ("Solid_key", "Solid_keys"):
        if prop_name in id_block:
            del id_block[prop_name]


def _material_solid_reference_properties(manifest, texture_hash):
    solid_hashes = manifest.get("materials", {}).get(texture_hash, {}).get("solid_hashes", [])
    keys = [_hex_key(value) for value in solid_hashes]
    return {
        "nfs_source_solid_keys": keys,
        "nfs_source_solid_key": keys[0] if keys else "",
    }


def _section_number(section_name):
    """Convert SECTION_41 -> 41 and UG2 SECTION_A11 -> 111, SECTION_C1 -> 301."""
    match = re.search(r"(?:SECTION[_-]?)?([A-Za-z]*)(\d+)$", section_name or "", re.I)
    if not match:
        return 0
    letters = match.group(1).upper()
    number = int(match.group(2))
    if not letters:
        return number
    letter_code = 0
    for char in letters:
        letter_code = letter_code * 26 + (ord(char) - ord('A') + 1)
    return letter_code * 100 + number


def _instance_index(node_id):
    """Return Modelulator's hexadecimal node suffix as an integer, when present."""
    match = re.search(r"0x([0-9A-Fa-f]+)$", str(node_id or ""))
    return int(match.group(1), 16) if match else -1


def _legacy_texture_label(image, texture_hash):
    parts = Path(bpy.path.abspath(image.filepath)).stem.split('.') if image.filepath else []
    if len(parts) >= 4 and parts[0].upper() == ('0X' + texture_hash.upper()):
        return '.'.join(parts[3:]) or texture_hash
    return texture_hash


def _set_properties(id_block, values):
    for key, value in values.items():
        if value is None:
            continue
        if isinstance(value, (dict, tuple, list)):
            id_block[key] = json.dumps(value, ensure_ascii=False, separators=(',', ':'))
        else:
            id_block[key] = value


def _canonical_image(texture_hash, info):
    filepath = info["path"]
    normalized = _norm_path(filepath)
    image = next((img for img in bpy.data.images if img.source == 'FILE' and img.filepath and _norm_path(bpy.path.abspath(img.filepath)) == normalized), None)
    if image is None:
        image = bpy.data.images.load(filepath, check_existing=True)
    image.name = info.get("friendly_name") or texture_hash
    _set_properties(image, {
        ADDON_TAG: True,
        "Texture_key": _hex_key(texture_hash),
        "nfs_texture_key": _hex_key(texture_hash),
        "nfs_tpk_texture_name": info.get("friendly_name"),
        "nfs_modulator_texture_hash": texture_hash,
        "nfs_modulator_texture_name": info.get("friendly_name"),
        "nfs_modulator_texture_filename": info.get("filename"),
        "nfs_modulator_texture_path": info.get("path"),
        "nfs_modulator_texture_pack_dir": info.get("texture_pack_dir"),
        "nfs_modulator_alpha_usage_source": info.get("alpha_usage"),
        "nfs_modulator_alpha_blend_source": info.get("alpha_blend"),
        "hp2_texture_hash": texture_hash,
        "hp2_texture_name": info.get("friendly_name"),
        "hp2_texture_filename": info.get("filename"),
        "hp2_texture_path": info.get("path"),
        "hp2_texture_pack_dir": info.get("texture_pack_dir"),
        "hp2_alpha_usage_source": info.get("alpha_usage"),
        "hp2_alpha_blend_source": info.get("alpha_blend"),
    })
    return image


def _canonical_images(manifest):
    return {texture_hash: _canonical_image(texture_hash, info) for texture_hash, info in manifest["textures"].items()}


def _effective_alpha_usage(image, texture_info):
    """Use real PNG alpha when Modelulator metadata incorrectly says None."""
    declared = texture_info.get("alpha_usage", "None")
    if image.channels < 4:
        return declared
    pixels = image.pixels[:]
    alpha_values = pixels[3::4]
    if not alpha_values or min(alpha_values) >= 0.99:
        return declared
    if declared != "None":
        return declared
    # Binary alpha is foliage/fences; partial alpha is glass/fx.
    has_partial_alpha = any(0.02 < value < 0.98 for value in alpha_values)
    return "Modulated" if has_partial_alpha else "PunchThru"


def _flip_v_uv_once(mesh):
    if mesh.get("nfs_modulator_uv_v_flipped") or mesh.get("hp2_uv_v_flipped"):
        mesh["nfs_modulator_uv_v_flipped"] = True
        return False
    for uv_layer in mesh.uv_layers:
        for uv_data in uv_layer.data:
            uv_data.uv.y = 1.0 - uv_data.uv.y
    mesh["nfs_modulator_uv_v_flipped"] = True
    mesh["hp2_uv_v_flipped"] = True  # v1.0-v1.7 compatibility
    return True


def _activate_mesh_display_layers(mesh, uv_name=None, color_name=None):
    """Make Modelulator source layers immediately usable by Solid shading.

    Blender stores both an active and a render-active UV/color selection.  Merely
    keeping a layer in the mesh is not enough: Solid's Texture/Attribute colour
    modes use these selections before the user ever opens Object Data.
    """
    uv = mesh.uv_layers.get(uv_name or mesh.get("nfs_modulator_uv_map_name", "") or mesh.get("hp2_uv_map_name", ""))
    if uv is None and mesh.uv_layers:
        uv = mesh.uv_layers[0]
    if uv is not None:
        mesh.uv_layers.active = uv
        mesh.uv_layers.active_index = list(mesh.uv_layers).index(uv)
        uv.active_render = True

    color = mesh.color_attributes.get(color_name or mesh.get("nfs_modulator_color_attribute_name", "") or mesh.get("hp2_color_attribute_name", ""))
    if color is None and mesh.color_attributes:
        color = mesh.color_attributes[0]
    if color is not None:
        mesh.color_attributes.active_color = color
        mesh.color_attributes.active_color_index = list(mesh.color_attributes).index(color)
        mesh.color_attributes.render_color_index = list(mesh.color_attributes).index(color)


@persistent
def _restore_nfs_modulator_display_layers(_dummy):
    """Restore active display layers when an imported .blend is reopened."""
    for mesh in bpy.data.meshes:
        if _is_addon_data(mesh):
            _activate_mesh_display_layers(mesh)


def _normalize_mesh_metadata(mesh, solid_info):
    solid_hash = solid_info["solid_hash"]
    friendly_name = solid_info["friendly_name"]
    uv_name = "geometry-0x%s_uv_src" % solid_hash
    color_name = "geometry-0x%s_color_src" % solid_hash
    preferred_uv = mesh.uv_layers.get("src-texcoord0") or (mesh.uv_layers[0] if mesh.uv_layers else None)
    if preferred_uv:
        for layer_name in [layer.name for layer in mesh.uv_layers if layer != preferred_uv]:
            layer = mesh.uv_layers.get(layer_name)
            if layer is not None:
                mesh.uv_layers.remove(layer)
        preferred_uv.name = uv_name
    preferred_color = mesh.color_attributes.get("src-colour0") or mesh.color_attributes.get("src-color0") or (mesh.color_attributes[0] if mesh.color_attributes else None)
    if preferred_color:
        for attribute_name in [attribute.name for attribute in mesh.color_attributes if attribute != preferred_color]:
            attribute = mesh.color_attributes.get(attribute_name)
            if attribute is not None:
                mesh.color_attributes.remove(attribute)
        preferred_color.name = color_name
    mesh.name = _friendly_id("MESH", friendly_name, solid_hash)
    _set_properties(mesh, {
        ADDON_TAG: True,
        "nfs_modulator_solid_hash": solid_hash,
        "nfs_modulator_solid_group": solid_info.get("solid_group", ""),
        "nfs_modulator_solid_name": friendly_name,
        "nfs_modulator_solid_source_file": solid_info.get("source_file"),
        "nfs_modulator_solid_relative_path": solid_info.get("relative_path"),
        "nfs_modulator_geometry_id": solid_info.get("geometry_id"),
        "nfs_modulator_geometry_name": solid_info.get("geometry_name"),
        "nfs_modulator_library_node_id": solid_info.get("library_node_id"),
        "nfs_modulator_uv_map_name": uv_name if preferred_uv else "",
        "nfs_modulator_color_attribute_name": color_name if preferred_color else "",
        "nfs_modulator_source_uv_layers": solid_info.get("uv_source_ids"),
        "nfs_modulator_source_color_attributes": solid_info.get("color_source_ids"),
        "nfs_modulator_source_materials": solid_info.get("material_source_names"),
        "hp2_solid_hash": solid_hash,
        "hp2_solid_name": friendly_name,
        "hp2_solid_source_file": solid_info.get("source_file"),
        "hp2_solid_relative_path": solid_info.get("relative_path"),
        "hp2_geometry_id": solid_info.get("geometry_id"),
        "hp2_geometry_name": solid_info.get("geometry_name"),
        "hp2_library_node_id": solid_info.get("library_node_id"),
        "hp2_uv_map_name": uv_name if preferred_uv else "",
        "hp2_color_attribute_name": color_name if preferred_color else "",
        "hp2_source_uv_layers": solid_info.get("uv_source_ids"),
        "hp2_source_color_attributes": solid_info.get("color_source_ids"),
        "hp2_source_materials": solid_info.get("material_source_names"),
        **_solid_key_properties(solid_hash, friendly_name),
    })
    _remove_legacy_solid_key(mesh)
    _activate_mesh_display_layers(mesh, uv_name, color_name)
    _flip_v_uv_once(mesh)


def _apply_solid_metadata(imported_objects, solid_info):
    for obj in imported_objects:
        _set_properties(obj, {
            ADDON_TAG: True,
            "nfs_modulator_solid_hash": solid_info["solid_hash"],
            "nfs_modulator_solid_group": solid_info.get("solid_group", ""),
            "nfs_modulator_solid_name": solid_info["friendly_name"],
            "nfs_modulator_solid_source_file": solid_info.get("source_file"),
            "nfs_modulator_solid_relative_path": solid_info.get("relative_path"),
            "nfs_modulator_geometry_id": solid_info.get("geometry_id"),
            "nfs_modulator_geometry_name": solid_info.get("geometry_name"),
            "nfs_modulator_library_node_id": solid_info.get("library_node_id"),
            "nfs_modulator_source_metadata": solid_info,
            "hp2_solid_hash": solid_info["solid_hash"],
            "hp2_solid_name": solid_info["friendly_name"],
            "hp2_solid_source_file": solid_info.get("source_file"),
            "hp2_solid_relative_path": solid_info.get("relative_path"),
            "hp2_geometry_id": solid_info.get("geometry_id"),
            "hp2_geometry_name": solid_info.get("geometry_name"),
            "hp2_library_node_id": solid_info.get("library_node_id"),
            "hp2_source_metadata": solid_info,
            **_solid_key_properties(solid_info["solid_hash"], solid_info["friendly_name"]),
        })
        if obj.type == 'MESH':
            _normalize_mesh_metadata(obj.data, solid_info)
            obj.name = "__NFS_MODULATOR_PROTO__" + solid_info["friendly_name"]


def _configure_material(material, texture_hash, image, texture_info):
    material.name = texture_info.get("friendly_name") or texture_hash
    material.use_nodes = True
    material.node_tree.nodes.clear()
    nodes = material.node_tree.nodes
    links = material.node_tree.links
    output = nodes.new("ShaderNodeOutputMaterial")
    output.location = (520, 0)
    texture = nodes.new("ShaderNodeTexImage")
    texture.location = (-380, 0)
    texture.image = image
    texture.interpolation = 'Linear'
    texcoord = nodes.new("ShaderNodeTexCoord")
    texcoord.location = (-620, 0)
    vertex_color = nodes.new("ShaderNodeVertexColor")
    vertex_color.location = (-160, -180)
    multiply = nodes.new("ShaderNodeMixRGB")
    multiply.location = (40, 50)
    multiply.blend_type = 'MULTIPLY'
    multiply.inputs[0].default_value = 1.0
    emission = nodes.new("ShaderNodeEmission")
    emission.location = (260, 50)
    # UV V is flipped once in mesh data, so Solid and Material Preview agree.
    links.new(texcoord.outputs['UV'], texture.inputs['Vector'])
    links.new(texture.outputs['Color'], multiply.inputs[1])
    links.new(vertex_color.outputs['Color'], multiply.inputs[2])
    links.new(multiply.outputs['Color'], emission.inputs['Color'])

    alpha_usage = _effective_alpha_usage(image, texture_info)
    alpha_blend = texture_info.get("alpha_blend", "SrcCopy")
    if alpha_usage == "None":
        image.alpha_mode = 'NONE'
        material.blend_method = 'OPAQUE'
        material.shadow_method = 'OPAQUE'
        material.show_transparent_back = False
        links.new(emission.outputs['Emission'], output.inputs['Surface'])
    else:
        image.alpha_mode = 'STRAIGHT'
        material.show_transparent_back = True
        transparent = nodes.new("ShaderNodeBsdfTransparent")
        transparent.location = (260, -100)
        color_alpha_mul = nodes.new("ShaderNodeMath")
        color_alpha_mul.location = (-120, -120)
        color_alpha_mul.operation = 'MULTIPLY'
        color_alpha_mul.inputs[1].default_value = 255.0 * 2.0
        color_alpha_div = nodes.new("ShaderNodeMath")
        color_alpha_div.location = (-40, -120)
        color_alpha_div.operation = 'DIVIDE'
        color_alpha_div.inputs[1].default_value = 127.0
        alpha = nodes.new("ShaderNodeMath")
        alpha.location = (40, -100)
        alpha.operation = 'MULTIPLY'
        links.new(vertex_color.outputs['Alpha'], color_alpha_mul.inputs[0])
        links.new(color_alpha_mul.outputs[0], color_alpha_div.inputs[0])
        links.new(texture.outputs['Alpha'], alpha.inputs[0])
        links.new(color_alpha_div.outputs[0], alpha.inputs[1])
        if alpha_blend == "SrcAdditive":
            material.blend_method = 'BLEND'
            material.shadow_method = 'NONE'
            shader = nodes.new("ShaderNodeAddShader")
            links.new(alpha.outputs[0], emission.inputs['Strength'])
            links.new(transparent.outputs[0], shader.inputs[0])
            links.new(emission.outputs[0], shader.inputs[1])
            links.new(shader.outputs[0], output.inputs['Surface'])
        else:
            material.blend_method = 'CLIP' if alpha_usage == "PunchThru" else 'BLEND'
            material.shadow_method = 'CLIP' if alpha_usage == "PunchThru" else 'HASHED'
            shader = nodes.new("ShaderNodeMixShader")
            links.new(alpha.outputs[0], shader.inputs[0])
            links.new(transparent.outputs[0], shader.inputs[1])
            links.new(emission.outputs[0], shader.inputs[2])
            links.new(shader.outputs[0], output.inputs['Surface'])
    _set_properties(material, {
        ADDON_TAG: True,
        "Texture_key": _hex_key(texture_hash),
        "nfs_texture_key": _hex_key(texture_hash),
        "nfs_tpk_texture_name": texture_info.get("friendly_name"),
        "nfs_modulator_texture_hash": texture_hash,
        "nfs_modulator_texture_name": texture_info.get("friendly_name"),
        "nfs_modulator_texture_filename": texture_info.get("filename"),
        "nfs_modulator_texture_path": texture_info.get("path"),
        "nfs_modulator_texture_pack_dir": texture_info.get("texture_pack_dir"),
        "nfs_modulator_alpha_usage": alpha_usage,
        "nfs_modulator_alpha_blend": alpha_blend,
        "hp2_texture_hash": texture_hash,
        "hp2_texture_name": texture_info.get("friendly_name"),
        "hp2_texture_filename": texture_info.get("filename"),
        "hp2_texture_path": texture_info.get("path"),
        "hp2_texture_pack_dir": texture_info.get("texture_pack_dir"),
        "hp2_alpha_usage": alpha_usage,
        "hp2_alpha_blend": alpha_blend,
    })


def _find_canonical_material(texture_hash):
    return next((material for material in bpy.data.materials if _is_addon_data(material) and (material.get("nfs_modulator_texture_hash") or material.get("hp2_texture_hash")) == texture_hash), None)


def _canonical_materials(manifest, images):
    result = {}
    for texture_hash, image in images.items():
        material = _find_canonical_material(texture_hash)
        if material is None:
            material = bpy.data.materials.new("NFS_MAT_" + texture_hash)
        _configure_material(material, texture_hash, image, manifest["textures"][texture_hash])
        _set_properties(material, {
            "nfs_modulator_source_material_names": manifest.get("materials", {}).get(texture_hash, {}).get("source_material_names", []),
            "nfs_modulator_source_solid_hashes": manifest.get("materials", {}).get(texture_hash, {}).get("solid_hashes", []),
            "hp2_source_material_names": manifest.get("materials", {}).get(texture_hash, {}).get("source_material_names", []),
            "hp2_source_solid_hashes": manifest.get("materials", {}).get(texture_hash, {}).get("solid_hashes", []),
            **_material_solid_reference_properties(manifest, texture_hash),
        })
        _set_properties(image, {
            **_material_solid_reference_properties(manifest, texture_hash),
        })
        _remove_legacy_solid_key(material)
        _remove_legacy_solid_key(image)
        result[texture_hash] = material
    return result


def _materialize_missing(material, canonical_materials):
    texture_hash = _texture_hash(material.name)
    if texture_hash and texture_hash in canonical_materials:
        return canonical_materials[texture_hash]
    key = "MISSING_" + (texture_hash or re.sub(r"[. ]\d+$", "", material.name).upper())
    name = _friendly_id("MAT_MISSING", key)
    existing = bpy.data.materials.get(name)
    if existing:
        return existing
    material.name = name
    _set_properties(material, {ADDON_TAG: True, "nfs_modulator_texture_hash": texture_hash or "", "nfs_modulator_missing_texture": True, "hp2_texture_hash": texture_hash or "", "hp2_missing_texture": True})
    material.diffuse_color = (1.0, 0.0, 1.0, 1.0)
    return material


def _remap_imported_materials(imported_objects, canonical_materials):
    imported_materials = set()
    for obj in imported_objects:
        if obj.type == 'MESH':
            imported_materials.update(slot.material for slot in obj.material_slots if slot.material)
    remaps = {}
    for material in imported_materials:
        remaps[material] = _materialize_missing(material, canonical_materials)
    for obj in imported_objects:
        if obj.type == 'MESH':
            for slot in obj.material_slots:
                if slot.material in remaps:
                    slot.material = remaps[slot.material]
            obj.data.use_auto_smooth = False
            obj.data[ADDON_TAG] = True
            _flip_v_uv_once(obj.data)
    for old, new in remaps.items():
        if old != new and old.users == 0:
            bpy.data.materials.remove(old, do_unlink=True)


def _import_prototype(filepath, prototype_collection, canonical_materials, solid_info):
    before = set(bpy.data.objects)
    result = bpy.ops.wm.collada_import(filepath=filepath)
    if 'FINISHED' not in result:
        raise RuntimeError("Collada importer returned %s for %s" % (result, filepath))
    imported = list(set(bpy.data.objects) - before)
    if not imported:
        raise RuntimeError("No objects were imported from " + filepath)
    _remap_imported_materials(imported, canonical_materials)
    _apply_solid_metadata(imported, solid_info)
    for obj in imported:
        obj[ADDON_TAG] = True
        _unlink_from_all_collections(obj)
        prototype_collection.objects.link(obj)
        obj.hide_render = True
        obj.hide_set(True)
    roots = [obj for obj in imported if obj.parent not in imported]
    return imported, roots


def _copy_prototype(roots, target_collection, matrix, instance, solid_info):
    copies = {}
    for root in roots:
        for original in (root,) + tuple(root.children_recursive):
            clone = original.copy()
            clone.data = original.data
            target_collection.objects.link(clone)
            copies[original] = clone
    for original, clone in copies.items():
        if original.parent in copies:
            clone.parent = copies[original.parent]
            clone.matrix_parent_inverse = original.matrix_parent_inverse.copy()
        else:
            clone.matrix_world = matrix @ original.matrix_world
            clone.name = solid_info["friendly_name"]
            _set_properties(clone, {
                ADDON_TAG: True,
                "nfs_modulator_instance_node_id": instance["name"],
                "nfs_modulator_section": instance.get("section", ""),
                "nfs_modulator_instance_matrix": instance["matrix"],
                "nfs_modulator_solid_hash": solid_info["solid_hash"],
                "nfs_modulator_solid_group": solid_info.get("solid_group", ""),
                "nfs_modulator_solid_name": solid_info["friendly_name"],
                "nfs_modulator_solid_source_file": solid_info.get("source_file"),
                "nfs_modulator_solid_relative_path": solid_info.get("relative_path"),
                "nfs_modulator_geometry_id": solid_info.get("geometry_id"),
                "nfs_modulator_geometry_name": solid_info.get("geometry_name"),
                "hp2_instance_node_id": instance["name"],
                "hp2_section": instance.get("section", ""),
                "hp2_instance_matrix": instance["matrix"],
                "hp2_solid_hash": solid_info["solid_hash"],
                "hp2_solid_name": solid_info["friendly_name"],
                "hp2_solid_source_file": solid_info.get("source_file"),
                "hp2_solid_relative_path": solid_info.get("relative_path"),
                "hp2_geometry_id": solid_info.get("geometry_id"),
                "hp2_geometry_name": solid_info.get("geometry_name"),
                "nfs_section_name": instance.get("section", ""),
                "nfs_section_number": _section_number(instance.get("section", "")),
                "nfs_instance_node_id": instance["name"],
                "nfs_instance_index": _instance_index(instance["name"]),
                "nfs_file_instance_order": _instance_index(instance["name"]),
                "nfs_position": (instance["matrix"][3], instance["matrix"][7], instance["matrix"][11]),
                "nfs_rotation_matrix": instance["matrix"],
                **_minimal_nfs_annotation_properties(solid_info["solid_hash"], solid_info["friendly_name"]),
            })
            _remove_legacy_solid_key(clone)
        clone.hide_set(False)
        clone.hide_render = False
    return len(copies)


def _matrix(values):
    if len(values) != 16:
        raise ValueError("Expected 16 matrix values, got %d" % len(values))
    # Modelulator writes translation in cells 3/7/11, i.e. the row layout Blender expects.
    return Matrix((values[0:4], values[4:8], values[8:12], values[12:16]))


def _instance_matrix_key(obj):
    """A placement key only when the original 4x4 Modelulator matrix is known."""
    values = obj.get("nfs_modulator_instance_matrix") or obj.get("hp2_instance_matrix")
    if isinstance(values, str):
        try:
            values = json.loads(values)
        except json.JSONDecodeError:
            return None
    if not isinstance(values, (list, tuple)) or len(values) != 16:
        return None
    try:
        return tuple(float(value) for value in values)
    except (TypeError, ValueError):
        return None


def _placement_sort_key(obj):
    return (
        _section_number(str(obj.get("nfs_modulator_section", "") or obj.get("hp2_section", ""))),
        _instance_index(str(obj.get("nfs_modulator_instance_node_id", "") or obj.get("hp2_instance_node_id", ""))),
        obj.name,
    )


def _remove_duplicate_placements_from_scene():
    """Remove only same-solid, same-transform duplicate placement objects.

    Section DAE files sometimes repeat a source DAE at exactly the same matrix
    under two section IDs.  Keeping both produces visual duplicate solids and
    needless `.001` names.  Distinct source hashes or any transform difference
    always remain separate.
    """
    canonical = {}
    duplicates = []
    for obj in bpy.data.objects:
        if obj.type != 'MESH' or not _is_addon_data(obj) or not (obj.get("nfs_modulator_instance_node_id") or obj.get("hp2_instance_node_id")):
            continue
        solid_hash = str(obj.get("nfs_modulator_solid_hash") or obj.get("hp2_solid_hash") or obj.data.get("nfs_modulator_solid_hash") or obj.data.get("hp2_solid_hash") or "")
        matrix = _instance_matrix_key(obj)
        if not solid_hash or matrix is None:
            continue
        solid_group = str(obj.get("nfs_modulator_solid_group") or obj.data.get("nfs_modulator_solid_group") or "")
        key = solid_hash, solid_group, matrix
        existing = canonical.get(key)
        if existing is None:
            canonical[key] = obj
        elif _placement_sort_key(obj) < _placement_sort_key(existing):
            duplicates.append(existing)
            canonical[key] = obj
        else:
            duplicates.append(obj)
    for obj in duplicates:
        bpy.data.objects.remove(obj, do_unlink=True)
    return len(duplicates)


def _dedupe_images():
    canonical = {}
    for image in tuple(bpy.data.images):
        if image.source != 'FILE' or not image.filepath:
            continue
        key = _norm_path(bpy.path.abspath(image.filepath))
        old = canonical.get(key)
        if old is None:
            canonical[key] = image
        elif old != image:
            image.user_remap(old)
            bpy.data.images.remove(image, do_unlink=True)


def _write_diagnostics_text(manifest):
    diagnostics = manifest.get("diagnostics", {})
    text = bpy.data.texts.get(DIAGNOSTICS_TEXT_NAME)
    if text is None:
        text = bpy.data.texts.new(DIAGNOSTICS_TEXT_NAME)
    else:
        text.clear()
    lines = [
        "NFS Modulator Import Diagnostics",
        "profile: %s / %s" % (manifest.get("platform", ""), manifest.get("game", "")),
        "primary bundle: %s" % manifest.get("solids_dir", ""),
        "placements imported/scanned: %s / %s" % (
            diagnostics.get("instances_after_limit", len(manifest.get("instances", []))),
            diagnostics.get("instances_before_limit", len(manifest.get("instances", []))),
        ),
        "missing source placements: %s" % diagnostics.get("missing_source_instances", 0),
        "missing unique solids: %s" % diagnostics.get("missing_source_unique_solids", len(diagnostics.get("missing_source_references", []))),
        "resolved from additional Solids: %s solids / %s placements" % (
            diagnostics.get("resolved_from_additional_solids", 0),
            diagnostics.get("resolved_from_additional_solid_instances", 0),
        ),
        "missing texture hashes: %s" % diagnostics.get("missing_texture_hashes", 0),
        "",
        "Automatic related roots:",
    ]
    auto_roots = diagnostics.get("automatic_resource_roots", [])
    if auto_roots:
        lines.extend("  " + value for value in auto_roots)
    else:
        lines.append("  none")
    lines.extend(("", "Resolved texture sources:"))
    texture_sources = diagnostics.get("texture_source_counts", {})
    if texture_sources:
        for source, count in sorted(texture_sources.items(), key=lambda item: (-item[1], item[0].casefold())):
            lines.append("  %s  x%s" % (source, count))
    else:
        lines.append("  none")
    lines.extend(("", "Discovered Modelulator resource directories:"))
    for category, paths in diagnostics.get("resource_directories", {}).items():
        lines.append("[%s] %d" % (category, len(paths)))
        lines.extend("  " + value for value in paths)
    refs = diagnostics.get("missing_source_references", [])
    lines.extend(("", "Missing referenced solid DAE files:"))
    if not refs:
        lines.append("  none")
    for item in refs:
        count = item.get("count", 1)
        sections = item.get("sections") or [item.get("section", "")]
        lines.append(
            "  %s/%s  %s  x%s  sections=%s" % (
                item.get("solid_group", ""), item.get("solid_hash", ""),
                item.get("solid_name", ""), count, ",".join(value for value in sections if value),
            )
        )
        expected = item.get("expected_relative_path")
        if expected:
            lines.append("    expected: " + expected)
    text.write("\n".join(lines) + "\n")
    return text


def _resource_roots(settings):
    """Additional Modelulator roots, recursively scanned by the worker.

    search_roots is the v1.9 UI field. texture_dirs/global_dir are retained as
    compatibility inputs for .blend files saved with v1.7/v1.8.
    """
    values = []
    values.extend(value.strip() for value in settings.search_roots.split(';') if value.strip())
    values.extend(value.strip() for value in settings.texture_dirs.split(';') if value.strip())
    if settings.global_dir.strip():
        values.append(settings.global_dir.strip())
    result = []
    seen = set()
    for value in values:
        path = Path(bpy.path.abspath(value))
        key = _norm_path(str(path))
        if key not in seen:
            seen.add(key)
            result.append(path)
    return result


def _run_worker(solids_dir, resource_roots, manifest_path, platform, game, prepared_dir=None,
                solids_only=False, workers=8, limit_instances=0):
    worker = Path(__file__).with_name("worker.py")
    command = [
        sys.executable, str(worker),
        "--platform", platform,
        "--game", game,
        "--solids", str(solids_dir),
        "--output", str(manifest_path),
        "--workers", str(max(1, workers)),
        "--limit-instances", str(max(0, limit_instances)),
    ]
    if prepared_dir is not None:
        command.extend(("--prepared-dir", str(prepared_dir)))
    for directory in resource_roots:
        command.extend(("--resource-root", str(directory)))
    if solids_only:
        command.append("--solids-only")
    process = subprocess.run(command, capture_output=True, text=True, check=False)
    if process.returncode:
        raise RuntimeError(process.stderr.strip() or process.stdout.strip() or "Worker failed")
    return json.loads(manifest_path.read_text(encoding='utf-8'))


class HP2TrackSettings(PropertyGroup):
    # The property group keeps its old Python name so Blender files from v1.0-v1.7
    # continue to load, while the visible UI and worker are now game-agnostic.
    platform: EnumProperty(name="Platform", items=PLATFORM_ITEMS, default='PSX2')
    game: EnumProperty(name="Game", items=GAME_ITEMS, default='HOTPURSUIT2')
    solids_dir: StringProperty(
        name="Primary bundle root",
        description="Modelulator bundle root such as STREAML4RF.BUN. Selecting Solids/ itself is also accepted",
        subtype='DIR_PATH',
        default=r"C:\Tools\modelulator.v5.1.5.pub\ug2-ps2-omt_out\TRACKS\STREAML4RF.BUN",
    )
    search_roots: StringProperty(
        name="Additional/global roots (optional)",
        description="Optional extra roots separated by semicolons. HP2 automatically finds matching TEXxxLOCATION/TEXxxTRACK plus shared FRONTEND/GLOBAL resources; manual roots are only needed for unusual layouts",
        default="",
    )
    # Legacy v1.7/v1.8 properties are intentionally retained but no longer
    # shown in the UI. Saved .blend files can still feed them into the search.
    texture_dirs: StringProperty(name="Legacy additional roots", default="")
    global_dir: StringProperty(name="Legacy global root", subtype='DIR_PATH', default="")
    clear_previous: BoolProperty(name="Replace prior NFS Modulator import", default=True)
    include_sections: BoolProperty(name="Use ScenerySections placement", default=True)
    worker_processes: IntProperty(name="External worker processes", description="Parallel DAE parsing processes before Blender import", min=1, max=64, default=8)
    limit_instances: IntProperty(name="Debug instance limit", description="0 imports the complete bundle; the limit is applied before temporary DAE preparation", min=0, default=0)


class HP2_OT_import_track(Operator, ImportHelper):
    # Keep the old idname so shortcuts/scripts made for v1.7 still invoke the importer.
    bl_idname = "hp2.import_track"
    bl_label = "NFS Modulator Importer"
    bl_description = "Import a Modelulator bundle using the selected platform/game profile"
    bl_options = {'REGISTER', 'UNDO'}

    filter_glob: StringProperty(default="*.dae", options={'HIDDEN'})

    def invoke(self, context, event):
        settings = context.scene.hp2_track_settings
        if not self.filepath and settings.solids_dir:
            self.filepath = os.path.join(bpy.path.abspath(settings.solids_dir), "Solids")
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def draw(self, context):
        layout = self.layout
        settings = context.scene.hp2_track_settings
        layout.label(text="NFS Modulator import settings", icon='IMPORT')
        row = layout.row(align=True)
        row.prop(settings, "platform")
        row.prop(settings, "game")
        if not _profile_supported(settings):
            layout.label(text="This platform/game importer is not implemented yet", icon='ERROR')
        layout.prop(settings, "solids_dir")
        layout.prop(settings, "search_roots")
        layout.separator()
        layout.prop(settings, "include_sections")
        layout.prop(settings, "clear_previous")
        layout.prop(settings, "worker_processes")
        layout.prop(settings, "limit_instances")
        if settings.platform == 'PSX2' and settings.game == 'HOTPURSUIT2':
            layout.label(text="HP2: matching TEXxxLOCATION/TEXxxTRACK + FRONTEND/GLOBAL are found automatically.", icon='INFO')
        else:
            layout.label(text="Additional roots use ;. All five Modelulator resource folders are found recursively.", icon='INFO')
        if settings.platform == 'PSX2' and settings.game == 'UNDERGROUND2':
            layout.label(text="UG2: malformed Modelulator solid names are repaired in temporary DAE copies.", icon='INFO')

    def execute(self, context):
        settings = context.scene.hp2_track_settings
        if not _profile_supported(settings):
            self.report({'ERROR'}, "No importer profile for %s / %s" % (settings.platform, settings.game))
            return {'CANCELLED'}
        selected_root = Path(bpy.path.abspath(settings.solids_dir))
        resource_roots = _resource_roots(settings)
        if not selected_root.is_dir():
            self.report({'ERROR'}, "Primary export root does not exist: " + str(selected_root))
            return {'CANCELLED'}
        try:
            solids_dir = resolve_bundle_root(selected_root)
        except ValueError as exc:
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}
        invalid_resource_roots = [path for path in resource_roots if not path.is_dir()]
        if invalid_resource_roots:
            self.report({'WARNING'}, "Ignoring missing optional root: " + str(invalid_resource_roots[0]))
            resource_roots = [path for path in resource_roots if path.is_dir()]

        with tempfile.TemporaryDirectory(prefix="nfs_modulator_import_") as temp_dir:
            temp_root = Path(temp_dir)
            manifest_path = temp_root / "manifest.json"
            prepared_dir = temp_root / "prepared_dae"
            try:
                manifest = _run_worker(
                    solids_dir, resource_roots, manifest_path,
                    settings.platform, settings.game,
                    prepared_dir, not settings.include_sections,
                    settings.worker_processes, settings.limit_instances,
                )
            except (OSError, RuntimeError) as exc:
                self.report({'ERROR'}, "Could not run worker: " + str(exc))
                return {'CANCELLED'}
            _write_diagnostics_text(manifest)
            if not manifest["instances"]:
                diagnostics = manifest.get("diagnostics", {})
                missing = diagnostics.get("missing_source_instances", 0)
                extra = " (%d section references point to missing DAE files)" % missing if missing else ""
                self.report({'ERROR'}, "Worker found no importable solid instances" + extra)
                return {'CANCELLED'}

            context.window_manager.progress_begin(0, len(manifest["instances"]))
            if settings.clear_previous:
                _clear_previous_import()
            root = _collection(ROOT_COLLECTION_NAME)
            root[ADDON_TAG] = True
            root["nfs_modulator_platform"] = manifest.get("platform", settings.platform)
            root["nfs_modulator_game"] = manifest.get("game", settings.game)
            diagnostics = manifest.get("diagnostics", {})
            root["nfs_modulator_diagnostics"] = json.dumps(diagnostics, ensure_ascii=False, separators=(',', ':'))
            root["nfs_modulator_resource_directory_counts"] = json.dumps(diagnostics.get("resource_directory_counts", {}), separators=(',', ':'))
            prototypes = _collection(PROTOTYPE_COLLECTION_NAME)
            prototypes.hide_render = True
            prototypes.hide_viewport = True
            images = _canonical_images(manifest)
            canonical_materials = _canonical_materials(manifest, images)
            section_collections = {}
            prototypes_by_file = {}
            imported_solids = 0
            total_objects = 0
            instances = manifest["instances"]
            try:
                for index, instance in enumerate(instances, 1):
                    solid = instance["solid"]
                    solid_info = manifest["solids"][solid]
                    prototype = prototypes_by_file.get(solid)
                    if prototype is None:
                        filepath = manifest["import_files"][solid]
                        _, roots = _import_prototype(filepath, prototypes, canonical_materials, solid_info)
                        prototype = roots
                        prototypes_by_file[solid] = prototype
                        imported_solids += 1
                    section = instance.get("section", "Solids")
                    target = section_collections.get(section)
                    if target is None:
                        target = _collection(section, root)
                        target[ADDON_TAG] = True
                        section_collections[section] = target
                    total_objects += _copy_prototype(prototype, target, _matrix(instance["matrix"]), instance, solid_info)
                    if index % 25 == 0:
                        context.window_manager.progress_update(index)
            finally:
                _dedupe_images()
                context.window_manager.progress_end()

            diagnostics = manifest.get("diagnostics", {})
            missing_sources = diagnostics.get("missing_source_instances", 0)
            missing_textures = diagnostics.get("missing_texture_hashes", 0)
            if missing_sources:
                refs = diagnostics.get("missing_source_references", [])
                sample = ""
                if refs:
                    first = refs[0]
                    sample = " First missing: %s/%s %s." % (first.get("solid_group", ""), first.get("solid_hash", ""), first.get("solid_name", ""))
                self.report({'WARNING'}, "%d ScenerySections placements were skipped because referenced solid DAE files were not present.%s" % (missing_sources, sample))
            if missing_textures:
                self.report({'WARNING'}, "%d referenced texture hashes were not found; those materials are marked as missing" % missing_textures)
            self.report(
                {'INFO'},
                "%s import complete: %d placements, %d unique solids, %d textures, %d materials" % (
                    manifest.get("profile_label", "%s / %s" % (settings.platform, settings.game)),
                    len(instances), imported_solids, len(images), len(canonical_materials),
                )
            )
            return {'FINISHED'}


class HP2_OT_repair_existing_track(Operator):
    bl_idname = "hp2.repair_existing_track"
    bl_label = "NFS Modulator: Repair Existing Scene"
    bl_description = "Repair metadata/UVs/materials using the selected platform/game profile"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        settings = context.scene.hp2_track_settings
        if not _profile_supported(settings):
            self.report({'ERROR'}, "No importer profile for %s / %s" % (settings.platform, settings.game))
            return {'CANCELLED'}
        selected_root = Path(bpy.path.abspath(settings.solids_dir))
        resource_roots = _resource_roots(settings)
        if not selected_root.is_dir():
            self.report({'ERROR'}, "Set a valid primary Modelulator export root")
            return {'CANCELLED'}
        try:
            solids_dir = resolve_bundle_root(selected_root)
        except ValueError as exc:
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}
        resource_roots = [path for path in resource_roots if path.is_dir()]
        try:
            with tempfile.TemporaryDirectory(prefix="nfs_modulator_repair_") as temp_dir:
                manifest = _run_worker(
                    solids_dir, resource_roots, Path(temp_dir) / "manifest.json",
                    settings.platform, settings.game,
                    workers=settings.worker_processes,
                )
                _write_diagnostics_text(manifest)
        except (OSError, RuntimeError) as exc:
            self.report({'ERROR'}, "Could not scan source/texture folders: " + str(exc))
            return {'CANCELLED'}

        solids_by_key = {
            (metadata["solid_hash"], metadata.get("solid_group", "")): metadata
            for metadata in manifest.get("solids", {}).values()
        }
        solids_by_hash = {}
        for metadata in manifest.get("solids", {}).values():
            solids_by_hash.setdefault(metadata["solid_hash"], metadata)

        def metadata_for(id_block, data_block=None):
            data_block = data_block or id_block
            solid_hash = (
                id_block.get("nfs_modulator_solid_hash") or id_block.get("hp2_solid_hash") or
                data_block.get("nfs_modulator_solid_hash") or data_block.get("hp2_solid_hash")
            )
            if not solid_hash:
                match = re.search(r"0x([0-9A-Fa-f]{8})", id_block.name)
                solid_hash = match.group(1).upper() if match else None
            if not solid_hash:
                return None
            solid_group = (
                id_block.get("nfs_modulator_solid_group") or
                data_block.get("nfs_modulator_solid_group") or
                ("DEFAULT" if settings.game == 'HOTPURSUIT2' else "")
            )
            return solids_by_key.get((solid_hash, solid_group)) or solids_by_hash.get(solid_hash)

        removed_duplicate_placements = _remove_duplicate_placements_from_scene()
        flipped_meshes = 0
        for mesh in bpy.data.meshes:
            if not _is_addon_data(mesh):
                continue
            metadata = metadata_for(mesh)
            if metadata:
                was_flipped = bool(mesh.get("nfs_modulator_uv_v_flipped") or mesh.get("hp2_uv_v_flipped"))
                _normalize_mesh_metadata(mesh, metadata)
                flipped_meshes += int(not was_flipped)
            elif _flip_v_uv_once(mesh):
                flipped_meshes += 1

        renamed_objects = 0
        for obj in bpy.data.objects:
            if not _is_addon_data(obj) or obj.type != 'MESH':
                continue
            metadata = metadata_for(obj, obj.data)
            if not metadata:
                continue
            instance_id = obj.get("nfs_modulator_instance_node_id") or obj.get("hp2_instance_node_id") or obj.name
            _set_properties(obj, {
                ADDON_TAG: True,
                "nfs_modulator_instance_node_id": instance_id,
                "nfs_modulator_solid_hash": metadata["solid_hash"],
                "nfs_modulator_solid_group": metadata.get("solid_group", ""),
                "nfs_modulator_solid_name": metadata["friendly_name"],
                "nfs_modulator_solid_source_file": metadata.get("source_file"),
                "nfs_modulator_solid_relative_path": metadata.get("relative_path"),
                "nfs_modulator_geometry_id": metadata.get("geometry_id"),
                "nfs_modulator_geometry_name": metadata.get("geometry_name"),
                "hp2_instance_node_id": instance_id,
                "hp2_solid_hash": metadata["solid_hash"],
                "hp2_solid_name": metadata["friendly_name"],
                "hp2_solid_source_file": metadata.get("source_file"),
                "hp2_solid_relative_path": metadata.get("relative_path"),
                "hp2_geometry_id": metadata.get("geometry_id"),
                "hp2_geometry_name": metadata.get("geometry_name"),
                "nfs_instance_node_id": instance_id,
                "nfs_instance_index": _instance_index(instance_id),
                "nfs_file_instance_order": _instance_index(instance_id),
                **_minimal_nfs_annotation_properties(metadata["solid_hash"], metadata["friendly_name"]),
            })
            _remove_legacy_solid_key(obj)
            readable_name = metadata["friendly_name"]
            if obj.name != readable_name:
                obj.name = readable_name
                renamed_objects += 1

        repaired_materials = 0
        remaps = []
        for material in tuple(bpy.data.materials):
            if not _is_addon_data(material):
                continue
            texture_hash = material.get("nfs_modulator_texture_hash") or material.get("hp2_texture_hash") or _texture_hash(material.name)
            if texture_hash is None:
                missing = MISSING_HASH_RE.search(material.name)
                texture_hash = missing.group(1).upper() if missing else None
            if not texture_hash or texture_hash not in manifest["textures"]:
                continue
            canonical = _find_canonical_material(texture_hash) or material
            image = _canonical_image(texture_hash, manifest["textures"][texture_hash])
            _configure_material(canonical, texture_hash, image, manifest["textures"][texture_hash])
            _set_properties(canonical, {
                "nfs_modulator_source_material_names": manifest.get("materials", {}).get(texture_hash, {}).get("source_material_names", []),
                "nfs_modulator_source_solid_hashes": manifest.get("materials", {}).get(texture_hash, {}).get("solid_hashes", []),
                "hp2_source_material_names": manifest.get("materials", {}).get(texture_hash, {}).get("source_material_names", []),
                "hp2_source_solid_hashes": manifest.get("materials", {}).get(texture_hash, {}).get("solid_hashes", []),
                **_material_solid_reference_properties(manifest, texture_hash),
            })
            _set_properties(image, _material_solid_reference_properties(manifest, texture_hash))
            _remove_legacy_solid_key(canonical)
            _remove_legacy_solid_key(image)
            repaired_materials += 1
            if material != canonical:
                remaps.append((material, canonical))
        for old, canonical in remaps:
            old.user_remap(canonical)
            if old.users == 0:
                bpy.data.materials.remove(old, do_unlink=True)

        for image in bpy.data.images:
            if not _is_addon_data(image):
                continue
            texture_hash = image.get("nfs_modulator_texture_hash") or image.get("hp2_texture_hash")
            if not texture_hash:
                match = re.search(r"([0-9A-Fa-f]{8})$", image.name)
                texture_hash = match.group(1).upper() if match else None
            if not texture_hash:
                continue
            info = manifest["textures"].get(texture_hash)
            if info:
                _canonical_image(texture_hash, info)
            else:
                legacy_label = _legacy_texture_label(image, texture_hash)
                image.name = legacy_label
                _set_properties(image, {
                    "nfs_modulator_texture_hash": texture_hash,
                    "nfs_modulator_texture_name": legacy_label,
                    "hp2_texture_hash": texture_hash,
                    "hp2_texture_name": legacy_label,
                })
        _dedupe_images()
        self.report(
            {'INFO'},
            "%s repair complete: %d duplicate placements removed, %d UV meshes flipped, %d objects renamed, %d materials rebuilt" % (
                manifest.get("profile_label", "%s / %s" % (settings.platform, settings.game)),
                removed_duplicate_placements, flipped_meshes, renamed_objects, repaired_materials,
            )
        )
        return {'FINISHED'}


def _menu_import(self, _context):
    self.layout.operator(HP2_OT_import_track.bl_idname, text="NFS Modulator Importer", icon='IMPORT')


CLASSES = (HP2TrackSettings, HP2_OT_import_track, HP2_OT_repair_existing_track)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.Scene.hp2_track_settings = bpy.props.PointerProperty(type=HP2TrackSettings)
    bpy.types.TOPBAR_MT_file_import.append(_menu_import)
    if _restore_nfs_modulator_display_layers not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(_restore_nfs_modulator_display_layers)


def unregister():
    bpy.types.TOPBAR_MT_file_import.remove(_menu_import)
    if _restore_nfs_modulator_display_layers in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(_restore_nfs_modulator_display_layers)
    del bpy.types.Scene.hp2_track_settings
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
