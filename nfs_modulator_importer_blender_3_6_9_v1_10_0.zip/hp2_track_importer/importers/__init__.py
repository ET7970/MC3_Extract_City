from __future__ import annotations

from .psx2 import hotpursuit2, underground2


PROFILES = {
    (hotpursuit2.PLATFORM, hotpursuit2.GAME): hotpursuit2,
    (underground2.PLATFORM, underground2.GAME): underground2,
}

PLATFORM_ORDER = ('GAMECUBE', 'PC', 'PSX', 'PSX2', 'PS3', 'REVOLUTION', 'XBOX', 'XENON')
GAME_ORDER = (
    'NASCAR2001', 'NASCARTHUNDER2002', 'NASCARTHUNDER2003', 'NASCARTHUNDER2004',
    'HOTPURSUIT2_A098', 'HOTPURSUIT2', 'UNDERGROUNDPROTO', 'UNDERGROUND', 'UNDERGROUND2',
    'MOSTWANTED_DEMO', 'MOSTWANTED', 'CARBON', 'PROSTREET', 'NITRO', 'UNDERCOVER', 'WORLD',
)


def get_profile(platform: str, game: str):
    key = (str(platform).upper(), str(game).upper())
    try:
        return PROFILES[key]
    except KeyError:
        raise ValueError('Unsupported importer profile: %s / %s' % key)


def supported_platforms():
    return [value for value in PLATFORM_ORDER if any(key[0] == value for key in PROFILES)]


def supported_games(platform: str):
    platform = str(platform).upper()
    return [value for value in GAME_ORDER if (platform, value) in PROFILES]
