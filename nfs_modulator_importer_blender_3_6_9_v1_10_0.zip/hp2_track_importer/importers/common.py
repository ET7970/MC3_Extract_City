from __future__ import annotations

import json
import os
import re
import xml.etree.ElementTree as ET
from pathlib import Path, PurePosixPath


TEXTURE_HASH_RE = re.compile(r"^0x([0-9A-Fa-f]{8})\.")
MATERIAL_TEXTURE_HASH_RE = re.compile(r"TEX0x([0-9A-Fa-f]{8})")
NODE_ID_RE_BYTES = re.compile(br'<node\s+id="([^"]+)"')


def local_name(element):
    return element.tag.rsplit('}', 1)[-1]


def native_relative_path(root: Path, relative: str) -> Path:
    return root.joinpath(*PurePosixPath(relative).parts)


def parse_texture_metadata(texture_dir: Path):
    metadata = {}
    for path in sorted(texture_dir.rglob('*.json')):
        try:
            data = json.loads(path.read_text(encoding='utf-8'))
        except (OSError, UnicodeDecodeError, json.JSONDecodeError):
            continue
        for item in data.get('eTextureInfoList', []):
            match = TEXTURE_HASH_RE.match(item.get('Texture', ''))
            if match:
                metadata[match.group(1).upper()] = {
                    'alpha_usage': item.get('AlphaUsage', 'None'),
                    'alpha_blend': item.get('AlphaBlend', 'SrcCopy'),
                }
    return metadata


def friendly_texture_name(path: Path, texture_hash: str):
    parts = path.stem.split('.')
    if len(parts) >= 4 and parts[0].upper() == ('0X' + texture_hash):
        value = '.'.join(parts[3:])
    else:
        value = path.stem
    return value or texture_hash


def collect_textures(texture_dirs, required_hashes=None):
    textures = {}
    for texture_dir in texture_dirs:
        metadata = parse_texture_metadata(texture_dir)
        for path in sorted(texture_dir.rglob('*')):
            if not path.is_file() or path.suffix.lower() not in {'.png', '.dds', '.tga', '.bmp', '.jpg', '.jpeg'}:
                continue
            match = TEXTURE_HASH_RE.match(path.name)
            if not match:
                continue
            texture_hash = match.group(1).upper()
            if required_hashes is not None and texture_hash not in required_hashes:
                continue
            if texture_hash not in textures:
                info = {
                    'path': str(path),
                    'filename': path.name,
                    'texture_hash': texture_hash,
                    'friendly_name': friendly_texture_name(path, texture_hash),
                    'texture_pack_dir': str(texture_dir),
                    'alpha_usage': 'None',
                    'alpha_blend': 'SrcCopy',
                }
                info.update(metadata.get(texture_hash, {}))
                textures[texture_hash] = info
    return textures


def natural_section_key(section_name: str):
    value = str(section_name or '')
    match = re.search(r'(?:SECTION[_-]?)?([A-Za-z]*)(\d+)$', value, re.I)
    if not match:
        return (1 << 30, 1 << 30, value)
    letters = match.group(1).upper()
    number = int(match.group(2))
    letter_code = 0
    for char in letters:
        letter_code = letter_code * 26 + (ord(char) - ord('A') + 1)
    return (letter_code, number, value)


def section_sort_key(instance):
    node_match = re.search(r"0x([0-9A-Fa-f]+)$", str(instance.get('name', '')))
    node_number = int(node_match.group(1), 16) if node_match else 1 << 30
    return natural_section_key(instance.get('section', '')) + (node_number, str(instance.get('name', '')))


def deduplicate_placements(instances):
    canonical = {}
    for instance in instances:
        key = (str(instance['solid']), tuple(float(value) for value in instance['matrix']))
        existing = canonical.get(key)
        if existing is None or section_sort_key(instance) < section_sort_key(existing):
            canonical[key] = instance
    return sorted(canonical.values(), key=section_sort_key)


def xml_metadata(root, relative_solid, source: Path, solid_hash, friendly_name, solid_group=''):
    geometry = next((element for element in root.iter() if local_name(element) == 'geometry'), None)
    node = next((element for element in root.iter() if local_name(element) == 'node'), None)
    source_ids = [element.get('id', '') for element in root.iter() if local_name(element) == 'source']
    material_names = [element.get('name', '') for element in root.iter() if local_name(element) == 'material']
    material_hashes = sorted({match.group(1).upper() for name in material_names if (match := MATERIAL_TEXTURE_HASH_RE.search(name))})
    return {
        'solid_hash': solid_hash.upper(),
        'solid_group': solid_group,
        'friendly_name': friendly_name,
        'source_file': str(source),
        'relative_path': relative_solid,
        'geometry_id': geometry.get('id', '') if geometry is not None else '',
        'geometry_name': geometry.get('name', '') if geometry is not None else '',
        'library_node_id': node.get('id', '') if node is not None else '',
        'dae_source_ids': source_ids,
        'uv_source_ids': [value for value in source_ids if 'texcoord' in value.lower()],
        'color_source_ids': [value for value in source_ids if 'colour' in value.lower() or 'color' in value.lower()],
        'material_source_names': material_names,
        'material_hashes': material_hashes,
    }


def append_import_scene(raw: bytes, source: Path) -> bytes:
    match = NODE_ID_RE_BYTES.search(raw)
    if match is None:
        raise ValueError('No library node found in ' + str(source))
    node_id = match.group(1)
    if any(byte < 0x20 or byte > 0x7E for byte in node_id):
        raise ValueError('Unexpected non-ASCII library node id in ' + str(source))
    suffix = (
        b'\n<library_visual_scenes><visual_scene id="NFS_MODULATOR_IMPORT_SCENE">'
        b'<node id="NFS_MODULATOR_IMPORT_ROOT"><instance_node url="#' + node_id +
        b'"/></node></visual_scene></library_visual_scenes>'
        b'<scene><instance_visual_scene url="#NFS_MODULATOR_IMPORT_SCENE"/></scene>\n'
    )
    closing = raw.rfind(b'</COLLADA>')
    if closing < 0:
        raise ValueError('Missing </COLLADA> in ' + str(source))
    return raw[:closing] + suffix + raw[closing:]


MODELULATOR_RESOURCE_DIRS = (
    'CollisionPacks',
    'RoadNetworks',
    'ScenerySections',
    'Solids',
    'Textures',
)
_RESOURCE_NAME_MAP = {name.casefold(): name for name in MODELULATOR_RESOURCE_DIRS}


def discover_resource_directories(roots):
    """Find Modelulator resource folders below one or more user-selected roots.

    A root may be either a bundle itself (for example STREAML4RF.BUN, which
    directly contains Solids/ and Textures/) or a broad folder such as
    FRONTEND/GLOBAL where bundle directories live one or more levels deeper.
    The search also accepts selecting one of the five resource directories
    directly.
    """
    result = {name: [] for name in MODELULATOR_RESOURCE_DIRS}
    seen = {name: set() for name in MODELULATOR_RESOURCE_DIRS}

    def add(path: Path):
        canonical = _RESOURCE_NAME_MAP.get(path.name.casefold())
        if canonical is None:
            return
        try:
            key = os.path.normcase(os.path.abspath(os.path.normpath(str(path))))
        except OSError:
            key = str(path)
        if key not in seen[canonical]:
            seen[canonical].add(key)
            result[canonical].append(path)

    for raw_root in roots:
        if raw_root is None:
            continue
        root = Path(raw_root)
        if not root.is_dir():
            continue
        add(root)
        for current, dirs, _files in os.walk(root):
            current_path = Path(current)
            add(current_path)
            # Resource folders contain files, not more bundle roots.  Pruning
            # them keeps searches fast on large extracted games.
            if current_path.name.casefold() in _RESOURCE_NAME_MAP:
                dirs[:] = []
                continue
            dirs.sort(key=str.casefold)

    for values in result.values():
        values.sort(key=lambda p: os.path.normcase(str(p)))
    return result


def resolve_bundle_root(path: Path):
    """Resolve a selected path to one bundle directory containing Solids/."""
    path = Path(path)
    if path.name.casefold() in _RESOURCE_NAME_MAP:
        path = path.parent
    if (path / 'Solids').is_dir():
        return path
    discovered = discover_resource_directories([path])
    candidates = []
    seen = set()
    for solids in discovered['Solids']:
        candidate = solids.parent
        key = os.path.normcase(os.path.abspath(os.path.normpath(str(candidate))))
        if key not in seen:
            seen.add(key)
            candidates.append(candidate)
    if not candidates:
        raise ValueError('No Modelulator bundle containing Solids/ was found under: ' + str(path))
    if len(candidates) > 1:
        preview = '; '.join(str(value) for value in candidates[:5])
        if len(candidates) > 5:
            preview += '; ...'
        raise ValueError('More than one bundle containing Solids/ was found. Select the bundle itself: ' + preview)
    return candidates[0]
