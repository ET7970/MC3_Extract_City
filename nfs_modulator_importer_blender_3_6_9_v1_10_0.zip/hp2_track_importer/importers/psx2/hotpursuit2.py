from __future__ import annotations

import re
import urllib.parse
import xml.etree.ElementTree as ET
from pathlib import Path

from ..common import append_import_scene, deduplicate_placements, local_name, native_relative_path, xml_metadata


PLATFORM = 'PSX2'
GAME = 'HOTPURSUIT2'
LABEL = 'PSX2 / Hot Pursuit 2'
SOLID_FILE_RE = re.compile(r"^0x([0-9A-Fa-f]{8})\.DEFAULT\.(.+)\.dae$", re.I)


def discover_related_roots(bundle_root: Path):
    """Return HP2 resource roots related to the selected Modelulator bundle.

    PS2 Hot Pursuit 2 splits track geometry and textures between TRACKBxx.LZC,
    TEXxxLOCATION.BIN, TEXxxTRACK.BIN and shared FRONTEND/GLOBAL packages.
    A user selecting TRACKBxx.LZC should not need to know or enter those
    dependencies manually.
    """
    bundle_root = Path(bundle_root).resolve()
    category = bundle_root.parent.name.upper()
    export_root = bundle_root.parent.parent if category in {'TRACKS', 'FRONTEND', 'GLOBAL'} else None
    roots = []

    def add(path):
        path = Path(path)
        if path.is_dir() and path.resolve() != bundle_root and path not in roots:
            roots.append(path)

    # Track bundles use split texture packs named after the track number.
    if category == 'TRACKS':
        match = re.match(r'^TRACKB(\d+)\.(?:LZC|BUN)$', bundle_root.name, re.I)
        if match:
            track_id = match.group(1)
            add(bundle_root.parent / ('TEX%sLOCATION.BIN' % track_id))
            add(bundle_root.parent / ('TEX%sTRACK.BIN' % track_id))

    # Shared HP2 references/textures are nested below these broad folders.
    if export_root is not None:
        add(export_root / 'GLOBAL')
        add(export_root / 'FRONTEND')

    return roots


def order_texture_dirs(bundle_root: Path, texture_dirs):
    """Order HP2 texture packs from most specific to most general.

    This prevents a texture from another track pack winning merely because its
    filesystem path sorts first when a broad user root is supplied.
    """
    bundle_root = Path(bundle_root).resolve()
    category = bundle_root.parent.name.upper()
    track_id = None
    match = re.match(r'^TRACKB(\d+)\.(?:LZC|BUN)$', bundle_root.name, re.I)
    if match:
        track_id = match.group(1)

    def rank(path):
        path = Path(path)
        parent_name = path.parent.name.upper()
        grandparent_name = path.parent.parent.name.upper() if len(path.parents) > 1 else ''
        try:
            is_primary = path.resolve() == (bundle_root / 'Textures').resolve()
        except OSError:
            is_primary = False
        if is_primary:
            return (0, str(path).casefold())
        if track_id and parent_name == ('TEX%sLOCATION.BIN' % track_id):
            return (1, str(path).casefold())
        if track_id and parent_name == ('TEX%sTRACK.BIN' % track_id):
            return (2, str(path).casefold())
        if grandparent_name == 'GLOBAL':
            return (3, str(path).casefold())
        if grandparent_name == 'FRONTEND':
            return (4, str(path).casefold())
        if grandparent_name == category:
            return (5, str(path).casefold())
        return (6, str(path).casefold())

    return sorted((Path(path) for path in texture_dirs), key=rank)


def _solid_search_index(solids_dir: Path, solid_search_dirs=None):
    result = {}
    directories = [solids_dir / 'Solids'] + list(solid_search_dirs or [])
    seen_dirs = set()
    for directory in directories:
        directory = Path(directory)
        try:
            key_dir = str(directory.resolve()).casefold()
        except OSError:
            key_dir = str(directory).casefold()
        if key_dir in seen_dirs or not directory.is_dir():
            continue
        seen_dirs.add(key_dir)
        for solid in sorted(directory.glob('*.dae')):
            result.setdefault(solid.name.casefold(), solid)
    return result


def parse_sections(solids_dir: Path, solid_search_dirs=None):
    search_index = _solid_search_index(solids_dir, solid_search_dirs)
    sections_dir = solids_dir / 'ScenerySections'
    instances = []
    missing = {}
    malformed = 0
    if not sections_dir.is_dir():
        return instances, {
            'section_files': 0,
            'missing_source_instances': 0,
            'missing_source_references': [],
            'malformed_section_instances': 0,
            'parser': 'xml',
        }
    section_files = 0
    for section_file in sorted(sections_dir.glob('*.dae')):
        section_files += 1
        try:
            root = ET.parse(section_file).getroot()
        except (OSError, ET.ParseError):
            malformed += 1
            continue
        for node in (element for element in root.iter() if local_name(element) == 'node'):
            reference = next((child for child in node if local_name(child) == 'instance_node'), None)
            matrix = next((child for child in node if local_name(child) == 'matrix'), None)
            if reference is None or matrix is None:
                malformed += 1
                continue
            url = urllib.parse.unquote(reference.get('url', ''))
            solid_path = url.split('#', 1)[0].replace('\\', '/')
            if not solid_path:
                malformed += 1
                continue
            resolved = (section_file.parent / solid_path).resolve()
            try:
                relative_solid = resolved.relative_to(solids_dir.resolve()).as_posix()
            except ValueError:
                malformed += 1
                continue
            try:
                values = [float(value) for value in (matrix.text or '').split()]
            except ValueError:
                malformed += 1
                continue
            if len(values) != 16:
                malformed += 1
                continue
            source = resolved if resolved.is_file() else search_index.get(Path(solid_path).name.casefold())
            if source is None:
                filename = Path(solid_path).name
                match = SOLID_FILE_RE.match(filename)
                solid_hash = match.group(1).upper() if match else ''
                solid_name = match.group(2) if match else filename
                key = (solid_hash, solid_name.casefold(), filename.casefold())
                info = missing.setdefault(key, {
                    'solid_hash': solid_hash,
                    'solid_group': 'DEFAULT',
                    'solid_name': solid_name,
                    'count': 0,
                    'sections': set(),
                    'first_node': node.get('id') or section_file.stem,
                    'expected_relative_path': relative_solid,
                })
                info['count'] += 1
                info['sections'].add(section_file.stem)
                continue
            source = source.resolve()
            instances.append({
                'solid': str(source),
                'solid_source': str(source),
                'relative_solid': 'Solids/' + source.name,
                'matrix': values,
                'section': section_file.stem,
                'name': node.get('id') or section_file.stem,
            })
    missing_references = []
    for key in sorted(missing):
        info = dict(missing[key])
        info['sections'] = sorted(info['sections'])
        missing_references.append(info)
    return deduplicate_placements(instances), {
        'section_files': section_files,
        'missing_source_instances': sum(item['count'] for item in missing_references),
        'missing_source_references': missing_references,
        'missing_source_unique_solids': len(missing_references),
        'malformed_section_instances': malformed,
        'parser': 'xml',
    }


def parse_solids_only(solids_dir: Path):
    result = []
    for solid in sorted((solids_dir / 'Solids').glob('*.dae')):
        if solid.name.lower().startswith('esolidpalette.'):
            continue
        result.append({
            'solid': str(solid.resolve()),
            'solid_source': str(solid.resolve()),
            'relative_solid': solid.relative_to(solids_dir).as_posix(),
            'matrix': [1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0],
            'section': 'Solids',
            'name': solid.stem,
        })
    return result, {'section_files': 0, 'missing_source_instances': 0, 'parser': 'solids-only'}


def _source_and_label(source_or_root: Path, relative_solid=None):
    source_or_root = Path(source_or_root)
    if relative_solid is not None and source_or_root.is_dir():
        source = native_relative_path(source_or_root, relative_solid)
        label = relative_solid
    else:
        source = source_or_root
        label = relative_solid or ('Solids/' + source.name)
    return source, label


def parse_solid_metadata(source_or_root: Path, relative_solid=None):
    source, label = _source_and_label(source_or_root, relative_solid)
    match = SOLID_FILE_RE.match(source.name)
    if not match:
        raise ValueError('Unexpected HP2 solid filename: ' + source.name)
    solid_hash, friendly_name = match.groups()
    root = ET.parse(source).getroot()
    return xml_metadata(root, label, source, solid_hash, friendly_name, 'DEFAULT')


def prepare_import_file(source_or_root: Path, relative_solid, destination: Path):
    source, _label = _source_and_label(source_or_root, relative_solid)
    raw = source.read_bytes()
    destination.write_bytes(append_import_scene(raw, source))
