from __future__ import annotations

import re
import xml.etree.ElementTree as ET
from pathlib import Path

from ..common import append_import_scene, deduplicate_placements, native_relative_path, xml_metadata


PLATFORM = 'PSX2'
GAME = 'UNDERGROUND2'
LABEL = 'PSX2 / Underground 2'
SOLID_FILE_RE = re.compile(r"^0x([0-9A-Fa-f]{8})\.([^.]+)\..+\.dae$", re.I)
NODE_BLOCK_RE = re.compile(br'<node\b[^>]*\bid="([^"]*)"[^>]*>(.*?)</node>', re.S | re.I)
URL_RE = re.compile(br'<instance_node\b[^>]*\burl="([^"]*)"', re.I)
MATRIX_RE = re.compile(br'<matrix\b[^>]*>([^<]+)</matrix>', re.S | re.I)
FRAGMENT_KEY_RE = re.compile(br'#([A-Za-z0-9]+)_0x([0-9A-Fa-f]{8})', re.I)
FILE_KEY_RE = re.compile(br'0x([0-9A-Fa-f]{8})%2E([A-Za-z0-9]+)%2E', re.I)
# Actual Modelulator output has no space before the closing quote. Keep a second,
# simpler expression because the malformed trailing bytes can be arbitrary.
GEOMETRY_TAG_RE = re.compile(br'<geometry\b[^>]*>', re.I)


# UG2 PS2 stores the visible solid name in a 28-byte field. Null-terminated
# names normally occupy at most 27 bytes, while an exact 28-byte name can use
# the full field. Modelulator 5.1.5 drops NUL padding but accidentally keeps
# non-zero bytes from following fields. Hash matching recovers ordinary and
# exact-28 names; the 27-byte boundary is only a fallback for repeated solids
# whose key is not derived from their readable name.
UG2_NULL_TERMINATED_NAME_MAX = 27


def _nfs_bin_hash(raw_name: bytes):
    value = 0xFFFFFFFF
    for byte in raw_name:
        if 0x61 <= byte <= 0x7A:
            byte -= 0x20
        value = (value * 33 + byte) & 0xFFFFFFFF
    return value


def _extract_geometry_parts(raw: bytes, source: Path):
    tag_match = GEOMETRY_TAG_RE.search(raw)
    if tag_match is None:
        raise ValueError('No geometry tag found in ' + str(source))
    tag = tag_match.group(0)
    marker = b'name="xSolid_0x'
    start = tag.find(marker)
    if start < 0:
        raise ValueError('No xSolid geometry name found in ' + str(source))
    value = tag[start + len(marker):]
    match = re.match(br'([0-9A-Fa-f]{8})\.([^.]+)\.(.*)"', value, re.S)
    if match is None:
        raise ValueError('Unexpected xSolid geometry name in ' + str(source))
    return tag_match.span(), match.group(1).decode('ascii').upper(), match.group(2).decode('ascii', 'replace'), match.group(3)


def _repair_name(raw_tail: bytes, solid_hash: str):
    target = int(solid_hash, 16)
    printable = 0
    for byte in raw_tail:
        if 0x20 <= byte <= 0x7E:
            printable += 1
        else:
            break
    # Most UG2 keys are the NFS hash of the readable name. Checking every ASCII
    # prefix recovers even short names where the leaked float starts with ASCII.
    for length in range(1, printable + 1):
        candidate = raw_tail[:length]
        if _nfs_bin_hash(candidate) == target:
            return candidate.decode('ascii'), 'nfs-hash'
    # Some repeated world solids intentionally share a 27-byte readable name
    # while carrying different solid keys. In those cases the struct boundary
    # is authoritative.
    if len(raw_tail) >= UG2_NULL_TERMINATED_NAME_MAX and all(0x20 <= b <= 0x7E for b in raw_tail[:UG2_NULL_TERMINATED_NAME_MAX]):
        return raw_tail[:UG2_NULL_TERMINATED_NAME_MAX].decode('ascii'), 'fixed-27'
    fallback = raw_tail[:printable].decode('ascii', 'replace').rstrip()
    return fallback or ('SOLID_' + solid_hash), 'ascii-fallback'


def _solid_identity(source: Path):
    raw = source.read_bytes()
    _span, solid_hash, solid_group, raw_tail = _extract_geometry_parts(raw, source)
    friendly_name, method = _repair_name(raw_tail, solid_hash)
    return raw, solid_hash, solid_group, friendly_name, method


def _sanitize_solid_xml(source: Path):
    raw, solid_hash, solid_group, friendly_name, method = _solid_identity(source)
    span, check_hash, check_group, _raw_tail = _extract_geometry_parts(raw, source)
    if check_hash != solid_hash or check_group != solid_group:
        raise ValueError('Inconsistent UG2 geometry identity in ' + str(source))
    old_tag = raw[span[0]:span[1]]
    value_re = re.compile(br'(\bname=")xSolid_0x[0-9A-Fa-f]{8}\.[^."\r\n>]+\.[^"\r\n>]*(")', re.S)
    replacement = (r'\1xSolid_0x%s.%s.%s\2' % (solid_hash, solid_group, friendly_name)).encode('ascii')
    new_tag, count = value_re.subn(replacement, old_tag, count=1)
    if count != 1:
        raise ValueError('Could not repair malformed UG2 geometry name in ' + str(source))
    sanitized = raw[:span[0]] + new_tag + raw[span[1]:]
    return sanitized, solid_hash, solid_group, friendly_name, method


def _solid_index(solids_dir: Path, solid_search_dirs=None):
    result = {}
    duplicates = []
    directories = [solids_dir / 'Solids'] + list(solid_search_dirs or [])
    seen_dirs = set()
    for directory in directories:
        directory = Path(directory)
        try:
            dir_key = str(directory.resolve()).casefold()
        except OSError:
            dir_key = str(directory).casefold()
        if dir_key in seen_dirs or not directory.is_dir():
            continue
        seen_dirs.add(dir_key)
        for solid in sorted(directory.glob('*.dae')):
            if solid.name.lower().startswith('esolidpalette.'):
                continue
            match = SOLID_FILE_RE.match(solid.name)
            if not match:
                continue
            key = (match.group(1).upper(), match.group(2).upper())
            if key in result:
                duplicates.append(key)
                continue
            result[key] = solid.resolve()
    return result, duplicates


def _key_from_url(url: bytes):
    match = FRAGMENT_KEY_RE.search(url)
    if match:
        return match.group(2).decode('ascii').upper(), match.group(1).decode('ascii').upper()
    match = FILE_KEY_RE.search(url)
    if match:
        return match.group(1).decode('ascii').upper(), match.group(2).decode('ascii').upper()
    return None




def _percent_decode_bytes(value: bytes):
    def replace(match):
        return bytes((int(match.group(1), 16),))
    return re.sub(br'%([0-9A-Fa-f]{2})', replace, value)


def _name_from_reference_url(url: bytes, key):
    decoded = _percent_decode_bytes(url.split(b'#', 1)[0]).replace(b'\\', b'/')
    filename = decoded.rsplit(b'/', 1)[-1]
    if filename.lower().endswith(b'.dae'):
        filename = filename[:-4]
    prefix = (b'0x' + key[0].encode('ascii') + b'.' + key[1].encode('ascii') + b'.')
    if filename.lower().startswith(prefix.lower()):
        raw_tail = filename[len(prefix):]
        name, method = _repair_name(raw_tail, key[0])
        return name, method
    return filename.decode('ascii', 'replace'), 'reference-fallback'

def parse_sections(solids_dir: Path, solid_search_dirs=None):
    sections_dir = solids_dir / 'ScenerySections'
    index, duplicate_keys = _solid_index(solids_dir, solid_search_dirs)
    instances = []
    missing = {}
    malformed = 0
    section_files = 0
    if not sections_dir.is_dir():
        return instances, {
            'section_files': 0,
            'missing_source_instances': 0,
            'missing_source_references': [],
            'malformed_section_instances': 0,
            'duplicate_solid_keys': len(duplicate_keys),
            'parser': 'ug2-tolerant-bytes',
        }
    for section_file in sorted(sections_dir.glob('*.dae')):
        section_files += 1
        raw = section_file.read_bytes()
        for node_id, body in NODE_BLOCK_RE.findall(raw):
            url_match = URL_RE.search(body)
            matrix_match = MATRIX_RE.search(body)
            if url_match is None or matrix_match is None:
                malformed += 1
                continue
            url = url_match.group(1)
            key = _key_from_url(url)
            if key is None:
                malformed += 1
                continue
            source = index.get(key)
            if source is None:
                friendly_name, repair_method = _name_from_reference_url(url, key)
                info = missing.setdefault(key, {
                    'solid_hash': key[0],
                    'solid_group': key[1],
                    'solid_name': friendly_name,
                    'name_repair_method': repair_method,
                    'count': 0,
                    'sections': set(),
                    'first_node': node_id.decode('ascii', 'replace'),
                })
                info['count'] += 1
                info['sections'].add(section_file.stem)
                continue
            try:
                values = [float(value) for value in matrix_match.group(1).split()]
            except ValueError:
                malformed += 1
                continue
            if len(values) != 16:
                malformed += 1
                continue
            instances.append({
                'solid': str(source),
                'solid_source': str(source),
                'relative_solid': 'Solids/' + source.name,
                'matrix': values,
                'section': section_file.stem,
                'name': node_id.decode('ascii', 'replace') or section_file.stem,
                'solid_group': key[1],
            })
    missing_references = []
    for key in sorted(missing):
        info = dict(missing[key])
        info['sections'] = sorted(info['sections'])
        missing_references.append(info)
    return deduplicate_placements(instances), {
        'section_files': section_files,
        'missing_source_instances': sum(item['count'] for item in missing_references),
        'missing_source_references': missing_references,
        'missing_source_unique_solids': len(missing_references),
        'malformed_section_instances': malformed,
        'duplicate_solid_keys': len(duplicate_keys),
        'parser': 'ug2-tolerant-bytes',
    }


def parse_solids_only(solids_dir: Path):
    result = []
    for solid in sorted((solids_dir / 'Solids').glob('*.dae')):
        if solid.name.lower().startswith('esolidpalette.'):
            continue
        match = SOLID_FILE_RE.match(solid.name)
        if not match:
            continue
        solid = solid.resolve()
        result.append({
            'solid': str(solid),
            'solid_source': str(solid),
            'relative_solid': 'Solids/' + solid.name,
            'matrix': [1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0],
            'section': 'Solids',
            'name': solid.stem,
            'solid_group': match.group(2).upper(),
        })
    return result, {
        'section_files': 0,
        'missing_source_instances': 0,
        'malformed_section_instances': 0,
        'duplicate_solid_keys': 0,
        'parser': 'solids-only',
    }


def _source_and_label(source_or_root: Path, relative_solid=None):
    source_or_root = Path(source_or_root)
    if relative_solid is not None and source_or_root.is_dir():
        source = native_relative_path(source_or_root, relative_solid)
        label = relative_solid
    else:
        source = source_or_root
        label = relative_solid or ('Solids/' + source.name)
    return source, label


def parse_solid_metadata(source_or_root: Path, relative_solid=None):
    source, label = _source_and_label(source_or_root, relative_solid)
    sanitized, solid_hash, solid_group, friendly_name, repair_method = _sanitize_solid_xml(source)
    try:
        root = ET.fromstring(sanitized)
    except ET.ParseError as exc:
        raise ValueError('UG2 solid is still invalid after name repair: %s: %s' % (source, exc))
    metadata = xml_metadata(root, label, source, solid_hash, friendly_name, solid_group)
    metadata['name_repair_method'] = repair_method
    metadata['modelulator_export_name'] = source.stem
    return metadata


def prepare_import_file(source_or_root: Path, relative_solid, destination: Path):
    source, _label = _source_and_label(source_or_root, relative_solid)
    sanitized, _solid_hash, _solid_group, _friendly_name, _repair_method = _sanitize_solid_xml(source)
    destination.write_bytes(append_import_scene(sanitized, source))
