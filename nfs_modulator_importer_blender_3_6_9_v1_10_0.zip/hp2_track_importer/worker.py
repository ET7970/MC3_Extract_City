"""External, Blender-independent scanner for NFS Modulator exports.

The Blender add-on delegates game/platform-specific parsing to importer profiles.
Currently implemented profiles:
  * PSX2 / HOTPURSUIT2
  * PSX2 / UNDERGROUND2
"""

from __future__ import annotations

import argparse
from collections import Counter
from concurrent.futures import ProcessPoolExecutor
import json
import os
import sys
from pathlib import Path

from importers import get_profile
from importers.common import collect_textures, discover_resource_directories, resolve_bundle_root


def parse_solid_metadata(task):
    solid_key, source_file, relative_solid, platform, game = task
    profile = get_profile(platform, game)
    metadata = profile.parse_solid_metadata(Path(source_file), relative_solid)
    return solid_key, metadata


def collect_solid_metadata(instances, workers, platform, game):
    unique = {}
    for item in instances:
        unique.setdefault(item['solid'], item)
    if not unique:
        return {}
    tasks = [
        (solid_key, item.get('solid_source', solid_key), item.get('relative_solid'), platform, game)
        for solid_key, item in sorted(unique.items())
    ]
    count = max(1, min(workers, os.cpu_count() or 1, len(tasks)))
    if count == 1:
        pairs = map(parse_solid_metadata, tasks)
        return dict(pairs)
    with ProcessPoolExecutor(max_workers=count) as pool:
        pairs = pool.map(parse_solid_metadata, tasks, chunksize=16)
        return dict(pairs)


def collect_material_metadata(solid_metadata):
    result = {}
    for metadata in solid_metadata.values():
        for texture_hash in metadata['material_hashes']:
            info = result.setdefault(texture_hash, {
                'texture_hash': texture_hash,
                'solid_hashes': [],
                'source_material_names': [],
            })
            if metadata['solid_hash'] not in info['solid_hashes']:
                info['solid_hashes'].append(metadata['solid_hash'])
            for name in metadata['material_source_names']:
                if texture_hash in name.upper() and name not in info['source_material_names']:
                    info['source_material_names'].append(name)
    return result


def prepare_import_files(instances, prepared_dir: Path, profile):
    prepared_dir.mkdir(parents=True, exist_ok=True)
    unique = {}
    for item in instances:
        unique.setdefault(item['solid'], item)
    result = {}
    for index, (solid_key, item) in enumerate(sorted(unique.items()), 1):
        source = Path(item.get('solid_source', solid_key))
        relative_solid = item.get('relative_solid') or ('Solids/' + source.name)
        destination = prepared_dir / ('%05d.dae' % index)
        profile.prepare_import_file(source, relative_solid, destination)
        result[solid_key] = str(destination)
    return result


def build_manifest(solids_dir: Path, resource_roots, platform='PSX2', game='HOTPURSUIT2',
                   solids_only=False, prepared_dir=None, workers=8, limit_instances=0):
    if not solids_dir.is_dir():
        raise ValueError('Source directory does not exist: ' + str(solids_dir))
    solids_dir = resolve_bundle_root(solids_dir)
    profile = get_profile(platform, game)
    user_resource_roots = [Path(value) for value in resource_roots if Path(value).is_dir()]
    auto_resource_roots = []
    discover_related = getattr(profile, 'discover_related_roots', None)
    if discover_related is not None:
        auto_resource_roots = [Path(value) for value in discover_related(solids_dir) if Path(value).is_dir()]
    roots = [solids_dir] + auto_resource_roots + user_resource_roots
    discovered = discover_resource_directories(roots)
    texture_dirs = discovered['Textures']
    order_texture_dirs = getattr(profile, 'order_texture_dirs', None)
    if order_texture_dirs is not None:
        texture_dirs = order_texture_dirs(solids_dir, texture_dirs)
        discovered['Textures'] = texture_dirs
    primary_solids = (solids_dir / 'Solids').resolve()
    solid_search_dirs = [path for path in discovered['Solids'] if path.resolve() != primary_solids]
    instances, diagnostics = profile.parse_solids_only(solids_dir) if solids_only else profile.parse_sections(solids_dir, solid_search_dirs)
    total_instances_before_limit = len(instances)
    if limit_instances:
        instances = instances[:max(0, int(limit_instances))]
    solid_metadata = collect_solid_metadata(instances, workers, platform, game)
    required_hashes = {value for metadata in solid_metadata.values() for value in metadata['material_hashes']}
    textures = collect_textures(texture_dirs, required_hashes) if texture_dirs else {}
    missing_texture_hashes = sorted(required_hashes.difference(textures))
    name_repair_methods = Counter(
        metadata.get('name_repair_method', 'not-needed') for metadata in solid_metadata.values()
    )
    diagnostics = dict(diagnostics or {})
    primary_solids_resolved = primary_solids.resolve()
    additional_source_instances = sum(
        1 for item in instances
        if Path(item.get('solid_source', item['solid'])).parent.resolve() != primary_solids_resolved
    )
    additional_source_solids = len({
        item['solid'] for item in instances
        if Path(item.get('solid_source', item['solid'])).parent.resolve() != primary_solids_resolved
    })
    diagnostics.update({
        'instances_before_limit': total_instances_before_limit,
        'instances_after_limit': len(instances),
        'unique_solids': len(solid_metadata),
        'required_texture_hashes': len(required_hashes),
        'resolved_texture_hashes': len(textures),
        'missing_texture_hashes': len(missing_texture_hashes),
        'name_repair_methods': dict(name_repair_methods),
        'resolved_from_additional_solid_instances': additional_source_instances,
        'resolved_from_additional_solids': additional_source_solids,
        'automatic_resource_roots': [str(path) for path in auto_resource_roots],
        'user_resource_roots': [str(path) for path in user_resource_roots],
        'texture_source_counts': dict(Counter(
            info.get('texture_pack_dir', '') for info in textures.values()
        )),
        'resource_directories': {name: [str(path) for path in paths] for name, paths in discovered.items()},
        'resource_directory_counts': {name: len(paths) for name, paths in discovered.items()},
    })
    return {
        'format': 'nfs-modulator-manifest-v2',
        'platform': profile.PLATFORM,
        'game': profile.GAME,
        'profile_label': profile.LABEL,
        'solids_dir': str(solids_dir),
        'worker_processes': max(1, min(workers, os.cpu_count() or 1)),
        'textures': textures,
        'missing_texture_hashes': missing_texture_hashes,
        'solids': solid_metadata,
        'materials': collect_material_metadata(solid_metadata),
        'instances': instances,
        'import_files': prepare_import_files(instances, prepared_dir, profile) if prepared_dir else {},
        'diagnostics': diagnostics,
    }


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--platform', default='PSX2')
    parser.add_argument('--game', default='HOTPURSUIT2')
    parser.add_argument('--solids', required=True, type=Path, help='Modelulator bundle directory containing Solids/')
    parser.add_argument('--resource-root', action='append', type=Path, default=[], help='Modelulator export/search root; may be repeated and is scanned recursively')
    parser.add_argument('--textures', action='append', type=Path, default=[], help='Legacy alias for an additional resource root')
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--prepared-dir', type=Path, help='Temporary directory for Blender-ready DAE copies')
    parser.add_argument('--workers', type=int, default=8, help='External XML parsing processes (default: 8)')
    parser.add_argument('--solids-only', action='store_true')
    parser.add_argument('--limit-instances', type=int, default=0, help='Debug limit applied before metadata/prepared DAE work')
    args = parser.parse_args(argv)
    resource_roots = list(args.resource_root) + list(args.textures)
    for directory in resource_roots:
        if not directory.is_dir():
            parser.error('Resource root does not exist: ' + str(directory))
    manifest = build_manifest(
        args.solids,
        resource_roots,
        args.platform,
        args.game,
        args.solids_only,
        args.prepared_dir,
        max(1, args.workers),
        max(0, args.limit_instances),
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(manifest, ensure_ascii=False, separators=(',', ':')), encoding='utf-8')
    diagnostics = manifest['diagnostics']
    print(
        'profile=%s/%s instances=%d solids=%d textures=%d missing_sources=%d missing_textures=%d workers=%d' % (
            manifest['platform'], manifest['game'], len(manifest['instances']), len(manifest['solids']),
            len(manifest['textures']), diagnostics.get('missing_source_instances', 0),
            diagnostics.get('missing_texture_hashes', 0), manifest['worker_processes'],
        )
    )


if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        print('worker error: ' + str(exc), file=sys.stderr)
        raise
